const path = require('path');
const ENV = require('../environment-variables');
const chromeDrivers = require('vg-chrome-drivers');
const PROTRACTOR_CHROME_DRIVER = chromeDrivers(ENV.PLATFORM);

const browsers = {
  chromeHeadlessNoSandbox: {
    base: 'ChromeHeadless',
    flags: [
      '--no-sandbox',
      '--disable-extensions',
      '--disable-plugins',
      `--proxy-bypass-list=${ENV.HOSTNAME}`,
      '--proxy-server=\'http://http-proxy.vanguard.com:80\''
    ]
  }
};

module.exports = function (config) {
  config.set({
    hostname: ENV.HOSTNAME,
    basePath: '',
    frameworks: ['jasmine', '@angular-devkit/build-angular'],
    plugins: [
      require('karma-jasmine'),
      require('karma-jasmine-html-reporter'),
      require('karma-coverage-istanbul-reporter'),
      require('@angular-devkit/build-angular/plugins/karma'),
      require('karma-junit-reporter'),
      require('karma-htmlfile-reporter'),
      require('karma-chrome-launcher')
    ],
    client: {
      clearContext: false, // leave Jasmine Spec Runner output visible in browser
      jasmine: {
        timeoutInterval: 10000 // default value in jasmine
      }
    },
    coverageIstanbulReporter: {
      dir: ENV.TEST_UNIT_COVERAGE_REPORT_DIRECTORY,
      reporters: ['html', 'lcov', 'text', 'text-summary'],
      fixWebpackSourcePaths: true,
      thresholds: {
        global: {
          statements: 90,
          lines: 90,
          branches: 90,
          functions: 90
        },
        each: {
          statements: 80,
          lines: 80,
          branches: 50,
          functions: 80
        }
      }
    },
    reporters: ['progress', 'html', 'kjhtml', 'junit'],
    htmlReporter: {
      outputFile: ENV.REQUIREMENTS_EVIDENCE_FILE,
      pageTitle: 'Requirements Evidence'
    },
    colors: true,
    logLevel: config.LOG_INFO,
    concurrency: Infinity,
    captureTimeout: 15000,
    browserDisconnectTolerance: 3,
    browserDisconnectTimeout: 30000,
    browserNoActivityTimeout: 30000,
    processKillTimeout: 15000,
    chromeDriver: PROTRACTOR_CHROME_DRIVER,
    customLaunchers: browsers,
    browsers: Object.keys(browsers),
    junitReporter: {
      outputDir: ENV.TEST_UNIT_REPORT_DIRECTORY
    },
    autoWatch: true,
    retryLimit: 3
  });
};
