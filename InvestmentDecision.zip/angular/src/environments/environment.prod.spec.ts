import { environment } from './environment.prod';

describe('environment prod', () => {
    it('should test if the production value is true', () => {
        const environmentProd = environment;

        expect(environmentProd.production).toBe(true);
    });
});
