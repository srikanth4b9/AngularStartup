/**
 * Environment Variables for Build
 * Don't add API endpoints here, add them to ./endpoints.ts
 */
import { common } from './environment.common';
import { buildEnvMap } from '../../server/endpoints';

export const environment: { [key: string]: any } = {
  ...common,
  ...buildEnvMap,
  production: true,
  test: false
};
