/**
 * Common Environment Variables for all build states
 * Don't add API endpoints here, addd them to ./endpoints.ts
 */

 import { version as packageVersion } from 'package.json';

export const common = {
  VERSION: packageVersion,
  INVESTABLE_CASH_REPORT: '/reports/investable-cash',
  T1_TRADE_REPORT: '/reports/trade-calculations',
  TRADE_CALC_ERRORS: '/reports/trade-calculation-errors',
  MANUAL_CASH: '/investable-cash-adjustments',
  FUND_LIST: '/fund-list',
  FUND_PROFILES: '/fund-profiles',
  FUND_HOLDINGS: '/fund-holdings',
  SECURITIES: '/securities',
  DIRECTIVES: '/directives',
  INVESTMENT_DECISION_RUNS: '/runs',
  TRADES: '/trades'
};
