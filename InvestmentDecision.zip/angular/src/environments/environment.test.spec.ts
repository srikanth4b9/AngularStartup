import { environment } from './environment.test';

describe('environment test', () => {
    it('should test if the test value is true', () => {
        const environmentTest = environment;

        expect(environmentTest.test).toBe(true);
    });
});
