import { ConfirmDialogModel } from './confirm-dialog.model';

describe('ConfirmDialogModel', () => {
  describe('constructor', () => {
    it('should set default parameters', () => {
      const model = new ConfirmDialogModel();

      expect(model.title).toEqual('Are You Sure?');
      expect(model.message).toEqual(null);
      expect(model.confirmButtonText).toEqual('OK');
    });
    it('should set default parameters as null', () => {
      const model = new ConfirmDialogModel(null, null, null, null);

      expect(model.title).toEqual(null);
      expect(model.message).toEqual(null);
      expect(model.confirmButtonText).toEqual(null);
    });
  });
});
