
export enum ColumnType {
  BOOLEAN,
  STRING,
  ENUM,
  NUMBER,
  CURRENCY,
  PERCENT,
  DATE,
  TIMESTAMP,
  STATUS,
  EDIT,
  CUSIP,
  ACCOUNT_NUMBER,
  ACCOUNTING_SECURITY_ID
}

export class ColumnDef {
  header: string;
  attribute: string;
  type: ColumnType;
  minWidth: any;
  headerClass: string;
  align?: string;
  enumType?: any;
  violation?: Violation;
  formatter?: string;
  editable?: boolean;

  constructor(builder: ColumnDefBuilder) {
    this.header = builder._header;
    this.attribute = builder._attribute;
    this.type = builder._type;
    this.minWidth = builder._minWidth;
    this.headerClass = builder._headerClass;
    this.align = builder._align;
    this.enumType = builder._enumType;
    this.violation = builder._violation;
    this.formatter = builder._formatter;
    this.editable = builder._editable;
  }
}

export class Violation {
  flag: string;
  title: string;
}

export class ColumnDefBuilder {
  _header: string;
  _attribute: string;
  _type: ColumnType;
  _minWidth: number;
  _headerClass: string = 'header-cell-text';
  _align: string = 'left';
  _enumType: any = null;
  _violation: Violation;
  _formatter: string;
  _editable?: boolean = false;

  constructor(header: string, attribute: string, type: ColumnType, minWidth: number = 100) {
    this._header = header;
    this._attribute = attribute;
    this._type = type;
    this._minWidth = minWidth;

    if ([
      ColumnType.CURRENCY, ColumnType.PERCENT, ColumnType.BOOLEAN
    ].indexOf(type) !== -1) {
      this._headerClass = 'header-cell-number';
      this._align = 'right';
    }
    if (type === ColumnType.PERCENT) {
      this._formatter = '1.0-3';
    }
    if (type === ColumnType.DATE) {
      this._formatter = 'MM/dd/yyyy';
    }
  }

  format(formatString: string): ColumnDefBuilder {
    this._formatter = formatString;
    return this;
  }

  enumType(enumType): ColumnDefBuilder {
    this._enumType = enumType;
    return this;
  }

  align(align: string): ColumnDefBuilder {
    this._align = align;
    this._headerClass = align === 'left' ? 'header-cell-text' : 'header-cell-number';
    return this;
  }

  editable(): ColumnDefBuilder {
    this._editable = true;
    return this;
  }

  violationFlag(flag, title): ColumnDefBuilder {
    this._violation = { title: title, flag: flag };
    return this;
  }

  build(): ColumnDef {
    return new ColumnDef(this);
  }
}
