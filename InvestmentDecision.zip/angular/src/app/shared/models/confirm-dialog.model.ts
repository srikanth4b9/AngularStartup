import { IconDefinition } from '@fortawesome/free-solid-svg-icons';

export class ConfirmDialogModel {
  title: string;
  message?: string;
  confirmButtonText?: string;
  confirmButtonIcon?: IconDefinition;

  constructor(title = 'Are You Sure?', message = null, confirmButtonText = 'OK', confirmButtonIcon = null) {
    this.title = title;
    this.message = message;
    this.confirmButtonText = confirmButtonText;
    this.confirmButtonIcon = confirmButtonIcon;
  }
}
