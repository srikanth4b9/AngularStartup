export interface Message {
  text?: string;
  type?: string;
  title?: string;
}
