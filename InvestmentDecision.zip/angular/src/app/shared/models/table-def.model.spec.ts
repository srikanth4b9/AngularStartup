import { TableDef } from './table-def.model';

describe('TableDef', () => {
  let tableDef: TableDef;

  describe('constructor', () => {
    it('should set hasActions to false by default', () => {
      tableDef = new TableDef([]);
      expect(tableDef.hasActions).toEqual(false);
    });
  });

  describe('showMultiSelect', () => {
    it('should return false if multiSelect is false', () => {
      tableDef = new TableDef([], true, false);

      expect(tableDef.showMultiSelect).toEqual(false);
    });

    it('should return false if hasActions is false', () => {
      tableDef = new TableDef([], false, true);

      expect(tableDef.showMultiSelect).toEqual(false);
    });

    it('should return true if table has actions and multiSelect is enabled', () => {
      tableDef = new TableDef([], true, true);

      expect(tableDef.showMultiSelect).toEqual(true);
    });
  });
});
