import { of } from 'rxjs';

export class MockDialog {
  open = jasmine.createSpy().and.returnValue({
    afterClosed: () => of({})
  });

  mockConfirm() {
    this.open.and.returnValue({
      afterClosed: () => of('confirm')
    });
  }

  mockReturnData(data: any) {
    this.open.and.returnValue({
      afterClosed: () => of(data)
    });
  }
}
