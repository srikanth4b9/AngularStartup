import { ColumnDef } from './column-def.model';

export enum ACTION {
  EDIT = 'Edit',
  RELEASE = 'Release',
  DELETE = 'Delete',
  EXPORT = 'Export',
  UPLOAD_MANUAL_CASH = 'Upload Manual Cash',
  RECALCULATE = 'Recalculate',
  NEW_MANUAL_TRADE = 'New Manual Trade'
}

export class ActionRequest {
  action: ACTION;
  object: any;

  constructor(action: ACTION, object: any) {
    this.action = action;
    this.object = object;
  }
}

export class TableDef {
  columns: ColumnDef[];
  hasActions = false;
  multiSelect = false;

  constructor(columns: ColumnDef[], hasActions = false, multiSelect = false) {
    this.columns = columns;
    this.hasActions = hasActions;
    this.multiSelect = multiSelect;
  }

  get showMultiSelect(): boolean {
    return this.multiSelect && this.hasActions;
  }
}
