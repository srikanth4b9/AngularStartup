import { NgModule } from '@angular/core';
import { CommonModule, CurrencyPipe } from '@angular/common';
import { CustomCurrencyPipe } from './custom-currency.pipe';

@NgModule({
  declarations: [CustomCurrencyPipe],
  exports: [CustomCurrencyPipe],
  providers: [CurrencyPipe]
})
export class CustomCurrencyModule { }
