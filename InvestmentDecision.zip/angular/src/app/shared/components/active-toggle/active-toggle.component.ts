import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';

@Component({
  selector: 'app-active-toggle',
  templateUrl: './active-toggle.component.html',
  styleUrls: ['./active-toggle.component.scss']
})
export class ActiveToggleComponent implements OnInit {
  @Input() id: string = 'active-toggle';
  @Input() isActive: boolean = true;
  @Output() isActiveChange: EventEmitter<boolean> = new EventEmitter();

  constructor() { }

  ngOnInit() {
  }

}
