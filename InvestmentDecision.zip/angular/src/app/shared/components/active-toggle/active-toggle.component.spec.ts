import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { VuiSwitchModule } from 'vg-vui-ng/switch';

import { ActiveToggleComponent } from './active-toggle.component';

describe('ActiveToggleComponent', () => {
  let component: ActiveToggleComponent;
  let fixture: ComponentFixture<ActiveToggleComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        VuiSwitchModule
      ],
      declarations: [ ActiveToggleComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ActiveToggleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
