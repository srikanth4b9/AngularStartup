import { CustomMatTableModule } from './custom-mat-table.module';

describe('ExportableReportModule', () => {
  let customMatTableModule: CustomMatTableModule;

  beforeEach(() => {
    customMatTableModule = new CustomMatTableModule();
  });

  it('should create an instance', () => {
    expect(customMatTableModule).toBeTruthy();
  });
});
