import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import {
  MatButtonModule,
  MatCheckboxModule,
  MatPaginatorModule,
  MatSortModule,
  MatTableModule,
  MatTooltipModule,
} from '@angular/material';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

import { ActionSelectModule } from '../action-select';
import { CustomMatCellModule } from '../custom-mat-cell';
import { CustomMatTableComponent } from './custom-mat-table.component';

@NgModule({
  imports: [
    CommonModule,
    MatButtonModule,
    MatPaginatorModule,
    MatTableModule,
    MatTooltipModule,
    MatSortModule,
    MatCheckboxModule,
    FontAwesomeModule,
    CustomMatCellModule,
    ActionSelectModule
  ],
  declarations: [CustomMatTableComponent],
  exports: [CustomMatTableComponent]
})
export class CustomMatTableModule { }
