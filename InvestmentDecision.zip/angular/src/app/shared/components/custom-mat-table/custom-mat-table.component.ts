import { SelectionChange, SelectionModel } from '@angular/cdk/collections';
import { Component, EventEmitter, Input, OnChanges, Output, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatSortable, MatTableDataSource } from '@angular/material';
import { ACTION, ActionRequest, ColumnType, TableDef } from '@app/shared/models';
import { faEdit } from '@fortawesome/free-solid-svg-icons';

const PAGE_SIZE_50 = 50;
const PAGE_SIZE_100 = 100;

@Component({
  selector: 'app-custom-mat-table',
  templateUrl: './custom-mat-table.component.html',
  styleUrls: ['./custom-mat-table.component.scss']
})
export class CustomMatTableComponent implements OnChanges {
  @Input() tableDef: TableDef;
  @Input() tableData: Array<any>;
  @Input() sortBy: MatSortable = { id: null, start: 'desc', disableClear: false };

  @Output() action: EventEmitter<ActionRequest> = new EventEmitter();
  @Output() selectionChange: EventEmitter<SelectionChange<any>> = new EventEmitter();

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  isVuiTable = false;
  displayedColumns: string[];
  dataSource: MatTableDataSource<any> = new MatTableDataSource<any>();
  selection: SelectionModel<any> = new SelectionModel<any>(true);

  ColumnType = ColumnType;
  faEdit = faEdit;

  pageSizeOptions = [PAGE_SIZE_50, PAGE_SIZE_100];

  ngOnChanges() {
    this.setupTableData();
  }

  setupTableData(): void {
    if (this.tableData) {
      this.displayedColumns = this.tableDef.columns.map(def => def.attribute);

      this.dataSource = new MatTableDataSource<any>(this.tableData);
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;
      this.sort.sort(this.sortBy);
      this.selection.clear();

      if (this.showMultiSelect()) {
        this.setupMultiSelection();
      }

      if (this.tableDef.hasActions && this.isAnySelectEnabled()) {
        this.displayedColumns.push('actions');
      }
    }
  }

  setupMultiSelection(): void {
    this.displayedColumns.unshift('select');
    this.selection.changed.subscribe((change: SelectionChange<any>) => {
      this.selectionChange.emit(change);
    });
  }

  applyFilter(filterValue: string): void {
    this.selection.clear();
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  emitAction(action: ACTION, element: any): void {
    this.action.emit(new ActionRequest(action, element));
  }

  get selectableData(): any[] {
    return this.dataSource.filteredData.filter(element => this.isSelectEnabled(element));
  }

  showMultiSelect(): boolean {
    return this.tableDef.showMultiSelect && this.isAnySelectEnabled();
  }

  isAnySelectEnabled(): boolean {
    return this.dataSource.data.some(element => this.isSelectEnabled(element));
  }

  isSelectEnabled(element: any): boolean {
    return element.hasActions ? element.hasActions() : false;
  }

  isAllSelected(): boolean {
    const numSelected = this.selection.selected.length;
    const numRows = this.selectableData.length;
    return numSelected === numRows;
  }

  masterSelectToggle(): void {
    this.isAllSelected() ?
      this.selection.clear() :
      this.selectableData.forEach(row => this.selection.select(row));
  }
}
