import { Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import {
  MatButtonModule,
  MatCheckboxModule,
  MatPaginatorModule,
  MatSortModule,
  MatTableModule,
  MatTooltipModule,
} from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { investableCashReportDef, mockInvestableCashReport } from '@app/modules/reports/modules/investable-cash/models';
import {
  ManualTrade,
  ManualTradeReportDef,
  mockManualRuns,
  mockManualTrades,
  Trade,
  TradeReportDef,
  InvestmentDecisionRun,
} from '@app/modules/trades/models';
import { MaterialModule } from '@app/shared/material.module';
import { ACTION, ActionRequest } from '@app/shared/models';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

import { ActionSelectModule } from '../action-select';
import { CustomMatCellModule } from '../custom-mat-cell';
import { CustomMatTableComponent } from './custom-mat-table.component';

@Component({ selector: 'app-host-for-test', template: '' })
class HostComponent {
}

describe('CustomMatTableComponent', () => {
  let component: CustomMatTableComponent;
  let fixture: ComponentFixture<CustomMatTableComponent>;
  let setupTableDataSpy: jasmine.Spy;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        MaterialModule,
        NoopAnimationsModule,
        FormsModule,
        MatButtonModule,
        MatPaginatorModule,
        MatTableModule,
        MatTooltipModule,
        MatSortModule,
        MatCheckboxModule,
        FontAwesomeModule,
        CustomMatCellModule,
        ActionSelectModule
      ],
      declarations: [HostComponent, CustomMatTableComponent]
    }).compileComponents();
  });

  function createComponent(tableDef = investableCashReportDef, tableData: any[] = mockInvestableCashReport) {
    fixture = TestBed.createComponent(CustomMatTableComponent);
    component = fixture.componentInstance;
    component.tableDef = tableDef;
    component.tableData = tableData;
    setupTableDataSpy = spyOn(component, 'setupTableData').and.callThrough();
    fixture.detectChanges();
  }
  function createHostComponent(template: string): ComponentFixture<HostComponent> {
    TestBed.overrideComponent(HostComponent, { set: { template: template } });
    const hostFixture = TestBed.createComponent(HostComponent);
    hostFixture.detectChanges();
    return hostFixture;
  }

  it('should create', () => {
    createComponent();
    expect(component).toBeTruthy();
  });

  describe('ngOnChanges:', () => {
    it('should setup table data', () => {
      createComponent();
      component.ngOnChanges();

      expect(setupTableDataSpy).toHaveBeenCalled();
    });
  });

  describe('setupTableData:', () => {
    it('should not setup mat table data when tableData is undefined', () => {
      createComponent();
      component.tableData = undefined;

      component.setupTableData();

      expect(component.dataSource.data).toEqual([]);
    });

    it('should setup mat table data, sorting, and pagination', () => {
      createComponent();

      component.setupTableData();

      expect(component.dataSource.data).toEqual(component.tableData);
      expect(component.dataSource.sort).toEqual(component.sort);
      expect(component.dataSource.paginator).toEqual(component.paginator);
    });

    it('should setup displayed columns by using the table definition', () => {
      const expectedColumns = [
        'portId',
        'fundName',
        'productType',
        'runTimestamp',
        'activitySource',
        'participantActivity',
        'indirectCash',
        'manualCash',
        'expenses',
        'totalInvestableCash'
      ];
      createComponent();

      component.setupTableData();

      expect(component.displayedColumns).toEqual(expectedColumns);
    });

    it('should add actions to displayedColumns if table definition has actions', () => {
      createComponent(new TradeReportDef(), mockManualTrades.map(trade => new Trade(trade)));
      spyOn(component, 'isAnySelectEnabled').and.returnValue(true);

      component.setupTableData();

      expect(component.displayedColumns).toContain('actions');
    });
  });

  describe('apply Filter:', () => {
    it('should apply filter to table dataSource', () => {
      createComponent();
      component.setupTableData();
      spyOn(component.selection, 'clear');

      const filterValue = ' Mock Filter ';
      component.applyFilter(filterValue);

      expect(component.selection.clear).toHaveBeenCalled();
      expect(component.dataSource.filter).toBe('mock filter');
    });
  });

  describe('emitAction:', () => {
    it('should emit action event passing ActionRequest', () => {
      const action = ACTION.EDIT;
      const element = mockManualTrades[0];
      createComponent();
      component.tableDef = investableCashReportDef;
      const actionSpy = spyOn(component.action, 'emit');

      component.emitAction(action, element);

      expect(actionSpy).toHaveBeenCalledWith(new ActionRequest(action, element));
    });
  });

  describe('Multi Selection', () => {
    let manualTrades: ManualTrade[];
    let anySelectEnabledSpy: jasmine.Spy;
    beforeEach(() => {
      const runs = mockManualRuns.map(run => new InvestmentDecisionRun(run));
      manualTrades = runs.map(run => new ManualTrade(run));
      createComponent(new ManualTradeReportDef(), manualTrades);
      anySelectEnabledSpy = spyOn(component, 'isAnySelectEnabled').and.returnValue(true);
      component.ngOnChanges();
    });

    describe('setupMultiSelection', () => {
      it('should setup multi selection', () => {
        spyOn(component.selectionChange, 'emit');

        component.selection.select(mockManualTrades);

        expect(component.selectionChange.emit).toHaveBeenCalled();
      });
    });

    describe('showMultiSelect', () => {
      it('should return false when tableDef should not show multiSelect', () => {
        createComponent();

        expect(component.showMultiSelect()).toEqual(false);
      });

      it('should return false when no data is selectable', () => {
        anySelectEnabledSpy.and.returnValue(false);

        expect(component.showMultiSelect()).toEqual(false);
      });

      it('should return true when data is selectable', () => {
        anySelectEnabledSpy.and.returnValue(true);

        expect(component.showMultiSelect()).toEqual(true);
      });
    });

    describe('isSelectEnabled', () => {
      it('should return true if the element has actions', () => {
        const element = new Trade(mockManualTrades[0]);
        element.setActions([ACTION.DELETE]);

        expect(component.isSelectEnabled(element)).toEqual(true);
      });
    });

    describe('isAllSelected', () => {
      beforeEach(function() {
        spyOnProperty(component, 'selectableData').and.returnValue([manualTrades[0]]);
      });

      it('should return false when all selectable rows are not selected', () => {
        expect(component.isAllSelected()).toEqual(false);
      });

      it('should return true when all selectable rows are selected', () => {
        component.selection.select(manualTrades[0]);

        expect(component.isAllSelected()).toEqual(true);
      });
    });

    describe('masterSelectToggle', () => {
      it('should clear the selection if all rows are selected', () => {
        spyOn(component, 'isAllSelected').and.returnValue(true);
        spyOn(component.selection, 'clear');

        component.masterSelectToggle();

        expect(component.selection.clear).toHaveBeenCalled();
      });

      it('should select all rows if all rows are not selected', () => {
        spyOn(component, 'isAllSelected').and.returnValue(false);

        component.masterSelectToggle();

        expect(component.selection.selected.length).toEqual(component.selectableData.length);
      });
    });
  });
});
