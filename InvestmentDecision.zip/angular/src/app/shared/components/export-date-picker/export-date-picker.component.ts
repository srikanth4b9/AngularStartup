import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { formatDate } from '@angular/common';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Moment } from 'moment';

@Component({
  selector: 'app-export-date-picker',
  templateUrl: './export-date-picker.component.html',
  styleUrls: ['./export-date-picker.component.scss']
})
export class ExportDatePickerComponent implements OnInit {
  @Input() maxDate = new Date();
  @Output() submitEvent = new EventEmitter();

  exportDateForm: FormGroup;

  config = {
    exportButtonLabel: 'Export',
    exportDateFormat: 'YYYY-MM-DD'
  };
  datePickerDate: string = '';

  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.exportDateForm = this.createFormGroup();
  }

  private createFormGroup() {
    return this.formBuilder.group({
      date: ['']
    });
  }

  get exportDate() { return this.exportDateForm.get('date'); }

  formatDate(inputDateMoment: Moment) {
    return inputDateMoment.format(this.config.exportDateFormat);
  }

  emitSubmit() {
    this.submitEvent.emit(this.formatDate(this.exportDate.value));
  }

}
