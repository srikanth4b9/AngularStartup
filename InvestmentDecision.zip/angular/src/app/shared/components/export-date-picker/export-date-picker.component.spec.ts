import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule, MatDatepickerModule, MatInputModule, MatNativeDateModule } from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import * as moment from 'moment';

import { ExportDatePickerComponent } from './export-date-picker.component';
import { SvgModule } from 'vg-vui-ng/svg';

describe('ExportDatePickerComponent', () => {
  let component: ExportDatePickerComponent;
  let fixture: ComponentFixture<ExportDatePickerComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ExportDatePickerComponent],
      imports: [
        NoopAnimationsModule,
        ReactiveFormsModule,
        MatButtonModule,
        MatDatepickerModule,
        MatNativeDateModule,
        MatInputModule,
        SvgModule
      ]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExportDatePickerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('formatDate:', () => {
    const inputDateMoment = moment('2018-12-17T11:13:16.158');
    const exportDate = '2018-12-17';
    it('should return a properly formatted date', () => {
      expect(component.formatDate(inputDateMoment)).toBe(exportDate);
    });
  });

  describe('emit submit:', () => {
    it('should emit export event passing exportDate', () => {
      const transformDateSpy = spyOn(component, 'formatDate');
      const emitSpy = spyOn(component.submitEvent, 'emit');

      component.emitSubmit();

      expect(transformDateSpy).toHaveBeenCalledWith(component.exportDate.value);
      expect(emitSpy).toHaveBeenCalled();
    });
  });
});
