import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule, MatDatepickerModule, MatInputModule } from '@angular/material';
import { MatMomentDateModule } from '@angular/material-moment-adapter';

import { ExportDatePickerComponent } from './export-date-picker.component';
import { SvgModule } from 'vg-vui-ng/svg';

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatDatepickerModule,
    MatMomentDateModule,
    MatInputModule,
    SvgModule
  ],
  declarations: [ExportDatePickerComponent],
  exports: [ExportDatePickerComponent]
})
export class ExportDatePickerModule { }
