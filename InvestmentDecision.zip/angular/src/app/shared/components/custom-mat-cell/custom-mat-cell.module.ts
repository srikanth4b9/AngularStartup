import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTooltipModule } from '@angular/material';
import { MdcCheckboxModule } from '@angular-mdc/web';
import { RouterModule } from '@angular/router';
import { CustomCurrencyModule } from '@app/shared/pipes';
import { FormsModule } from '@angular/forms';

import { CustomMatCellComponent } from './custom-mat-cell.component';
import { ActionSelectModule } from '../action-select';

@NgModule({
  declarations: [CustomMatCellComponent],
  imports: [
    CommonModule,
    CustomCurrencyModule
  ],
  exports: [CustomMatCellComponent]
})
export class CustomMatCellModule { }
