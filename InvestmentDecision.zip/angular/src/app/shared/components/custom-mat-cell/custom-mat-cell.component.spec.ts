import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { MdcCheckboxModule } from '@angular-mdc/web';
import { CustomCurrencyModule } from '@app/shared/pipes';
import { ColumnDefBuilder, ColumnType } from '@app/shared/models';
import { RouterTestingModule } from '@angular/router/testing';

import { CustomMatCellComponent } from './custom-mat-cell.component';
import { ActionSelectModule } from '../action-select';
import { RunStatus, RunType } from '@app/modules/trades/models';
import { ErrorType } from '@app/modules/reports/modules/trade-errors/models';
import { TradeSubmissionMethod } from '@app/modules/fund-maintenance/models';

describe('CustomMatCellComponent', () => {
  let component: CustomMatCellComponent;
  let fixture: ComponentFixture<CustomMatCellComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        CustomCurrencyModule
      ],
      declarations: [ CustomMatCellComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomMatCellComponent);
    component = fixture.componentInstance;
    component.column = new ColumnDefBuilder('Net Rate', 'netRate', ColumnType.PERCENT).build();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('getEnumValue:', () => {
    it('should return null for an unknown enum type', () => {
      const enumType = 'UNKNOWN';

      const enumValue = component.getEnumValue('unknownType', enumType);
      expect(enumValue).toEqual(null);
    });

    it('should return the string value for a status enum type', () => {
      const enumType = 'PENDING_REVIEW';
      const enumValue = component.getEnumValue('status', enumType);

      expect(enumValue).toEqual(RunStatus[enumType]);
    });
    it('should return the string value for a TradeType enum type', () => {
      const enumType = 'CAPSTOCK_ACTIVITY';
      const enumValue = component.getEnumValue('tradeType', enumType);

      expect(enumValue).toEqual(RunType[enumType]);
    });

    it('should return the string value for an ErrorType enum type', () => {
      const enumType = 'TRDB';
      const enumValue = component.getEnumValue('errorType', enumType);

      expect(enumValue).toEqual(ErrorType[enumType]);
    });
    it('should return the string value for an TradeSubmissionMethod enum type', () => {
      const enumType = 'DIRECT';
      const enumValue = component.getEnumValue('tradeSubmissionMethod', enumType);

      expect(enumValue).toEqual(TradeSubmissionMethod[enumType]);
    });
  });
});
