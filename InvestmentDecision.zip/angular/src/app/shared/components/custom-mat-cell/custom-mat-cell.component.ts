import { Component, Input } from '@angular/core';
import { TradeSubmissionMethod } from '@app/modules/fund-maintenance/models';
import { ErrorType } from '@app/modules/reports/modules/trade-errors/models';
import { RunStatus, RunType, StatusBadgeClasses } from '@app/modules/trades/models';
import { ColumnDef, ColumnType } from '@app/shared/models';

@Component({
  selector: 'app-custom-mat-cell',
  templateUrl: './custom-mat-cell.component.html',
  styleUrls: ['./custom-mat-cell.component.scss']
})
export class CustomMatCellComponent {
  @Input() column: ColumnDef;
  @Input() value: any;

  ColumnType = ColumnType;
  StatusBadgeClasses = StatusBadgeClasses;

  constructor() { }

  getEnumValue(enumType: string, value: string) {
    switch (enumType) {
      case 'status': return RunStatus[value];
      case 'tradeType': return RunType[value];
      case 'errorType': return ErrorType[value];
      case 'tradeSubmissionMethod': return TradeSubmissionMethod[value];
      default: return null;
    }
  }
}
