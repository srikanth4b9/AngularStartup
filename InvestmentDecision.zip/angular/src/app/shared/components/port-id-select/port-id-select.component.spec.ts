import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder, FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatAutocompleteModule, MatFormFieldModule, MatInputModule } from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { mockPortIdList } from '@app/modules/fund-maintenance/models';
import { MockFundMaintenanceService } from '@app/modules/fund-maintenance/services/fund-maintenance.service.mock';
import { FundMaintenanceService } from '@fund-maintenance/services';
import { of } from 'rxjs';

import { ActiveToggleModule } from '../active-toggle';
import { PortIdSelectComponent } from './port-id-select.component';


describe('PortIdSelectComponent', () => {
  let component: PortIdSelectComponent;
  let fixture: ComponentFixture<PortIdSelectComponent>;
  let maintenanceService: MockFundMaintenanceService;
  const formBuilder: FormBuilder = new FormBuilder();

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule,
        FormsModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatInputModule,
        MatAutocompleteModule,
        ActiveToggleModule
      ],
      declarations: [PortIdSelectComponent],
      providers: [
        { provide: FundMaintenanceService, useClass: MockFundMaintenanceService },
        { provide: FormBuilder, useValue: formBuilder }
      ]
    })
      .compileComponents();

    maintenanceService = TestBed.get(FundMaintenanceService);
  });

  function createComponent() {
    fixture = TestBed.createComponent(PortIdSelectComponent);
    component = fixture.componentInstance;
    component.parentForm = formBuilder.group({
      portId: ['']
    });
    fixture.detectChanges();
  }

  it('should create', () => {
    createComponent();
    expect(component).toBeTruthy();
  });

  describe('ngOnInit:', () => {
    it('should call loadPortIds to load all Port IDs', () => {
      createComponent();
      const loadPortIdsSpy = spyOn(component, 'loadPortIds');

      component.ngOnInit();

      expect(loadPortIdsSpy).toHaveBeenCalled();
    });

    it('should set Indirect Placeholder', () => {
      createComponent();
      component.isIndirectOnly = true;

      component.ngOnInit();

      expect(component.placeholder).toEqual('Indirect Port ID');
    });
  });

  describe('loadPortIds:', () => {
    it('should call the service to get list of port IDs', () => {
      createComponent();
      const setFilteredOptionsSpy = spyOn(component, 'setFilteredPortIds');
      const setValidatorsSpy = spyOn(component.portId, 'setValidators');
      const setAsyncValidatorsSpy = spyOn(component.portId, 'setAsyncValidators');

      component.loadPortIds();

      expect(maintenanceService.getPortIds).toHaveBeenCalled();
      expect(component.portIdList).toEqual(mockPortIdList);
      expect(setFilteredOptionsSpy).toHaveBeenCalled();
      expect(setValidatorsSpy).toHaveBeenCalled();
      expect(setAsyncValidatorsSpy).toHaveBeenCalled();
    });
  });

  describe('setFilteredPortIds:', () => {
    it('should set the filtered list of Port IDs', () => {
      createComponent();

      component.setFilteredPortIds();

      expect(component.filteredPortIds).toBeDefined();
    });
  });

  describe('resetFilteredPortIds:', () => {
    it('should reset the filtered list of Port IDs', () => {
      createComponent();
      const setFilteredOptionsSpy = spyOn(component, 'setFilteredPortIds');

      component.resetFilteredPortIds();

      expect(component.portId.value).toEqual('');
      expect(setFilteredOptionsSpy).toHaveBeenCalled();
    });
  });

  describe('validatePortId:', () => {
    let control: FormControl;

    beforeEach(() => {
      control = new FormControl('0430');
      createComponent();
    });

    it('should return null if the form control is pristine', () => {
      control.markAsPristine();

      component.validatePortId(control).subscribe(response => {
        expect(response).toBeNull();
      });
    });

    it('should return null if the control value is empty', () => {
      control.setValue('');

      component.validatePortId(control).subscribe(response => {
        expect(response).toBeNull();
      });
    });

    it('should return a validation error if the Port ID does not exist', () => {
      control.markAsDirty();
      component.filteredPortIds = of([]);

      component.validatePortId(control).subscribe(response => {
        expect(response).toEqual({ invalidPortId: true });
      });
    });

    it('should return null if the Port ID exists', () => {
      control.markAsDirty();
      component.filteredPortIds = of(['0430']);

      component.validatePortId(control).subscribe(response => {
        expect(response).toEqual(null);
      });
    });
  });

  describe('getValidationErrorMessage:', () => {
    it('should display message for invalidPortId validation error', () => {
      createComponent();
      component.portId.setErrors({ invalidPortId: true });

      expect(component.getValidationErrorMessage()).toEqual('Invalid Port ID');
    });

    it('should display message for minlength validation error', () => {
      createComponent();
      component.portId.setErrors({ minlength: { requiredLength: 4 } });

      expect(component.getValidationErrorMessage()).toEqual('Must be 4 characters');
    });

    it('should not display message if no errors are present', () => {
      createComponent();
      component.portId.setErrors({});

      expect(component.getValidationErrorMessage()).toEqual('');
    });
  });
});
