import { PortIdSelectModule } from './port-id-select.module';

describe('PortIdSelectModule', () => {
  let portIdSelectModule: PortIdSelectModule;

  beforeEach(() => {
    portIdSelectModule = new PortIdSelectModule();
  });

  it('should create an instance', () => {
    expect(portIdSelectModule).toBeTruthy();
  });
});
