import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule, MatInputModule, MatAutocompleteModule } from '@angular/material';

import { PortIdSelectComponent } from './port-id-select.component';
import { ActiveToggleModule } from '../active-toggle';

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatAutocompleteModule,
    ActiveToggleModule
  ],
  declarations: [PortIdSelectComponent],
  exports: [PortIdSelectComponent]
})

export class PortIdSelectModule { }
