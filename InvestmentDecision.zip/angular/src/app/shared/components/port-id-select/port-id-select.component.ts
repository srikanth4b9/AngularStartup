import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, AbstractControl, ValidationErrors, Validators } from '@angular/forms';

import { FundMaintenanceService } from '@fund-maintenance/services';
import { PortIdListItem } from '@fund-maintenance/models';
import { Observable, of } from 'rxjs';
import { startWith, map } from 'rxjs/operators';

const MIN_PORT_ID = 4;

@Component({
  selector: 'app-port-id-select',
  templateUrl: './port-id-select.component.html',
  styleUrls: ['./port-id-select.component.scss']
})
export class PortIdSelectComponent implements OnInit {
  @Input() parentForm: FormGroup;
  @Input() controlName: string = 'portId';
  @Input() activeToggle: boolean = true;
  @Input() isIndirectOnly: boolean = false;

  placeholder: string = 'Port ID';
  portIdList: PortIdListItem[] = [];
  filteredPortIds: Observable<string[]>;
  isActive = true;

  constructor(private fundProfileService: FundMaintenanceService) {
  }

  ngOnInit() {
    if (this.isIndirectOnly) {
      this.placeholder = 'Indirect Port ID';
    }
    this.loadPortIds();
  }

  get portId() { return this.parentForm.get(this.controlName); }

  loadPortIds(): void {
    this.fundProfileService.portIds$.subscribe((portIdList: PortIdListItem[]) => {
      this.setPortIds(portIdList);
      this.setValidators();
    });
    this.fundProfileService.getPortIds();
  }

  private setPortIds(portIdList: PortIdListItem[]) {
    this.portIdList = portIdList
      .filter(portIdListItem => this._indirectFilter(portIdListItem.indirectFund));
    this.setFilteredPortIds();
  }

  private setValidators() {
    this.portId.setValidators(Validators.minLength(MIN_PORT_ID));
    this.portId.setAsyncValidators(this.validatePortId.bind(this));
  }

  validatePortId(control: AbstractControl): Observable<ValidationErrors> {
    if (!control.pristine && control.value !== '') {
      return this.filteredPortIds.pipe(
        map((filteredPortIds: string[]) => filteredPortIds.length === 1 ? null : { invalidPortId: true })
      );
    }
    return of(null);
  }

  setFilteredPortIds() {
    this.filteredPortIds = this.portId.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value))
    );
  }

  resetFilteredPortIds() {
    this.portId.setValue('');
    this.setFilteredPortIds();
  }

  private _filter(value: string = ''): string[] {
    const filterValue = (value || '').toLowerCase();
    return this.portIdList
      .filter(portIdListItem => this._activeFilter(portIdListItem.active))
      .map(portIdListItem => portIdListItem.portId)
      .filter(option => (option || '').toLowerCase().includes(filterValue));
  }

  private _indirectFilter(indirectFund: boolean) {
    return this.isIndirectOnly ? indirectFund : true;
  }

  private _activeFilter(isPortIdActive: boolean) {
    return this.activeToggle ? this.isActive === isPortIdActive : isPortIdActive;
  }

  getValidationErrorMessage(): string {
    return this.portId.errors.invalidPortId ? 'Invalid Port ID' :
      this.portId.errors.minlength ? `Must be ${this.portId.errors.minlength.requiredLength} characters` :
        '';
  }
}
