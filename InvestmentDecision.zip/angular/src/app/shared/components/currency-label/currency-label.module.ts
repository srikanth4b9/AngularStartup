import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CurrencyLabelComponent } from './currency-label.component';
import { CustomCurrencyModule } from '@app/shared/pipes';

@NgModule({
  imports: [
    CommonModule,
    CustomCurrencyModule
  ],
  declarations: [CurrencyLabelComponent],
  exports: [CurrencyLabelComponent]
})
export class CurrencyLabelModule { }
