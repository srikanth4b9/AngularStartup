import { CurrencyLabelModule } from './currency-label.module';

describe('CurrencyLabelModule', () => {
  let currencyLabelModule: CurrencyLabelModule;

  beforeEach(() => {
    currencyLabelModule = new CurrencyLabelModule();
  });

  it('should create an instance', () => {
    expect(currencyLabelModule).toBeTruthy();
  });
});
