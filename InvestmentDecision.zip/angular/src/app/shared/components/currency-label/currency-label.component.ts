import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-currency-label',
  templateUrl: './currency-label.component.html',
  styleUrls: ['./currency-label.component.scss']
})
export class CurrencyLabelComponent implements OnInit {
  @Input() inputValue: any;

  constructor() { }

  ngOnInit() {
  }

}
