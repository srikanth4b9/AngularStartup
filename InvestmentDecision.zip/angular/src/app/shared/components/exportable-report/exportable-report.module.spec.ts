import { ExportableReportModule } from './exportable-report.module';

describe('ExportableReportModule', () => {
  let exportableReportModule: ExportableReportModule;

  beforeEach(() => {
    exportableReportModule = new ExportableReportModule();
  });

  it('should create an instance', () => {
    expect(exportableReportModule).toBeTruthy();
  });
});
