import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomCurrencyModule } from '@app/shared/pipes';
import { ExportableReportComponent } from './exportable-report.component';
import { FormsModule } from '@angular/forms';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { ExportDatePickerModule } from '../export-date-picker';
import { CustomMatTableModule } from '../custom-mat-table';
import { MatToolbarModule, MatInputModule } from '@angular/material';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    CustomCurrencyModule,
    MatToolbarModule,
    MatInputModule,
    FontAwesomeModule,
    ExportDatePickerModule,
    CustomMatTableModule
  ],
  declarations: [ExportableReportComponent],
  exports: [ExportableReportComponent]
})
export class ExportableReportModule { }
