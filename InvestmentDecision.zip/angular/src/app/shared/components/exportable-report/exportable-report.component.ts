import { SelectionChange } from '@angular/cdk/collections';
import { Component, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { MatSortable } from '@angular/material';
import { ActionRequest, TableDef } from '@app/shared/models';
import { faSearch } from '@fortawesome/free-solid-svg-icons';

import { CustomMatTableComponent } from '../custom-mat-table';

@Component({
  selector: 'app-exportable-report',
  templateUrl: './exportable-report.component.html',
  styleUrls: ['./exportable-report.component.scss']
})
export class ExportableReportComponent {
  @Input() reportName: string = '';
  @Input() tableDef: TableDef;
  @Input() tableData: Array<any>;
  @Input() sortBy: MatSortable = { id: null, start: 'desc', disableClear: false };
  @Input() showCurrentDate: boolean = false;
  @Input() exportable: boolean = false;
  @Input() includeDateExportField: boolean = false;
  @Input() includeTableFilter: boolean = true;
  @Output() selectionChange: EventEmitter<SelectionChange<any>> = new EventEmitter();

  @Output() exportReport: EventEmitter<string> = new EventEmitter<string>();
  @Output() action: EventEmitter<ActionRequest> = new EventEmitter();

  @ViewChild(CustomMatTableComponent, { static: false }) customMatTable: CustomMatTableComponent;

  currentDate = new Date();
  faSearch = faSearch;

  constructor() { }

}
