import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ExportableReportComponent } from './exportable-report.component';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { CustomCurrencyModule } from '@app/shared/pipes';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { ExportDatePickerModule } from '../export-date-picker';
import { CustomMatTableModule } from '../custom-mat-table';
import { MatToolbarModule, MatInputModule } from '@angular/material';
import { investableCashReportDef } from '@app/modules/reports/modules/investable-cash/models';

describe('ExportableReportComponent', () => {
  let component: ExportableReportComponent;
  let fixture: ComponentFixture<ExportableReportComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule,
        FormsModule,
        CustomCurrencyModule,
        MatToolbarModule,
        MatInputModule,
        FontAwesomeModule,
        ExportDatePickerModule,
        CustomMatTableModule
      ],
      declarations: [ExportableReportComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExportableReportComponent);
    component = fixture.componentInstance;
    component.tableDef = investableCashReportDef;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
