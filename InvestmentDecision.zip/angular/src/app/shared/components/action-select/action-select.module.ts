import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatButtonModule, MatInputModule, MatSelectModule } from '@angular/material';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

import { ActionSelectComponent } from './action-select.component';

@NgModule({
  imports: [
    CommonModule,
    MatButtonModule,
    MatInputModule,
    MatSelectModule,
    FontAwesomeModule
  ],
  declarations: [ActionSelectComponent],
  exports: [ActionSelectComponent]
})
export class ActionSelectModule { }
