import { Component, EventEmitter, Input, Output } from '@angular/core';
import { MatSelectChange } from '@angular/material';
import { ACTION } from '@app/shared/models';
import { faCalculator, faEdit, faFileUpload, faPlusCircle, faShare, faTrash, faFileDownload } from '@fortawesome/free-solid-svg-icons';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-action-select',
  templateUrl: './action-select.component.html',
  styleUrls: ['./action-select.component.scss']
})
export class ActionSelectComponent {
  @Input() actionOptions: Observable<ACTION[]>;
  @Output() action: EventEmitter<ACTION> = new EventEmitter();

  actionIcons = {
    Release: faShare,
    Edit: faEdit,
    Delete: faTrash,
    Export: faFileDownload,
    Recalculate: faCalculator,
    'Upload Manual Cash': faFileUpload,
    'New Manual Trade': faPlusCircle
  };

  constructor() { }

  emitAction(selectChange: MatSelectChange): void {
    if (selectChange.value) {
      this.action.emit(selectChange.value);

      selectChange.source.writeValue(null);
    }
  }
}
