import * as moment from 'moment';

import { DateTimeUtils } from './dateTime.utils';

type Moment = moment.Moment;

function mockDate(momentDate: Moment) {
  jasmine.clock().mockDate(momentDate.toDate());
}

describe('DateTimeUtils', () => {
  describe('isTradingMarketClosed:', () => {
    it('should return true if date is on Sunday', () => {
      mockDate(moment().day(0));
      expect(DateTimeUtils.isTradingMarketClosed()).toEqual(true);
    });

    it('should return true if date is on Saturday', () => {
      mockDate(moment().day(6));
      expect(DateTimeUtils.isTradingMarketClosed()).toEqual(true);
    });

    it('should return true if time is after cutoff time', () => {
      mockDate(moment().day(1).hour(16));
      expect(DateTimeUtils.isTradingMarketClosed()).toEqual(true);
    });
  });

  describe('tradeDateFilter:', () => {
    it('should return false if date is on Sunday', () => {
      expect(DateTimeUtils.tradeDateFilter(moment().day(0))).toEqual(false);
    });

    it('should return false if date is on Saturday', () => {
      expect(DateTimeUtils.tradeDateFilter(moment().day(6))).toEqual(false);
    });

    it('should return false if date is before current date', () => {
      expect(DateTimeUtils.tradeDateFilter(moment().day(-2))).toEqual(false);
    });

    it('should return true if date is after current date', () => {
      expect(DateTimeUtils.tradeDateFilter(moment().day(8))).toEqual(true);
    });
  });

  describe('toISOString:', () => {
    let dateString: string;
    beforeEach(function () {
      dateString = '2019-10-02T00:00:00-04:00';
    });


    it('should ISO string if date is a moment object', () => {
      const date = moment(dateString);
      const expectedISOString = '2019-10-02T04:00:00.000Z';
      expect(DateTimeUtils.toISOString(date)).toEqual(expectedISOString);
    });

    it('should return date if not a moment object', () => {
      expect(DateTimeUtils.toISOString(dateString)).toEqual(dateString);
    });
  });
});
