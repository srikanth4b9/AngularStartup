import * as moment from 'moment';
// import 'moment-timezone';
import * as momentTz from 'moment-timezone';

import { ProductType } from '@app/modules/trades/models';

type Moment = moment.Moment;

const SATURDAY = 6;
const SUNDAY = 0;
const TO_MINUTES_60 = 60;

export class DateTimeUtils {
  static timezone: string = 'America/New_York';
  static defaultCutoffTime: Moment = momentTz('04:00p', 'HH:mm a').tz(DateTimeUtils.timezone);
  static cutoffTimes = {
    'CUSTOM_TARGET_DATE_FUND': DateTimeUtils.defaultCutoffTime,
    'LEGACY_FUND_OF_FUND': DateTimeUtils.defaultCutoffTime,
    'LEGACY_AM_FUND_OF_FUND': momentTz('10:30a', 'HH:mm a').tz(DateTimeUtils.timezone)
  };

  static isTradingMarketClosed(productType: ProductType = 'LEGACY_FUND_OF_FUND'): boolean {
    const currentMoment = momentTz().tz(DateTimeUtils.timezone);
    return this.isWeekend(currentMoment) || this.isAfterCutoffTime(currentMoment, productType);
  }

  private static isWeekend(currentMoment: Moment) {
    const currentDay = currentMoment.day();
    return currentDay === SUNDAY || currentDay === SATURDAY;
  }

  private static isAfterCutoffTime(currentMoment: Moment, productType: ProductType) {
    const cutoffTime = this.cutoffTimes[productType];
    return DateTimeUtils.minutesOfDay(currentMoment) >= DateTimeUtils.minutesOfDay(cutoffTime);
  }

  private static minutesOfDay(momentObj: Moment): number {
    return momentObj.minutes() + (momentObj.hours() * TO_MINUTES_60);
  }

  static tradeDateFilter(datepickerMoment: Moment): boolean {
    const day = datepickerMoment.day();
    // Prevent Saturday and Sunday from being selected.
    const isWeekday: boolean = day !== SUNDAY && day !== SATURDAY;
    return isWeekday && this.asOfDateFilter(datepickerMoment);
  }

  static asOfDateFilter(datepickerMoment: Moment): boolean {
    const currentMoment: Moment = moment();
    return datepickerMoment.isSameOrAfter(currentMoment, 'day');
  }

  static toISOString(date): string {
    return date.toISOString ? date.toISOString() : date;
  }
}
