import { MdcTypographyModule } from '@angular-mdc/web';
import { HTTP_INTERCEPTORS, HttpClientModule, HttpClientXsrfModule } from '@angular/common/http';
import { APP_ID, Inject, NgModule } from '@angular/core';
import { MAT_DIALOG_DEFAULT_OPTIONS, MAT_SNACK_BAR_DEFAULT_OPTIONS, MatSnackBarModule } from '@angular/material';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppComponent } from '@app/app.component';
import { AppRoutingModule } from '@app/app.routing.module';
import { HttpConfigInterceptor, LoadingIndicatorService, SnackBarService } from '@app/services';
import { VuiHttpModule } from 'vg-vui-ng/http';

import {
  AppToolbarComponentModule,
  ConfirmDialogComponent,
  ConfirmDialogModule,
  ExportDialogComponent,
  ExportDialogModule,
  LoadingIndicatorModule,
  TabGroupComponentModule,
  UploadDialogComponent,
  UploadDialogModule,
} from './components';

// Angular Universal requires HttpClientModule to be declared at app level
// https://www.thecodecampus.de/blog/angular-universal-xmlhttprequest-not-defined-httpclient/
@NgModule({
  imports: [
    BrowserModule.withServerTransition({ appId: 'investment-decision' }),
    AppRoutingModule,
    HttpClientModule,
    HttpClientXsrfModule,
    VuiHttpModule,
    MdcTypographyModule,
    BrowserAnimationsModule,
    MatSnackBarModule,
    LoadingIndicatorModule,
    AppToolbarComponentModule,
    TabGroupComponentModule,
    ConfirmDialogModule,
    ExportDialogModule,
    UploadDialogModule
  ],
  declarations: [AppComponent],
  providers: [
    LoadingIndicatorService,
    SnackBarService,
    { provide: HTTP_INTERCEPTORS, useClass: HttpConfigInterceptor, multi: true },
    { provide: MAT_SNACK_BAR_DEFAULT_OPTIONS, useValue: { duration: 5000 } },
    { provide: MAT_DIALOG_DEFAULT_OPTIONS, useValue: { hasBackdrop: true, autoFocus: false, disableClose: true } }
  ],
  bootstrap: [AppComponent],
  entryComponents: [
    ConfirmDialogComponent,
    ExportDialogComponent,
    UploadDialogComponent
  ]
})
export class AppModule {
  constructor(@Inject(APP_ID) private readonly appId: string) {
    console.log(`Running with appId=${appId}`);
  }
}
