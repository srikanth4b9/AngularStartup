import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { MatTabsModule } from '@angular/material/tabs';

import { SecurityMasterTabsComponent } from './security-master-tabs.component';

describe('SecurityMasterTabsComponent', () => {
  let component: SecurityMasterTabsComponent;
  let fixture: ComponentFixture<SecurityMasterTabsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        MatTabsModule
      ],
      declarations: [SecurityMasterTabsComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SecurityMasterTabsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });


  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
