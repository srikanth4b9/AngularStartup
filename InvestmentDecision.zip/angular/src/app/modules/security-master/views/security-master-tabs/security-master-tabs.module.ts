import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MaterialModule } from '@app/shared/material.module';

import { SecurityMasterTabsComponent } from './security-master-tabs.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    MaterialModule
  ],
  declarations: [SecurityMasterTabsComponent],
  exports: [SecurityMasterTabsComponent]
})
export class SecurityMasterTabsModule {}
