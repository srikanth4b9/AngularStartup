import { Component } from '@angular/core';
import { NavLink } from '@app/shared/models';

@Component({
  selector: 'app-security-master-tabs',
  templateUrl: './security-master-tabs.component.html',
  styleUrls: ['./security-master-tabs.component.scss']
})
export class SecurityMasterTabsComponent {

  navLinks: NavLink[] = [
    {path: 'securities', label: 'Securities'},
    {path: 'directives', label: 'Directives'}
  ];

  constructor() { }

}
