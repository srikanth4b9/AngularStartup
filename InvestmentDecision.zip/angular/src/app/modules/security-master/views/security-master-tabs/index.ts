export * from './security-master-tabs.component';
export * from './security-master-tabs.module';
