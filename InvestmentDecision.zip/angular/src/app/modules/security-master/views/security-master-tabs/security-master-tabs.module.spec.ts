import { SecurityMasterTabsModule } from './security-master-tabs.module';

describe('SecurityMasterTabsModule', () => {
  let securityMasterTabsModule: SecurityMasterTabsModule;

  beforeEach(() => {
    securityMasterTabsModule = new SecurityMasterTabsModule();
  });

  it('should create an instance', () => {
    expect(securityMasterTabsModule).toBeTruthy();
  });
});
