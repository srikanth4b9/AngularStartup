import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SecurityMasterRoutingModule } from './security-master-routing.module';
import { SecurityMasterTabsModule } from './views';


@NgModule({
  imports: [
    CommonModule,
    SecurityMasterRoutingModule,
    SecurityMasterTabsModule
  ],
  declarations: []
})
export class SecurityMasterModule {}
