import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SecurityMasterTabsComponent } from '@security-master/views';

const routes: Routes = [
  {
    path: '',
    component: SecurityMasterTabsComponent,
    children: [
      {
        path: '',
        redirectTo: 'securities'
      },
      {
        path: 'securities',
        loadChildren: './modules/securities/securities.module#SecuritiesModule'
      },
      {
        path: 'directives',
        loadChildren: './modules/directives/directives.module#DirectivesModule'
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SecurityMasterRoutingModule { }
