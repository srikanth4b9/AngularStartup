import { SecurityMasterRoutingModule } from './security-master-routing.module';

describe('SecurityMasterRoutingModule', () => {
  let securityMasterRoutingModule: SecurityMasterRoutingModule;

  beforeEach(() => {
    securityMasterRoutingModule = new SecurityMasterRoutingModule();
  });

  it('should create an instance', () => {
    expect(securityMasterRoutingModule).toBeTruthy();
  });
});
