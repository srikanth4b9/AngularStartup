import { SecurityMasterModule } from './security-master.module';

describe('SecurityMasterModule', () => {
  let securityMasterModule: SecurityMasterModule;

  beforeEach(() => {
    securityMasterModule = new SecurityMasterModule();
  });

  it('should create an instance', () => {
    expect(securityMasterModule).toBeTruthy();
  });
});
