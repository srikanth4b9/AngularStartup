import { mockSecurities } from '@security-master/modules/securities/models';
import { mockDirectives } from '@security-master/modules/directives/models';
import { of } from 'rxjs';
import { } from 'jasmine';

export class MockSecurityMasterService {
  loadSecurityMaster = jasmine.createSpy().and.callFake(() => of({}));

  getSecurities = jasmine.createSpy().and.returnValue(of(mockSecurities));
  getSecurity = jasmine.createSpy().and.returnValue(of(mockSecurities[0]));
  saveSecurity = jasmine.createSpy().and.returnValue(of(true));
  refreshSecurities = jasmine.createSpy().and.returnValue(of(true));
  deactivateSecurity = jasmine.createSpy().and.returnValue(of(mockSecurities));
  reactivateSecurity = jasmine.createSpy().and.returnValue(of(mockSecurities));
  getSecurityByName = jasmine.createSpy().and.returnValue(of(mockSecurities[0]));


  getDirectives = jasmine.createSpy().and.returnValue(of(mockDirectives));
  getDirective = jasmine.createSpy().and.returnValue(of(mockDirectives[0]));
  saveDirective = jasmine.createSpy().and.returnValue(of(true));
  refreshDirectives = jasmine.createSpy().and.returnValue(of(mockDirectives));
  deactivateDirective = jasmine.createSpy().and.returnValue(of(mockDirectives[0]));
  reactivateDirective = jasmine.createSpy().and.returnValue(of(mockDirectives));
  getDirectiveyByName = jasmine.createSpy().and.returnValue(of(mockDirectives[0]));
}
