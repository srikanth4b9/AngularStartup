import { Injectable } from '@angular/core';
import { Directive } from '@security-master/modules/directives/models';
import { Security } from '@security-master/modules/securities/models';
import { Observable, of, forkJoin } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '@env';

import { RestService } from '@app/services';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class SecurityMasterService {
  portIdList: any;
  securities: Array<Security> = [];
  directives: Array<Directive> = [];

  constructor(private restService: RestService, private router: Router) { }

  isSecuritiesLoaded(): boolean {
    return this.securities && this.securities.length > 0;
  }

  isDirectivesLoaded(): boolean {
    return this.directives && this.directives.length > 0;
  }

  public getSecurities(refreshData?: boolean): Observable<Security[]> {
    if (!this.isSecuritiesLoaded() || refreshData) {
      return this.restService.getData<Security[]>(environment.SECURITIES, 'Load Securities')
        .pipe(
          map(data => this.securities = data)
        );
    } else {
      return of(this.securities);
    }
  }

  public getDirectives(refreshData?: boolean): Observable<Directive[]> {
    if (!this.isDirectivesLoaded() || refreshData) {
      return this.restService.getData<Directive[]>(environment.DIRECTIVES, 'Load Directives')
        .pipe(
          map(data => this.directives = data)
        );
    } else {
      return of(this.directives);
    }
  }

  public getSecurity(cusip: string): Observable<Security> {
    return this.getSecurities().pipe(
      map(
        securities => securities.filter(security => security.cusip === cusip)[0]
      )
    );
  }

  public getSecurityByName(name: string): Observable<Security> {
    return this.getSecurities().pipe(
      map(
        securities => securities.filter(security => security.name === name)[0]
      )
    );
  }

  public getDirective(id: number): Observable<Directive> {
    return this.getDirectives().pipe(
      map(
        directives => directives.filter(directive => directive.id === id)[0]
      )
    );
  }

  public getDirectiveyByName(name: string): Observable<Directive> {
    return this.getDirectives().pipe(
      map(
        directives => directives.filter(directive => directive.name === name)[0]
      )
    );
  }

  public loadSecurityMaster(): Observable<any> {
    return forkJoin([this.getDirectives(), this.getSecurities()]);
  }

  public refreshSecurities() {
    return this.getSecurities(true).subscribe(
      () => this.router.navigate(['/security-master/securities'])
    );
  }

  public refreshDirectives() {
    return this.getDirectives(true).subscribe(
      () => this.router.navigate(['/security-master/directives'])
      );
  }

  public saveSecurity(security: Security, isNewSecurity: boolean): Observable<any> {
    return isNewSecurity ?
      this.restService.postData<Security>(environment.SECURITIES, security, 'Save Security')
      : this.restService.putData<Security>(`${environment.SECURITIES}/${security.id}`, security, 'Save Security');
  }

  public saveDirective(directive: Directive, isNewDirective: boolean): Observable<any> {
    return isNewDirective ?
      this.restService.postData<Directive>(environment.DIRECTIVES, directive, 'Save Directive')
      : this.restService.putData<Directive>(`${environment.DIRECTIVES}/${directive.id}`, directive, 'Save Directive');
  }


  public deactivateSecurity(security: Security): void {
    const request = this.restService.deleteData<Security>(`${environment.SECURITIES}/${security.id}`,
      security, 'Deactivate Security');

      request.subscribe(() => this.refreshSecurities());
  }

  public reactivateSecurity(security: Security): void {
    const request = this.restService.postData<any>(`${environment.SECURITIES}/${security.id}`,
      security, 'Reactivate Security');

      request.subscribe(() => this.refreshSecurities());
  }

  public deactivateDirective(directive: Directive) {
    const request = this.restService.deleteData<Directive>(`${environment.DIRECTIVES}/${directive.id}`, directive, 'Deactivate Directive');

    request.subscribe(() => this.refreshDirectives());
  }

  public reactivateDirective(directive: Directive) {
    const request =  this.restService.postData<any>(`${environment.DIRECTIVES}/${directive.id}`, directive, 'Reactivate Directive');

    request.subscribe(() => this.refreshDirectives());
  }
}
