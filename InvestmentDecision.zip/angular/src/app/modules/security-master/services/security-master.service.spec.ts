import { TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import { environment } from '@env';

import { mockDirectives, Directive } from '@security-master/modules/directives/models';
import { mockSecurities, Security } from '@security-master/modules/securities/models';
import { RestService } from '@app/services';
import { SecurityMasterService } from './security-master.service';
import { RouterTestingModule } from '@angular/router/testing';
import { Router } from '@angular/router';


class MockRestService {
  getData = jasmine.createSpy().and.callFake((apiPath) => {
    if (apiPath === environment.SECURITIES) {
      return of(mockSecurities);
    } else if (apiPath === environment.DIRECTIVES) {
      return of(mockDirectives);
    } else {
      return of(null);
    }
  });
  postData = jasmine.createSpy().and.returnValue(of({}));
  putData = jasmine.createSpy().and.returnValue(of({}));
  deleteData = jasmine.createSpy().and.returnValue(of({}));
}

class MockRouter {
  navigate = jasmine.createSpy().and.returnValue(true);
}

describe('SecurityMasterService', () => {
  let service: SecurityMasterService;
  let restService: MockRestService;
  let isSecuritiesLoadedSpy: jasmine.Spy;
  let isDirectivesLoadedSpy: jasmine.Spy;
  let getSecuritiesSpy: jasmine.Spy;
  let getDirectivesSpy: jasmine.Spy;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [{ provide: RestService, useClass: MockRestService },
      { provide: Router, useClass: MockRouter }]
    });

    service = TestBed.get(SecurityMasterService);
    restService = TestBed.get(RestService);

    isSecuritiesLoadedSpy = spyOn(service, 'isSecuritiesLoaded').and.callThrough();
    isDirectivesLoadedSpy = spyOn(service, 'isDirectivesLoaded').and.callThrough();
    getSecuritiesSpy = spyOn(service, 'getSecurities').and.callThrough();
    getDirectivesSpy = spyOn(service, 'getDirectives').and.callThrough();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('isSecuritiesLoaded:', () => {
    it('should return false if securities are undefined', () => {
      service.securities = undefined;

      expect(service.isSecuritiesLoaded()).toBeFalsy();
    });

    it('should return false if securities are empty', () => {
      service.securities = [];

      expect(service.isSecuritiesLoaded()).toBeFalsy();
    });

    it('should return true if already loaded', () => {
      service.securities = mockSecurities;

      expect(service.isSecuritiesLoaded()).toBe(true);
    });
  });

  describe('isDirectivesLoaded:', () => {
    it('should return false if directives are undefined', () => {
      service.directives = undefined;

      expect(service.isDirectivesLoaded()).toBeFalsy();
    });

    it('should return false if directives are empty', () => {
      service.directives = [];

      expect(service.isDirectivesLoaded()).toBeFalsy();
    });

    it('should return true if already loaded', () => {
      service.directives = mockDirectives;

      expect(service.isDirectivesLoaded()).toBe(true);
    });
  });

  describe('getSecurities:', () => {
    it('should try to fetch the data if not loaded', () => {
      isSecuritiesLoadedSpy.and.returnValue(false);
      service.getSecurities().subscribe(data => {
        expect(data).toEqual(mockSecurities);
      });

      expect(isSecuritiesLoadedSpy).toHaveBeenCalled();
      expect(restService.getData).toHaveBeenCalledWith(environment.SECURITIES, 'Load Securities');
    });

    it('should try to fetch the data if refreshData is true', () => {
      isSecuritiesLoadedSpy.and.returnValue(true);
      service.getSecurities(true).subscribe(data => {
        expect(data).toEqual(mockSecurities);
      });

      expect(restService.getData).toHaveBeenCalledWith(environment.SECURITIES, 'Load Securities');
    });

    it('should return data directly if already loaded', () => {
      service.securities = mockSecurities;
      isSecuritiesLoadedSpy.and.returnValue(true);
      service.getSecurities().subscribe(data => {
        expect(data).toEqual(mockSecurities);
      });

      expect(restService.getData).not.toHaveBeenCalled();
    });
  });

  describe('getDirectives:', () => {
    it('should try to fetch the data if not loaded', () => {
      isDirectivesLoadedSpy.and.returnValue(false);
      service.getDirectives().subscribe(data => {
        expect(data).toEqual(mockDirectives);
      });

      expect(isDirectivesLoadedSpy).toHaveBeenCalled();
      expect(restService.getData).toHaveBeenCalledWith(environment.DIRECTIVES, 'Load Directives');
    });

    it('should try to fetch the data if refreshData is true', () => {
      isDirectivesLoadedSpy.and.returnValue(true);
      service.getDirectives(true).subscribe(data => {
        expect(data).toEqual(mockDirectives);
      });

      expect(restService.getData).toHaveBeenCalledWith(environment.DIRECTIVES, 'Load Directives');
    });

    it('should return data directly if already loaded', () => {
      service.directives = mockDirectives;
      isDirectivesLoadedSpy.and.returnValue(true);
      service.getDirectives().subscribe(data => {
        expect(data).toEqual(mockDirectives);
      });

      expect(restService.getData).not.toHaveBeenCalled();
    });
  });

  describe('getSecurity:', () => {
    beforeEach(() => {
      getSecuritiesSpy.and.returnValue(of(mockSecurities));
    });

    it('should return a security by cusip', () => {
      service.getSecurity('922906300').subscribe(security => {
        expect(security.name).toEqual('VG FEDERAL MONEY MARKET');
      });

      expect(getSecuritiesSpy).toHaveBeenCalled();
    });

    it('should return null if security cannot be found', () => {
      service.getSecurity('0000').subscribe(security => {
        expect(security).not.toBeDefined();
      });
    });
  });

  describe('getSecurityByName:', () => {
    beforeEach(() => {
      getSecuritiesSpy.and.returnValue(of(mockSecurities));
    });

    it('should return a security by name', () => {
      service.getSecurityByName('VG FEDERAL MONEY MARKET').subscribe(security => {
        expect(security.name).toEqual('VG FEDERAL MONEY MARKET');
      });

      expect(getSecuritiesSpy).toHaveBeenCalled();
    });

    it('should return null if security cannot be found', () => {
      service.getSecurityByName('1').subscribe(security => {
        expect(security).toEqual(undefined);
      });

      expect(getSecuritiesSpy).toHaveBeenCalled();
    });
  });

  describe('getDirective:', () => {
    beforeEach(() => {
      getDirectivesSpy.and.returnValue(of(mockDirectives));
    });

    it('should return a directive by id', () => {
      service.getDirective(26).subscribe(directive => {
        expect(directive.name).toEqual('CASH');
      });

      expect(getDirectivesSpy).toHaveBeenCalled();
    });

    it('should return null if directive cannot be found', () => {
      service.getDirective(1).subscribe(directive => {
        expect(directive).not.toBeDefined();
      });

      expect(getDirectivesSpy).toHaveBeenCalled();
    });
  });

  describe('getDirectiveyByName:', () => {
    beforeEach(() => {
      getDirectivesSpy.and.returnValue(of(mockDirectives));
    });

    it('should return a directive by name', () => {
      service.getDirectiveyByName('CASH').subscribe(directive => {
        expect(directive.id).toEqual(26);
      });

      expect(getDirectivesSpy).toHaveBeenCalled();
    });

    it('should return null if directive cannot be found', () => {
      service.getDirectiveyByName('UNKNOWN').subscribe(directive => {
        expect(directive).toEqual(undefined);
      });

      expect(getDirectivesSpy).toHaveBeenCalled();
    });
  });

  describe('loadSecurityMaster:', () => {
    it('should return Observable after getDirectives and getSecurities', () => {
      service.loadSecurityMaster().subscribe(() => {
        expect(getSecuritiesSpy).toHaveBeenCalled();
        expect(getDirectivesSpy).toHaveBeenCalled();
      });
    });
  });

  describe('refreshSecurities:', () => {
    it('should call getSecurities with refreshData flag', () => {
      service.refreshSecurities();

      expect(getSecuritiesSpy).toHaveBeenCalledWith(true);
    });
  });

  describe('refreshDirectives:', () => {
    it('should call getDirectives with refreshData flag', () => {
      service.refreshDirectives();

      expect(getDirectivesSpy).toHaveBeenCalledWith(true);
    });
  });

  describe('saveSecurity:', () => {
    it('should call the rest service to save a new security', () => {
      const security: Security = {
        accountingSecurityId: '123',
        name: 'New Security',
        cusip: '987654321',
        id: 5
      };
      service.saveSecurity(security, true);

      expect(restService.postData).toHaveBeenCalledWith(environment.SECURITIES, security, 'Save Security');
    });

    it('should call the rest service to save an existing security', () => {
      const security: Security = mockSecurities[0];
      service.saveSecurity(security, false);

      expect(restService.putData).toHaveBeenCalledWith(`${environment.SECURITIES}/${security.id}`, security, 'Save Security');
    });
  });

  describe('saveDirective:', () => {
    it('should call the rest service to save a new directive', () => {
      const directive: Directive = {
        name: 'New Directive'
      };
      service.saveDirective(directive, true);

      expect(restService.postData).toHaveBeenCalledWith(environment.DIRECTIVES, directive, 'Save Directive');
    });

    it('should call the rest service to save an existing directive', () => {
      const directive: Directive = mockDirectives[0];
      service.saveDirective(directive, false);

      expect(restService.putData).toHaveBeenCalledWith(`${environment.DIRECTIVES}/${directive.id}`, directive, 'Save Directive');
    });
  });

  describe('deactivate / reactivate security ', () => {
    const security: Security = {
      'accountingSecurityId': '33',
      'active': true,
      'crewUserId': 'U53X',
      'cusip': '922906300',
      'id': 295,
      'lastUpdatedTimestamp': '2019-09-04T08:50:56.927506-04:00',
      'name': 'VG FEDERAL MONEY MARKET'
    };
    it('should make a rest call to deactivate a security', () => {
      const refreshSpy = spyOn(service, 'refreshSecurities');

      service.deactivateSecurity(security);

      expect(restService.deleteData).toHaveBeenCalledWith(`${environment.SECURITIES}/${security.id}`, security, 'Deactivate Security');
      expect(refreshSpy).toHaveBeenCalled();
    });

    it('should make a rest call to reactivate a security', () => {
      const refreshSpy = spyOn(service, 'refreshSecurities');

      service.reactivateSecurity(security);

      expect(restService.postData).toHaveBeenCalledWith(`${environment.SECURITIES}/${security.id}`, security, 'Reactivate Security');
      expect(refreshSpy).toHaveBeenCalled();
    });
  });

  describe('deactivate / reactivate directive', () => {
    const directive: Directive = {
      'active': true,
      'crewUserId': 'UN9S',
      'id': 26,
      'lastUpdatedTimestamp': '2019-01-22T11:54:23.985-05:00',
      'name': 'CASH'
    };

    it('should make a rest call to deactivate a security', () => {
      const refreshSpy = spyOn(service, 'refreshDirectives');

      service.deactivateDirective(directive);

      expect(restService.deleteData).toHaveBeenCalledWith(`${environment.DIRECTIVES}/${directive.id}`, directive, 'Deactivate Directive');
      expect(refreshSpy).toHaveBeenCalled();
    });

    it('should make a rest call to reactivate a directive', () => {
      const refreshSpy = spyOn(service, 'refreshDirectives');

      service.reactivateDirective(directive);

      expect(restService.postData).toHaveBeenCalledWith(`${environment.DIRECTIVES}/${directive.id}`, directive, 'Reactivate Directive');
      expect(refreshSpy).toHaveBeenCalled();
    });
  });
});

