import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { MaterialModule } from '@app/shared/material.module';
import { ExportableReportModule, ActiveToggleModule } from '@app/shared/components';
import { SecuritiesViewComponent } from './securities-view.component';

@NgModule({
  declarations: [SecuritiesViewComponent],
  imports: [
    CommonModule,
    RouterModule,
    MaterialModule,
    ExportableReportModule,
    FontAwesomeModule,
    ActiveToggleModule
  ],
  exports: [SecuritiesViewComponent]
})
export class SecuritiesViewModule { }
