import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SecuritiesViewComponent, EditSecurityViewComponent } from './views';

const routes: Routes = [
  {
    path: '',
    component: SecuritiesViewComponent
  },
  {
    path: 'create',
    component: EditSecurityViewComponent
  },
  {
    path: 'edit/:cusip',
    component: EditSecurityViewComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SecuritiesRoutingModule { }
