import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SecuritiesRoutingModule } from './securities-routing.module';
import { SecuritiesViewModule, EditSecurityViewModule } from './views';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    SecuritiesRoutingModule,
    SecuritiesViewModule,
    EditSecurityViewModule
  ]
})
export class SecuritiesModule { }
