import { SecuritiesRoutingModule } from './securities-routing.module';

describe('SecuritiesRoutingModule', () => {
    let securitiesRoutingModule: SecuritiesRoutingModule;

    beforeEach(() => {
        securitiesRoutingModule = new SecuritiesRoutingModule();
    });

    it('should create an instance', () => {
        expect(securitiesRoutingModule).toBeTruthy();
    });
});
