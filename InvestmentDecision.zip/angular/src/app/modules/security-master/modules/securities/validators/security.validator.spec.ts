import { TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import { mockSecurities } from '../models';
import { SecurityMasterService } from '@security-master/services';

import { SecurityValidator } from './security.validator';

class MockSecurityMasterService {
  getSecurities() {
    return of(mockSecurities);
  }
}

describe('SecurityValidator', () => {
  let validator: SecurityValidator;
  let securityMasterService: SecurityMasterService;
  let getDirectivesSpy: jasmine.Spy;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: SecurityMasterService, useClass: MockSecurityMasterService },
        SecurityValidator
      ]
    });

    validator = TestBed.get(SecurityValidator);
    securityMasterService = TestBed.get(SecurityMasterService);
    getDirectivesSpy = spyOn(securityMasterService, 'getSecurities')
      .and.returnValue(of(mockSecurities));
  });

  it('should be created', () => {
    expect(validator).toBeTruthy();
  });

  describe('checkIfAttributeValueExists:', () => {
    it('should return true if security name already exists', () => {
      validator.checkIfAttributeValueExists('name', 'VG FEDERAL MONEY MARKET').subscribe(
        response => expect(response).toBeTruthy()
      );

      expect(getDirectivesSpy).toHaveBeenCalled();
    });

    it('should return false if security name is unique', () => {
      validator.checkIfAttributeValueExists('name', 'NEW SECURITY').subscribe(
        response => expect(response).toBeFalsy()
      );

      expect(getDirectivesSpy).toHaveBeenCalled();
    });
  });
});
