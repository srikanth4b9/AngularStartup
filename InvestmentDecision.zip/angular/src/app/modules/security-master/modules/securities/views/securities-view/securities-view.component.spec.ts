import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ActivatedRoute, Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { ActiveToggleModule, ExportableReportModule } from '@app/shared/components';
import { MaterialModule } from '@app/shared/material.module';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { mockSecurities, Security } from '@security-master/modules/securities/models';
import { MockSecurityMasterService, SecurityMasterService } from '@security-master/services';

import { SecuritiesViewComponent } from './securities-view.component';
import { ActionRequest, ACTION } from '@app/shared/models';


describe('SecuritiesViewComponent', () => {
  let component: SecuritiesViewComponent;
  let fixture: ComponentFixture<SecuritiesViewComponent>;
  let router: Router;
  let route: ActivatedRoute;
  let securityMasterService: SecurityMasterService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule,
        RouterTestingModule,
        MaterialModule,
        ExportableReportModule,
        FontAwesomeModule,
        ActiveToggleModule
      ],
      declarations: [SecuritiesViewComponent],
      providers: [
        { provide: SecurityMasterService, useClass: MockSecurityMasterService }
      ]
    })
      .compileComponents();

    router = TestBed.get(Router);
    route = TestBed.get(ActivatedRoute);
    securityMasterService = TestBed.get(SecurityMasterService);
  });

  function createComponent() {
    fixture = TestBed.createComponent(SecuritiesViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  beforeEach(() => {
    createComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('ngOnInit:', () => {
    it('should call loadSecurities', () => {
      const loadSecuritiesSpy = spyOn(component, 'loadSecurities');

      component.ngOnInit();

      expect(loadSecuritiesSpy).toHaveBeenCalled();
    });
  });

  describe('loadSecurities:', () => {
    let expectedSecurities: Security[];
    beforeEach(function() {
      expectedSecurities = mockSecurities.map(security => new Security(security));
    });

    it('should call securityMasterService to load securities', () => {
      component.loadSecurities();

      expect(securityMasterService.getSecurities).toHaveBeenCalledWith(false);
      expect(component.securities).toEqual(expectedSecurities);
    });

    it('should call securityMasterService with refreshFlag to load securities', () => {
      component.loadSecurities(true);

      expect(securityMasterService.getSecurities).toHaveBeenCalledWith(true);
      expect(component.securities).toEqual(expectedSecurities);
    });
  });

  describe('action:', () => {
    it('should navigate to edit security route for EDIT action', () => {
      const security: Security = mockSecurities[0];
      const navigateSpy = spyOn(router, 'navigate');

      component.action(new ActionRequest(ACTION.EDIT, security));

      expect(navigateSpy).toHaveBeenCalledWith(['../edit', security.cusip], { relativeTo: route });
    });
  });

  describe('filter securities', () => {
    it('should filter securities  with active flag', () => {
      component.isActive = false;

      component.securities = mockSecurities;
      component.filterSecurities();

      expect(component.filteredSecurities.length).toEqual(0);
    });
  });
});
