import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { MaterialModule } from '@app/shared/material.module';
import { EditSecurityViewComponent } from './edit-security-view.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SecurityValidator } from '@security-master/modules/securities/validators';
import { MatSnackBarModule } from '@angular/material';
import { PortIdSelectModule } from '@app/shared/components/port-id-select';

@NgModule({
  declarations: [EditSecurityViewComponent],
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    MatSnackBarModule,
    FontAwesomeModule,
    PortIdSelectModule
  ],
  exports: [EditSecurityViewComponent],
  providers: [SecurityValidator]
})
export class EditSecurityViewModule { }
