import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, AbstractControl, Validators, ValidationErrors } from '@angular/forms';
import { map } from 'rxjs/operators';
import { faPlusCircle } from '@fortawesome/free-solid-svg-icons';

import { Security, securityAttributeMap } from '@security-master/modules/securities/models';
import { SecurityMasterService } from '@security-master/services';
import { SecurityValidator } from '@security-master/modules/securities/validators';
import { Observable, of } from 'rxjs';
import { ConfirmDialogModel } from '@app/shared/models';
import { MatDialog } from '@angular/material';
import { ConfirmDialogComponent } from '@app/components';
import { FormUtils } from '@app/modules/fund-maintenance/models';

const MIN_CUSIP = 9;
const MAX_SECURITY_ID = 20;
@Component({
  selector: 'app-edit-security-view',
  templateUrl: './edit-security-view.component.html',
  styleUrls: ['./edit-security-view.component.scss']
})
export class EditSecurityViewComponent implements OnInit {
  isNewSecurity: boolean = true;
  security: Security = new Security(undefined);
  securityForm: FormGroup = this.createFormGroup();

  filteredIndirectPortIds: Observable<string[]>;
  indirectPortIds: string[] = [];

  faPlusCircle = faPlusCircle;
  FormUtils = FormUtils;

  confirmDialogData: ConfirmDialogModel = {
    title: 'Are You Sure?',
    confirmButtonText: 'Continue'
  };

  constructor(
    private securityMasterService: SecurityMasterService,
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private securityValidator: SecurityValidator,
    private dialog: MatDialog) {
  }

  ngOnInit() {
    const cusip: string = this.route.snapshot.params.cusip;
    if (cusip) {
      this.loadSecurity(cusip);
    }
  }
  createFormGroup() {
    return this.formBuilder.group({
      id: [this.security.id],
      name: [this.security.name, [], [this.validateAttributeValueExists.bind(this, 'name')]],
      cusip: [
        this.security.cusip,
        [Validators.minLength(MIN_CUSIP), Validators.pattern('^[a-zA-Z0-9]{0,20}$')],
        [this.validateAttributeValueExists.bind(this, 'cusip')]
      ],
      accountingSecurityId: [
        this.security.accountingSecurityId,
        [Validators.maxLength(MAX_SECURITY_ID), Validators.pattern('^[a-zA-Z0-9]{0,20}$')],
        [this.validateAttributeValueExists.bind(this, 'accountingSecurityId')]
      ],
      indirectPortId: [this.security.indirectPortId],
      fundCompany: [this.security.fundCompany],
      transferAgentId: [this.security.transferAgentId],
      active: [this.security.active]
    });
  }

  get name() { return this.securityForm.get('name'); }
  get cusip() { return this.securityForm.get('cusip'); }
  get accountingSecurityId() { return this.securityForm.get('accountingSecurityId'); }
  get active() { return this.securityForm.get('active'); }

  loadSecurity(cusip: string) {
    this.securityMasterService.getSecurity(cusip).subscribe(
      security => {
        this.security = security;
        this.isNewSecurity = false;
        this.securityForm = this.createFormGroup();
      }
    );
  }

  validateAttributeValueExists(attributeName: string, control: AbstractControl): Observable<ValidationErrors> {
    if (!control.pristine && this.isControlDirty(control, attributeName)) {
      return this.securityValidator.checkIfAttributeValueExists(attributeName, control.value)
        .pipe(map(
          (response: boolean) => response ? { valueExists: attributeName } : null
        ));
    }
    return of(null);
  }

  showConfirmDialog(action) {
    this.confirmDialogData.message = `Are you sure you want to ${action} this security?`;
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      hasBackdrop: true,
      data: this.confirmDialogData
    });

    dialogRef.afterClosed().subscribe(data => {
      if (data === 'confirm') {
        (action === 'deactivate') ? this.deactivateSecurity() : this.reactivateSecurity();
      }
    });
  }

  saveSecurity(): void {
    this.securityMasterService.saveSecurity(this.securityForm.value, this.isNewSecurity).subscribe(
      () => this.securityMasterService.refreshSecurities()
    );
  }

  getValidationErrorMessage(control: AbstractControl): string {
    return control.errors.valueExists ? `${securityAttributeMap[control.errors.valueExists]} already exists` :
      control.errors.pattern ? 'No special characters' :
        control.errors.minlength ? `Must be at least ${control.errors.minlength.requiredLength} characters` :
          control.errors.required ? 'Please enter a value' :
            '';
  }



  isFormDirty() {
    return FormUtils.isFormDirty(this.securityForm, this.security);
  }

  isFieldDirty(attributeName: string) {
    return this.isControlDirty(this.securityForm.get(attributeName), attributeName);
  }

  isControlDirty(control: AbstractControl, attributeName: string) {
    return control.value !== this.security[attributeName];
  }

  deactivateSecurity(): void {
    this.securityMasterService.deactivateSecurity(this.securityForm.getRawValue());
  }

  reactivateSecurity(): void {
    this.securityMasterService.reactivateSecurity(this.securityForm.getRawValue());
  }
}
