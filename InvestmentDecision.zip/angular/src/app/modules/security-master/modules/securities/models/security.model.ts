import { ColumnDefBuilder, ColumnType, TableDef } from '@app/shared/models';
import { Directive } from '../../directives/models';

export class Security extends Directive {
  accountingSecurityId: string;
  cusip: string;
  indirectPortId?: string;
  fundCompany?: string;
  transferAgentId?: string;

  constructor(security: Security) {
    super(security);
    if (security) {
      this.accountingSecurityId = security.accountingSecurityId;
      this.cusip = security.cusip;
      this.indirectPortId = security.indirectPortId;
      this.fundCompany = security.fundCompany;
      this.transferAgentId = security.transferAgentId;
    }
  }
}

export const securityAttributeMap = {
  name: 'Security Name',
  cusip: 'CUSIP',
  accountingSecurityId: 'Accounting Security ID'
};

export const securitiesTableDef: TableDef = new TableDef(
  [
    new ColumnDefBuilder('Accounting Security ID', 'accountingSecurityId', ColumnType.STRING).editable().build(),
    new ColumnDefBuilder('Name', 'name', ColumnType.STRING).editable().build(),
    new ColumnDefBuilder('CUSIP', 'cusip', ColumnType.STRING).editable().build(),
    new ColumnDefBuilder('Indirect Port ID', 'indirectPortId', ColumnType.STRING).editable().build(),
    new ColumnDefBuilder('Fund Company', 'fundCompany', ColumnType.STRING).editable().build(),
    new ColumnDefBuilder('Transfer Agent ID', 'transferAgentId', ColumnType.STRING).editable().build(),
    new ColumnDefBuilder('Last Updated User', 'crewUserId', ColumnType.STRING).build(),
    new ColumnDefBuilder('Last Updated Timestamp', 'lastUpdatedTimestamp', ColumnType.TIMESTAMP).build()
  ],
  true
);
