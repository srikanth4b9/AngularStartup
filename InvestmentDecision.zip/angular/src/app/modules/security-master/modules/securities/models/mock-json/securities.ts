import { Security } from '@security-master/modules/securities/models';

export const mockSecurities: Security[] = [


  {
    'accountingSecurityId': '33',
    'active' : true,
    'crewUserId' : 'U53X',
    'cusip' : '922906300',
    'id' : 295,
    'lastUpdatedTimestamp' : '2019-09-04T08:50:56.927506-04:00',
    'name' : 'VG FEDERAL MONEY MARKET'
  },
  {
    'accountingSecurityId': '33',
    'active' : true,
    'crewUserId' : 'U53X',
    'cusip' : '922906300',
    'id' : 295,
    'lastUpdatedTimestamp' : '2019-09-04T08:50:56.927506-04:00',
    'name' : 'VG FEDERAL MONEY MARKET'
  },
  {
    'accountingSecurityId': '33',
    'active' : true,
    'crewUserId' : 'U53X',
    'cusip' : '922906300',
    'id' : 295,
    'lastUpdatedTimestamp' : '2019-09-04T08:50:56.927506-04:00',
    'name' : 'VG FEDERAL MONEY MARKET'
  },
  {
    'accountingSecurityId': '33',
    'active' : true,
    'crewUserId' : 'U53X',
    'cusip' : '922906300',
    'id' : 295,
    'lastUpdatedTimestamp' : '2019-09-04T08:50:56.927506-04:00',
    'name' : 'VG FEDERAL MONEY MARKET'
  }];
