import { Injectable } from '@angular/core';
import { SecurityMasterService } from '@security-master/services';

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Security } from '@security-master/modules/securities/models';

@Injectable()
export class SecurityValidator {

  constructor(private securityMasterService: SecurityMasterService) { }

  checkIfAttributeValueExists(attributeName: string, attributeValue: any): Observable<boolean> {
    return this.securityMasterService.getSecurities().pipe(
      map(securities => {
        return this.isExisting(securities, attributeName, attributeValue);
      })
    );
  }

  private isExisting(securities: Security[], attributeName: string, attributeValue: any): boolean {
    return securities.filter(security => security[attributeName] === attributeValue).length > 0;
  }
}
