import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDialog, MatDialogModule } from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { FundMaintenanceService } from '@app/modules/fund-maintenance/services';
import { MockFundMaintenanceService } from '@app/modules/fund-maintenance/services/fund-maintenance.service.mock';
import { MaterialModule } from '@app/shared/material.module';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { mockSecurities, Security } from '@security-master/modules/securities/models';
import { MockSecurityValidator, SecurityValidator } from '@security-master/modules/securities/validators';
import { MockSecurityMasterService, SecurityMasterService } from '@security-master/services';
import { PortIdSelectModule } from '@shared/components';
import { EMPTY, of } from 'rxjs';

import { EditSecurityViewComponent } from './edit-security-view.component';

class MockActivatedRoute {
  snapshot = { params: { cusip: undefined } };
}

class MockDialog {
  open = jasmine.createSpy();
}

describe('EditSecurityViewComponent', () => {
  let component: EditSecurityViewComponent;
  let fixture: ComponentFixture<EditSecurityViewComponent>;
  let activatedRoute: MockActivatedRoute;
  let securityMasterService: MockSecurityMasterService;
  let securityValidator: MockSecurityValidator;
  let dialog: MockDialog;

  let loadSecuritySpy: jasmine.Spy;

  beforeEach(() => {
    activatedRoute = new MockActivatedRoute();

    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule,
        RouterTestingModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule,
        FontAwesomeModule,
        PortIdSelectModule,
        MatDialogModule
      ],
      declarations: [EditSecurityViewComponent],
      providers: [
        { provide: FundMaintenanceService, useClass: MockFundMaintenanceService },
        { provide: SecurityMasterService, useClass: MockSecurityMasterService },
        { provide: ActivatedRoute, useValue: activatedRoute },
        { provide: SecurityValidator, useClass: MockSecurityValidator },
        { provide: MatDialog, useClass: MockDialog }
      ]
    })
      .compileComponents();

    securityMasterService = TestBed.get(SecurityMasterService);
    securityValidator = TestBed.get(SecurityValidator);
    dialog = TestBed.get(MatDialog);
  });

  function createComponent() {
    fixture = TestBed.createComponent(EditSecurityViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    loadSecuritySpy = spyOn(component, 'loadSecurity').and.callThrough();
  }

  it('should create', () => {
    createComponent();
    expect(component).toBeTruthy();
  });

  describe('ngOnInit:', () => {
    it('should not call loadSecurity if no route param exists', () => {
      createComponent();
      loadSecuritySpy.and.stub();

      component.ngOnInit();

      expect(loadSecuritySpy).not.toHaveBeenCalled();
    });

    it('should call loadSecurity if a cusip exists in the route params', () => {
      const routeID = '99009913570';
      activatedRoute.snapshot.params.cusip = routeID;
      createComponent();
      loadSecuritySpy.and.stub();

      component.ngOnInit();

      expect(loadSecuritySpy).toHaveBeenCalledWith(routeID);
    });
  });

  describe('createFormGroup:', () => {
    it('should call FormBuilder to create security form', () => {
      createComponent();
      component.security = mockSecurities[0];
      const formGroup = component.createFormGroup();

      expect(formGroup.get('id').value).toEqual(mockSecurities[0].id);
      expect(formGroup.get('name').value).toEqual(mockSecurities[0].name);
      expect(formGroup.get('cusip').value).toEqual(mockSecurities[0].cusip);
      expect(formGroup.get('accountingSecurityId').value).toEqual(mockSecurities[0].accountingSecurityId);
      expect(formGroup.get('indirectPortId').value).toBeNull();
    });
  });

  describe('loadSecurity:', () => {
    it('should call securityMasterService to load security', () => {
      createComponent();
      const formGroup: FormGroup = new FormGroup({});
      const createFormGroupSpy = spyOn(component, 'createFormGroup')
        .and.returnValue(formGroup);

      component.loadSecurity(mockSecurities[0].cusip);

      expect(securityMasterService.getSecurity).toHaveBeenCalledWith(mockSecurities[0].cusip);
      expect(component.security).toEqual(mockSecurities[0]);
      expect(component.isNewSecurity).toEqual(false);
      expect(createFormGroupSpy).toHaveBeenCalled();
      expect(component.securityForm).toEqual(formGroup);
    });
  });

  describe('validateAttributeValueExists:', () => {
    const attributeName: string = 'name';
    let control: FormControl;
    let isControlDirtySpy: jasmine.Spy;

    beforeEach(() => {
      control = new FormControl('SECURITY NAME');
      createComponent();
      isControlDirtySpy = spyOn(component, 'isControlDirty').and.returnValue(true);
    });

    it('should return null if the form control is pristine', () => {
      control.markAsPristine();

      component.validateAttributeValueExists(attributeName, control).subscribe(response => {
        expect(response).toBeNull();
        expect(securityValidator.checkIfAttributeValueExists).not.toHaveBeenCalled();
      });
    });

    it('should return null if the form control value is not dirty', () => {
      isControlDirtySpy.and.returnValue(false);

      component.validateAttributeValueExists(attributeName, control).subscribe(response => {
        expect(response).toBeNull();
        expect(securityValidator.checkIfAttributeValueExists).not.toHaveBeenCalled();
      });
    });

    it('should return a validation error if the attribute value exists', () => {
      control.markAsDirty();
      securityValidator.checkIfAttributeValueExists.and.returnValue(of(true));

      component.validateAttributeValueExists(attributeName, control).subscribe(response => {
        expect(response).toEqual({ valueExists: attributeName });
        expect(securityValidator.checkIfAttributeValueExists).toHaveBeenCalledWith(attributeName, control.value);
      });
    });

    it('should return a null if the attribute value does not exist', () => {
      control.markAsDirty();
      securityValidator.checkIfAttributeValueExists.and.returnValue(of(false));

      component.validateAttributeValueExists(attributeName, control).subscribe(response => {
        expect(response).toEqual(null);
        expect(securityValidator.checkIfAttributeValueExists).toHaveBeenCalledWith(attributeName, control.value);
      });
    });
  });

  describe('saveSecurity:', () => {
    let expectedSecurity: Security;

    beforeEach(() => {
      createComponent();
      component.isNewSecurity = false;
      expectedSecurity = {
        id: 5,
        name: 'NEW NAME',
        cusip: '999478371',
        accountingSecurityId: '173',
        indirectPortId: null,
        fundCompany: 'VANGUARD',
        transferAgentId: null,
        active: true
      };
      component.securityForm.setValue(expectedSecurity);
    });

    it('should navigate to securities view and display snackBar message after a successful request', () => {
      securityMasterService.saveSecurity.and.returnValue(of(true));

      component.saveSecurity();

      expect(securityMasterService.saveSecurity).toHaveBeenCalledWith(expectedSecurity, component.isNewSecurity);
    });
    it('should display snackBar message after a failed request', () => {
      securityMasterService.saveSecurity.and.returnValue(of(new Error('ERROR')));

      component.saveSecurity();

      expect(securityMasterService.saveSecurity).toHaveBeenCalledWith(expectedSecurity, component.isNewSecurity);
    });
  });

  describe('getValidationErrorMessage:', () => {
    it('should display message for valueExists validation error', () => {
      createComponent();
      const control = new FormControl();
      control.setErrors({ valueExists: 'accountingSecurityId' });

      expect(component.getValidationErrorMessage(control)).toEqual('Accounting Security ID already exists');
    });

    it('should display message for minlength validation error', () => {
      createComponent();
      const control = new FormControl();
      control.setErrors({ minlength: { requiredLength: 9 } });

      expect(component.getValidationErrorMessage(control)).toEqual('Must be at least 9 characters');
    });

    it('should display message for required validation error', () => {
      createComponent();
      const control = new FormControl();
      control.setErrors({ required: true });

      expect(component.getValidationErrorMessage(control)).toEqual('Please enter a value');
    });

    it('should display message for special characters', () => {
      createComponent();
      const control = new FormControl();
      control.setErrors({ pattern: ('^[a-zA-Z0-9]{0,20}$') });

      expect(component.getValidationErrorMessage(control)).toEqual('No special characters');
    });

    it('should not display message if no errors are present', () => {
      createComponent();
      const control = new FormControl();
      control.setErrors({});

      expect(component.getValidationErrorMessage(control)).toEqual('');
    });
  });

  describe('isFieldDirty:', () => {
    it('should return true if field is in dirty state', () => {
      createComponent();
      const attributeName = 'cusip';
      const isControlDirtySpy = spyOn(component, 'isControlDirty').and.returnValue(true);

      const result = component.isFieldDirty(attributeName);

      expect(isControlDirtySpy).toHaveBeenCalledWith(component.securityForm.get(attributeName), attributeName);
      expect(result).toEqual(true);
    });
  });

  describe('isControlDirty:', () => {
    const attributeName = 'cusip';
    let control: FormControl;
    beforeEach(() => {
      createComponent();
      component.security = mockSecurities[0];
    });
    it('should return true if control is in dirty state', () => {
      control = new FormControl('NEW CUSIP');

      expect(component.isControlDirty(control, attributeName)).toEqual(true);
    });

    it('should return false if control is not in dirty state', () => {
      control = new FormControl(mockSecurities[0].cusip);

      expect(component.isControlDirty(control, attributeName)).toEqual(false);
    });
  });

  describe('reactivateSecurity', () => {
    it('should reactivate security', () => {
      createComponent();
      component.reactivateSecurity();
      expect(securityMasterService.reactivateSecurity).toHaveBeenCalled();
    });
  });

  describe('deactivateSecurity', () => {
    it('should deactivate security', () => {
      const routeID = '99009913570';
      activatedRoute.snapshot.params.cusip = routeID;

      createComponent();

      component.deactivateSecurity();
      expect(securityMasterService.deactivateSecurity).toHaveBeenCalled();
    });
  });

  describe('showConfirmDialog', () => {

    it('should show the message dialog when user clicks deactivate', () => {
      securityMasterService.deactivateSecurity.and.returnValue(of(EMPTY));
      createComponent();
      dialog.open.and.returnValue({
        afterClosed: () => of('confirm')
      });
      component.showConfirmDialog('deactivate');
      expect(securityMasterService.deactivateSecurity).toHaveBeenCalled();
    });

    it('should show the message dialog when user clicks reactivate', () => {
      securityMasterService.reactivateSecurity.and.returnValue(of(EMPTY));
      createComponent();
      dialog.open.and.returnValue({
        afterClosed: () => of('confirm')
      });
      component.showConfirmDialog('reactivate');
      expect(securityMasterService.reactivateSecurity).toHaveBeenCalled();
    });
  });
});
