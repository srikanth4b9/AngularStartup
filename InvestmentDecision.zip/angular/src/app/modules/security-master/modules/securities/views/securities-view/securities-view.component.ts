import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { faPlusCircle } from '@fortawesome/free-solid-svg-icons';

import { Security, securitiesTableDef } from '@security-master/modules/securities/models';
import { SecurityMasterService } from '@security-master/services';
import { ActionRequest, ACTION } from '@app/shared/models';

@Component({
  selector: 'app-securities-view',
  templateUrl: './securities-view.component.html',
  styleUrls: ['./securities-view.component.scss']
})
export class SecuritiesViewComponent implements OnInit {
  securitiesTableDef = securitiesTableDef;
  securities: Security[] = [];
  filteredSecurities: Security[] = [];
  isActive = true;

  faPlusCircle = faPlusCircle;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private securityMasterService: SecurityMasterService) { }

  ngOnInit() {
    this.loadSecurities();
  }

  loadSecurities(refreshFlag: boolean = false) {
    this.securityMasterService.getSecurities(refreshFlag).subscribe(
      data => {
        this.securities = data.map(security => new Security(security));
        this.filterSecurities();
      });
  }

  action(actionRequest: ActionRequest) {
    if (actionRequest.action === ACTION.EDIT) {
      this.router.navigate(['../edit', actionRequest.object.cusip], { relativeTo: this.route });
    }
  }

  filterSecurities() {
    this.filteredSecurities = this.securities.filter(security => {
      const isSecurityActive: boolean = security.active;
      return this.isActive ? isSecurityActive : !isSecurityActive;
    });
  }
}
