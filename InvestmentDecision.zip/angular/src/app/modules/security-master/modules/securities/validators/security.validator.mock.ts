import { of } from 'rxjs';
import { } from 'jasmine';

export class MockSecurityValidator {
  checkIfAttributeValueExists = jasmine.createSpy().and.returnValue(of(false));
}
