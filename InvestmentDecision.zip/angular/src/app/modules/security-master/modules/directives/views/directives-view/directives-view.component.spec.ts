import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ActivatedRoute, Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { ActiveToggleModule, ExportableReportModule } from '@app/shared/components';
import { MaterialModule } from '@app/shared/material.module';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { Directive, mockDirectives } from '@security-master/modules/directives/models';
import { MockSecurityMasterService, SecurityMasterService } from '@security-master/services';

import { DirectivesViewComponent } from './directives-view.component';
import { ActionRequest, ACTION } from '@app/shared/models';


describe('DirectivesViewComponent', () => {
  let component: DirectivesViewComponent;
  let fixture: ComponentFixture<DirectivesViewComponent>;
  let router: Router;
  let route: ActivatedRoute;
  let securityMasterService: SecurityMasterService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule,
        RouterTestingModule,
        MaterialModule,
        ExportableReportModule,
        FontAwesomeModule,
        ActiveToggleModule
      ],
      declarations: [DirectivesViewComponent],
      providers: [
        { provide: SecurityMasterService, useClass: MockSecurityMasterService }
      ]
    })
      .compileComponents();

    router = TestBed.get(Router);
    route = TestBed.get(ActivatedRoute);
    securityMasterService = TestBed.get(SecurityMasterService);
  });

  function createComponent() {
    fixture = TestBed.createComponent(DirectivesViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  beforeEach(() => {
    createComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('ngOnInit:', () => {
    it('should call loadDirectives', () => {
      const loadDirectivesSpy = spyOn(component, 'loadDirectives');

      component.ngOnInit();

      expect(loadDirectivesSpy).toHaveBeenCalled();
    });
  });

  describe('loadDirectives:', () => {
    it('should call securityMasterService to load directives', () => {
      const expectedDirectives = mockDirectives.map(directive => new Directive(directive));

      component.loadDirectives();

      expect(securityMasterService.getDirectives).toHaveBeenCalled();
      expect(component.directives).toEqual(expectedDirectives);
    });
  });

  describe('action:', () => {
    it('should navigate to edit directive route for EDIT action', () => {
      const directive: Directive = mockDirectives[0];
      const navigateSpy = spyOn(router, 'navigate');

      component.action(new ActionRequest(ACTION.EDIT, directive));

      expect(navigateSpy).toHaveBeenCalledWith(['../edit', directive.id], { relativeTo: route });
    });
  });

  describe('filterDirectives', () => {
    it('should filter directives with active flag', () => {
      component.isActive = false;

      component.filterDirectives();

      expect(component.filteredDirectives).toEqual([]);
    });
  });

});
