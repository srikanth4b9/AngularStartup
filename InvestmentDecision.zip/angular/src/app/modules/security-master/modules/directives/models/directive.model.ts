import { ColumnDefBuilder, ColumnType, TableDef, ACTION } from '@app/shared/models';
import { BehaviorSubject, Observable } from 'rxjs';

export class Directive {
  id?: number;
  name: string;
  crewUserId?: string;
  lastUpdatedTimestamp?: string;
  active?: boolean = true;

  private readonly actionOptions?: BehaviorSubject<ACTION[]>;
  actionOptions$?: Observable<ACTION[]>;

  constructor(directive: Directive) {
    if (directive) {
      this.id = directive.id;
      this.name = directive.name;
      this.crewUserId = directive.crewUserId;
      this.lastUpdatedTimestamp = directive.lastUpdatedTimestamp;
      this.active = directive.active;
    }

    this.actionOptions = new BehaviorSubject([ACTION.EDIT]);
    this.actionOptions$ = this.actionOptions.asObservable();
  }
}

export const directivesTableDef: TableDef = new TableDef(
  [
    new ColumnDefBuilder('Name', 'name', ColumnType.STRING).editable().build(),
    new ColumnDefBuilder('Last Updated User', 'crewUserId', ColumnType.STRING).build(),
    new ColumnDefBuilder('Last Updated Timestamp', 'lastUpdatedTimestamp', ColumnType.TIMESTAMP).build()
  ],
  true
);
