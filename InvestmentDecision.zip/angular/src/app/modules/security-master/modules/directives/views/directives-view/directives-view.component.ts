import { Component, OnInit } from '@angular/core';
import { faPlusCircle } from '@fortawesome/free-solid-svg-icons';

import { Directive, directivesTableDef } from '@security-master/modules/directives/models';
import { SecurityMasterService } from '@security-master/services';
import { Router, ActivatedRoute } from '@angular/router';
import { ActionRequest, ACTION } from '@app/shared/models';

@Component({
  selector: 'app-directives-view',
  templateUrl: './directives-view.component.html',
  styleUrls: ['./directives-view.component.scss']
})
export class DirectivesViewComponent implements OnInit {
  directivesTableDef = directivesTableDef;
  directives: Directive[] = [];
  filteredDirectives: Directive[] = [];

  isActive = true;

  faPlusCircle = faPlusCircle;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private securityMasterService: SecurityMasterService) { }

  ngOnInit() {
    this.loadDirectives();
  }

  loadDirectives() {
    this.securityMasterService.getDirectives().subscribe(
      data => {
        this.directives = data.map(directive => new Directive(directive));
        this.filterDirectives();
      });
  }

  action(actionRequest: ActionRequest) {
    if (actionRequest.action === ACTION.EDIT) {
      this.router.navigate(['../edit', actionRequest.object.id], { relativeTo: this.route });
    }
  }

  filterDirectives() {
    this.filteredDirectives = this.directives.filter(directive => {
      const isDirectiveActive: boolean = directive.active;
      return this.isActive ? isDirectiveActive : !isDirectiveActive;
    });
  }

}
