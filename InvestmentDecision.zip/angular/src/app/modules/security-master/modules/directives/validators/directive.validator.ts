import { Injectable } from '@angular/core';
import { SecurityMasterService } from '@security-master/services';
import { Directive } from '@security-master/modules/directives/models';

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable()
export class DirectiveValidator {

  constructor(private securityMasterService: SecurityMasterService) { }

  checkIfDirectiveNameExists(name: string): Observable<boolean> {
    return this.securityMasterService.getDirectives().pipe(
      map(directives => {
        return this.isExisitingDirective(directives, name);
      })
    );
  }

  private isExisitingDirective(directives: Directive[], name: string): boolean {
    return directives.filter(directive => directive.name === name).length > 0;
  }
}
