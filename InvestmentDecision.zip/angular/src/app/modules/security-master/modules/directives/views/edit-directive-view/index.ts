export * from './edit-directive-view.component';
export * from './edit-directive-view.module';
