import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDialog, MatDialogModule } from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { MaterialModule } from '@app/shared/material.module';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { Directive, mockDirectives } from '@security-master/modules/directives/models';
import { DirectiveValidator, MockDirectiveValidator } from '@security-master/modules/directives/validators';
import { MockSecurityMasterService, SecurityMasterService } from '@security-master/services';
import { EMPTY, of } from 'rxjs';

import { EditDirectiveViewComponent } from './edit-directive-view.component';

class MockActivatedRoute {
  snapshot = { params: { id: undefined } };
}

class MockDialog {
  open = jasmine.createSpy();
}
describe('EditDirectiveViewComponent', () => {
  let component: EditDirectiveViewComponent;
  let fixture: ComponentFixture<EditDirectiveViewComponent>;
  let activatedRoute: MockActivatedRoute;
  let securityMasterService: MockSecurityMasterService;
  let directiveValidator: MockDirectiveValidator;
  let dialog: MockDialog;

  let loadDirectiveSpy: jasmine.Spy;

  beforeEach(() => {
    activatedRoute = new MockActivatedRoute();

    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule,
        RouterTestingModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule,
        FontAwesomeModule,
        MatDialogModule
      ],
      declarations: [EditDirectiveViewComponent],
      providers: [
        { provide: SecurityMasterService, useClass: MockSecurityMasterService },
        { provide: ActivatedRoute, useValue: activatedRoute },
        { provide: DirectiveValidator, useClass: MockDirectiveValidator },
        { provide: MatDialog, useClass: MockDialog }
      ]
    })
      .compileComponents();

    securityMasterService = TestBed.get(SecurityMasterService);
    dialog = TestBed.get(MatDialog);
    directiveValidator = TestBed.get(DirectiveValidator);
  });

  function createComponent() {
    fixture = TestBed.createComponent(EditDirectiveViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    loadDirectiveSpy = spyOn(component, 'loadDirective').and.callThrough();
  }

  it('should create', () => {
    createComponent();
    expect(component).toBeTruthy();
  });

  describe('ngOnInit:', () => {
    it('should not call loadDirective if no route param exists', () => {
      createComponent();
      loadDirectiveSpy.and.stub();

      component.ngOnInit();

      expect(loadDirectiveSpy).not.toHaveBeenCalled();
    });

    it('should call loadDirective if an id exists in the route params', () => {
      const routeID = '998877665';
      activatedRoute.snapshot.params.id = routeID;
      createComponent();
      loadDirectiveSpy.and.stub();

      component.ngOnInit();

      expect(loadDirectiveSpy).toHaveBeenCalledWith(+routeID);
    });
  });

  describe('createFormGroup:', () => {
    it('should call FormBuilder to create directive form', () => {
      createComponent();
      component.directive = mockDirectives[0];
      const formGroup = component.createFormGroup();

      expect(formGroup.get('id').value).toEqual(mockDirectives[0].id);
      expect(formGroup.get('name').value).toEqual(mockDirectives[0].name);
    });
  });

  describe('loadDirective:', () => {
    it('should call securityMasterService to load directive', () => {
      createComponent();
      const formGroup: FormGroup = new FormGroup({});
      const createFormGroupSpy = spyOn(component, 'createFormGroup')
        .and.returnValue(formGroup);

      component.loadDirective(mockDirectives[0].id);

      expect(securityMasterService.getDirective).toHaveBeenCalledWith(mockDirectives[0].id);
      expect(component.directive).toEqual(mockDirectives[0]);
      expect(component.isNewDirective).toEqual(false);
      expect(createFormGroupSpy).toHaveBeenCalled();
      expect(component.directiveForm).toEqual(formGroup);
    });
  });

  describe('validateName:', () => {
    let control: FormControl;
    let isFormDirtySpy: jasmine.Spy;

    beforeEach(() => {
      control = new FormControl('SECURITY NAME');
      createComponent();
      isFormDirtySpy = spyOn(component, 'isFormDirty').and.returnValue(true);
    });

    it('should return null if the form control is pristine', () => {
      control.markAsPristine();

      component.validateName(control).subscribe(response => {
        expect(response).toBeNull();
        expect(directiveValidator.checkIfDirectiveNameExists).not.toHaveBeenCalled();
      });
    });

    it('should return null if the form is not dirty', () => {
      isFormDirtySpy.and.returnValue(false);

      component.validateName(control).subscribe(response => {
        expect(response).toBeNull();
        expect(directiveValidator.checkIfDirectiveNameExists).not.toHaveBeenCalled();
      });
    });

    it('should return a validation error if the directive name exists', () => {
      control.markAsDirty();
      directiveValidator.checkIfDirectiveNameExists.and.returnValue(of(true));

      component.validateName(control).subscribe(response => {
        expect(response).toEqual({ nameExists: true });
        expect(directiveValidator.checkIfDirectiveNameExists).toHaveBeenCalledWith(control.value);
      });
    });

    it('should return null if the directive name does not exist', () => {
      control.markAsDirty();
      directiveValidator.checkIfDirectiveNameExists.and.returnValue(of(false));

      component.validateName(control).subscribe(response => {
        expect(response).toEqual(null);
        expect(directiveValidator.checkIfDirectiveNameExists).toHaveBeenCalledWith(control.value);
      });
    });
  });

  describe('saveDirective:', () => {
    let expectedDirective: Directive;

    beforeEach(() => {
      createComponent();
      component.isNewDirective = false;
      expectedDirective = { id: 5, name: 'NEW NAME', active: true };
      component.directiveForm.setValue(expectedDirective);
    });

    it('should navigate to directives view and display snackBar message after a successful request', () => {
      securityMasterService.saveDirective.and.returnValue(of(true));

      component.saveDirective();

      expect(securityMasterService.saveDirective).toHaveBeenCalledWith(expectedDirective, component.isNewDirective);
    });
    it('should display snackBar message after a failed request', () => {
      securityMasterService.saveDirective.and.returnValue(of(new Error('ERROR')));

      component.saveDirective();

      expect(securityMasterService.saveDirective).toHaveBeenCalledWith(expectedDirective, component.isNewDirective);
    });
  });


  describe('getValidationErrorMessage:', () => {
    it('should display message for nameExists validation error', () => {
      createComponent();
      component.name.setErrors({ nameExists: true });

      expect(component.getValidationErrorMessage()).toEqual('Directive Name Already Exists');
    });

    it('should display message for required validation error', () => {
      createComponent();
      component.name.setErrors({ required: true });

      expect(component.getValidationErrorMessage()).toEqual('Please enter a value');
    });

    it('should not display message if no errors are present', () => {
      createComponent();
      component.name.setErrors({});

      expect(component.getValidationErrorMessage()).toEqual('');
    });
  });

  describe('isFormDirty:', () => {
    beforeEach(() => {
      createComponent();
      component.directive = mockDirectives[0];
    });
    it('should return true if form is in dirty state', () => {
      component.name.setValue('FORM NAME');

      expect(component.isFormDirty()).toBeTruthy();
    });

    it('should return false if form is not in dirty state', () => {
      component.name.setValue(mockDirectives[0].name);

      expect(component.isFormDirty()).toBeFalsy();
    });
  });

  describe('reactivateDirective', () => {
    it('should reactivate directive', () => {
      createComponent();
      component.reactivateDirective();
      expect(securityMasterService.reactivateDirective).toHaveBeenCalled();
      // expect(securityMasterService.refreshDirectives).toHaveBeenCalled();
    });
  });

  describe('deactivateDirective', () => {
    it('should de activate directive', () => {
      const routeID = '99009913570';
      activatedRoute.snapshot.params.id = routeID;
      const event = { preventDefault() { } };
      createComponent();
      component.deactivateDirective();
      expect(securityMasterService.deactivateDirective).toHaveBeenCalled();
    });
  });

  describe('showConfirmDialog', () => {

    it('should show the message dialog when user clicks deactivate', () => {
      securityMasterService.deactivateDirective.and.returnValue(of(EMPTY));
      createComponent();
      dialog.open.and.returnValue({
        afterClosed: () => of('confirm')
      });
      component.showConfirmDialog('deactivate');
      expect(securityMasterService.deactivateDirective).toHaveBeenCalled();
    });

    it('should show the message dialog when user clicks reactivate', () => {
      securityMasterService.reactivateDirective.and.returnValue(of(EMPTY));
      createComponent();
      dialog.open.and.returnValue({
        afterClosed: () => of('confirm')
      });
      component.showConfirmDialog('reactivate');
      expect(securityMasterService.reactivateDirective).toHaveBeenCalled();
    });
  });
});
