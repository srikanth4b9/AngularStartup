import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DirectivesViewComponent, EditDirectiveViewComponent } from './views';

const routes: Routes = [
  {
    path: '',
    component: DirectivesViewComponent
  },
  {
    path: 'create',
    component: EditDirectiveViewComponent
  },
  {
    path: 'edit/:id',
    component: EditDirectiveViewComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DirectivesRoutingModule { }
