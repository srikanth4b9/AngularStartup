import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, AbstractControl, ValidationErrors } from '@angular/forms';
import { map } from 'rxjs/operators';
import { faPlusCircle } from '@fortawesome/free-solid-svg-icons';

import { Directive } from '@security-master/modules/directives/models';
import { SecurityMasterService } from '@security-master/services';
import { DirectiveValidator } from '@security-master/modules/directives/validators';
import { Observable, of } from 'rxjs';
import { MatDialog } from '@angular/material';
import { ConfirmDialogModel } from '@app/shared/models';
import { ConfirmDialogComponent } from '@app/components';

@Component({
  selector: 'app-edit-directive-view',
  templateUrl: './edit-directive-view.component.html',
  styleUrls: ['./edit-directive-view.component.scss']
})
export class EditDirectiveViewComponent implements OnInit {
  isNewDirective: boolean = true;
  directive: Directive = new Directive(undefined);
  directiveForm: FormGroup = this.createFormGroup();

  faPlusCircle = faPlusCircle;

  confirmDialogData: ConfirmDialogModel = {
    title: 'Are You Sure?',
    confirmButtonText: 'Continue'
  };

  constructor(
    private securityMasterService: SecurityMasterService,
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private directiveValidator: DirectiveValidator,
    private dialog: MatDialog) {
  }

  ngOnInit() {
    const directiveId: number = +this.route.snapshot.params.id;
    if (directiveId) {
      this.loadDirective(directiveId);
    }
  }

  createFormGroup() {
    return this.formBuilder.group({
      id: [this.directive.id],
      name: [this.directive.name, [], [this.validateName.bind(this)]],
      active: [this.directive.active]
    });
  }

  get name() { return this.directiveForm.get('name'); }
  get active() { return (this.directiveForm && this.directiveForm.get('active')); }


  loadDirective(directiveId) {
    this.securityMasterService.getDirective(directiveId).subscribe(
      directive => {
        this.directive = directive;
        this.isNewDirective = false;
        this.directiveForm = this.createFormGroup();
      }
    );
  }

  validateName(control: AbstractControl): Observable<ValidationErrors> {
    if (!control.pristine && this.isFormDirty()) {
      return this.directiveValidator
        .checkIfDirectiveNameExists(control.value)
        .pipe(map(
          (response: boolean) => response ? { nameExists: true } : null
        ));
    }
    return of(null);
  }

  showConfirmDialog(action) {
    this.confirmDialogData.message =  `Are you sure you want to ${action} this directive?`;
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      hasBackdrop: true,
      data: this.confirmDialogData
    });

    dialogRef.afterClosed().subscribe(data => {
      if (data === 'confirm') {
        (action === 'deactivate') ? this.deactivateDirective() : this.reactivateDirective();
      }
    });
  }

  saveDirective(): void {
    this.securityMasterService.saveDirective(this.directiveForm.value, this.isNewDirective).subscribe(
      () => this.securityMasterService.refreshDirectives());
  }

  getValidationErrorMessage(): string {
    return this.name.errors.nameExists ? 'Directive Name Already Exists' :
      this.name.errors.required ? 'Please enter a value' :
        '';
  }

  isFormDirty(): boolean {
    return this.name.value !== this.directive.name;
  }


  deactivateDirective(): void {
    this.securityMasterService.deactivateDirective(this.directiveForm.getRawValue());
  }

  reactivateDirective(): void {
    this.securityMasterService.reactivateDirective(this.directiveForm.getRawValue());
  }
}
