export * from './directives-view.component';
export * from './directives-view.module';
