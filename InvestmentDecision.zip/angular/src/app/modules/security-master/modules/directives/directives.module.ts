import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DirectivesRoutingModule } from './directives-routing.module';
import { DirectivesViewModule, EditDirectiveViewModule } from './views';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    DirectivesRoutingModule,
    DirectivesViewModule,
    EditDirectiveViewModule
  ]
})
export class DirectivesModule { }
