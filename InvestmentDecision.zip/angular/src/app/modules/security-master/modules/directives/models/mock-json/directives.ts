import { Directive } from '@security-master/modules/directives/models';

export const mockDirectives: Directive[] = [
  {
    'active': true,
    'crewUserId': 'UN9S',
    'id': 26,
    'lastUpdatedTimestamp': '2019-01-22T11:54:23.985-05:00',
    'name': 'CASH'
  },
  {
    'active': true,
    'crewUserId': 'UN9S',
    'id': 27,
    'lastUpdatedTimestamp': '2019-01-22T11:54:23.985-05:00',
    'name': 'FIXED INCOME'
  },
  {
    'active': true,
    'crewUserId': 'UN9S',
    'id': 28,
    'lastUpdatedTimestamp': '2019-01-22T11:54:23.985-05:00',
    'name': 'OTHER'
  },
  {
    'active': true,
    'crewUserId': 'UN9S',
    'id': 29,
    'lastUpdatedTimestamp': '2019-01-22T11:54:23.985-05:00',
    'name': 'OTHER 2'
  }
];
