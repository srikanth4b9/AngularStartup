import { of } from 'rxjs';
import { } from 'jasmine';

export class MockDirectiveValidator {
  checkIfDirectiveNameExists = jasmine.createSpy().and.returnValue(of(false));
}
