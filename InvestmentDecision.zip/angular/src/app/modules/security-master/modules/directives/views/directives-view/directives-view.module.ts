import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { MaterialModule } from '@app/shared/material.module';
import { ExportableReportModule, ActiveToggleModule } from '@app/shared/components';
import { DirectivesViewComponent } from './directives-view.component';

@NgModule({
  declarations: [DirectivesViewComponent],
  imports: [
    CommonModule,
    RouterModule,
    MaterialModule,
    ExportableReportModule,
    FontAwesomeModule,
    ActiveToggleModule
  ],
  exports: [DirectivesViewComponent]
})
export class DirectivesViewModule { }
