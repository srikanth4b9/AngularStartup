import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { MaterialModule } from '@app/shared/material.module';
import { EditDirectiveViewComponent } from './edit-directive-view.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DirectiveValidator } from '@security-master/modules/directives/validators';
import { MatSnackBarModule } from '@angular/material';

@NgModule({
  declarations: [EditDirectiveViewComponent],
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    MatSnackBarModule,
    FontAwesomeModule
  ],
  exports: [EditDirectiveViewComponent],
  providers: [DirectiveValidator]
})
export class EditDirectiveViewModule { }
