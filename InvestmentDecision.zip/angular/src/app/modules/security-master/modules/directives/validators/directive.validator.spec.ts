import { TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import { mockDirectives } from '../models';
import { SecurityMasterService } from '@security-master/services';

import { DirectiveValidator } from './directive.validator';

class MockSecurityMasterService {
  getDirectives() {
    return of(mockDirectives);
  }
}

describe('DirectiveValidator', () => {
  let validator: DirectiveValidator;
  let securityMasterService: SecurityMasterService;
  let getDirectivesSpy: jasmine.Spy;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: SecurityMasterService, useClass: MockSecurityMasterService },
        DirectiveValidator
      ]
    });

    validator = TestBed.get(DirectiveValidator);
    securityMasterService = TestBed.get(SecurityMasterService);
    getDirectivesSpy = spyOn(securityMasterService, 'getDirectives')
      .and.returnValue(of(mockDirectives));
  });

  it('should be created', () => {
    expect(validator).toBeTruthy();
  });

  describe('checkIfDirectiveNameExists:', () => {
    it('should return true if directive name already exists', () => {
      validator.checkIfDirectiveNameExists('CASH').subscribe(
        response => expect(response).toBeTruthy()
      );

      expect(getDirectivesSpy).toHaveBeenCalled();
    });

    it('should return false if directive name is unique', () => {
      validator.checkIfDirectiveNameExists('NEW DIRECTIVE').subscribe(
        response => expect(response).toBeFalsy()
      );

      expect(getDirectivesSpy).toHaveBeenCalled();
    });
  });
});
