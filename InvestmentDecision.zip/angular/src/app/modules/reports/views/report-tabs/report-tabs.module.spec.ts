import { ReportTabsModule } from './report-tabs.module';

describe('ReportTabsModule', () => {
  let reportTabsModule: ReportTabsModule;

  beforeEach(() => {
    reportTabsModule = new ReportTabsModule();
  });

  it('should create an instance', () => {
    expect(reportTabsModule).toBeTruthy();
  });
});
