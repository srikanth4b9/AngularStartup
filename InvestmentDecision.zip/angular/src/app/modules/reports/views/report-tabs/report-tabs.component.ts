import { Component } from '@angular/core';
import { NavLink } from '@app/shared/models';

@Component({
  selector: 'app-report-tabs',
  templateUrl: './report-tabs.component.html',
  styleUrls: ['./report-tabs.component.scss']
})
export class ReportTabsComponent {

  navLinks: NavLink[] = [
    {path: 'investable-cash', label: 'Investable Cash'},
    {path: 'manual-cash', label: 'Pending Manual Cash'},
    {path: 't1-trades', label: 'T+1 Trade Calculations'},
    {path: 'errors', label: 'Trade Calculation Errors'}
  ];

  constructor() { }

}
