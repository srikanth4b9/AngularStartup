export * from './report-tabs.component';
export * from './report-tabs.module';
