import { TestBed } from '@angular/core/testing';
import { RestService } from '@app/services';
import { environment } from '@env';
import { of } from 'rxjs';

import { mockInvestableCashReport } from '../modules/investable-cash/models';
import { mockManualCashReport } from '../modules/manual-cash/models';
import { mockT1TradingReport } from '../modules/t1-trades/models';
import { mockTradeCalcErrorReport } from '../modules/trade-errors/models';
import { ReportService } from './reports.service';


class MockRestService {
  exportData = jasmine.createSpy('exportData');

  getData = jasmine.createSpy().and.callFake((apiPath) => {
    if (apiPath === environment.INVESTABLE_CASH_REPORT) {
      return of(mockInvestableCashReport);
    } else if (apiPath === environment.T1_TRADE_REPORT) {
      return of(mockT1TradingReport);
    } else if (apiPath === environment.MANUAL_CASH) {
      return of(mockManualCashReport);
    } else if (apiPath === environment.TRADE_CALC_ERRORS) {
      return of(mockTradeCalcErrorReport);
    } else {
      return of(null);
    }
  });
}

describe('ReportService', () => {
  let service: ReportService;
  let restService: MockRestService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [{ provide: RestService, useClass: MockRestService }]
    });

    service = TestBed.get(ReportService);
    restService = TestBed.get(RestService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('getInvestableCashReport:', () => {
    it('should call rest service to get the investable cash data', () => {
      service.getInvestableCashReport().subscribe(data => {
        expect(restService.getData).toHaveBeenCalledWith(environment.INVESTABLE_CASH_REPORT, 'Load Investable cash report');
        expect(data).toEqual(mockInvestableCashReport);
      });
    });
  });

  describe('getManualCashReport:', () => {
    it('should call rest service to get the manual cash data', () => {
      service.getManualCashReport().subscribe(data => {
        expect(restService.getData).toHaveBeenCalledWith(environment.MANUAL_CASH, 'Load Pending Manual Cash report');
        expect(data).toEqual(mockManualCashReport);
      });
    });
  });

  describe('getT1TradingReport:', () => {
    it('should call rest service to get the t+1 trading data', () => {
      service.getT1TradingReport().subscribe(data => {
        expect(restService.getData).toHaveBeenCalledWith(environment.T1_TRADE_REPORT, 'Load T1 Trading report');
        expect(data).toEqual(mockT1TradingReport);
      });
    });
  });

  describe('getTradeCalcErrorReport:', () => {
    it('should call rest service to get the trading calculation error data', () => {
      service.getTradeCalcErrorReport().subscribe(data => {
        expect(restService.getData).toHaveBeenCalledWith(environment.TRADE_CALC_ERRORS, 'Load Trade Calculation error report');
        expect(data).toEqual(mockTradeCalcErrorReport);
      });
    });
  });

  describe('exportInvestableCashReport:', () => {
    it('should call rest service to export the investable cash report', () => {
      const exportDate = '2018-12-17';
      const apiUrl = `${environment.INVESTABLE_CASH_REPORT}?runDate=${exportDate}`;
      const fileName = `investable-cash-${exportDate}`;

      service.exportInvestableCashReport(exportDate);

      expect(restService.exportData).toHaveBeenCalledWith(apiUrl, fileName, 'Export Investable cash report');
    });
  });

  describe('exportT1TradingReport:', () => {
    it('should call rest service to export the t+1 trading report', () => {
      const exportDate = '2018-12-17';
      const apiUrl = `${environment.T1_TRADE_REPORT}?runDate=${exportDate}`;
      const fileName = `t1-trading-calculation-${exportDate}`;

      service.exportT1TradingReport(exportDate);

      expect(restService.exportData).toHaveBeenCalledWith(apiUrl, fileName, 'Export T1 Trading report');
    });
  });
});
