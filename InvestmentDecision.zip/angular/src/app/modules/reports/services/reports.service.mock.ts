import { of } from 'rxjs';
import { } from 'jasmine';
import { mockInvestableCashReport } from '../modules/investable-cash/models';
import { mockManualCashReport } from '../modules/manual-cash/models';
import { mockT1TradingReport } from '../modules/t1-trades/models';
import { mockTradeCalcErrorReport } from '../modules/trade-errors/models';

export class MockReportService {
  getInvestableCashReport = jasmine.createSpy().and.returnValue(of(mockInvestableCashReport));
  exportInvestableCashReport = jasmine.createSpy();

  getManualCashReport = jasmine.createSpy().and.returnValue(of(mockManualCashReport));

  getT1TradingReport = jasmine.createSpy().and.returnValue(of(mockT1TradingReport));
  exportT1TradingReport = jasmine.createSpy();

  getTradeCalcErrorReport = jasmine.createSpy().and.returnValue(of(mockTradeCalcErrorReport));
}
