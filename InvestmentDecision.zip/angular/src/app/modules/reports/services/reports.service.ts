import { Injectable } from '@angular/core';
import { RestService } from '@app/services';
import { environment } from '@env';
import { Observable, Subscription } from 'rxjs';

import { InvestableCashReportEntry } from '../modules/investable-cash/models';
import { ManualCashEntry } from '../modules/manual-cash/models';
import { T1TradingReportEntry } from '../modules/t1-trades/models';
import { TradeCalculationError } from '../modules/trade-errors/models';

@Injectable({
  providedIn: 'root'
})
export class ReportService {

  constructor(private restService: RestService) { }

  getInvestableCashReport(): Observable<InvestableCashReportEntry[]> {
    return this.restService.getData<InvestableCashReportEntry[]>(environment.INVESTABLE_CASH_REPORT, 'Load Investable cash report');
  }

  getManualCashReport(): Observable<ManualCashEntry[]> {
    return this.restService.getData<ManualCashEntry[]>(environment.MANUAL_CASH, 'Load Pending Manual Cash report');
  }

  getT1TradingReport(): Observable<T1TradingReportEntry[]> {
    return this.restService.getData<T1TradingReportEntry[]>(environment.T1_TRADE_REPORT, 'Load T1 Trading report');
  }

  getTradeCalcErrorReport(): Observable<TradeCalculationError[]> {
    return this.restService.getData<TradeCalculationError[]>(environment.TRADE_CALC_ERRORS, 'Load Trade Calculation error report');
  }

  exportInvestableCashReport(exportDate: string): Subscription {
    const apiUrl = `${environment.INVESTABLE_CASH_REPORT}?runDate=${exportDate}`;
    const fileName = `investable-cash-${exportDate}`;
    return this.restService.exportData(apiUrl, fileName, 'Export Investable cash report');
  }

  exportT1TradingReport(exportDate: string): Subscription {
    const apiUrl = `${environment.T1_TRADE_REPORT}?runDate=${exportDate}`;
    const fileName = `t1-trading-calculation-${exportDate}`;
    return this.restService.exportData(apiUrl, fileName, 'Export T1 Trading report');
  }
}
