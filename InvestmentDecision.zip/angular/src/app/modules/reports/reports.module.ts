import { NgModule } from '@angular/core';
import { ReportTabsModule } from '@reports/views';
import { CommonModule } from '@angular/common';
import { ReportsRoutingModule } from './reports-routing.module';

@NgModule({
  imports: [
    CommonModule,
    ReportsRoutingModule,
    ReportTabsModule
  ],
  declarations: []
})
export class ReportsModule { }
