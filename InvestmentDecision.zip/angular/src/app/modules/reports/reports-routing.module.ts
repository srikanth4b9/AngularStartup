import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ReportTabsComponent } from '@reports/views';

const routes: Routes = [
  {
    path: '',
    component: ReportTabsComponent,
    children: [
      {
        path: '',
        redirectTo: 'investable-cash'
      },
      {
        path: 'investable-cash',
        loadChildren: './modules/investable-cash/investable-cash.module#InvestableCashModule'
      },
      {
        path: 'manual-cash',
        loadChildren: './modules/manual-cash/manual-cash.module#ManualCashModule',
        runGuardsAndResolvers: 'always',
      },
      {
        path: 't1-trades',
        loadChildren: './modules/t1-trades/t1-trades.module#T1TradesModule'
      },
      {
        path: 'errors',
        loadChildren: './modules/trade-errors/trade-errors.module#TradeErrorsModule'
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportsRoutingModule { }
