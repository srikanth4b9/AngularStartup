import { ColumnDefBuilder, ColumnType, TableDef } from '@app/shared/models';

export interface T1TradingReportEntry {
  portId: string;
  accountingSecurityId: string;
  priorDayMarketValueAndAccruedIncome: string;
  priorDayTrades: string;
  beginningAllocation: string;
  beginningVarianceFromTarget: string;
  calculatedInvestment: string;
  endingAllocation: string;
  endingVarianceFromTarget: string;
  hasRebalanceViolation: string;
}

export const t1TradingReportDef: TableDef = new TableDef([
  new ColumnDefBuilder('Port ID', 'portId', ColumnType.STRING).build(),
  new ColumnDefBuilder('Accounting Security ID', 'accountingSecurityId', ColumnType.STRING).build(),
  new ColumnDefBuilder('Prior Day Security Market Value & Accrued Income', 'priorDayMarketValueAndAccruedIncome', ColumnType.CURRENCY)
    .build(),
  new ColumnDefBuilder('Prior Day Trades', 'priorDayTrades', ColumnType.CURRENCY).build(),
  new ColumnDefBuilder('Beginning Allocation', 'beginningAllocation', ColumnType.PERCENT).build(),
  new ColumnDefBuilder('Beginning Variance From Target', 'beginningVarianceFromTarget', ColumnType.PERCENT).build(),
  new ColumnDefBuilder('Calculated Investment', 'calculatedInvestment', ColumnType.CURRENCY).build(),
  new ColumnDefBuilder('Ending Allocation', 'endingAllocation', ColumnType.PERCENT).build(),
  new ColumnDefBuilder('Ending Variance From Target', 'endingVarianceFromTarget', ColumnType.PERCENT)
    .violationFlag('hasRebalanceViolation', 'Rebalance Violation').build()
]);
