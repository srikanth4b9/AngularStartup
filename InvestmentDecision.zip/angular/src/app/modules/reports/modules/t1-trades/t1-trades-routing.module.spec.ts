import { T1TradesRoutingModule } from './t1-trades-routing.module';

describe('T1TradesRoutingModule', () => {
    let t1TradesRoutingModule: T1TradesRoutingModule;

    beforeEach(() => {
        t1TradesRoutingModule = new T1TradesRoutingModule();
    });

    it('should create an instance', () => {
        expect(t1TradesRoutingModule).toBeTruthy();
    });
});
