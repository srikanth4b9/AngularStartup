import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { T1TradesRoutingModule } from './t1-trades-routing.module';
import { T1TradesViewModule } from './views';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    T1TradesRoutingModule,
    T1TradesViewModule
  ]
})
export class T1TradesModule { }
