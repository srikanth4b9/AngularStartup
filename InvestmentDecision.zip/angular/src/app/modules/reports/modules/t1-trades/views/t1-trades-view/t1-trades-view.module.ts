import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from '@app/shared/material.module';
import { ExportableReportModule } from '@app/shared/components';
import { T1TradesViewComponent } from './t1-trades-view.component';

@NgModule({
  declarations: [T1TradesViewComponent],
  imports: [
    CommonModule,
    MaterialModule,
    ExportableReportModule
  ],
  exports: [T1TradesViewComponent]
})
export class T1TradesViewModule { }
