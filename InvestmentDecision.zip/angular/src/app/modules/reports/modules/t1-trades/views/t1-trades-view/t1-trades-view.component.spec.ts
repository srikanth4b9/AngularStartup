import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { MockReportService } from '@app/modules/reports/services/reports.service.mock';
import { ExportableReportModule } from '@app/shared/components';
import { MaterialModule } from '@app/shared/material.module';
import { mockT1TradingReport } from '@reports/modules/t1-trades/models';
import { ReportService } from '@reports/services';

import { T1TradesViewComponent } from './t1-trades-view.component';


describe('T1TradesViewComponent', () => {
  let component: T1TradesViewComponent;
  let fixture: ComponentFixture<T1TradesViewComponent>;
  let reportService: MockReportService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule,
        MaterialModule,
        ExportableReportModule
      ],
      declarations: [T1TradesViewComponent],
      providers: [{ provide: ReportService, useClass: MockReportService }]
    })
      .compileComponents();

    reportService = TestBed.get(ReportService);
  });

  function createComponent() {
    fixture = TestBed.createComponent(T1TradesViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  beforeEach(() => {
    createComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('loadT1TradingReportData:', () => {
    it('should load t+1 trading report data', () => {
      component.loadT1TradingReportData();

      expect(reportService.getT1TradingReport).toHaveBeenCalled();
      expect(component.t1TradingReportData).toEqual(mockT1TradingReport);
    });
  });

  describe('exportT1TradingReport:', () => {
    it('should call the service to export t+1 trading report', () => {
      const exportDate = '2018-12-17';

      component.exportT1TradingReport(exportDate);

      expect(reportService.exportT1TradingReport).toHaveBeenCalledWith(exportDate);
    });
  });
});
