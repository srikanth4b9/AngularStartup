import { Component } from '@angular/core';
import { ReportService } from '@reports/services';
import { T1TradingReportEntry, t1TradingReportDef } from '@reports/modules/t1-trades/models';

@Component({
  selector: 'app-t1-trades-view',
  templateUrl: './t1-trades-view.component.html',
  styleUrls: ['./t1-trades-view.component.scss']
})
export class T1TradesViewComponent {
  t1TradingReportDef = t1TradingReportDef;
  t1TradingReportData: Array<T1TradingReportEntry> = [];

  constructor(private reportService: ReportService) {
    this.loadT1TradingReportData();
  }

  loadT1TradingReportData(): void {
    this.reportService.getT1TradingReport().subscribe(
      data => this.t1TradingReportData = data
    );
  }

  exportT1TradingReport(exportDate: string): void {
    this.reportService.exportT1TradingReport(exportDate);
  }
}
