import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { T1TradesViewComponent } from './views';

const routes: Routes = [
  {
    path: '',
    component: T1TradesViewComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class T1TradesRoutingModule { }
