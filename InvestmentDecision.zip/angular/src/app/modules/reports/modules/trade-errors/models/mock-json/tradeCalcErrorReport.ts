import { TradeCalculationError } from '@reports/modules/trade-errors/models';


export const mockTradeCalcErrorReport: TradeCalculationError[] = [
    {
        portId: '430',
        fundName: 'AGGRESSIVE GRWTH PORT',
        runTimestamp: '2019-01-22T12:46:24.137-04:00',
        errorType: 'TRDB'
    },
    {
        portId: '1394',
        fundName: 'THOMSON REUTERS 500 INDEX',
        runTimestamp: '2019-01-22T12:46:24.137-07:00',
        errorType: 'INCZ'
    },
    {
        portId: '4255',
        fundName: 'NISSAN OPTION A',
        runTimestamp: '2019-01-22T12:46:24.137-09:00',
        errorType: 'SDPZ'
    },
    {
        portId: '5828',
        fundName: 'CLARK COMPANY CONTRIBUTION',
        runTimestamp: '2019-01-22T12:46:24.137-04:00',
        errorType: 'SYSE'
    }
];
