import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from '@app/shared/material.module';
import { ExportableReportModule } from '@app/shared/components';
import { TradeErrorsViewComponent } from './trade-errors-view.component';

@NgModule({
  declarations: [TradeErrorsViewComponent],
  imports: [
    CommonModule,
    MaterialModule,
    ExportableReportModule
  ],
  exports: [TradeErrorsViewComponent]
})
export class TradeErrorsViewModule { }
