import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { MockReportService } from '@app/modules/reports/services/reports.service.mock';
import { ExportableReportModule } from '@app/shared/components';
import { MaterialModule } from '@app/shared/material.module';
import { mockTradeCalcErrorReport } from '@reports/modules/trade-errors/models';
import { ReportService } from '@reports/services';

import { TradeErrorsViewComponent } from './trade-errors-view.component';

describe('TradeErrorsViewComponent', () => {
  let component: TradeErrorsViewComponent;
  let fixture: ComponentFixture<TradeErrorsViewComponent>;
  let reportService: MockReportService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule,
        MaterialModule,
        ExportableReportModule
      ],
      declarations: [TradeErrorsViewComponent],
      providers: [{ provide: ReportService, useClass: MockReportService }]
    })
      .compileComponents();

      reportService = TestBed.get(ReportService);
  });

  function createComponent() {
    fixture = TestBed.createComponent(TradeErrorsViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  beforeEach(() => {
    createComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('loadTradeCalcErrorReportData:', () => {
    it('should load trade error report data', () => {
      component.loadTradeCalcErrorReportData();

      expect(reportService.getTradeCalcErrorReport).toHaveBeenCalled();
      expect(component.tradeCalcErrorReportData).toEqual(mockTradeCalcErrorReport);
    });
  });
});
