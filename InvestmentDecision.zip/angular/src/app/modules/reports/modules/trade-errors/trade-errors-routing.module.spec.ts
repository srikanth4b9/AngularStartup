import { TradeErrorsRoutingModule } from './trade-errors-routing.module';

describe('TradeErrorsRoutingModule', () => {
    let tradeErrorsRoutingModule: TradeErrorsRoutingModule;

    beforeEach(() => {
        tradeErrorsRoutingModule = new TradeErrorsRoutingModule();
    });

    it('should create an instance', () => {
        expect(tradeErrorsRoutingModule).toBeTruthy();
    });
});
