import { ColumnDefBuilder, TableDef, ColumnType } from '@app/shared/models';

export interface TradeCalculationError {
    portId: string;
    fundName: string;
    runTimestamp: string;
    errorType: ErrorType;
}

export const tradeCalcErrorReportDef: TableDef = new TableDef([
    new ColumnDefBuilder('Port ID', 'portId', ColumnType.STRING).build(),
    new ColumnDefBuilder('Fund Name', 'fundName', ColumnType.STRING).build(),
    new ColumnDefBuilder('Run TimeStamp', 'runTimestamp', ColumnType.TIMESTAMP).build(),
    new ColumnDefBuilder('Error Type', 'errorType', ColumnType.ENUM).build()
]);

type ErrorType = 'SYSE' | 'TRDB' | 'INCZ' | 'SDPZ';
export const ErrorType = {
    'SYSE': 'System Error',
    'TRDB': 'Trading Disabled',
    'INCZ': 'Total Investable Cash is zero',
    'SDPZ': 'Start of Day Position is zero'
};
