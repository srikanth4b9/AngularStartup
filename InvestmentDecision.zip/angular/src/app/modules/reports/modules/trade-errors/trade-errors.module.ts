import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TradeErrorsRoutingModule } from './trade-errors-routing.module';
import { TradeErrorsViewModule } from './views';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    TradeErrorsRoutingModule,
    TradeErrorsViewModule
  ]
})
export class TradeErrorsModule { }
