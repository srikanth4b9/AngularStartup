import { Component } from '@angular/core';
import { ReportService } from '@reports/services';
import { TradeCalculationError, tradeCalcErrorReportDef } from '@reports/modules/trade-errors/models';

@Component({
  selector: 'app-trade-errors-view',
  templateUrl: './trade-errors-view.component.html',
  styleUrls: ['./trade-errors-view.component.scss']
})
export class TradeErrorsViewComponent {
  tradeCalcErrorReporDef = tradeCalcErrorReportDef;
  tradeCalcErrorReportData: Array<TradeCalculationError> = [];

  constructor(private reportService: ReportService) {
    this.loadTradeCalcErrorReportData();
  }

  loadTradeCalcErrorReportData(): void {
    this.reportService.getTradeCalcErrorReport().subscribe(
      data => this.tradeCalcErrorReportData = data
    );
  }
}
