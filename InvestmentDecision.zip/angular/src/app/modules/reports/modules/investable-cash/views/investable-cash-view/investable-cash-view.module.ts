import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from '@app/shared/material.module';
import { ExportableReportModule } from '@app/shared/components';
import { InvestableCashViewComponent } from './investable-cash-view.component';

@NgModule({
  declarations: [InvestableCashViewComponent],
  imports: [
    CommonModule,
    MaterialModule,
    ExportableReportModule
  ],
  exports: [InvestableCashViewComponent]
})
export class InvestableCashViewModule { }
