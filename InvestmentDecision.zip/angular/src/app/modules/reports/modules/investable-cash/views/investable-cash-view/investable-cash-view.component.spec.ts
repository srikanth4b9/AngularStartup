import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { MockReportService } from '@app/modules/reports/services/reports.service.mock';
import { ExportableReportModule } from '@app/shared/components';
import { MaterialModule } from '@app/shared/material.module';
import { mockInvestableCashReport } from '@reports/modules/investable-cash/models';
import { ReportService } from '@reports/services';
import { of } from 'rxjs';

import { InvestableCashViewComponent } from './investable-cash-view.component';


describe('InvestableCashViewComponent', () => {
  let component: InvestableCashViewComponent;
  let fixture: ComponentFixture<InvestableCashViewComponent>;
  let reportService: MockReportService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule,
        MaterialModule,
        ExportableReportModule
      ],
      declarations: [InvestableCashViewComponent],
      providers: [
        { provide: ReportService, useClass: MockReportService },
      ]
    })
      .compileComponents();

    reportService = TestBed.get(ReportService);
  });

  function createComponent() {
    fixture = TestBed.createComponent(InvestableCashViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  beforeEach(() => {
    createComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('loadInvestableCashReportData:', () => {
    it('should load investable cash report data', () => {
      component.loadInvestableCashReportData();
      reportService.getInvestableCashReport.and.returnValue(of(mockInvestableCashReport));
      expect(component.investableCashReportData).toEqual(mockInvestableCashReport);
    });
  });

  describe('exportInvestableCashReport:', () => {
    it('should call the service to export investable cash report', () => {
      const exportDate = '2018-12-17';

      component.exportInvestableCashReport(exportDate);

      expect(reportService.exportInvestableCashReport).toHaveBeenCalledWith(exportDate);
    });
  });
});
