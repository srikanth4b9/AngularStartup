import { ColumnDef, ColumnDefBuilder, ColumnType, TableDef } from '@app/shared/models';

export interface InvestableCashReportEntry {
  portId: string;
  fundName: string;
  productType: string;
  runTimestamp: string;
  activitySource?: string;
  participantActivity: number;
  indirectCash: number;
  manualCash: number;
  expenses: number;
  totalInvestableCash: number;
}

export const investableCashReportDef: TableDef = new TableDef([
  new ColumnDefBuilder('Port ID', 'portId', ColumnType.STRING).build(),
  new ColumnDefBuilder('Fund Name', 'fundName', ColumnType.STRING).build(),
  new ColumnDefBuilder('Product Type', 'productType', ColumnType.STRING).build(),
  new ColumnDefBuilder('Run Timestamp', 'runTimestamp', ColumnType.TIMESTAMP).build(),
  new ColumnDefBuilder('Activity Source', 'activitySource', ColumnType.STRING).build(),
  new ColumnDefBuilder('Participant Activity', 'participantActivity', ColumnType.CURRENCY).build(),
  new ColumnDefBuilder('Indirect Cash', 'indirectCash', ColumnType.CURRENCY).build(),
  new ColumnDefBuilder('Manual Cash', 'manualCash', ColumnType.CURRENCY).build(),
  new ColumnDefBuilder('Expenses', 'expenses', ColumnType.CURRENCY).build(),
  new ColumnDefBuilder('Total Investable Cash', 'totalInvestableCash', ColumnType.CURRENCY).build()
]);
