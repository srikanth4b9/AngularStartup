import { InvestableCashReportEntry } from '@reports/modules/investable-cash/models';

export const mockInvestableCashReport: InvestableCashReportEntry[] = [
  {
    portId: '1779',
    fundName: 'Fund Name',
    productType: 'CTDF',
    runTimestamp: '',
    // activitySource: 'VISTA',
    participantActivity: 46000,
    indirectCash: 0,
    manualCash: 450000,
    expenses: 0,
    totalInvestableCash: 75000
  },
  {
    portId: '1870',
    fundName: 'UN9S',
    productType: '922040407',
    runTimestamp: '2018-11-28T07:30:58.758-05:00',
    participantActivity: -345,
    indirectCash: -2,
    manualCash: 2019,
    expenses: 2444,
    totalInvestableCash: -1870
  }
];
