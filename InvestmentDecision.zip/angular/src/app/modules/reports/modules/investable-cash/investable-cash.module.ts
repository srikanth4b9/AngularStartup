import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { InvestableCashRoutingModule } from './investable-cash-routing.module';
import { InvestableCashViewModule } from './views';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    InvestableCashRoutingModule,
    InvestableCashViewModule
  ]
})
export class InvestableCashModule { }
