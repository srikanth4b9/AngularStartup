import { InvestableCashRoutingModule } from './investable-cash-routing.module';

describe('InvestableCashRoutingModule', () => {
    let investableCashRoutingModule: InvestableCashRoutingModule;

    beforeEach(() => {
        investableCashRoutingModule = new InvestableCashRoutingModule();
    });

    it('should create an instance', () => {
        expect(investableCashRoutingModule).toBeTruthy();
    });
});
