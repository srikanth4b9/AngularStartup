import { Component } from '@angular/core';
import { ReportService } from '@reports/services';
import { InvestableCashReportEntry, investableCashReportDef } from '@reports/modules/investable-cash/models';

@Component({
  selector: 'app-investable-cash-view',
  templateUrl: './investable-cash-view.component.html',
  styleUrls: ['./investable-cash-view.component.scss']
})
export class InvestableCashViewComponent {
  investableCashReportDef = investableCashReportDef;
  investableCashReportData: Array<InvestableCashReportEntry> = [];

  constructor(private reportService: ReportService) {
    this.loadInvestableCashReportData();
  }

  loadInvestableCashReportData(): void {
    this.reportService.getInvestableCashReport().subscribe(
      data => this.investableCashReportData = data
    );
  }

  exportInvestableCashReport(exportDate: string): void {
    this.reportService.exportInvestableCashReport(exportDate);
  }
}
