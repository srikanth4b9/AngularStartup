import { ManualCashRoutingModule } from './manual-cash-routing.module';

describe('ManualCashRoutingModule', () => {
    let manualCashRoutingModule: ManualCashRoutingModule;

    beforeEach(() => {
        manualCashRoutingModule = new ManualCashRoutingModule();
    });

    it('should create an instance', () => {
        expect(manualCashRoutingModule).toBeTruthy();
    });
});
