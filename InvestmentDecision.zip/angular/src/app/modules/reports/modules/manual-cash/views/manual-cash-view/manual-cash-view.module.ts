import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatToolbarModule } from '@angular/material';

import { ExportableReportModule } from '@app/shared/components';
import { ManualCashViewComponent } from './manual-cash-view.component';
import { UploadDialogButtonModule } from '@app/components/upload-dialog-button/upload-dialog-button.module';

@NgModule({
  declarations: [ManualCashViewComponent],
  imports: [
    CommonModule,
    MatToolbarModule,
    ExportableReportModule,
    UploadDialogButtonModule
  ],
  exports: [ManualCashViewComponent]
})
export class ManualCashViewModule { }
