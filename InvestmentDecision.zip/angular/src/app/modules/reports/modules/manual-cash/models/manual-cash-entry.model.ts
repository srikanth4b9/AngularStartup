import { ColumnDef, ColumnDefBuilder, ColumnType, TableDef } from '@app/shared/models';

export interface ManualCashEntry {
    portId: string;
    amount: number;
    crewUserId: string;
    lastUpdatedTimestamp: string;
}

export const manualCashReportDef: TableDef = new TableDef([
    new ColumnDefBuilder('Port ID', 'portId', ColumnType.STRING).build(),
    new ColumnDefBuilder('Amount', 'amount', ColumnType.CURRENCY).align('left').build()
]);
