import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { NavigationEnd, Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { UploadDialogButtonModule } from '@app/components/upload-dialog-button';
import { MockReportService } from '@app/modules/reports/services/reports.service.mock';
import { ExportableReportModule } from '@app/shared/components';
import { MaterialModule } from '@app/shared/material.module';
import { mockManualCashReport } from '@reports/modules/manual-cash/models';
import { ReportService } from '@reports/services';
import { of } from 'rxjs';

import { ManualCashViewComponent } from './manual-cash-view.component';


class MockRouter {
  public events = of(new NavigationEnd(0, 'url', 'urlAfterRedirects'));
}

describe('ManualCashViewComponent', () => {
  let component: ManualCashViewComponent;
  let fixture: ComponentFixture<ManualCashViewComponent>;
  let reportService: MockReportService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        NoopAnimationsModule,
        MaterialModule,
        ExportableReportModule,
        UploadDialogButtonModule
      ],
      declarations: [ManualCashViewComponent],
      providers: [
        { provide: ReportService, useClass: MockReportService },
        { provide: Router, useClass: MockRouter }
      ]
    })
      .compileComponents();

    reportService = TestBed.get(ReportService);
  });

  function createComponent() {
    fixture = TestBed.createComponent(ManualCashViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  beforeEach(() => {
    createComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('loadManualCashReportData:', () => {
    it('should load trade error report data', () => {
      component.loadManualCashReportData();

      expect(reportService.getManualCashReport).toHaveBeenCalled();
      expect(component.manualCashReportData).toEqual(mockManualCashReport);
    });
  });
});
