import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ManualCashRoutingModule } from './manual-cash-routing.module';
import { ManualCashViewModule } from './views';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ManualCashRoutingModule,
    ManualCashViewModule
  ]
})
export class ManualCashModule { }
