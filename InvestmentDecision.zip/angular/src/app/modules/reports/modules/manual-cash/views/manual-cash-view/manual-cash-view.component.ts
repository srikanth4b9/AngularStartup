import { Component, OnDestroy } from '@angular/core';
import { ReportService } from '@reports/services';
import { ManualCashEntry, manualCashReportDef } from '@reports/modules/manual-cash/models';
import { MatSortable } from '@angular/material';
import { Router, NavigationEnd, RouterEvent } from '@angular/router';
import { Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-manual-cash-view',
  templateUrl: './manual-cash-view.component.html',
  styleUrls: ['./manual-cash-view.component.scss']
})
export class ManualCashViewComponent implements OnDestroy {
  manualCashReportDef = manualCashReportDef;
  manualCashReportData: Array<ManualCashEntry> = [];
  sortBy: MatSortable = { id: 'portId', start: 'desc', disableClear: false };
  navigationSubscription: Subscription;

  constructor(
    private reportService: ReportService,
    private router: Router
  ) {
    this.navigationSubscription = this.router.events.pipe(
      filter((event: RouterEvent) => event instanceof NavigationEnd)
    ).subscribe(() => {
      this.loadManualCashReportData();
    });
  }

  loadManualCashReportData(): void {
    this.reportService.getManualCashReport().subscribe(
      data => this.manualCashReportData = data
    );
  }

  ngOnDestroy() {
    this.navigationSubscription.unsubscribe();
  }
}
