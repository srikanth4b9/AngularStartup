import { ManualCashEntry } from '@reports/modules/manual-cash/models';

export const mockManualCashReport: ManualCashEntry[] = [
  {
    portId: '0430',
    amount: 15000.00,
    crewUserId: 'UXXX',
    lastUpdatedTimestamp: '2019-01-22T12:46:24.137-04:00'
  },
  {
    portId: '5828',
    amount: 340000.00,
    crewUserId: 'UXXX',
    lastUpdatedTimestamp: '2019-01-25T08:03:24.137-04:00'
  }
];
