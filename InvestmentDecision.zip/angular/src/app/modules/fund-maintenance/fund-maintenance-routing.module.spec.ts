import { FundMaintenanceRoutingModule } from './fund-maintenance-routing.module';

describe('FundMaintenanceRoutingModule', () => {
  let fundMaintenanceRoutingModule: FundMaintenanceRoutingModule;

  beforeEach(() => {
    fundMaintenanceRoutingModule = new FundMaintenanceRoutingModule();
  });

  it('should create an instance', () => {
    expect(fundMaintenanceRoutingModule).toBeTruthy();
  });
});
