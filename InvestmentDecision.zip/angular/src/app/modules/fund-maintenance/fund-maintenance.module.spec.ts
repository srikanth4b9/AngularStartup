import { FundMaintenanceModule } from './fund-maintenance.module';

describe('FundMaintenanceModule', () => {
  let fundMaintenanceModule: FundMaintenanceModule;

  beforeEach(() => {
    fundMaintenanceModule = new FundMaintenanceModule();
  });

  it('should create an instance', () => {
    expect(fundMaintenanceModule).toBeTruthy();
  });
});
