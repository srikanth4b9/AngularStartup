import { of, EMPTY } from 'rxjs';
import { mockFund5828, mockPortIdList, mockFund0430 } from '../models';

export class MockFundMaintenanceService {
  portIds$ = of(mockPortIdList);
  getPortIds = jasmine.createSpy().and.returnValue(this.portIds$);

  selectedTabIndex$ = of(0);
  setSelectedTabIndex = jasmine.createSpy();

  fundProfiles$ = of([mockFund0430, mockFund5828]);
  getFundProfile = jasmine.createSpy().and.returnValue(of(mockFund5828));
  getFundProfileForHoldings = jasmine.createSpy().and.returnValue(of(mockFund5828));
  getFundProfileTabs = jasmine.createSpy().and.returnValue(of([]));

  refreshFundProfile = jasmine.createSpy().and.returnValue(EMPTY);
  deactivateFundProfile = jasmine.createSpy().and.returnValue(of({}));
  reactivateFundProfile = jasmine.createSpy().and.returnValue(of({}));
  saveFundProfile = jasmine.createSpy().and.returnValue(EMPTY);
  removeFundProfile = jasmine.createSpy();

  exportFundProfile = jasmine.createSpy();
  exportFundHoldings = jasmine.createSpy();
}
