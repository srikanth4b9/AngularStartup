import { of } from 'rxjs';
import { FundProfileForm, mockFund5828 } from '../models';

export class MockFundProfileFormService {
    fundProfileForm$ = of(new FundProfileForm(mockFund5828));
    loadProfile = jasmine.createSpy();
  }
