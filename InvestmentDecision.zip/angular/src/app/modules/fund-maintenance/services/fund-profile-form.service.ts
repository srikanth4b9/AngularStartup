import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
import { FundProfile, FundProfileForm } from '../models';

import { mockFund0430, mockFund5828 } from '@app/modules/fund-maintenance/models';

@Injectable()
export class FundProfileFormService {
  private fundProfileFormSubject: BehaviorSubject<FundProfileForm> = new BehaviorSubject(new FundProfileForm());
  fundProfileForm$: Observable<FundProfileForm> = this.fundProfileFormSubject.asObservable();

  constructor() { }

  public loadProfile(fundProfile: FundProfile = new FundProfile()) {
    this.fundProfileFormSubject.next(new FundProfileForm(fundProfile));
    // this.fundProfileFormSubject.next(new FundProfileForm(mockFund5828));
  }

  get fundProfileForm(): FundProfileForm {
    return this.fundProfileFormSubject.getValue();
  }
}
