import { TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';

import { mockFund0430, mockFund5828 } from '../models';
import { FundProfileFormService } from './fund-profile-form.service';

describe('FundProfileFormService', () => {
  let service: FundProfileFormService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        ReactiveFormsModule
      ],
      providers: [FundProfileFormService]
    });
    service = TestBed.get(FundProfileFormService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('loadProfile', () => {
    it('should set the fund profile of type legacy', () => {
      service.loadProfile(mockFund0430);

      service.fundProfileForm$.subscribe(fundProfileForm => {
        expect(fundProfileForm.get('fundName').value).toEqual(mockFund0430.fundName);
        expect(fundProfileForm.get('productType').value).toEqual(mockFund0430.productType);
        expect(fundProfileForm.get('vastAccountNumber').value).toEqual(mockFund0430.vastAccountNumber);
      });
    });

    it('should set the fund profile of type ctdf', () => {
      service.loadProfile(mockFund5828);

      service.fundProfileForm$.subscribe(fundProfileForm => {
        expect(fundProfileForm.get('fundName').value).toEqual(mockFund5828.fundName);
        expect(fundProfileForm.get('productType').value).toEqual(mockFund5828.productType);
        expect(fundProfileForm.get('vastAccountNumber').value).toEqual(mockFund5828.vastAccountNumber);
      });
    });
  });

  describe('isDirty', () => {
    beforeEach(function() {
      service.loadProfile(mockFund0430);
    });

    it('should return true if a form control is dirty', () => {
      service.loadProfile(mockFund0430);
      service.fundProfileForm.get('fundName').setValue('NEW NAME');
      expect(service.fundProfileForm.isDirty()).toEqual(true);
    });
  });
});
