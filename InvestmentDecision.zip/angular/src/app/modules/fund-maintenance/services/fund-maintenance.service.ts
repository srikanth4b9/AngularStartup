import { Injectable } from '@angular/core';
import { Observable, of, BehaviorSubject } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import { environment } from '@env';

import { RestService } from '@app/services';
import { PortIdListItem, FundProfile } from '@app/modules/fund-maintenance/models';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class FundMaintenanceService {
  private portIdsSubject: BehaviorSubject<PortIdListItem[]> = new BehaviorSubject([]);
  portIds$: Observable<PortIdListItem[]> = this.portIdsSubject.asObservable();
  fundProfiles: FundProfile[] = [];
  fundProfiles$: BehaviorSubject<FundProfile[]> = new BehaviorSubject(this.fundProfiles);
  selectedTabIndex: number = 0;
  selectedTabIndex$: BehaviorSubject<number> = new BehaviorSubject(this.selectedTabIndex);

  constructor(
    private restService: RestService,
    private router: Router) { }


  public getPortIds(): void {
    this.restService.getData<PortIdListItem[]>(environment.FUND_LIST, 'Load Port IDs')
      .pipe(
        tap(data => this.portIdsSubject.next(data))
      ).subscribe();
  }

  public setSelectedTabIndex(index: number) {
    this.selectedTabIndex = index;
    this.selectedTabIndex$.next(index);
  }

  public getFundProfile(portId: string, refreshData?: boolean): Observable<FundProfile> {
    const foundFundProfile = this.findFundProfile(portId);
    if (refreshData || !foundFundProfile) {
      return this.restService.getData<FundProfile>(`${environment.FUND_PROFILES}/${portId}`, 'Load Fund Profile')
        .pipe(
          map(response => refreshData ? this.updateProfile(response) : this.addProfile(response))
        );
    } else {
      this.setSelectedTabIndex(this.fundProfiles.indexOf(foundFundProfile));
      return of(foundFundProfile);
    }
  }

  public getFundProfileForHoldings(portId: string): Observable<FundProfile> {
    return this.restService.getData<FundProfile>(`${environment.FUND_PROFILES}/${portId}`, 'Load Fund Profile Holdings');
  }

  private findFundProfile(portId: string): FundProfile {
    return this.fundProfiles.filter(fundProfile => fundProfile.portId.portId === portId)[0];
  }

  public refreshFundProfile(portId: string): void {
    this.getFundProfile(portId, true).subscribe(
      () => this.router.navigate(['/fund-maintenance'])
    );
  }

  private addProfile(fundProfile: FundProfile): FundProfile {
    this.fundProfiles.push(fundProfile);
    this.selectedTabIndex = this.fundProfiles.length - 1;
    this.pushFundProfilesUpdate();

    return fundProfile;
  }

  private updateProfile(updatedFundProfile: FundProfile): FundProfile {
    const index = this.fundProfiles.indexOf(this.findFundProfile(updatedFundProfile.portId.portId));

    this.fundProfiles.splice(index, 1, updatedFundProfile);
    this.selectedTabIndex = index;
    this.pushFundProfilesUpdate();

    return updatedFundProfile;
  }

  public removeFundProfile(index: number): void {
    this.fundProfiles.splice(index, 1);
    this.pushFundProfilesUpdate();
  }

  private pushFundProfilesUpdate() {
    this.fundProfiles$.next(this.fundProfiles);
    this.selectedTabIndex$.next(this.selectedTabIndex);
  }

  public exportFundProfile(exportDate): void {
    this.restService.exportData(environment.FUND_PROFILES, `fund-profile-${exportDate}`, 'Export Fund Profile');
  }

  public exportFundHoldings(exportDate): void {
    this.restService.exportData(environment.FUND_HOLDINGS, `fund-holdings-${exportDate}`, 'Export Fund Holdings');
  }

  public saveFundProfile(fundProfile: FundProfile, isNewFund: boolean): Observable<any> {
    return isNewFund ?
      this.restService.postData<FundProfile>(environment.FUND_PROFILES, fundProfile, 'Create Fund Profile')
      : this.restService.putData<FundProfile>(`${environment.FUND_PROFILES}/${fundProfile.portId.portId}`,
        fundProfile, 'Save Fund Profile');
  }

  public deactivateFundProfile(fundProfile: FundProfile): void {
    const request = this.restService.deleteData<FundProfile>(`${environment.FUND_PROFILES}/${fundProfile.portId.portId}`,
      null, 'Deactivate Fund Profile');

    request.subscribe(() => {
      this.getPortIds();
      this.refreshFundProfile(fundProfile.portId.portId);
    });
  }

  public reactivateFundProfile(fundProfile: FundProfile): void {
    const request = this.restService.postData<null>(`${environment.FUND_PROFILES}/${fundProfile.portId.portId}`,
      null, 'Reactivate Fund Profile');

    request.subscribe(() => {
      this.getPortIds();
      this.refreshFundProfile(fundProfile.portId.portId);
    });
  }
}
