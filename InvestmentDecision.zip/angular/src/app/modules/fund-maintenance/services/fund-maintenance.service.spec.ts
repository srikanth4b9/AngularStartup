import { TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { mockFund0430 as mockFundProfile, mockFund5828, mockPortIdList } from '@app/modules/fund-maintenance/models';
import { RestService } from '@app/services';
import { environment } from '@env';
import { of } from 'rxjs';

import { FundMaintenanceService } from './fund-maintenance.service';


class MockRestService {
  getData = jasmine.createSpy().and.callFake((apiPath: string) => {
    if (apiPath === environment.FUND_LIST) {
      return of(mockPortIdList);
    } else if (apiPath === `${environment.FUND_PROFILES}/0430`) {
      return of(mockFundProfile);
    } else {
      return of(null);
    }
  });
  postData = jasmine.createSpy().and.returnValue(of({}));
  putData = jasmine.createSpy().and.returnValue(of({}));
  deleteData = jasmine.createSpy().and.returnValue(of({}));
  exportData = jasmine.createSpy();
}

describe('FundMaintentanceService', () => {
  let service: FundMaintenanceService;
  let restService: MockRestService;
  let router: Router;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule
      ],
      providers: [{ provide: RestService, useClass: MockRestService }]
    });
    service = TestBed.get(FundMaintenanceService);
    restService = TestBed.get(RestService);
    router = TestBed.get(Router);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('getPortIds:', () => {
    it('should fetch list of Port IDs', () => {
      service.getPortIds();
      service.portIds$.subscribe(data => {
        expect(data).toEqual(mockPortIdList);
      });

      expect(restService.getData).toHaveBeenCalledWith(environment.FUND_LIST, 'Load Port IDs');
    });
  });

  describe('setSelectedTabIndex:', () => {
    it('should get current fund profile tabs', () => {
      const index = 7;
      service.setSelectedTabIndex(index);

      expect(service.selectedTabIndex).toEqual(index);
    });
  });

  describe('getFundProfile', () => {
    it('should try to fetch the data if not loaded', () => {
      const portId = mockFundProfile.portId.portId;
      service.getFundProfile(portId, false).subscribe(data => {
        expect(data).toEqual(mockFundProfile);
      });

      expect(restService.getData).toHaveBeenCalledWith(`${environment.FUND_PROFILES}/${portId}`, 'Load Fund Profile');
    });

    it('should try to fetch the data if not loaded', () => {
      const portId = mockFundProfile.portId.portId;
      service.getFundProfile(portId, true).subscribe(data => {
        expect(data).toEqual(mockFundProfile);
      });

      expect(restService.getData).toHaveBeenCalledWith(`${environment.FUND_PROFILES}/${portId}`, 'Load Fund Profile');
    });

    it('should pull the data from cached fundProfiles', () => {
      const portId = mockFundProfile.portId.portId;
      service.fundProfiles = [mockFundProfile];
      service.getFundProfile(portId, false).subscribe(data => {
        expect(data).toEqual(mockFundProfile);
      });
    });
  });

  describe('Refresh fund profile', () => {
    it('should call getFundProfile', () => {
      const getFundProfileSpy = spyOn(service, 'getFundProfile').and.returnValue(of(mockFund5828));
      const navigateSpy = spyOn(router, 'navigate');

      service.refreshFundProfile(mockFundProfile.portId.portId);

      expect(getFundProfileSpy).toHaveBeenCalledWith(mockFundProfile.portId.portId, true);
      expect(navigateSpy).toHaveBeenCalledWith(['/fund-maintenance']);
    });
  });



  describe('exportReports:', () => {
    it('should call rest service to export the Fund profile', () => {
      service.exportFundProfile('2019-06-10');
      expect(restService.exportData).toHaveBeenCalledWith(environment.FUND_PROFILES, 'fund-profile-2019-06-10', 'Export Fund Profile');
    });

    it('should call rest service to export the Fund Holdings', () => {
      service.exportFundHoldings('2019-06-10');
      expect(restService.exportData).toHaveBeenCalledWith(environment.FUND_HOLDINGS, 'fund-holdings-2019-06-10', 'Export Fund Holdings');
    });
  });

  it('remove fund profile', () => {
    service.fundProfiles = [mockFundProfile, mockFund5828];
    service.removeFundProfile(1);
    expect(service.fundProfiles).toEqual([mockFundProfile]);
  });

  describe('savefundProfile:', () => {
    it('save fund profile should be called with postData', () => {
      service.saveFundProfile(mockFund5828, true);
      expect(restService.postData).toHaveBeenCalledWith(environment.FUND_PROFILES, mockFund5828, 'Create Fund Profile');
    });
    it('save fund profile should be called with putData', () => {
      service.saveFundProfile(mockFund5828, false);
      expect(restService.putData)
        .toHaveBeenCalledWith(`${environment.FUND_PROFILES}/${mockFund5828.portId.portId}`, mockFund5828, 'Save Fund Profile');
    });
  });

  describe('deactivateFundProfile:', () => {
    it('should make delete request to deactivate fund profile', () => {
      const getPortIdsSpy = spyOn(service, 'getPortIds');
      const refreshSpy = spyOn(service, 'refreshFundProfile');

      service.deactivateFundProfile(mockFund5828);

      expect(restService.deleteData)
        .toHaveBeenCalledWith(`${environment.FUND_PROFILES}/${mockFund5828.portId.portId}`, null, 'Deactivate Fund Profile');
      expect(getPortIdsSpy).toHaveBeenCalled();
      expect(refreshSpy).toHaveBeenCalledWith(mockFund5828.portId.portId);
    });
  });

  describe('reactivateFundProfile:', () => {
    it('save fund profile should be called with postData', () => {
      const getPortIdsSpy = spyOn(service, 'getPortIds');
      const refreshSpy = spyOn(service, 'refreshFundProfile');

      service.reactivateFundProfile(mockFund5828);

      expect(restService.postData)
        .toHaveBeenCalledWith(`${environment.FUND_PROFILES}/${mockFund5828.portId.portId}`, null, 'Reactivate Fund Profile');
        expect(getPortIdsSpy).toHaveBeenCalled();
        expect(refreshSpy).toHaveBeenCalledWith(mockFund5828.portId.portId);
    });
  });
});
