import { ColumnDefBuilder, ColumnType, TableDef } from '@app/shared/models';

// import { HoldingType } from './forms/form.utils';

export enum HoldingType {
  Directive = 'Directive',
  Security = 'Security'
}

export class Cusip {
  cusipNumber: string;
}

export class Holding {
  type: string;
  holdingId: number;
  tier: number;
  name: string;
  tradeSubmissionMethod: TradeSubmissionMethod = 'NOT_APPLICABLE';
  rebalanceEligible: boolean = true;
  targetAllocation: number = 0;
  dailyActivityTargetAllocation: number = 0;
  rebalanceThreshold: number = 0.0085;
  cusip?: Cusip;
  accountNumber?: string;
  accountingSecurityId?: string;
  securityDirectiveId?: number;
  children?: Holding[];


  constructor(holdingType: HoldingType) {
    if (holdingType === HoldingType.Directive) {
      this.type = 'fundHoldingDirective';
      this.children = [];
    } else {
      this.type = 'fundHoldingSecurity';
      this.tradeSubmissionMethod = 'NSCC';
      this.cusip = new Cusip();
    }
  }
}

type TradeSubmissionMethod = 'NSCC' | 'DIRECT' | 'FAX' | 'NOT_APPLICABLE';
export const TradeSubmissionMethod = {
  'NSCC': 'NSCC',
  'DIRECT': 'Direct',
  'FAX': 'Fax'
};

export class HoldingsTableDef extends TableDef {
  constructor() {
    super([
      new ColumnDefBuilder('Name', 'name', ColumnType.STRING).build(),
      new ColumnDefBuilder('CUSIP', 'cusip', ColumnType.CUSIP).build(),
      new ColumnDefBuilder('Accounting Security Id', 'accountingSecurityId', ColumnType.STRING).build(),
      new ColumnDefBuilder('Account No', 'accountNumber', ColumnType.STRING).build(),
      new ColumnDefBuilder('Trade Submission Method', 'tradeSubmissionMethod', ColumnType.ENUM).enumType(TradeSubmissionMethod).build(),
      new ColumnDefBuilder('Daily Target Allocation %', 'dailyActivityTargetAllocation', ColumnType.PERCENT).build(),
      new ColumnDefBuilder('Target Allocation %', 'targetAllocation', ColumnType.PERCENT).build(),
      new ColumnDefBuilder('Rebalance Threshold', 'rebalanceThreshold', ColumnType.PERCENT).build(),
      new ColumnDefBuilder('Rebalance', 'rebalanceEligible', ColumnType.BOOLEAN).build()
    ]);
  }

}
export const holdingsTableDef: TableDef = new HoldingsTableDef();
