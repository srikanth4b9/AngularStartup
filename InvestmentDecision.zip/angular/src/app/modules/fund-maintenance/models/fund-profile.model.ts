import { Holding } from '@app/modules/fund-maintenance/models';

export class PortIdListItem {
  indirectFund: boolean;
  portId: string;
  active: boolean;
}

export class PortId {
  portId: string;
}

export class FundProfile {
  portId: PortId = new PortId();
  fundName: string;
  productType: ProductType;
  classification: FundClassification;
  rebalanceType: RebalanceType;
  indirectFund: boolean = false;
  effectiveBeginTimestamp: string;
  tradingActive: boolean;
  rebalanceEligible: boolean = true;
  crewUserId: string;
  lastUpdatedTimestamp: string;
  client?: string;
  recordkeeper?: string;
  activitySource?: string;
  vastAccountNumber?: string;
  active: boolean = true;
  holdings: Holding[];
  isNewFund?: boolean;

  constructor() {
    this.isNewFund = true;
  }
}

type ProductType = 'CUSTOM_TARGET_DATE_FUND' | 'LEGACY_FUND_OF_FUND' | 'LEGACY_AM_FUND_OF_FUND';
export const ProductType = {
  'CUSTOM_TARGET_DATE_FUND': 'CTDF',
  'LEGACY_FUND_OF_FUND': 'Legacy',
  'LEGACY_AM_FUND_OF_FUND': 'Legacy AM'
};
export enum ProductTypeEnum {
  CUSTOM_TARGET_DATE_FUND = 'CUSTOM_TARGET_DATE_FUND',
  LEGACY_FUND_OF_FUND = 'LEGACY_FUND_OF_FUND',
  LEGACY_AM = 'LEGACY_AM_FUND_OF_FUND'
}

type RebalanceType = 'BASIC' | 'SMART' | 'LEGACY';
export const RebalanceType = {
  'BASIC': 'Basic',
  'SMART': 'Smart',
  'LEGACY': 'Legacy'
};
export enum RebalanceTypeEnum {
  BASIC = 'BASIC',
  SMART = 'SMART',
  LEGACY = 'LEGACY'
}

type FundClassification = 'RETAIL' | 'INSTITUTIONAL';
export const FundClassification = {
  'RETAIL': 'Retail',
  'INSTITUTIONAL': 'Institutional'
};
