import { PortIdListItem } from '../fund-profile.model';

export const mockPortIdList: PortIdListItem[] = [
    {
        'indirectFund': false,
        'portId': '0430',
        'active': true
    },
    {
        'indirectFund': true,
        'portId': '1000',
        'active': false
    },
    {
        'indirectFund': true,
        'portId': '1001',
        'active': false
    },
    {
        'indirectFund': true,
        'portId': '1007',
        'active': false
    },
    {
        'indirectFund': true,
        'portId': '1008',
        'active': false
    },
    {
        'indirectFund': false,
        'portId': '1107',
        'active': true
    },
    {
        'indirectFund': false,
        'portId': '1394',
        'active': true
    },
    {
        'indirectFund': false,
        'portId': '1395',
        'active': true
    },
    {
        'indirectFund': true,
        'portId': '2040',
        'active': true
    },
    {
        'indirectFund': true,
        'portId': '2041',
        'active': true
    },
    {
        'indirectFund': false,
        'portId': '2395',
        'active': false
    },
    {
        'indirectFund': false,
        'portId': '4255',
        'active': false
    },
    {
        'indirectFund': false,
        'portId': '4266',
        'active': true
    },
    {
        'indirectFund': false,
        'portId': '5828',
        'active': true
    },
    {
        'indirectFund': false,
        'portId': '5891',
        'active': true
    },
    {
        'indirectFund': false,
        'portId': '7007',
        'active': true
    },
    {
        'indirectFund': false,
        'portId': '8008',
        'active': true
    },
    {
        'indirectFund': false,
        'portId': '8828',
        'active': true
    },
    {
        'indirectFund': false,
        'portId': '3395',
        'active': true
    }
];
