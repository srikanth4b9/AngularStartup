import { FundProfile } from '@app/modules/fund-maintenance/models';

export const mockFund0430: FundProfile = {
  'activitySource': 'ETS',
  'classification': 'RETAIL',
  'client': 'IOWA 529 PLAN',
  'crewUserId': 'UU6E',
  'effectiveBeginTimestamp': '11/28/2018 07:30 AM',
  'fundName': 'AGGRESSIVE GRWTH PORT',
  'active': true,
  'holdings': [{
    'type': 'fundHoldingSecurity',
    'accountNumber': '9948141909',
    'accountingSecurityId': '1871',
    'cusip': { 'cusipNumber': '922040407' },
    'dailyActivityTargetAllocation': 0.6,
    'holdingId': 74,
    'name': 'TTL INTL STK IDX INST PLS',
    'rebalanceEligible': true,
    'rebalanceThreshold': 0.0085,
    'targetAllocation': 0.6,
    'tier': 1,
    'tradeSubmissionMethod': 'NSCC'
  },
  {
    'type': 'fundHoldingSecurity',
    'accountNumber': '9948141909',
    'accountingSecurityId': '871',
    'cusip': { 'cusipNumber': '921909776' },
    'dailyActivityTargetAllocation': 0.4,
    'holdingId': 79,
    'name': 'TTL STK MKT IDX INST PLUS',
    'rebalanceEligible': true,
    'rebalanceThreshold': 0.0085,
    'targetAllocation': 0.4,
    'tier': 1,
    'tradeSubmissionMethod': 'NSCC'
  }],
  'indirectFund': false,
  'lastUpdatedTimestamp': '06/25/2019 01:13 PM',
  'portId': { 'portId': '0430' },
  'productType': 'LEGACY_FUND_OF_FUND',
  'rebalanceEligible': true,
  'rebalanceType': 'LEGACY',
  'tradingActive': true,
  'vastAccountNumber': '09947231221'
};

export const testHolding = [{
  'type': 'fundHoldingSecurity',
  'accountNumber': '9948141909',
  'accountingSecurityId': '1871',
  'cusip': { 'cusipNumber': '922040407' },
  'dailyActivityTargetAllocation': 0.6,
  'holdingId': 74,
  'name': 'TTL INTL STK IDX INST PLS',
  'rebalanceEligible': true,
  'rebalanceThreshold': 0.0085,
  'targetAllocation': 0.6,
  'tier': 1,
  'tradeSubmissionMethod': 'NSCC'
}];
