import { FormControl, Validators, FormGroup, FormArray, ValidatorFn, AbstractControl } from '@angular/forms';
import { Holding, HoldingType } from '../fund-holding.model';
import { FormUtils } from './form.utils';
import { Security } from '@security-master/modules/securities/models';
import { Directive } from '@app/modules/security-master/modules/directives/models';

const DECIMAL_PRECISION_5 = 5;
const MIN_DAILY_ALLOCATION = 0;
const MAX_PERCENT = 1;
const MIN_TARGET_ALLOCATION = 0.00001;

// tslint:disable: no-use-before-declare
export class HoldingsFormArray extends FormArray {
  holdings: Holding[];

  /* istanbul ignore next */
  constructor(holdings: Holding[] = []) {
    super(holdings.map(holding => {
      return new HoldingForm(FormUtils.getHoldingType(holding.type), holding.tier, holding);
    }));
    this.holdings = holdings;
    this.setValidators([
      this.validateHoldingMinimum(),
      this.validateAllocationTotal({ title: 'Target Allocation', name: 'targetAllocation' }),
      this.validateAllocationTotal({ title: 'Daily Activity Target Allocation', name: 'dailyActivityTargetAllocation' })
    ]);
  }

  addHolding(holdingType: HoldingType, tier: number) {
    this.push(new HoldingForm(holdingType, tier));
  }

  isDirty(): boolean {
    return this.controls.some(
      (holdingForm: HoldingForm) => holdingForm.isDirty()
    );
  }

  private validateHoldingMinimum(): ValidatorFn {
    const validator: ValidatorFn = (formArray: HoldingsFormArray) => {
      return formArray.controls.length >= 1 ? null : { noHoldings: true };
    };
    return validator;
  }

  private validateAllocationTotal(attribute: { title: string, name: string }): ValidatorFn {
    const validator: ValidatorFn = (formArray: HoldingsFormArray) => {
      const targetAllocationSum: number = (formArray.controls as HoldingForm[])
        .map(holdingForm => holdingForm[attribute.name].value)
        .reduce((a, b) => a + b, 0)
        .toFixed(DECIMAL_PRECISION_5);
      const isTotalValid = Math.abs(targetAllocationSum - 1) === 0;
      return isTotalValid ? null : { allocationTotal: { title: attribute.title, value: targetAllocationSum } };
    };
    return validator;
  }

  getValidationError(): string {
    return this.errors.noHoldings ? 'Must have at least one holding' :
      this.errors.allocationTotal ?
        `Sum of ${this.errors.allocationTotal.title} % must equal 100%.
        Actual: ${FormUtils.toPercentString(this.errors.allocationTotal.value)}` :
        '';
  }
}

export class HoldingForm extends FormGroup {
  holding: Holding;

  /* istanbul ignore next */
  constructor(holdingType: HoldingType, tier: number = 0, holding: Holding = new Holding(holdingType)) {
    super({
      holdingId: new FormControl(holding.holdingId),
      tier: new FormControl(tier),
      name: new FormControl({ value: holding.name, disabled: holding.name }, Validators.required),
      type: new FormControl(holding.type, Validators.required),
      tradeSubmissionMethod: new FormControl(holding.tradeSubmissionMethod, Validators.required),
      rebalanceEligible: new FormControl(holding.rebalanceEligible),
      rebalanceThreshold: new FormControl(holding.rebalanceThreshold,
        [Validators.required, Validators.max(MAX_PERCENT)]),
      targetAllocation: new FormControl(holding.targetAllocation,
        [Validators.required, Validators.min(MIN_TARGET_ALLOCATION), Validators.max(MAX_PERCENT)]),
      dailyActivityTargetAllocation: new FormControl(holding.dailyActivityTargetAllocation,
        [Validators.required, Validators.min(MIN_DAILY_ALLOCATION), Validators.max(MAX_PERCENT)]),
      securityDirectiveId: new FormControl(holding.securityDirectiveId)
    });

    if (holdingType === HoldingType.Directive) {
      this.addControl('children', new HoldingsFormArray(holding.children));
    } else {
      this.addControl('cusip', new FormGroup({
        'cusipNumber': new FormControl({ value: holding.cusip.cusipNumber, disabled: true }, Validators.required)
      }));
      this.addControl('accountNumber', new FormControl(holding.accountNumber,
        [Validators.required, Validators.pattern('^[a-zA-Z0-9-]{0,20}$')]
      ));
      this.addControl('accountingSecurityId',
        new FormControl({ value: holding.accountingSecurityId, disabled: true }, Validators.required));
    }
    this.holding = holding;
  }

  get tier(): AbstractControl { return this.get('tier'); }
  get type(): AbstractControl { return this.get('type'); }
  get name(): AbstractControl { return this.get('name'); }
  get cusip(): AbstractControl { return this.get('cusip'); }
  get accountNumber(): AbstractControl { return this.get('accountNumber'); }
  get cusipNumber(): AbstractControl { return this.cusip.get('cusipNumber'); }
  get accountingSecurityId(): AbstractControl { return this.get('accountingSecurityId'); }
  get dailyActivityTargetAllocation(): AbstractControl { return this.get('dailyActivityTargetAllocation'); }
  get targetAllocation(): AbstractControl { return this.get('targetAllocation'); }
  get rebalanceThreshold(): AbstractControl { return this.get('rebalanceThreshold'); }
  get securityDirectiveId(): AbstractControl { return this.get('securityDirectiveId'); }
  get children(): HoldingsFormArray { return this.get('children') as HoldingsFormArray; }

  getHoldingType(): HoldingType {
    return FormUtils.getHoldingType(this.type.value);
  }

  updateDirectiveIdValues(securityDirective: Directive) {
    this.securityDirectiveId.setValue(securityDirective.id);
  }

  updateSecurityIdValues(securityDirective: Security) {
    this.cusipNumber.setValue(securityDirective.cusip);
    this.accountingSecurityId.setValue(securityDirective.accountingSecurityId);
    this.securityDirectiveId.setValue(securityDirective.id);
  }

  getValidationError(formControlName: string): string {
    const errors = this.get(formControlName).errors;
    if (errors) {
      return errors.pattern ? 'No special characters' :
        errors.max ? 'Must be <= 100%' :
          errors.min ? `Must be >= ${FormUtils.toPercentString(errors.min.min)}` :
            '';
    }
  }

  isDirty(): boolean {
    return FormUtils.isFormDirty(this, this.holding);
  }
}
