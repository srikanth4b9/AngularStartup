import { Holding, HoldingType } from '../fund-holding.model';
import { HoldingsFormArray, HoldingForm } from './holdings-form.model';

// import * as chai from 'chai';
// import * as chaiAsPromised from 'chai-as-promised';

// chai.use(chaiAsPromised);
// const expect = chai.expect;

describe('HoldingsFormArray', () => {
  let holdingsFormArray: HoldingsFormArray;
  let holdingsFormArray2: HoldingsFormArray;
  const mockFundHoldings: Holding[] = [
    new Holding(HoldingType.Directive),
    new Holding(HoldingType.Security)
  ];

  beforeEach(() => {
    holdingsFormArray = new HoldingsFormArray(mockFundHoldings);
    holdingsFormArray2 = new HoldingsFormArray();
  });

  describe('constructor', () => {
    it('should create a holding form for each holding', () => {
      expect(holdingsFormArray.controls.length).toEqual(2);
      expect(holdingsFormArray.validator).toBeDefined();
    });

    it('should create a holding form with 0 controls', () => {
      expect(holdingsFormArray2.controls.length).toEqual(0);
      expect(holdingsFormArray2.validator).toBeDefined();
    });
  });

  describe('addHolding', () => {
    it('should add a holding of given HoldingType to the form array', () => {
      holdingsFormArray.addHolding(HoldingType.Security, 0);

      expect(holdingsFormArray.controls.length).toEqual(3);
      expect(holdingsFormArray.controls[2].get('rebalanceEligible').disabled).toBeFalsy();
    });
  });

  describe('isDirty', () => {
    it('should return true if a form control is dirty', () => {
      spyOn(holdingsFormArray.controls[0] as HoldingForm, 'isDirty').and.returnValue(true);

      expect(holdingsFormArray.isDirty()).toEqual(true);
    });
  });

  // describe('valideHoldingMinimum', () => {
  //   it('should be invalid if there are no holding forms', () => {
  //     holdingsFormArray = new HoldingsFormArray();

  //     expect(holdingsFormArray.invalid).toEqual(true);

  //     holdingsFormArray.addHolding(HoldingType.Security);

  //     expect(holdingsFormArray.invalid).toEqual(false);
  //   });
  // });

  // describe('getValidationError', () => {
  //   it('should return message for no holdings', () => {
  //     holdingsFormArray = new HoldingsFormArray();
  //     const noHoldingsMessage = 'Must have at least one holding';

  //     spyOn(holdingsFormArray as HoldingsFormArray, 'errors').and.returnValue({  });

  //     expect(holdingsFormArray.getValidationError()).toEqual(noHoldingsMessage);
  //   });
  // });
});
