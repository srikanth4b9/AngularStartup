import { FormGroup } from '@angular/forms';

import { Holding, HoldingType } from '../fund-holding.model';
import { FundProfileForm } from './fund-profile-form.model';
import { HoldingForm } from './holdings-form.model';

const TO_PERCENT_100 = 100;
const DECIMAL_PRECISION_3 = 3;
const DECIMAL_PRECISION_5 = 5;

export class FormUtils {

  static getHoldingType(typeString: string): HoldingType {
    return typeString.toLowerCase().indexOf('directive') !== -1 ? HoldingType.Directive : HoldingType.Security;
  }

  static getAllSecurityHoldings(holdings: Holding[]): Holding[] {
    let securityHoldings = [];
    holdings.forEach(holding => {
      if (FormUtils.getHoldingType(holding.type) === HoldingType.Directive) {
        securityHoldings = securityHoldings.concat(FormUtils.getAllSecurityHoldings(holding.children));
      } else {
        securityHoldings.push(holding);
      }
    });
    return securityHoldings;
  }

  static isFormDirty(form: FormGroup, object: any): boolean {
    const formControlKeys = Object.keys(form.controls);
    return formControlKeys.some(
      (controlKey) => FormUtils.isFieldDirty(form, controlKey, object)
    );
  }

  static isFieldDirty(form: FormGroup, attributeName: string, model: any): boolean {
    if (attributeName === 'holdings') {
      return (<FundProfileForm>form).holdings.isDirty();
    } else if (attributeName === 'children') {
      return (<HoldingForm>form).children.isDirty();
    } else {
      return FormUtils.isControlValueDirty(form.get(attributeName).value, model[attributeName]);
    }
  }

  static isControlValueDirty(controlValue: any, modelValue: any): boolean {
    return modelValue !== undefined ?
      controlValue !== modelValue :
      controlValue !== null;
  }
  static toPercentString(value: number): string {
    return +((value * TO_PERCENT_100).toFixed(DECIMAL_PRECISION_3)) + '%';
  }

  static toPercentDecimalValue(value: string): number {
    return +(parseFloat(value).toFixed(DECIMAL_PRECISION_5));
  }

  static trimWhitespace<T>(payload: T) {
    Object.keys(payload).forEach(key =>
      payload[key] = typeof payload[key] === 'string' ? payload[key].trim() : payload[key]
    );
  }
}
