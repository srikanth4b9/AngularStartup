import { FormControl, Validators, FormGroup, ValidatorFn, AbstractControl } from '@angular/forms';
import { FundProfile, RebalanceTypeEnum, ProductTypeEnum } from '../fund-profile.model';
import { HoldingsFormArray, HoldingForm } from './holdings-form.model';
import { FormUtils } from './form.utils';
import { HoldingType } from '../fund-holding.model';
import { BehaviorSubject, Observable } from 'rxjs';

const MAX_PORT_ID = 4;
const MAX_STRING = 255;

export class FundProfileForm extends FormGroup {
  fundProfile: FundProfile;
  private rebalanceTypeOptions: BehaviorSubject<RebalanceTypeEnum[]> = new BehaviorSubject([]);
  rebalanceTypeOptions$: Observable<RebalanceTypeEnum[]>;
  private holdingTypeOptions: BehaviorSubject<HoldingType[]> = new BehaviorSubject([]);
  holdingTypeOptions$: Observable<HoldingType[]>;

  /* istanbul ignore next */
  constructor(fundProfile: FundProfile = new FundProfile()) {
    super({
      portId: new FormGroup({
        portId: new FormControl(fundProfile.portId.portId, [
          Validators.required, Validators.maxLength(MAX_PORT_ID)
        ])
      }),
      effectiveBeginTimestamp: new FormControl(fundProfile.effectiveBeginTimestamp),
      active: new FormControl(fundProfile.active),
      fundName: new FormControl(fundProfile.fundName, [
        Validators.required, Validators.maxLength(MAX_STRING)
      ]),
      productType: new FormControl(fundProfile.productType, Validators.required),
      classification: new FormControl(fundProfile.classification, Validators.required),
      tradingActive: new FormControl({ value: fundProfile.tradingActive, disabled: fundProfile.isNewFund }),
      indirectFund: new FormControl(fundProfile.indirectFund),
      rebalanceType: new FormControl(fundProfile.rebalanceType, Validators.required),
      rebalanceEligible: new FormControl(fundProfile.rebalanceEligible),
      client: new FormControl(fundProfile.client, Validators.maxLength(MAX_STRING)),
      recordkeeper: new FormControl(fundProfile.recordkeeper, Validators.maxLength(MAX_STRING)),
      activitySource: new FormControl(fundProfile.activitySource, Validators.maxLength(MAX_STRING)),
      vastAccountNumber: new FormControl(fundProfile.vastAccountNumber, Validators.maxLength(MAX_STRING)),
      // crewUserId: new FormControl(fundProfile.crewUserId),
      // lastUpdatedTimestamp: new FormControl(fundProfile.lastUpdatedTimestamp),
      holdings: new HoldingsFormArray(fundProfile.holdings)
    });
    this.rebalanceTypeOptions$ = this.rebalanceTypeOptions.asObservable();
    this.holdingTypeOptions$ = this.holdingTypeOptions.asObservable();
    this.fundProfile = fundProfile;
    this.setValidators(this.validateUniqueHoldings());
    this.setTypeOptions();
  }

  get portId(): AbstractControl { return this.get('portId'); }
  get productType(): AbstractControl { return this.get('productType'); }
  get rebalanceType(): AbstractControl { return this.get('rebalanceType'); }
  get active(): AbstractControl { return this.get('active'); }
  get holdings(): HoldingsFormArray {
    return <HoldingsFormArray>this.get('holdings');
  }

  isDirty(): boolean {
    return FormUtils.isFormDirty(this, this.fundProfile);
  }

  private validateUniqueHoldings(): ValidatorFn {
    const validator: ValidatorFn = (fundProfileForm: FundProfileForm) => {
      const holdingNames = this.getHoldingNames(fundProfileForm.holdings);
      const duplicateNames = this.getDuplicateNames(holdingNames);

      return duplicateNames.length ? { duplicateNames: duplicateNames } : null;
    };
    return validator;
  }

  resetTypeOptions() {
    this.rebalanceType.reset();
    this.holdings.clear();
    this.setTypeOptions();
  }

  private setTypeOptions(): void {
    const productType = this.productType.value;
    this.rebalanceTypeOptions.next(productType === ProductTypeEnum.CUSTOM_TARGET_DATE_FUND ?
      [RebalanceTypeEnum.BASIC, RebalanceTypeEnum.SMART] :
      [RebalanceTypeEnum.LEGACY]
    );
    this.holdingTypeOptions.next(productType === ProductTypeEnum.CUSTOM_TARGET_DATE_FUND ?
      [HoldingType.Directive, HoldingType.Security] :
      [HoldingType.Security]
    );
  }

  private getHoldingNames(holdingsFormArray: HoldingsFormArray): string[] {
    let holdingNames: string[] = [];
    const holdingForms: HoldingForm[] = holdingsFormArray.controls as HoldingForm[];
    holdingForms.forEach(holdingForm => {
      holdingNames.push(holdingForm.name.value);
      if (holdingForm.getHoldingType() === HoldingType.Directive) {
        holdingNames = holdingNames.concat(this.getHoldingNames(holdingForm.children));
      }
    });
    return holdingNames;
  }

  private getDuplicateNames(names: string[]) {
    const uniqueNames = new Set();
    return names.filter(name => uniqueNames.size === uniqueNames.add(name).size);
  }

  getValidationError(): string {
    return this.errors.duplicateNames ? `Holdings must be unique across the fund profile: ${this.errors.duplicateNames}` :
      '';
  }
}
