import { Holding, HoldingType } from '../fund-holding.model';
import { HoldingForm } from './holdings-form.model';


describe('HoldingForm', () => {
  let holdingForm: HoldingForm;
  const holdingType: HoldingType = HoldingType.Security;
  const mockHolding: Holding = new Holding(holdingType);

  // beforeEach(() => {
  //   holdingForm = new HoldingForm(holdingType, mockHolding);
  // });

  // tslint:disable: no-unused-expression
  describe('constructor', () => {
    it('should create controls for a security holding', () => {
      holdingForm = new HoldingForm(HoldingType.Security);

      expect(holdingForm.cusip).toBeDefined();
      expect(holdingForm.accountingSecurityId).toBeDefined();
    });
    it('should create controls for a directive holding', () => {
      holdingForm = new HoldingForm(HoldingType.Directive);

      expect(holdingForm.children).toBeDefined();
    });
  });

  describe('Validators:', () => {
    describe('targetAllocation:', () => {
      it('should be invalid when value is < 0.00001', () => {
        holdingForm = new HoldingForm(HoldingType.Security);

        holdingForm.targetAllocation.setValue(0.000001);

        expect(holdingForm.invalid).toBe(true);
      });
    });
  });


  describe('getValidationError', () => {
      it('should return message must be equal or less than 100%', () => {
        holdingForm = new HoldingForm(HoldingType.Security);
        holdingForm.patchValue({
          dailyActivityTargetAllocation: 1.1
        });
        const result = holdingForm.getValidationError('dailyActivityTargetAllocation');
        expect(result).toBe('Must be <= 100%');
      });

      it('should return message must be greater than or less than 0', () => {
        holdingForm = new HoldingForm(HoldingType.Security);
        holdingForm.patchValue({
          dailyActivityTargetAllocation: -0.1
        });
        const result = holdingForm.getValidationError('dailyActivityTargetAllocation');
        expect(result).toBe('Must be >= 0%');
      });


      it('should return no message for no holdings', () => {
        holdingForm = new HoldingForm(HoldingType.Security);
        holdingForm.patchValue({
          dailyActivityTargetAllocation: ''
        });

        const result = holdingForm.getValidationError('dailyActivityTargetAllocation');
        expect(result).toBe('');
      });

      it('should return message special characters not allowed', () => {
        holdingForm = new HoldingForm(HoldingType.Security);
        holdingForm.patchValue({
          accountNumber: '123456789098765432$'
        });
        const result = holdingForm.getValidationError('accountNumber');
        expect(result).toBe('No special characters');
      });


      it('should return empty message when no special characters are entered', () => {
        holdingForm = new HoldingForm(HoldingType.Security);
        holdingForm.patchValue({
          accountNumber: ''
        });
        const result = holdingForm.getValidationError('accountNumber');
        expect(result).toBe('');
      });
    });

});
