import { Holding, HoldingType } from '../fund-holding.model';
import { FundProfile } from '../fund-profile.model';
import { mockFund0430, mockFund5828 } from '../mock-json';
import { FormUtils } from './form.utils';
import { FundProfileForm } from './fund-profile-form.model';
import { HoldingForm } from './holdings-form.model';
import { ManualTradeForm, mockManualTrades } from '@app/modules/trades/models';
import { Directive } from '@app/modules/security-master/modules/directives/models';

describe('FormUtils', () => {

  describe('getHoldingType', () => {
    it('should return a Directive HoldingType enum for a string', () => {
      const holdingTypeString: string = 'fundHoldingDirective';

      expect(FormUtils.getHoldingType(holdingTypeString)).toEqual(HoldingType.Directive);
    });

    it('should return a Security HoldingType enum for a string', () => {
      const holdingTypeString: string = 'fundHoldingSecurity';

      expect(FormUtils.getHoldingType(holdingTypeString)).toEqual(HoldingType.Security);
    });
  });

  describe('getAllSecurityHoldings:', () => {
    it('should get all security type holdings from a list of holdings', () => {
      expect(FormUtils.getAllSecurityHoldings(mockFund0430.holdings)).toEqual(mockFund0430.holdings);
    });

    it('should get all security type holdings from a list of tiered holdings', () => {
      const expectedHoldings = [
        ...mockFund5828.holdings[0].children,
        ...mockFund5828.holdings[1].children,
        ...mockFund5828.holdings[2].children,
        ...mockFund5828.holdings[3].children,
        ...mockFund5828.holdings[4].children
      ];

      expect(FormUtils.getAllSecurityHoldings(mockFund5828.holdings))
        .toEqual(expectedHoldings);
    });
  });

  describe('isFormDirty', () => {
    let form: ManualTradeForm;
    beforeEach(function () {
      form = new ManualTradeForm(mockManualTrades[0]);
    });

    it('should return false if no fields are dirty', () => {
      expect(FormUtils.isFormDirty(form, mockManualTrades[0])).toEqual(false);
    });

    it('should return true if any field is dirty', () => {
      form.amount.setValue('1000000');
      expect(FormUtils.isFormDirty(form, mockManualTrades[0])).toEqual(true);
    });
  });


  describe('isFieldDirty', () => {
    let form: FundProfileForm | HoldingForm;
    let attributeName: string;
    let model: FundProfile | Holding;

    it('should return true when fund holdings are dirty', () => {
      model = mockFund5828;
      form = new FundProfileForm(model);
      attributeName = 'holdings';

      spyOn(form.holdings, 'isDirty').and.returnValue(true);

      expect(FormUtils.isFieldDirty(form, attributeName, model)).toEqual(true);
    });

    it('should return validation error message', () => {
      model = mockFund5828;
      form = new FundProfileForm(model);
      form.setErrors({ 'duplicateNames': 'duplicate names found' });
      expect(form.getValidationError()).toBe(`Holdings must be unique across the fund profile: ${form.errors.duplicateNames}`);
    });

    it('should return empty validation error message', () => {
      model = mockFund5828;
      form = new FundProfileForm(model);
      form.setErrors({});
      expect(form.getValidationError()).toBe('');
    });

    it('should return true when directive children are dirty', () => {
      model = mockFund5828.holdings[0];
      form = new HoldingForm(HoldingType.Directive, 0, model);
      attributeName = 'children';

      spyOn(form.children, 'isDirty').and.returnValue(true);

      expect(FormUtils.isFieldDirty(form, attributeName, model)).toEqual(true);
    });

    it('should return true when a control value is dirty', () => {
      model = mockFund5828.holdings[0];
      form = new HoldingForm(HoldingType.Directive, 0, model);
      attributeName = 'name';

      spyOn(FormUtils, 'isControlValueDirty').and.returnValue(true);

      expect(FormUtils.isFieldDirty(form, attributeName, model)).toEqual(true);
    });
  });

  describe('isControlValueDirty', () => {
    let controlValue;
    let modelValue;

    it('should return false when model value is undefined and control value is null', () => {
      controlValue = null;
      modelValue = undefined;

      expect(FormUtils.isControlValueDirty(controlValue, modelValue)).toEqual(false);
    });

    it('should return true when model value is undefined and control value is set', () => {
      controlValue = 500;
      modelValue = undefined;

      expect(FormUtils.isControlValueDirty(controlValue, modelValue)).toEqual(true);
    });

    it('should return false when model value and control value are equal', () => {
      controlValue = 500;
      modelValue = 500;

      expect(FormUtils.isControlValueDirty(controlValue, modelValue)).toEqual(false);
    });

    it('should return true when model value and control value are not equal', () => {
      controlValue = 500;
      modelValue = 650;

      expect(FormUtils.isControlValueDirty(controlValue, modelValue)).toEqual(true);
    });
  });

  describe('trimWhitespace', () => {
    it('should trim whitespace from string values', () => {
      const payload: Directive = {
        name: '  T-INS   ',
      };
      FormUtils.trimWhitespace(payload);

      expect(payload.name).toEqual('T-INS');
    });
  });
});
