import { Holding, HoldingType } from '../fund-holding.model';
import { HoldingForm } from './holdings-form.model';
import { FundProfileForm } from './fund-profile-form.model';
import { mockFund5828 } from '../mock-json';


describe('FundProfileForm', () => {
  let fundProfileForm: FundProfileForm;


  // tslint:disable: no-unused-expression
  describe('constructor', () => {
    it('should create controls for a security holding', () => {
      fundProfileForm = new FundProfileForm(mockFund5828);
      expect(fundProfileForm).toBeDefined();
    });
  });
});
