import { FundProfilesViewModule } from './fund-profiles-view.module';

describe('FundProfilesViewModule', () => {
  let fundProfilesViewModule: FundProfilesViewModule;

  beforeEach(() => {
    fundProfilesViewModule = new FundProfilesViewModule();
  });

  it('should create an instance', () => {
    expect(fundProfilesViewModule).toBeTruthy();
  });
});
