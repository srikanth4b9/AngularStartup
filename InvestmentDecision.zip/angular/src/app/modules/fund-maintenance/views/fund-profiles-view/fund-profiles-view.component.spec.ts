import { DatePipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { FundProfileTabsModule } from '@app/modules/fund-maintenance/components';
import { FundMaintenanceService } from '@app/modules/fund-maintenance/services';
import { MaterialModule } from '@app/shared/material.module';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { PortIdSelectModule } from '@shared/components';

import { MockFundMaintenanceService } from '../../services/fund-maintenance.service.mock';
import { FundProfilesViewComponent } from './fund-profiles-view.component';


describe('FundProfilesViewComponent', () => {
  let component: FundProfilesViewComponent;
  let fixture: ComponentFixture<FundProfilesViewComponent>;
  let fundMaintenanceService: MockFundMaintenanceService;
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FundProfilesViewComponent],
      imports: [
        RouterTestingModule,
        MaterialModule,
        FormsModule,
        ReactiveFormsModule,
        NoopAnimationsModule,
        FontAwesomeModule,
        FundProfileTabsModule,
        PortIdSelectModule
      ],
      providers: [
        HttpClient, DatePipe,
        { provide: FundMaintenanceService, useClass: MockFundMaintenanceService }
      ]
    })
      .compileComponents();

    fundMaintenanceService = TestBed.get(FundMaintenanceService);
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FundProfilesViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should create the fund search form group', () => {
    expect(component.fundSearchForm).toBeDefined();
  });

  describe('getFundProfile:', () => {
    it('should call service to get a fund profile by Port ID', () => {
      const portIdValue = '0430';
      component.portId.setValue(portIdValue);

      component.getFundProfile();

      expect(fundMaintenanceService.getFundProfile).toHaveBeenCalledWith(portIdValue);
    });
  });

  describe('isSearchDisabled:', () => {
    it('should return true if portId value is null', () => {
      component.portId.setValue(null);

      expect(component.isSearchDisabled).toBe(true);
    });

    // it('should return true if portId value is invalid', () => {
    //   const portIdValue = '9999';
    //   component.portId.setValue(portIdValue);

    //   expect(component.isSearchDisabled).toBe(true);
    // });

    it('should return false if portId is valid', () => {
      const portIdValue = '0430';
      component.portId.setValue(portIdValue);

      expect(component.isSearchDisabled).toBe(false);
    });
  });

  describe('exportFundProfile:', () => {
    it('should call rest service to export the Fund profile', () => {
      component.exportFundProfile();

      expect(fundMaintenanceService.exportFundProfile).toHaveBeenCalled();
    });
  });

  describe('exportFundHoldings:', () => {
    it('should call rest service to export the Fund Holdings', () => {
      component.exportFundHoldings();

      expect(fundMaintenanceService.exportFundHoldings).toHaveBeenCalled();
    });
  });
});
