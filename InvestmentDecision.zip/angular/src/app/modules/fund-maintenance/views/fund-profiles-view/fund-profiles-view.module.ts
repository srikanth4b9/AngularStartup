import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import {
  MatFormFieldModule,
  MatAutocompleteModule,
  MatTabsModule,
  MatInputModule,
  MatButtonModule,
  MatToolbarModule,
  MatDividerModule
} from '@angular/material';

import { FundProfileTabsModule } from '@fund-maintenance/components';
import { FundProfilesViewComponent } from './fund-profiles-view.component';
import { PortIdSelectModule } from '@shared/components';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatInputModule,
    MatFormFieldModule,
    MatAutocompleteModule,
    MatTabsModule,
    MatToolbarModule,
    MatDividerModule,
    FundProfileTabsModule,
    FontAwesomeModule,
    PortIdSelectModule
  ],
  declarations: [FundProfilesViewComponent],
  providers: [DatePipe],
  exports: [FundProfilesViewComponent]
})
export class FundProfilesViewModule { }
