export * from './fund-profiles-view.component';
export * from './fund-profiles-view.module';
