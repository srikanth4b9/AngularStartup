import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';

import { FundMaintenanceService } from '@app/modules/fund-maintenance/services';
import { faDownload, faPlusCircle } from '@fortawesome/free-solid-svg-icons';
import { DatePipe } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-fund-profiles',
  templateUrl: './fund-profiles-view.component.html',
  styleUrls: ['./fund-profiles-view.component.scss']
})

export class FundProfilesViewComponent {
  fundSearchForm: FormGroup = this.createFormGroup();
  selectedPortId: number;
  selectedTabIndex: number = 0;

  faDownload = faDownload;
  faPlusCircle = faPlusCircle;
  fundDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd');

  constructor(
    public fundProfileService: FundMaintenanceService,
    public formBuilder: FormBuilder,
    private datePipe: DatePipe,
    private router: Router) { }

  private createFormGroup() {
    return this.formBuilder.group({
      portId: ['']
    });
  }

  get portId() { return this.fundSearchForm.get('portId'); }

  get isSearchDisabled() {
    return !this.portId.value || this.portId.invalid;
  }

  getFundProfile(): void {
    this.fundProfileService.getFundProfile(this.portId.value).subscribe();
  }

  exportFundProfile(): void {
    this.fundProfileService.exportFundProfile(this.fundDate);
  }

  exportFundHoldings(): void {
    this.fundProfileService.exportFundHoldings(this.fundDate);
  }

  addFundProfile(): void {
    this.router.navigate(['/fund-maintenance/create']);
  }
}
