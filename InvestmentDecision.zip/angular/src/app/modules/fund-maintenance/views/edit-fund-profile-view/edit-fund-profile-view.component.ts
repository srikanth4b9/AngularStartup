import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FundClassification, ProductType, RebalanceType, FundProfileForm } from '@app/modules/fund-maintenance/models';
import { FundMaintenanceService, FundProfileFormService } from '@app/modules/fund-maintenance/services';
import { Subscription } from 'rxjs';
import { MatDialog } from '@angular/material';
import { faExclamationTriangle } from '@fortawesome/free-solid-svg-icons';
import { SecurityMasterService } from '@app/modules/security-master/services';
import { ConfirmDialogModel } from '@app/shared/models';
import { ConfirmDialogComponent } from '@app/components';

@Component({
  selector: 'app-edit-fund-profile-view',
  templateUrl: './edit-fund-profile-view.component.html',
  styleUrls: ['./edit-fund-profile-view.component.scss']
})
export class EditFundProfileViewComponent implements OnInit, OnDestroy {
  portId: string;
  fundProfileForm: FundProfileForm;
  fundProfileFormSub: Subscription;

  isNewFund: boolean = true;
  formTitle: string;

  keys = Object.keys;
  classifications = FundClassification;
  productTypes = ProductType;
  rebalanceTypes = RebalanceType;
  faExclamationTriangle = faExclamationTriangle;

  confirmDialogData: ConfirmDialogModel = {
    title: 'Are You Sure?',
    message: `All of the fund's holdings will be removed.`,
    confirmButtonText: 'Continue'
  };

  constructor(private fundProfileFormService: FundProfileFormService,
    private route: ActivatedRoute,
    private fundMaintenanceService: FundMaintenanceService,
    private securityMasterService: SecurityMasterService,
    private dialog: MatDialog) { }

  ngOnInit() {
    this.portId = this.route.snapshot.params.portId;
    if (this.portId) {
      this.securityMasterService.loadSecurityMaster().subscribe(
        () => this.loadFundProfileForEdit()
      );
    } else {
      this.fundProfileFormService.loadProfile();
    }

    this.fundProfileFormSub = this.fundProfileFormService.fundProfileForm$.subscribe(
      fundProfileForm => {
        this.fundProfileForm = fundProfileForm;
        this.setProductTypeValueChange();
      }
    );
  }

  private loadFundProfileForEdit() {
    this.isNewFund = false;
    this.fundMaintenanceService.getFundProfile(this.portId).subscribe(
      profile => {
        this.formTitle = `${profile.portId.portId} - ${profile.fundName}`;
        this.fundProfileFormService.loadProfile(profile);
      }
    );
  }

  private setProductTypeValueChange() {
    this.fundProfileForm.productType.valueChanges.subscribe(productType => {
      const oldValue = this.fundProfileForm.value['productType'];
      const holdingsFormArray = this.fundProfileForm.holdings;
      if (productType !== oldValue) {
        if (holdingsFormArray.length > 0) {
          this.openConfirmDialog(oldValue);
        } else {
          this.fundProfileForm.resetTypeOptions();
        }
      }
    });
  }

  private openConfirmDialog(oldValue) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      hasBackdrop: true,
      data: this.confirmDialogData
    });

    dialogRef.afterClosed().subscribe(data => {
      if (data === 'confirm') {
        this.fundProfileForm.resetTypeOptions();
      } else {
        this.fundProfileForm.productType.setValue(oldValue, { emitEvent: false });
      }
    });
  }

  showConfirmDialog(action) {
    this.confirmDialogData.message = action === 'deactivate' ?
      'Are you sure you want to deactivate this fund? Trades may need to be removed before deactivating.' :
      'Trade Calculations may need to be reinitiated.';
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      hasBackdrop: true,
      data: this.confirmDialogData
    });

    dialogRef.afterClosed().subscribe(data => {
      if (data === 'confirm') {
        (action === 'deactivate') ? this.deactivateFundProfile() : this.reactivateFundProfile();
      }
    });
  }

  saveFundProfile(): void {
    this.fundMaintenanceService.saveFundProfile(this.fundProfileForm.getRawValue(), this.isNewFund)
      .subscribe(() => {
        const portId = this.isNewFund ? this.fundProfileForm.getRawValue().portId.portId : this.portId;
        this.fundMaintenanceService.refreshFundProfile(portId);
      });
  }

  get showDeactivate(): boolean {
    return this.fundProfileForm.active.value && !this.isNewFund;
  }

  deactivateFundProfile(): void {
    this.fundMaintenanceService.deactivateFundProfile(this.fundProfileForm.getRawValue());
  }

  reactivateFundProfile(): void {
    this.fundMaintenanceService.reactivateFundProfile(this.fundProfileForm.getRawValue());
  }

  ngOnDestroy() {
    this.fundProfileFormSub.unsubscribe();
  }
}
