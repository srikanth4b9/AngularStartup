import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import {
  MatButtonModule,
  MatCheckboxModule,
  MatDialog,
  MatDialogModule,
  MatInputModule,
  MatSelectModule,
  MatSnackBarModule,
  MatToolbarModule,
} from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ActivatedRoute, Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { FundMaintenanceService, FundProfileFormService } from '@fund-maintenance/services';
import { MockSecurityMasterService, SecurityMasterService } from '@security-master/services';
import { of } from 'rxjs';

import { FundHoldingsFormModule } from '../../components/forms/fund-holdings-form.module';
import { FundProfileForm, mockFund5828, ProductType } from '../../models';
import { MockFundMaintenanceService } from '../../services/fund-maintenance.service.mock';
import { MockFundProfileFormService } from '../../services/fund-profile-form.service.mock';
import { EditFundProfileViewComponent } from './edit-fund-profile-view.component';

class MockActivatedRoute {
  snapshot = { params: { portId: undefined } };
}

class MockDialog {
  open = jasmine.createSpy();
}

describe('EditFundProfileViewComponent', () => {
  let component: EditFundProfileViewComponent;
  let fixture: ComponentFixture<EditFundProfileViewComponent>;
  let router: Router;
  let fundMaintenanceService: MockFundMaintenanceService;
  let securityMasterService: MockSecurityMasterService;
  let fundProfileFormService: MockFundProfileFormService;
  let activatedRoute: MockActivatedRoute;
  let dialog: MockDialog;

  beforeEach(() => {
    activatedRoute = new MockActivatedRoute();
  });

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        ReactiveFormsModule,
        NoopAnimationsModule,
        MatCheckboxModule,
        MatInputModule,
        MatButtonModule,
        MatSelectModule,
        MatSnackBarModule,
        MatToolbarModule,
        FontAwesomeModule,
        FundHoldingsFormModule,
        MatDialogModule
      ],
      declarations: [EditFundProfileViewComponent],
      providers: [
        { provide: FundMaintenanceService, useClass: MockFundMaintenanceService },
        { provide: SecurityMasterService, useClass: MockSecurityMasterService },
        { provide: FundProfileFormService, useClass: MockFundProfileFormService },
        { provide: ActivatedRoute, useValue: activatedRoute },
        { provide: MatDialog, useClass: MockDialog }
      ]
    })
      .compileComponents();

    router = TestBed.get(Router);
    dialog = TestBed.get(MatDialog);
    fundMaintenanceService = TestBed.get(FundMaintenanceService);
    securityMasterService = TestBed.get(SecurityMasterService);
    fundProfileFormService = TestBed.get(FundProfileFormService);
  });

  function createComponent() {
    fixture = TestBed.createComponent(EditFundProfileViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  function setPortId(portId) {
    activatedRoute.snapshot.params.portId = portId;
  }

  it('should create', () => {
    createComponent();
    expect(component).toBeTruthy();
  });

  describe('ngOnInIt', () => {
    it('should not load fund profile if Port ID is not set', () => {
      createComponent();

      component.ngOnInit();

      expect(fundMaintenanceService.getFundProfile).not.toHaveBeenCalled();
    });

    it('should load fund profile & set fund profile form', () => {
      setPortId('5828');
      createComponent();

      component.ngOnInit();

      const fundProfileForm = new FundProfileForm(mockFund5828);

      expect(component.isNewFund).toBe(false);
      expect(securityMasterService.loadSecurityMaster).toHaveBeenCalled();
      expect(fundMaintenanceService.getFundProfile).toHaveBeenCalledWith(component.portId);
      expect(component.formTitle).toEqual('5828 - CLARK COMPANY CONTRIBUTION');
      expect(fundProfileFormService.loadProfile).toHaveBeenCalledWith(mockFund5828);
    });
  });

  describe('product type changes', () => {
    it('should subscribe to product type drop down changes', () => {
      createComponent();
      spyOn(component.fundProfileForm, 'resetTypeOptions');
      dialog.open.and.returnValue({
        afterClosed: () => of('confirm')
      });
      component.fundProfileForm.patchValue({
        productType: ProductType.LEGACY_FUND_OF_FUND
      });
      expect(dialog.open).toHaveBeenCalled();
      expect(component.fundProfileForm.resetTypeOptions).toHaveBeenCalled();
    });

    it('should subscribe to product type drop down changes', () => {
      dialog.open.and.returnValue({
        afterClosed: () => of('')
      });
      createComponent();
      component.fundProfileForm.patchValue({
        productType: ProductType.LEGACY_FUND_OF_FUND
      });
      expect(dialog.open).toHaveBeenCalled();
    });

  });

  describe('Fund Profile Updates:', () => {
    let expectedForm: FundProfileForm;

    beforeEach(() => {
      setPortId('5828');
      createComponent();
      expectedForm = new FundProfileForm(mockFund5828).getRawValue();
    });

    describe('saveFundProfile', () => {
      it('should save the FundProfile, and refresh fund profile', () => {
        fundMaintenanceService.saveFundProfile.and.returnValue(of(mockFund5828));

        component.saveFundProfile();

        expect(fundMaintenanceService.saveFundProfile).toHaveBeenCalledWith(expectedForm, component.isNewFund);
        expect(fundMaintenanceService.refreshFundProfile).toHaveBeenCalledWith(component.portId);
      });

      it('should save the FundProfile, and refresh fund profile', () => {
        fundMaintenanceService.saveFundProfile.and.returnValue(of(mockFund5828));
        component.isNewFund = true;
        component.saveFundProfile();

        expect(fundMaintenanceService.saveFundProfile).toHaveBeenCalledWith(expectedForm, component.isNewFund);
        expect(fundMaintenanceService.refreshFundProfile).toHaveBeenCalledWith(component.portId);
      });
    });

    describe('deactivateFundProfile', () => {
      it('should deactivate the FundProfile, and refresh fund profile', () => {
        fundMaintenanceService.deactivateFundProfile.and.returnValue(of(mockFund5828));

        createComponent();
        dialog.open.and.returnValue({
          afterClosed: () => of('confirm')
        });
        component.showConfirmDialog('deactivate');

        component.deactivateFundProfile();

        expect(fundMaintenanceService.deactivateFundProfile).toHaveBeenCalledWith(expectedForm);
      });
    });

    describe('reactivateFundProfile', () => {
      it('should reactivate the FundProfile, and refresh fund profile', () => {
        fundMaintenanceService.reactivateFundProfile.and.returnValue(of(mockFund5828));

        createComponent();
        dialog.open.and.returnValue({
          afterClosed: () => of('confirm')
        });
        component.showConfirmDialog('reactivate');

        component.reactivateFundProfile();

        expect(fundMaintenanceService.reactivateFundProfile).toHaveBeenCalledWith(expectedForm);
      });
    });
  });
});
