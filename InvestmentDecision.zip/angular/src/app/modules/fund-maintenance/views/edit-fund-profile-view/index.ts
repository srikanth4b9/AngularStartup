export * from './edit-fund-profile-view.module';
export * from './edit-fund-profile-view.component';
