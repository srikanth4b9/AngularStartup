import { EditFundProfileViewModule } from './edit-fund-profile-view.module';

describe('EditFundProfileViewModule', () => {
  let editFundProfileViewModule: EditFundProfileViewModule;

  beforeEach(() => {
    editFundProfileViewModule = new EditFundProfileViewModule();
  });

  it('should create an instance', () => {
    expect(editFundProfileViewModule).toBeTruthy();
  });
});
