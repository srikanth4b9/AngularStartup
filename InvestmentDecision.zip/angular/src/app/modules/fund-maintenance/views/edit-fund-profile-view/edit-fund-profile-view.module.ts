import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import {
  MatToolbarModule, MatButtonModule, MatInputModule, MatCheckboxModule, MatSelectModule, MatSnackBarModule
} from '@angular/material';

import { EditFundProfileViewComponent } from './edit-fund-profile-view.component';
import { FundProfileFormService } from '../../services';
import { FundHoldingsFormModule } from '../../components/forms/fund-holdings-form.module';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    MatCheckboxModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule,
    MatSnackBarModule,
    MatToolbarModule,
    FontAwesomeModule,
    FundHoldingsFormModule
  ],
  declarations: [EditFundProfileViewComponent],
  exports: [EditFundProfileViewComponent],
  providers: [
    FundProfileFormService
  ]
})
export class EditFundProfileViewModule { }
