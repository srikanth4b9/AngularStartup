import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FundProfilesViewComponent, EditFundProfileViewComponent } from '@fund-maintenance/views';

const routes: Routes = [
  {
    path: '',
    component: FundProfilesViewComponent
  },
  {
    path: 'create',
    component: EditFundProfileViewComponent
  },
  {
    path: 'edit/:portId',
    component: EditFundProfileViewComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FundMaintenanceRoutingModule { }
