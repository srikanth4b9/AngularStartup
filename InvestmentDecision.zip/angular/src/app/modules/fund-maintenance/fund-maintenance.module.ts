import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FundMaintenanceRoutingModule } from './fund-maintenance-routing.module';
import { FundProfilesViewModule, EditFundProfileViewModule } from './views';

@NgModule({
  imports: [
    CommonModule,
    FundMaintenanceRoutingModule,
    FundProfilesViewModule,
    EditFundProfileViewModule
  ]
})
export class FundMaintenanceModule { }
