import { FundProfileModule } from './fund-profile.module';

describe('FundProfileModule', () => {
  let fundProfileModule: FundProfileModule;

  beforeEach(() => {
    fundProfileModule = new FundProfileModule();
  });

  it('should create an instance', () => {
    expect(fundProfileModule).toBeTruthy();
  });
});
