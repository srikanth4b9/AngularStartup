import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from '@app/shared/material.module';
import { FormsModule } from '@angular/forms';
import { FundProfileComponent } from './fund-profile.component';
import { FundHoldingsModule } from '../fund-holdings';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { MatToolbarModule, MatDialogModule } from '@angular/material';
import { RouterModule } from '@angular/router';

import { ConfirmDialogModule } from '@app/components';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    MaterialModule,
    MatToolbarModule,
    MatDialogModule,
    FontAwesomeModule,
    FundHoldingsModule,
    RouterModule,
    ConfirmDialogModule
  ],
  declarations: [FundProfileComponent],
  exports: [FundProfileComponent]
})
export class FundProfileModule { }
