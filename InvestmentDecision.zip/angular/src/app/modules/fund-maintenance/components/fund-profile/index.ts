export * from './fund-profile.component';
export * from './fund-profile.module';
