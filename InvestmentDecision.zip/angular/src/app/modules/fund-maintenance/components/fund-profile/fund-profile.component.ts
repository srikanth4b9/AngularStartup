import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';

import { MatDialog} from '@angular/material';
import { faEdit } from '@fortawesome/free-solid-svg-icons';

import { FundProfile, ProductType, RebalanceType, FundClassification } from '@fund-maintenance/models';
import { ConfirmDialogComponent } from '@app/components';
import { ConfirmDialogModel } from '@shared/models';

@Component({
  selector: 'app-fund-profile',
  templateUrl: './fund-profile.component.html',
  styleUrls: ['./fund-profile.component.scss']
})
export class FundProfileComponent {
  ProductType = ProductType;
  RebalanceType = RebalanceType;
  FundClassification = FundClassification;

  faEdit = faEdit;

  @Input() fundProfile: FundProfile;

  confirmDialogData: ConfirmDialogModel = {
    title: 'Ensure trading is complete for the day before making any changes.',
    confirmButtonText: 'Continue'
  };

  constructor(
    private router: Router,
    private dialog: MatDialog) { }

  editFundProfile(): void {
    if (this.isTradingMarketClosed()) {
      this.navigateToEditFundProfile();
    } else {
      this.openConfirmDialog();
    }
  }

  private navigateToEditFundProfile() {
    this.router.navigate(['/fund-maintenance/edit', this.fundProfile.portId.portId]);
  }

  private openConfirmDialog() {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      hasBackdrop: true,
      data: this.confirmDialogData
    });

    dialogRef.afterClosed().subscribe(data => {
      if (data === 'confirm') {
        this.navigateToEditFundProfile();
      }
    });
  }

  private isTradingMarketClosed(): boolean {
    const currentHour = new Date().getHours();
    const marketClosedHour = 16;
    return currentHour >= marketClosedHour;
  }
}
