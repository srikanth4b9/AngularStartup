import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { Router } from '@angular/router';
import { MaterialModule } from '@app/shared/material.module';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { of } from 'rxjs';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

import { FundHoldingsComponent, FundHoldingRowComponent } from '@app/modules/fund-maintenance/components';
import { mockFund0430 } from '@app/modules/fund-maintenance/models';
import { FundProfileComponent } from './fund-profile.component';
import { MatDialog } from '@angular/material';
import { ConfirmDialogComponent, ConfirmDialogModule } from '@app/components';

class MockDialog {
  open = jasmine.createSpy().and.returnValue({
    afterClosed: jasmine.createSpy().and.returnValue(of({}))
  });
}

describe('FundProfileComponent', () => {
  let component: FundProfileComponent;
  let fixture: ComponentFixture<FundProfileComponent>;
  let router: Router;
  let newDateSpy: jasmine.Spy;
  let dialog: MockDialog;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FundProfileComponent, FundHoldingsComponent, FundHoldingRowComponent],
      imports: [
        RouterTestingModule,
        FormsModule,
        MaterialModule,
        NoopAnimationsModule,
        FontAwesomeModule,
        ConfirmDialogModule
      ],
      providers: [{ provide: MatDialog, useClass: MockDialog }]
    })
      .compileComponents();

    router = TestBed.get(Router);
    dialog = TestBed.get(MatDialog);
    newDateSpy = spyOn(Date.prototype, 'setDate');
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FundProfileComponent);
    component = fixture.componentInstance;
    component.fundProfile = mockFund0430;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('editFundProfile', () => {
    let navigateSpy: jasmine.Spy;

    beforeEach(() => {
      navigateSpy = spyOn(router, 'navigate');
    });

    it('should navigate to edit page if trading market is closed', () => {
      jasmine.clock().mockDate(new Date('July 3, 2019 16:00:00'));

      component.editFundProfile();

      expect(navigateSpy).toHaveBeenCalledWith(['/fund-maintenance/edit', component.fundProfile.portId.portId]);
    });

    it('should open a confirm dialog if trading market is open', () => {
      jasmine.clock().mockDate(new Date('July 3, 2019 15:59:00'));

      component.editFundProfile();

      expect(navigateSpy).not.toHaveBeenCalled();
      expect(dialog.open).toHaveBeenCalled();
    });

    it('should navigate to edit page if trading market is open and confirmed', () => {
      jasmine.clock().mockDate(new Date('July 3, 2019 15:59:00'));
      dialog.open.and.returnValue({
        afterClosed: jasmine.createSpy().and.returnValue(of('confirm'))
      });

      component.editFundProfile();

      expect(navigateSpy).toHaveBeenCalledWith(['/fund-maintenance/edit', component.fundProfile.portId.portId]);
    });
  });

});
