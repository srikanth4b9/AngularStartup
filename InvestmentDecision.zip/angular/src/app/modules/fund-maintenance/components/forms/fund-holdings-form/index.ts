export * from './fund-holdings-form.component';
