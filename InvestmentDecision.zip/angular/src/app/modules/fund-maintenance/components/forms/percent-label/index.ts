export * from './percent-label.component';
export * from './percent-label.module';
