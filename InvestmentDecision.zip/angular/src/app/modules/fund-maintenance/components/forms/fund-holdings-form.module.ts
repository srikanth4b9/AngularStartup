import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import {
  MatToolbarModule, MatInputModule, MatExpansionModule,
  MatButtonModule, MatSelectModule, MatCheckboxModule
} from '@angular/material';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

import { FundHoldingsFormComponent } from './fund-holdings-form/fund-holdings-form.component';
import { FundHoldingFormComponent } from './fund-holding-form/fund-holding-form.component';
import { HoldingNameSelectModule } from './holding-name-select';
import { PercentLabelModule } from './percent-label';

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatCheckboxModule,
    MatToolbarModule,
    MatInputModule,
    MatExpansionModule,
    MatSelectModule,
    FontAwesomeModule,
    HoldingNameSelectModule,
    PercentLabelModule
  ],
  declarations: [FundHoldingsFormComponent, FundHoldingFormComponent],
  exports: [FundHoldingsFormComponent, FundHoldingFormComponent]
})
export class FundHoldingsFormModule { }
