import { Component, OnInit, Input } from '@angular/core';
import { faPlusCircle, faExclamationTriangle } from '@fortawesome/free-solid-svg-icons';
import { MatSelectChange, MatDialog } from '@angular/material';
import { Observable } from 'rxjs';

import { HoldingsFormArray, HoldingType } from '@app/modules/fund-maintenance/models';
import { FundProfileFormService } from '@app/modules/fund-maintenance/services';
import { ConfirmDialogComponent } from '@app/components';
import { ConfirmDialogModel } from '@app/shared/models';

@Component({
  selector: 'app-fund-holdings-form',
  templateUrl: './fund-holdings-form.component.html',
  styleUrls: ['./fund-holdings-form.component.scss']
})
export class FundHoldingsFormComponent implements OnInit {

  @Input() holdingsFormArray: HoldingsFormArray = new HoldingsFormArray();
  @Input() tier: number;
  panelOpenState: boolean = true;
  holdingTypeOptions: Observable<HoldingType[]>;
  confirmDialogData: ConfirmDialogModel = {
    title: 'Are You Sure?',
    message: `All of the directive's holdings will be removed. `,
    confirmButtonText: 'Continue'
  };

  faPlusCircle = faPlusCircle;
  faExclamationTriangle = faExclamationTriangle;

  constructor(private fundProfileFormService: FundProfileFormService, private dialog: MatDialog) { }

  ngOnInit() {
    this.fundProfileFormService.fundProfileForm$.subscribe(fundProfileForm => {
        this.holdingTypeOptions = fundProfileForm.holdingTypeOptions$;
    });
  }

  addHolding(selectChange: MatSelectChange | {source: any, value: HoldingType}) {
    if (selectChange.value) {
      this.panelOpenState = true;

      this.holdingsFormArray.addHolding(selectChange.value, this.tier);

      selectChange.source.writeValue(null);
    }
  }

  removeHolding(isSecurity: boolean, index: number) {
    if (isSecurity) {
      this.holdingsFormArray.removeAt(index);
    } else {
      this.openConfirmDialog(index);
    }
  }

  openConfirmDialog(index: number) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      hasBackdrop: true,
      data: this.confirmDialogData
    });
    dialogRef.afterClosed().subscribe(data => {
      if (data === 'confirm') {
        this.holdingsFormArray.removeAt(index);
      }
    });
  }
}
