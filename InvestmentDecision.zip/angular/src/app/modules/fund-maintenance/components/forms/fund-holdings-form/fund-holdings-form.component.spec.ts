import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { FundProfileForm, HoldingType, mockFund5828 } from '@app/modules/fund-maintenance/models';
import { FundProfileFormService } from '@app/modules/fund-maintenance/services';
import { SnackBarService } from '@app/services';
import { MaterialModule } from '@app/shared/material.module';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { of } from 'rxjs';

import { FundHoldingFormComponent } from '../fund-holding-form';
import { HoldingNameSelectModule } from '../holding-name-select';
import { PercentLabelModule } from '../percent-label';
import { FundHoldingsFormComponent } from './fund-holdings-form.component';

class MockFundProfileFormService {
  fundProfileForm$ = of(new FundProfileForm(mockFund5828));
}

class MockDialog {
  open = jasmine.createSpy();
}


describe('FundHoldingsFormComponent', () => {
  let component: FundHoldingsFormComponent;
  let fixture: ComponentFixture<FundHoldingsFormComponent>;
  let dialog: MockDialog;
  let snackBarService: SnackBarService;


  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FundHoldingsFormComponent, FundHoldingFormComponent],
      imports: [
        NoopAnimationsModule, FontAwesomeModule, MaterialModule,
        ReactiveFormsModule, HoldingNameSelectModule, PercentLabelModule
      ],
      providers: [{ provide: FundProfileFormService, useClass: MockFundProfileFormService },
      { provide: MatDialog, useClass: MockDialog }]
    })
      .compileComponents();
      dialog = TestBed.get(MatDialog);
      snackBarService = TestBed.get(SnackBarService);
  });

  function createComponent() {
    fixture = TestBed.createComponent(FundHoldingsFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  // function createHostComponent(template: string): ComponentFixture<HostComponent> {
  //   TestBed.overrideComponent(HostComponent, { set: { template: template } });
  //   const hostFixture = TestBed.createComponent(HostComponent);
  //   hostFixture.detectChanges();
  //   return hostFixture as ComponentFixture<HostComponent>;
  // }

  beforeEach(() => {
    createComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
    expect(component.holdingTypeOptions).toBeDefined();
  });

  describe('addHolding:', () => {
    let mockMatSelectChange;

    beforeEach(() => {
      mockMatSelectChange = {
        source: { writeValue: jasmine.createSpy() },
        value: HoldingType.Security
      };
      createComponent();
    });

    it('should add a holding to the form array', () => {
      mockMatSelectChange.value = HoldingType.Security;

      component.addHolding(mockMatSelectChange);

      expect(component.panelOpenState).toEqual(true);
      expect(component.holdingsFormArray.length).toEqual(1);
      expect(mockMatSelectChange.source.writeValue).toHaveBeenCalledWith(null);
    });

    it('should do nothing if a type is not selected', () => {
      mockMatSelectChange.value = null;

      component.addHolding(mockMatSelectChange);

      expect(component.holdingsFormArray.length).toEqual(0);
    });
  });

  describe('removeHolding', () => {
    it('should remove holding', () => {
      const isSecurity = true;
      const index = 1;
      const holdingsFormArrayLength = component.holdingsFormArray.length;
      const holdingsFormArraySpy = spyOn(component.holdingsFormArray, 'removeAt');

      component.removeHolding(isSecurity, index);

      expect(holdingsFormArraySpy).toHaveBeenCalledWith(index);
      expect(holdingsFormArrayLength).toEqual(0);
    });

    it('should open Confirm Dialog ', () => {
      const isSecurity = false;
      const index = 1;
      const holdingsFormArraySpy = spyOn(component.holdingsFormArray, 'removeAt');
      dialog.open.and.returnValue({
        afterClosed: () => of('confirm')
      });
      component.removeHolding(isSecurity, index);
      expect(dialog.open).toHaveBeenCalled();
      expect(holdingsFormArraySpy).toHaveBeenCalledWith(index);
    });

    it('should open Confirm Dialog ', () => {
      const isSecurity = false;
      const index = 1;
      dialog.open.and.returnValue({
        afterClosed: () => of('')
      });
      component.removeHolding(isSecurity, index);
      expect(dialog.open).toHaveBeenCalled();
    });
  });
});
