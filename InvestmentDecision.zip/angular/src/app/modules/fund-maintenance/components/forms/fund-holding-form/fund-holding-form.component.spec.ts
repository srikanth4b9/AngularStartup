import { Component, DebugElement } from '@angular/core';
import { ComponentFixture, fakeAsync, TestBed, tick, async } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { HoldingForm, HoldingType, mockFund0430 } from '@app/modules/fund-maintenance/models';
import {
  FundMaintenanceService,
  FundProfileFormService,
  MockFundProfileFormService,
} from '@app/modules/fund-maintenance/services';
import { MockFundMaintenanceService } from '@app/modules/fund-maintenance/services/fund-maintenance.service.mock';
import { MockSecurityMasterService, SecurityMasterService } from '@app/modules/security-master/services';
import { MaterialModule } from '@app/shared/material.module';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

import { FundHoldingsFormComponent } from '../fund-holdings-form';
import { HoldingNameSelectModule } from '../holding-name-select';
import { PercentLabelModule } from '../percent-label';
import { FundHoldingFormComponent } from './fund-holding-form.component';

@Component({
  selector: `app-host-component`,
  template: `<app-fund-holding-form [holdingForm]="holdingForm"></app-fund-holding-form>`
})
class TestHostComponent {
  holdingForm: HoldingForm = new HoldingForm(HoldingType.Security, 0, mockFund0430.holdings[0]);
}

describe('FundHoldingFormComponent', () => {
  let component: FundHoldingFormComponent;
  let fixture: ComponentFixture<FundHoldingFormComponent>;
  let testHostComponent: TestHostComponent;
  let testHostFixture: ComponentFixture<TestHostComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule,
        FontAwesomeModule,
        ReactiveFormsModule,
        FormsModule,
        HoldingNameSelectModule,
        MaterialModule,
        PercentLabelModule,
        RouterTestingModule
      ],
      declarations: [FundHoldingFormComponent, FundHoldingsFormComponent, TestHostComponent],
      providers: [
        { provide: FundProfileFormService, useClass: MockFundProfileFormService },
        { provide: SecurityMasterService, useClass: MockSecurityMasterService },
        { provide: FundMaintenanceService, useClass: MockFundMaintenanceService }
      ]
    })
      .compileComponents();
  });

  function createComponent() {
    fixture = TestBed.createComponent(FundHoldingFormComponent);
    component = fixture.componentInstance;
    component.holdingForm = new HoldingForm(HoldingType.Security);
    fixture.detectChanges();
  }

  function createTestHostComponent() {
    testHostFixture = TestBed.createComponent(TestHostComponent);
    testHostComponent = testHostFixture.componentInstance;
    testHostFixture.detectChanges();
  }

  it('should create', () => {
    createTestHostComponent();
    expect(testHostComponent).toBeTruthy();
  });

  describe('onPercentChange', () => {
    it('should format input values into decimal with 4 precision for model', () => {
      const event = { value: '0.00452188' };
      createComponent();

      component.onPercentChange(event);

      expect(+(event.value)).toEqual(0.00452);
    });
  });

  describe('emitRemoveHolding', () => {
    it('should emitRemoveHolding', () => {
      createComponent();
      const event = { preventDefault() { } };
      const emitSpy = spyOn(component.removeHolding, 'emit');

      component.emitRemoveHolding(event);

      expect(emitSpy).toHaveBeenCalled();
    });
  });

  describe('Scenario: Display validation error when rebalance threshold is > 100%', () => {
    let rebalanceThresholdDebugElement: DebugElement;
    let rebalanceThresholdInputElement: HTMLInputElement;
    let errorElement: HTMLElement;

    it('Then a validation error should be displayed ', async(() => {
        createTestHostComponent();
        rebalanceThresholdDebugElement = testHostFixture.debugElement.query(By.css('.rebalanceThreshold'));
        rebalanceThresholdInputElement = rebalanceThresholdDebugElement.query(By.css('input')).nativeElement;

        rebalanceThresholdInputElement.value = '10';
        rebalanceThresholdInputElement.dispatchEvent(new Event('input'));
        rebalanceThresholdInputElement.dispatchEvent(new Event('blur'));
        testHostFixture.detectChanges();

        testHostFixture.whenStable().then(() => {
          errorElement = rebalanceThresholdDebugElement.query(By.css('.rebalanceThreshold-error')).nativeElement;
          expect(errorElement.textContent.trim()).toEqual('Must be <= 100%');
        });
    }));
  });
});
