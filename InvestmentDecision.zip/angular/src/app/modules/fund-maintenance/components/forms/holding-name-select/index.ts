export * from './holding-name-select.component';
export * from './holding-name-select.module';
