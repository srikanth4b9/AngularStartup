import { FundHoldingsFormModule } from './fund-holdings-form.module';

describe('EditFundProfileViewModule', () => {
  let fundHoldingsFormModule: FundHoldingsFormModule;

  beforeEach(() => {
    fundHoldingsFormModule = new FundHoldingsFormModule();
  });

  it('should create an instance', () => {
    expect(fundHoldingsFormModule).toBeTruthy();
  });
});
