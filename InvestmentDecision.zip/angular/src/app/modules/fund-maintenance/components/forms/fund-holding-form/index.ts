export * from './fund-holding-form.component';
