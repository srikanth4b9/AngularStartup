import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-percent-label',
  templateUrl: './percent-label.component.html',
  styleUrls: ['./percent-label.component.scss']
})
export class PercentLabelComponent implements OnInit {
  @Input() inputValue: any;

  constructor() { }

  ngOnInit() {
  }

}
