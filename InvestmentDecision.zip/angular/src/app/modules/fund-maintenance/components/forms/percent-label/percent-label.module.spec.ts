import { PercentLabelModule } from './percent-label.module';

describe('PercentLabelModule', () => {
  let percentLabelModule: PercentLabelModule;

  beforeEach(() => {
    percentLabelModule = new PercentLabelModule();
  });

  it('should create an instance', () => {
    expect(percentLabelModule).toBeTruthy();
  });
});
