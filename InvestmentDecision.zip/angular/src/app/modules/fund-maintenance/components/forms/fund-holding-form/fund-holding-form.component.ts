import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { HoldingForm, TradeSubmissionMethod, FormUtils, HoldingType, ProductTypeEnum } from '@app/modules/fund-maintenance/models';
import { faTimesCircle } from '@fortawesome/free-solid-svg-icons';

import { FundProfileFormService } from '@app/modules/fund-maintenance/services';

@Component({
  selector: 'app-fund-holding-form',
  templateUrl: './fund-holding-form.component.html',
  styleUrls: ['./fund-holding-form.component.scss']
})
export class FundHoldingFormComponent implements OnInit {

  @Input() holdingForm: HoldingForm;
  @Output() removeHolding: EventEmitter<any> = new EventEmitter();
  isSecurity: boolean;
  isCTDF: boolean;

  keys = Object.keys;
  tradeSubmissionMethods = TradeSubmissionMethod;
  faTimesCircle = faTimesCircle;

  constructor(private fundProfileFormService: FundProfileFormService) { }

  ngOnInit() {
    this.isSecurity = FormUtils.getHoldingType(this.holdingForm.type.value) === HoldingType.Security;
    this.fundProfileFormService.fundProfileForm$.subscribe(fundProfileForm => {
      this.isCTDF = fundProfileForm.productType.value === ProductTypeEnum.CUSTOM_TARGET_DATE_FUND;
    });
  }

  onPercentChange(event) {
    event.value = FormUtils.toPercentDecimalValue(event.value);
  }

  emitRemoveHolding(event) {
    event.preventDefault();
    this.removeHolding.emit(this.isSecurity);
  }
}
