import { Component, EventEmitter, Input, OnChanges, Output } from '@angular/core';
import { MatSelectChange } from '@angular/material';
import { FormUtils, Holding, HoldingForm, HoldingType } from '@app/modules/fund-maintenance/models';
import { FundMaintenanceService } from '@app/modules/fund-maintenance/services';
import { Directive } from '@app/modules/security-master/modules/directives/models';
import { Security } from '@app/modules/security-master/modules/securities/models';
import { SecurityMasterService } from '@app/modules/security-master/services';

@Component({
  selector: 'app-holding-name-select',
  templateUrl: './holding-name-select.component.html',
  styleUrls: ['./holding-name-select.component.scss']
})
export class HoldingNameSelectComponent implements OnChanges {
  @Input() holdingForm: HoldingForm = new HoldingForm(HoldingType.Security);
  @Input() controlName: string = 'name';
  @Input() placeholder: string = 'Name';
  @Input() selectedPortId: string;
  @Output() selectedHoldingId: EventEmitter<number> = new EventEmitter();
  @Output() selectedProductType: EventEmitter<any> = new EventEmitter();
  holdingType: HoldingType;
  masterList: Directive[] | Security[] | Holding[];
  selectedSecurity: string;
  private _enabled = true;

  constructor(private securityMasterService: SecurityMasterService, private fundMaintenanceService: FundMaintenanceService) { }

  ngOnChanges() {
    if (this._enabled) {
      if (this.selectedPortId) {
        this.loadHoldings(this.selectedPortId);
      } else {
        this.setFilteredNames();
      }
    }
  }

  @Input() set enabled(enable: boolean) {
    this._enabled = enable;
    if (enable) {
      this.holdingForm.name.enable();
      return;
    } else {
      this.holdingForm.name.reset();
      this.holdingForm.name.disable();
      this.selectedHoldingId.emit(null);
    }
  }

  loadHoldings(portId) {
    this.holdingForm.name.disable();
    this.fundMaintenanceService.getFundProfileForHoldings(portId).subscribe(
      fundProfile => {
        this.masterList = FormUtils.getAllSecurityHoldings(fundProfile.holdings);
        this.holdingForm.name.enable();
        this.selectedProductType.emit(fundProfile.productType);
      }
    );
  }

  private setFilteredNames() {
    this.holdingType = this.holdingForm.getHoldingType();
    if (this.holdingType === HoldingType.Directive) {

      this.securityMasterService.getDirectives().subscribe(
        directives => this.setOptions(directives)
      );
    } else {
      this.securityMasterService.getSecurities().subscribe(
        securities => this.setOptions(securities)
      );
    }
  }

  setOptions(securityMasterList) {
    this.masterList = securityMasterList.filter(security => security.active).sort((a, b) => (a.name > b.name) ? 1 : -1);
  }

  nameSelected(selectChange: MatSelectChange | { source: any, value: string }) {
    if (this.selectedPortId) {
      this.selectedHoldingId.emit(this.getHoldingByName(selectChange.value).holdingId);
    } else {
      if (this.holdingType === HoldingType.Directive) {
        this.securityMasterService.getDirectiveyByName(selectChange.value).subscribe(
          directive => this.holdingForm.updateDirectiveIdValues(directive)
        );
      } else {
        this.securityMasterService.getSecurityByName(selectChange.value).subscribe(
          security => this.holdingForm.updateSecurityIdValues(security)
        );
      }
    }
  }

  private getHoldingByName(holdingName: string): Holding {
    return (this.masterList as Holding[]).filter(holding => holding.name === holdingName)[0];
  }
}
