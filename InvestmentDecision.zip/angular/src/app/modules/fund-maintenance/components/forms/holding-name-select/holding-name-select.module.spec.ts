import { HoldingNameSelectModule } from './holding-name-select.module';

describe('EditFundProfileViewModule', () => {
  let holdingNameSelectModule: HoldingNameSelectModule;

  beforeEach(() => {
    holdingNameSelectModule = new HoldingNameSelectModule();
  });

  it('should create an instance', () => {
    expect(holdingNameSelectModule).toBeTruthy();
  });
});
