import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { MatInputModule, MatSelectModule } from '@angular/material';

import { HoldingNameSelectComponent } from './holding-name-select.component';

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatInputModule,
    MatSelectModule
  ],
  declarations: [HoldingNameSelectComponent],
  exports: [HoldingNameSelectComponent]
})
export class HoldingNameSelectModule { }
