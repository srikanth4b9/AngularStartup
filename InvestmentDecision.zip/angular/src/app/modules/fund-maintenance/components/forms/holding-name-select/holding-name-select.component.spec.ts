import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { HoldingForm, HoldingType } from '@app/modules/fund-maintenance/models';
import { FundMaintenanceService, MockFundMaintenanceService } from '@app/modules/fund-maintenance/services';
import { MockSecurityMasterService, SecurityMasterService } from '@app/modules/security-master/services';
import { MaterialModule } from '@app/shared/material.module';
import { HoldingNameSelectComponent } from './holding-name-select.component';
import { Component, ViewChild } from '@angular/core';
import { testHolding } from '@app/modules/fund-maintenance/models/mock-json/fund.0430';

@Component({
  selector: 'app-host-component',
  template: `<app-holding-name-select
  [selectedPortId]="selectedPortId"
  (selectedHoldingId)="setHoldingId($event)"></app-holding-name-select>`
})
class TestHostComponent {
  @ViewChild(HoldingNameSelectComponent, { static: true })
  public holdingNameSelectComponent: HoldingNameSelectComponent;

  selectedPortId: string;
  selectedHoldingId: number;

  setHoldingId(holdingId: number) {
    this.selectedHoldingId = holdingId;
  }
}

describe('HoldingNameSelectComponent', () => {
  let component: HoldingNameSelectComponent;
  let fixture: ComponentFixture<HoldingNameSelectComponent>;
  let testHostComponent: TestHostComponent;
  let testHostFixture: ComponentFixture<TestHostComponent>;
  let securityMasterService: MockSecurityMasterService;
  let fundMaintenanceService: MockFundMaintenanceService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [HoldingNameSelectComponent, TestHostComponent],
      imports: [
        NoopAnimationsModule,
        ReactiveFormsModule,
        MaterialModule,
        RouterTestingModule
      ],
      providers: [
        { provide: SecurityMasterService, useClass: MockSecurityMasterService },
        { provide: FundMaintenanceService, useClass: MockFundMaintenanceService }
      ]
    })
      .compileComponents();

    securityMasterService = TestBed.get(SecurityMasterService);
    fundMaintenanceService = TestBed.get(FundMaintenanceService);
  });

  function createComponent() {
    fixture = TestBed.createComponent(HoldingNameSelectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  function createTestHostComponent() {
    testHostFixture = TestBed.createComponent(TestHostComponent);
    testHostComponent = testHostFixture.componentInstance;
    testHostComponent.selectedPortId = '0430';
    testHostFixture.detectChanges();
  }

  it('should create', () => {
    createComponent();
    expect(component).toBeTruthy();
  });

  describe('ngOnChanges:', () => {
    it('should call setFilteredNames', () => {
      createComponent();
      const holdingTypeSpy = spyOn(component.holdingForm, 'getHoldingType').and.callThrough();

      component.ngOnChanges();

      expect(holdingTypeSpy).toHaveBeenCalled();
    });

    it('should set directives in setOptions', () => {
      createComponent();
      component.holdingForm = new HoldingForm(HoldingType.Directive);

      component.ngOnChanges();

      expect(securityMasterService.getDirectives).toHaveBeenCalled();
    });

    it('should set security in setOptions', () => {
      createComponent();
      component.holdingForm = new HoldingForm(HoldingType.Security);

      component.ngOnChanges();

      expect(securityMasterService.getSecurities).toHaveBeenCalled();
    });

    describe('selectedPortId:', () => {
      it('should load the selected fund holdings', () => {
        createTestHostComponent();

        expect(fundMaintenanceService.getFundProfileForHoldings).toHaveBeenCalledWith(testHostComponent.selectedPortId);
      });

    });
  });

  describe('nameSelected', () => {
    let mockMatSelectChange;
    beforeEach(function () {
      mockMatSelectChange = {
        source: {},
        value: HoldingType.Security
      };
    });


    it('should update security values for a selected security holding', () => {
      createComponent();

      component.holdingType = HoldingType.Security;
      component.nameSelected(mockMatSelectChange);

      expect(securityMasterService.getSecurityByName).toHaveBeenCalled();
    });

    it('should update directive values for a selected directive holding', () => {
      createComponent();

      component.holdingType = HoldingType.Directive;
      component.nameSelected(mockMatSelectChange);

      expect(securityMasterService.getDirectiveyByName).toHaveBeenCalled();
    });

    it('should emit selected holding ID event', () => {
      createComponent();
      component.selectedPortId = '0430';
      const matSelectChange = {
        source: {},
        value: 'TTL INTL STK IDX INST PLS'
      };

      spyOn<any>(component, 'getHoldingByName').and.callFake(function (params) {
        return testHolding.filter(holding => holding.name === params);
      });

      const emitSpy = spyOn(component.selectedHoldingId, 'emit');
      component.nameSelected(matSelectChange);

      expect(emitSpy).toHaveBeenCalled();
    });
  });
});
