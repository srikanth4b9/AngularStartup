import { FundHoldingRowModule } from './fund-holding-row.module';

describe('FundHoldingRowModule', () => {
  let fundHoldingRowModule: FundHoldingRowModule;

  beforeEach(() => {
    fundHoldingRowModule = new FundHoldingRowModule();
  });

  it('should create an instance', () => {
    expect(fundHoldingRowModule).toBeTruthy();
  });
});
