import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material';

import { FundHoldingRowComponent } from './fund-holding-row.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    MatCheckboxModule
  ],
  declarations: [FundHoldingRowComponent],
  exports: [FundHoldingRowComponent]
})
export class FundHoldingRowModule { }
