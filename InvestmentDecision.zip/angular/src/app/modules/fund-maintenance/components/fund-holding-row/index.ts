export * from './fund-holding-row.component';
export * from './fund-holding-row.module';
