import { Component, Input } from '@angular/core';
import { Holding, HoldingsTableDef, TradeSubmissionMethod } from '@fund-maintenance/models';
import { ColumnType } from '@shared/models';

@Component({
  selector: 'app-fund-holding-row',
  templateUrl: './fund-holding-row.component.html',
  styleUrls: ['./fund-holding-row.component.scss']
})
export class FundHoldingRowComponent {
  @Input() holding: Holding;

  holdingsTableDef = new HoldingsTableDef();
  ColumnType = ColumnType;
  TradeSubmissionMethod = TradeSubmissionMethod;

  constructor() { }
}
