import { HttpClient } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';

import { FundHoldingRowComponent } from './fund-holding-row.component';

describe('FundHoldingRowComponent', () => {
  let component: FundHoldingRowComponent;
  let fixture: ComponentFixture<FundHoldingRowComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FundHoldingRowComponent],
      imports: [
        MatCheckboxModule, FormsModule, ReactiveFormsModule, NoopAnimationsModule
      ],
      providers: [HttpClient]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FundHoldingRowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
