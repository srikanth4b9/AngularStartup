import { FundProfileTabsModule } from './fund-profile-tabs.module';

describe('FundProfileTabsModule', () => {
  let fundProfileTabsModule: FundProfileTabsModule;

  beforeEach(() => {
    fundProfileTabsModule = new FundProfileTabsModule();
  });

  it('should create an instance', () => {
    expect(fundProfileTabsModule).toBeTruthy();
  });
});
