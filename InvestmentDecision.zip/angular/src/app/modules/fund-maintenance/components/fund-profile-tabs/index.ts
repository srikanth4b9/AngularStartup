export * from './fund-profile-tabs.component';
export * from './fund-profile-tabs.module';
