import { Component, OnInit } from '@angular/core';
import { FundMaintenanceService } from '@app/modules/fund-maintenance/services';
import { FundProfile } from '@app/modules/fund-maintenance/models';
import { faTimes } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-fund-profile-tabs',
  templateUrl: './fund-profile-tabs.component.html',
  styleUrls: ['./fund-profile-tabs.component.scss']
})
export class FundProfileTabsComponent implements OnInit {
  profileTabs: FundProfile[] = [];
  selectedTabIndex: number = 0;

  faTimes = faTimes;

  constructor(private fundMaintenanceService: FundMaintenanceService) { }

  ngOnInit() {
    this.fundMaintenanceService.fundProfiles$.subscribe(fundProfiles => {
      this.profileTabs = fundProfiles;
    });
    this.fundMaintenanceService.selectedTabIndex$.subscribe(val => {
      this.selectedTabIndex = val;
    });
  }

  removeFundProfile(index: number): void {
    this.fundMaintenanceService.removeFundProfile(index);
  }

  setSelectedTabIndex(index: number) {
    this.fundMaintenanceService.setSelectedTabIndex(index);
  }
}
