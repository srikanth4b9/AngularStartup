import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatTabsModule } from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { BehaviorSubject } from 'rxjs';

import { FundProfile, mockFund0430, mockFund5828 } from '../../models';
import { FundMaintenanceService } from '../../services';
import { FundProfileModule } from '../fund-profile/fund-profile.module';
import { FundProfileTabsComponent } from './fund-profile-tabs.component';

class MockFundMaintenanceService {
  mockFundProfiles: FundProfile[] = [mockFund5828, mockFund0430];
  fundProfiles$: BehaviorSubject<FundProfile[]> = new BehaviorSubject(this.mockFundProfiles);
  removeFundProfile = jasmine.createSpy();

  setSelectedTabIndex = jasmine.createSpy();
  selectedTabIndex: number = 2;
  selectedTabIndex$: BehaviorSubject<number> = new BehaviorSubject(this.selectedTabIndex);
}

describe('FundProfileTabsComponent', () => {
  let component: FundProfileTabsComponent;
  let fixture: ComponentFixture<FundProfileTabsComponent>;
  let fundMaintenanceService: MockFundMaintenanceService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule,
        RouterTestingModule,
        MatTabsModule,
        FontAwesomeModule,
        FundProfileModule
      ],
      declarations: [FundProfileTabsComponent],
      providers: [{ provide: FundMaintenanceService, useClass: MockFundMaintenanceService }]
    })
      .compileComponents();

    fundMaintenanceService = TestBed.get(FundMaintenanceService);
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FundProfileTabsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('ngOnInit:', () => {
    it('should get fund profile tabs from the service', () => {
      component.ngOnInit();

      expect(component.profileTabs).toEqual(fundMaintenanceService.mockFundProfiles);
      expect(component.selectedTabIndex).toEqual(fundMaintenanceService.selectedTabIndex);
    });
  });

  describe('removeFundProfile:', () => {
    it('should remove a tab from the list of fund profile tabs', () => {
      const index = 3;

      component.removeFundProfile(index);

      expect(fundMaintenanceService.removeFundProfile).toHaveBeenCalledWith(index);
    });
  });

  describe('setSelectedTabIndex:', () => {
    it('should set the selected tab index', () => {
      const index = 7;

      component.setSelectedTabIndex(index);

      expect(fundMaintenanceService.setSelectedTabIndex).toHaveBeenCalledWith(index);
    });
  });
});
