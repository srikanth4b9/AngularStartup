import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { MatToolbarModule, MatTabsModule } from '@angular/material';
import { FundProfileTabsComponent } from './fund-profile-tabs.component';
import { FundProfileModule } from '../fund-profile';

@NgModule({
  imports: [
    CommonModule,
    MatTabsModule,
    FontAwesomeModule,
    FundProfileModule
  ],
  declarations: [FundProfileTabsComponent],
  exports: [FundProfileTabsComponent]
})
export class FundProfileTabsModule { }
