export * from './fund-holdings.component';
export * from './fund-holdings.module';
