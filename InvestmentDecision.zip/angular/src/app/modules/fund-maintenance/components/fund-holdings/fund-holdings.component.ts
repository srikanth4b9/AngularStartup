import { Component, OnInit, Input } from '@angular/core';
import { Holding, holdingsTableDef } from '@app/modules/fund-maintenance/models';
@Component({
  selector: 'app-fund-holdings',
  templateUrl: './fund-holdings.component.html',
  styleUrls: ['./fund-holdings.component.scss']
})
export class FundHoldingsComponent implements OnInit {
  @Input() isFundLevel = false;
  @Input() parent: Holding;
  @Input() holdings: Holding[] = [];

  readonly holdingsTableDef = holdingsTableDef;
  directives: Holding[];
  securities: Holding[];

  constructor() { }

  ngOnInit() {
    this.directives = this.holdings.filter(this.isDirective);
    this.securities = this.holdings.filter(this.isSecurity);
  }

  isSecurity(holding: Holding): boolean {
    return holding.type.indexOf('fundHoldingSecurity') !== -1;
  }

  isDirective(holding: Holding): boolean {
    return holding.type.indexOf('fundHoldingDirective') !== -1;
  }
}
