import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from '@app/shared/material.module';
import { FormsModule } from '@angular/forms';
import { FundHoldingRowModule } from '../fund-holding-row';
import { FundHoldingsComponent } from './fund-holdings.component';

@NgModule({
  imports: [
    CommonModule,
    MaterialModule,
    FundHoldingRowModule
  ],
  declarations: [FundHoldingsComponent],
  exports: [FundHoldingsComponent]
})
export class FundHoldingsModule { }
