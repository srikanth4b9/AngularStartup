import { HttpClient } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { Holding, mockFund0430, mockFund5828 } from '@app/modules/fund-maintenance/models';
import { MaterialModule } from '@app/shared/material.module';

import { FundHoldingRowComponent } from '../fund-holding-row/fund-holding-row.component';
import { FundHoldingsComponent } from './fund-holdings.component';

describe('FundHoldingsComponent', () => {
  let component: FundHoldingsComponent;
  let fixture: ComponentFixture<FundHoldingsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FundHoldingsComponent, FundHoldingRowComponent],
      imports: [
        MaterialModule, FormsModule, ReactiveFormsModule, NoopAnimationsModule
      ],
      providers: [HttpClient]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FundHoldingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  const security: Holding = mockFund0430.holdings[0];
  const directive: Holding = mockFund5828.holdings[0];

  describe('isSecurity', () => {
    it('should return true is holding is a security', () => {
      expect(component.isSecurity(security)).toBeTruthy();
    });
    it('should return false is holding is a directive', () => {
      expect(component.isSecurity(directive)).toBeFalsy();
    });
  });

  describe('isDirective', () => {
    it('should return true is holding is a directive', () => {
      expect(component.isDirective(directive)).toBeTruthy();
    });
    it('should return false is holding is a security', () => {
      expect(component.isDirective(security)).toBeFalsy();
    });
  });
});
