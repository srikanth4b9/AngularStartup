import { FundHoldingsModule } from './fund-holdings.module';

describe('FundHoldingsModule', () => {
  let fundHoldingsModule: FundHoldingsModule;

  beforeEach(() => {
    fundHoldingsModule = new FundHoldingsModule();
  });

  it('should create an instance', () => {
    expect(fundHoldingsModule).toBeTruthy();
  });
});
