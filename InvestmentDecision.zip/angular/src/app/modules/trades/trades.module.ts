import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TradesRoutingModule } from './trades-routing.module';
import { TradesViewModule, EditTradeViewModule } from './views';

@NgModule({
  imports: [
    CommonModule,
    TradesRoutingModule,
    TradesViewModule,
    EditTradeViewModule
  ]
})
export class TradesModule { }
