import { TradesRoutingModule } from './trades-routing.module';

describe('TradesRoutingModule', () => {
    let tradesRoutingModule: TradesRoutingModule;

    beforeEach(() => {
        tradesRoutingModule = new TradesRoutingModule();
    });

    it('should create an instance', () => {
        expect(tradesRoutingModule).toBeTruthy();
    });
});
