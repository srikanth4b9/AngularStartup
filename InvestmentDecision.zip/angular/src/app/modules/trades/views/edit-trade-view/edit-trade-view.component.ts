import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { DateTimeUtils } from '@app/shared/utils';
import * as moment from 'moment';

import { InvestmentDecisionRun, ManualRunForm } from '../../models';
import { TradeService } from '../../services';

type Moment = moment.Moment;

@Component({
  selector: 'app-edit-trade-view',
  templateUrl: './edit-trade-view.component.html',
  styleUrls: ['./edit-trade-view.component.scss']
})
export class EditTradeViewComponent implements OnInit {
  isNewTrade: boolean = true;
  manualRunForm: ManualRunForm = new ManualRunForm();
  portIdForm: FormGroup = this.createPortIdFormGroup();

  constructor(
    private readonly router: Router,
    private readonly route: ActivatedRoute,
    private readonly tradeService: TradeService) { }

  ngOnInit() {
    const runId: string = this.route.snapshot.params.runId;
    if (runId) {
      this.loadManualRun(+runId);
    }
  }

  createPortIdFormGroup(): FormGroup {
    return new FormGroup({
      portId: new FormControl(null, Validators.required)
    });
  }

  get portId() { return this.portIdForm.get('portId'); }

  loadManualRun(runId: number) {
    this.isNewTrade = false;
    this.tradeService.investmentDecisionRuns$.subscribe(runs => {
      if (!runs) {
        this.tradeService.getInvestmentDecisionRuns();
      } else {
        const manualRuns = runs.filter(run => run.isManualRun());
        const manualRun = this.findManualRun(manualRuns, runId);
        this.manualRunForm = new ManualRunForm(manualRun);
      }
    });
  }

  private findManualRun(runs: InvestmentDecisionRun[], runId: number): InvestmentDecisionRun {
    return runs.filter(run => run.runId === runId)[0];
  }

  isPortIdValid(): boolean {
    return this.portId.value && this.portId.valid;
  }

  setProductType(productType: string) {
    this.manualRunForm.productType.setValue(productType);
  }

  setHoldingId(holdingId: number) {
    this.manualRunForm.holdingId.setValue(holdingId);
  }

  settlementDateFilter(datepickerMoment: Moment): boolean {
    return DateTimeUtils.tradeDateFilter(datepickerMoment);
  }

  saveManualTrade(): void {
    const manualRun = this.formatSettlementDate(this.manualRunForm.value);
    this.tradeService.saveManualTrade(manualRun, this.isNewTrade, this.manualRunForm.runId).subscribe(
      () => this.router.navigate(['/trades'])
    );
  }

  private formatSettlementDate(manualRun: any): InvestmentDecisionRun {
    manualRun.trades[0].settlementDate = DateTimeUtils.toISOString(manualRun.trades[0].settlementDate);
    return manualRun;
  }
}
