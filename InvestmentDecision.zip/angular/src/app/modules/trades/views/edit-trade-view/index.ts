export * from './edit-trade-view.component';
export * from './edit-trade-view.module';
