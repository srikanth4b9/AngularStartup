import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule, MatDatepickerModule, MatInputModule, MatSelectModule, MatToolbarModule } from '@angular/material';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ActivatedRoute, Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { HoldingNameSelectModule } from '@app/modules/fund-maintenance/components';
import { FundMaintenanceService, MockFundMaintenanceService } from '@app/modules/fund-maintenance/services';
import { MockSecurityMasterService, SecurityMasterService } from '@app/modules/security-master/services';
import { CurrencyLabelModule, PortIdSelectModule } from '@app/shared/components';
import { DateTimeUtils } from '@app/shared/utils';
import * as moment from 'moment';
import { of } from 'rxjs';

import { mockManualRuns } from '../../models';
import { MockTradeService, TradeService } from '../../services';
import { EditTradeViewComponent } from './edit-trade-view.component';

class MockActivatedRoute {
  snapshot = { params: { runId: undefined } };
}

describe('EditTradeViewComponent', () => {
  let component: EditTradeViewComponent;
  let fixture: ComponentFixture<EditTradeViewComponent>;
  let activatedRoute: MockActivatedRoute;
  let router: Router;
  let tradeService: MockTradeService;

  let loadManualRunSpy: jasmine.Spy;

  beforeEach(() => {
    activatedRoute = new MockActivatedRoute();

    TestBed.configureTestingModule({
      declarations: [EditTradeViewComponent],
      imports: [
        NoopAnimationsModule,
        RouterTestingModule,
        ReactiveFormsModule,
        MatButtonModule,
        MatToolbarModule,
        PortIdSelectModule,
        HoldingNameSelectModule,
        MatSelectModule,
        MatDatepickerModule,
        MatMomentDateModule,
        MatInputModule,
        CurrencyLabelModule
      ],
      providers: [
        { provide: FundMaintenanceService, useClass: MockFundMaintenanceService },
        { provide: SecurityMasterService, useClass: MockSecurityMasterService },
        { provide: TradeService, useValue: new MockTradeService() },
        { provide: ActivatedRoute, useValue: activatedRoute }
      ]
    })
      .compileComponents();

    router = TestBed.get(Router);
    tradeService = TestBed.get(TradeService);
  });

  function createComponent() {
    fixture = TestBed.createComponent(EditTradeViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    loadManualRunSpy = spyOn(component, 'loadManualRun').and.callThrough();
  }

  function setRunIdRoute(runId: string = '768') {
    activatedRoute.snapshot.params.runId = runId;
  }

  it('should create', () => {
    createComponent();
    expect(component).toBeTruthy();
  });

  describe('ngOnInit:', () => {
    it('should not call loadManualRun if no route param exists', () => {
      createComponent();
      loadManualRunSpy.and.stub();

      component.ngOnInit();

      expect(loadManualRunSpy).not.toHaveBeenCalled();
    });

    it('should call loadManualRun if a runId exists in the route params', () => {
      const routeId = '768';
      setRunIdRoute(routeId);
      createComponent();
      loadManualRunSpy.and.stub();

      component.ngOnInit();

      expect(loadManualRunSpy).toHaveBeenCalledWith(+routeId);
    });
  });

  describe('loadManualRun:', () => {
    it('should call tradeService to load manual run', () => {
      const manualRun = mockManualRuns[0];
      createComponent();

      component.loadManualRun(manualRun.runId);

      expect(component.isNewTrade).toEqual(false);
      expect(component.manualRunForm.amount.value).toEqual(manualRun.trades[0].amount);
    });

    it('should call tradeService to get runs if not loaded', () => {
      tradeService.investmentDecisionRuns$ = of(undefined);
      createComponent();

      component.loadManualRun(mockManualRuns[0].runId);

      expect(tradeService.getInvestmentDecisionRuns).toHaveBeenCalled();
    });
  });

  describe('setProductType:', () => {
    it('should set the product type in the form', () => {
      const productType = 'LEGACY_FUND_OF_FUND';
      createComponent();

      component.setProductType(productType);

      expect(component.manualRunForm.productType.value).toEqual(productType);
    });
  });

  describe('setHoldingId:', () => {
    it('should set the holding ID in the form', () => {
      const holdingId = 868;
      createComponent();

      component.setHoldingId(holdingId);

      expect(component.manualRunForm.holdingId.value).toEqual(holdingId);
    });
  });

  describe('settlementDateFilter:', () => {
    it('should call tradeDateFilter from DateTimeUtils to filter date', () => {
      createComponent();
      const dateFilterSpy = spyOn(DateTimeUtils, 'tradeDateFilter');

      component.settlementDateFilter(moment().day(0));

      expect(dateFilterSpy).toHaveBeenCalled();
    });
  });

  describe('saveManualTrade:', () => {
    it('should call tradeService to save the manual trade', () => {
      setRunIdRoute();
      createComponent();
      const navigateSpy = spyOn(router, 'navigate');

      component.saveManualTrade();

      expect(tradeService.saveManualTrade).toHaveBeenCalledWith(
        component.manualRunForm.value, component.isNewTrade, component.manualRunForm.runId);
      expect(navigateSpy).toHaveBeenCalledWith(['/trades']);
    });
  });
});
