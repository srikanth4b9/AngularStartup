import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule, MatDatepickerModule, MatInputModule, MatSelectModule, MatToolbarModule } from '@angular/material';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { RouterModule } from '@angular/router';
import { HoldingNameSelectModule } from '@app/modules/fund-maintenance/components';
import { CurrencyLabelModule, PortIdSelectModule } from '@app/shared/components';

import { EditTradeViewComponent } from './edit-trade-view.component';

@NgModule({
  declarations: [EditTradeViewComponent],
  imports: [
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatToolbarModule,
    PortIdSelectModule,
    HoldingNameSelectModule,
    MatSelectModule,
    MatDatepickerModule,
    MatMomentDateModule,
    MatInputModule,
    CurrencyLabelModule
  ],
  exports: [EditTradeViewComponent]
})
export class EditTradeViewModule { }
