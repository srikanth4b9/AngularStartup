import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatDialogModule, MatExpansionModule, MatToolbarModule } from '@angular/material';
import { ActionSelectModule } from '@app/shared/components';
import { RunPanelModule } from '@trades/components';

import { TradesViewComponent } from './trades-view.component';


@NgModule({
  imports: [
    CommonModule,
    MatToolbarModule,
    MatExpansionModule,
    MatDialogModule,
    RunPanelModule,
    ActionSelectModule
  ],
  declarations: [TradesViewComponent],
  exports: [TradesViewComponent]
})
export class TradesViewModule {}
