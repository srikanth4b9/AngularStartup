import { Component, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialog, MatExpansionModule, MatToolbarModule } from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import {
  ConfirmDialogComponent,
  ExportDialogComponent,
  ExportDialogModule,
  UploadDialogComponent,
  UploadDialogModule,
} from '@app/components';
import { ACTION, MockDialog } from '@app/shared/models';
import { DateTimeUtils } from '@app/shared/utils';
import { InvestmentDecisionRun, mockManualRuns, mockSystemRuns } from '@trades/models';
import { MockTradeService, TradeService } from '@trades/services';

import { RunPanelModule } from '../../components';
import { TradesViewComponent } from './trades-view.component';

@Component({
  selector: `app-host-component`,
  template: `<app-trades></app-trades>`
})
class TestHostComponent { }

describe('TradesViewComponent', () => {
  let component: TradesViewComponent;
  let fixture: ComponentFixture<TradesViewComponent>;
  let testHostComponent: TestHostComponent;
  let testHostFixture: ComponentFixture<TestHostComponent>;
  let router: Router;
  let dialog: MockDialog;
  let tradeService: MockTradeService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        RouterTestingModule,
        NoopAnimationsModule,
        MatToolbarModule,
        MatExpansionModule,
        RunPanelModule,
        ExportDialogModule,
        UploadDialogModule
      ],
      declarations: [TradesViewComponent, TestHostComponent],
      providers: [
        { provide: TradeService, useClass: MockTradeService },
        { provide: MatDialog, useValue: new MockDialog() }
      ]
    })
      .compileComponents();

    router = TestBed.get(Router);
    dialog = TestBed.get(MatDialog);
    tradeService = TestBed.get(TradeService);
  });

  function createComponent() {
    fixture = TestBed.createComponent(TradesViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  function createTestHostComponent() {
    testHostFixture = TestBed.createComponent(TestHostComponent);
    testHostComponent = testHostFixture.componentInstance;
    testHostFixture.detectChanges();
  }

  it('should create', () => {
    createTestHostComponent();
    expect(testHostComponent).toBeTruthy();
  });

  describe('constructor', () => {
    let tradingMarketClosedSpy: jasmine.Spy;
    beforeEach(function () {
      tradingMarketClosedSpy = spyOn(DateTimeUtils, 'isTradingMarketClosed');
    });

    it('should add NEW_MANUAL_TRADE action if trading market is open', () => {
      tradingMarketClosedSpy.and.returnValue(false);
      createComponent();

      component.actionOptions$.subscribe(
        options => expect(options).toContain(ACTION.NEW_MANUAL_TRADE)
      );
    });
    it('should not add NEW_MANUAL_TRADE action if trading market is closed', () => {
      tradingMarketClosedSpy.and.returnValue(true);
      createComponent();

      component.actionOptions$.subscribe(
        options => expect(options).not.toContain(ACTION.NEW_MANUAL_TRADE)
      );
    });
  });


  describe('action:', () => {
    beforeEach(function () {
      createComponent();
    });

    describe('NEW_MANUAL_TRADE', () => {
      it('should navigate to the new trade page', () => {
        spyOn(router, 'navigate');

        component.action(ACTION.NEW_MANUAL_TRADE);

        expect(router.navigate).toHaveBeenCalledWith(['/trades/create']);
      });
    });

    describe('RECALCULATE', () => {
      it('should open the recalculate confirm dialog', () => {
        dialog.mockConfirm();

        component.action(ACTION.RECALCULATE);

        expect(dialog.open).toHaveBeenCalledWith(ConfirmDialogComponent, { data: component.recalculateConfirmDialogData });
        expect(tradeService.recalculateTrades).toHaveBeenCalled();
      });
    });

    describe('UPLOAD_MANUAL_CASH', () => {
      it('should open the upload dialog component', () => {
        component.action(ACTION.UPLOAD_MANUAL_CASH);

        expect(dialog.open).toHaveBeenCalledWith(UploadDialogComponent, {
          data: { type: 'manual-cash', title: 'Upload Manual Cash' }
        });
      });
    });

    describe('EXPORT', () => {
      it('should open the export dialog component to export the trades report', () => {
        const exportDate = '2018-12-17';
        dialog.mockReturnData({ exportDate });

        component.action(ACTION.EXPORT);

        expect(dialog.open).toHaveBeenCalledWith(ExportDialogComponent, {
          data: { title: 'Export Trades' }
        });
        expect(tradeService.exportTradesReport).toHaveBeenCalledWith(exportDate);
      });
    });
  });

  describe('Scenario: User can view System run panels on the Investment Decision runs page', () => {
    describe('When user navigate to the trades page', () => {
      beforeEach(function () {
        createComponent();
      });

      it('Then the Run panels should include system runs', () => {
        const expectedRuns = mockSystemRuns.map(run => new InvestmentDecisionRun(run));
        expect(tradeService.getInvestmentDecisionRuns).toHaveBeenCalled();
        expect(component.systemRuns).toEqual(expectedRuns);
      });
    });
  });

  describe('Scenario: User can view a Manual Trade panel on the Investment Decision runs page', () => {
    describe('When user navigate to the trades page', () => {
      beforeEach(function () {
        createComponent();
      });

      it('Then the a Manual Trade panel should include manual runs', () => {
        const expectedRuns = mockManualRuns.map(run => new InvestmentDecisionRun(run));
        expect(tradeService.getInvestmentDecisionRuns).toHaveBeenCalled();
        expect(component.manualRuns).toEqual(expectedRuns);
      });
    });
  });
});
