import { Component } from '@angular/core';
import { MatDialog } from '@angular/material';
import { ConfirmDialogComponent, UploadDialogComponent, ExportDialogComponent } from '@app/components';
import { InvestmentDecisionRun } from '@app/modules/trades/models';
import { ACTION, ConfirmDialogModel } from '@app/shared/models';
import { faCalculator } from '@fortawesome/free-solid-svg-icons';
import { TradeService } from '@trades/services';
import { BehaviorSubject, Observable } from 'rxjs';
import { DateTimeUtils } from '@app/shared/utils';
import { Router } from '@angular/router';

@Component({
  selector: 'app-trades',
  templateUrl: './trades-view.component.html',
  styleUrls: ['./trades-view.component.scss']
})
export class TradesViewComponent {
  systemRuns: InvestmentDecisionRun[] = [];
  manualRuns: InvestmentDecisionRun[] = [];

  private readonly actionOptions?: BehaviorSubject<ACTION[]> = new BehaviorSubject([
    ACTION.RECALCULATE,
    ACTION.UPLOAD_MANUAL_CASH,
    ACTION.EXPORT
  ]);
  actionOptions$?: Observable<ACTION[]> = this.actionOptions.asObservable();

  recalculateConfirmDialogData: ConfirmDialogModel = {
    title: 'Are You Sure?',
    confirmButtonText: 'Recalculate',
    confirmButtonIcon: faCalculator
  };

  constructor(
    protected router: Router,
    private dialog: MatDialog,
    private tradeService: TradeService) {
    if (!DateTimeUtils.isTradingMarketClosed()) {
      const newOptions = this.actionOptions.value;
      newOptions.unshift(ACTION.NEW_MANUAL_TRADE);
      this.actionOptions.next(newOptions);
    }
    this.loadInvestmentDecisionRuns();
  }

  private loadInvestmentDecisionRuns(): void {
    this.tradeService.investmentDecisionRuns$.subscribe(
      (runs: InvestmentDecisionRun[] = []) => this.filterRuns(runs)
    );
    this.tradeService.getInvestmentDecisionRuns();
  }

  private filterRuns(runs: InvestmentDecisionRun[]) {
    this.systemRuns = runs.filter(run => !run.isManualRun());
    this.systemRuns.sort(this.sortRuns);

    this.manualRuns = runs.filter(run => run.isManualRun());
    this.manualRuns.sort(this.sortRuns);
  }

  private sortRuns(a: InvestmentDecisionRun, b: InvestmentDecisionRun) {
    const aTimestamp: any = new Date(a.runTimestamp);
    const bTimestamp: any = new Date(b.runTimestamp);
    return bTimestamp - aTimestamp;
  }

  action(action: ACTION) {
    if (action === ACTION.NEW_MANUAL_TRADE) {
      this.router.navigate(['/trades/create']);
    }
    if (action === ACTION.RECALCULATE) {
      this.openRecalculateConfirmDialog();
    }
    if (action === ACTION.UPLOAD_MANUAL_CASH) {
      this.openUploadDialog();
    }
    if (action === ACTION.EXPORT) {
      this.openExportDialog();
    }
  }

  private openUploadDialog() {
    this.dialog.open(UploadDialogComponent, {
      data: { type: 'manual-cash', title: 'Upload Manual Cash' }
    });
  }

  private openRecalculateConfirmDialog() {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, { data: this.recalculateConfirmDialogData });
    dialogRef.afterClosed().subscribe(data => {
      if (data === 'confirm') {
        this.tradeService.recalculateTrades();
      }
    });
  }

  private openExportDialog() {
    const dialogRef = this.dialog.open(ExportDialogComponent, { data: { title: 'Export Trades' } });
    dialogRef.afterClosed().subscribe(data => {
      if (data) {
        this.tradeService.exportTradesReport(data.exportDate);
      }
    });
  }
}
