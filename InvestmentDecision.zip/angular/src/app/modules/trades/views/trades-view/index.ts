export * from './trades-view.component';
export * from './trades-view.module';
