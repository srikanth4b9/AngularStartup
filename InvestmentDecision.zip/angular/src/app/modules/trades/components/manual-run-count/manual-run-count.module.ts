import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ManualRunCountComponent } from './manual-run-count.component';

@NgModule({
  declarations: [ManualRunCountComponent],
  imports: [
    CommonModule
  ],
  exports: [ManualRunCountComponent]
})
export class ManualRunCountModule { }
