import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManualRunCountComponent } from './manual-run-count.component';
import { mockManualRuns } from '../../models';

describe('ManualRunCountComponent', () => {
  let component: ManualRunCountComponent;
  let fixture: ComponentFixture<ManualRunCountComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ManualRunCountComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManualRunCountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('ngOnChanges', () => {
    it('should setup run count map object', () => {
      component.runs = mockManualRuns;
      component.ngOnChanges();

      expect(component.runCount).toEqual({
        'PENDING_REVIEW': 1,
        'RELEASED': 1
      });
    });
  });
});
