import { Component, Input, OnChanges } from '@angular/core';

import { InvestmentDecisionRun, RunStatus, StatusBadgeClasses } from '../../models';

@Component({
  selector: 'app-manual-run-count',
  templateUrl: './manual-run-count.component.html',
  styleUrls: ['./manual-run-count.component.scss']
})
export class ManualRunCountComponent implements OnChanges {
  @Input() runs: InvestmentDecisionRun[] = [];

  runCount: { [key: string]: number; } = {};
  RunStatus = RunStatus;
  StatusBadgeClasses = StatusBadgeClasses;
  keys = Object.keys;

  constructor() { }

  ngOnChanges() {
    this.runCount = this.runs.reduce((counter, run) => {
      const status = run.status;
      counter[status] = counter.hasOwnProperty(status) ? counter[status] + 1 : 1;
      return counter;
    }, {});
  }
}
