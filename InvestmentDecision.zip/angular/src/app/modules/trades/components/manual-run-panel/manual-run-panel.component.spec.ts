import { Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatButtonModule, MatDialog, MatExpansionModule } from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { ConfirmDialogComponent } from '@app/components';
import { CustomMatTableComponent, ExportableReportComponent, ExportableReportModule } from '@app/shared/components';
import { ACTION, ActionRequest } from '@app/shared/models';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { of } from 'rxjs';

import { InvestmentDecisionRun, ManualTrade, mockManualRuns } from '../../models';
import { MockTradeService, TradeService } from '../../services';
import { ManualRunCountModule } from '../manual-run-count';
import { ManualRunPanelComponent } from './manual-run-panel.component';

class MockDialog {
  open = jasmine.createSpy().and.returnValue({
    afterClosed: jasmine.createSpy().and.returnValue(of({}))
  });
}

@Component({
  selector: `app-host-component`,
  template: `<app-manual-run-panel [manualRuns]="manualRuns"></app-manual-run-panel>`
})
class TestHostComponent {
  manualRuns: InvestmentDecisionRun[];
}

describe('ManualRunPanelComponent', () => {
  let component: ManualRunPanelComponent;
  let fixture: ComponentFixture<ManualRunPanelComponent>;
  let testHostComponent: TestHostComponent;
  let testHostFixture: ComponentFixture<TestHostComponent>;
  let dialog: MockDialog;
  let tradeService: MockTradeService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        NoopAnimationsModule,
        MatButtonModule,
        MatExpansionModule,
        ExportableReportModule,
        FontAwesomeModule,
        ManualRunCountModule
      ],
      declarations: [ManualRunPanelComponent, TestHostComponent],
      providers: [
        { provide: TradeService, useClass: MockTradeService },
        { provide: MatDialog, useClass: MockDialog }
      ]
    })
      .compileComponents();

    dialog = TestBed.get(MatDialog);
    tradeService = TestBed.get(TradeService);
  });

  function createComponent() {
    fixture = TestBed.createComponent(ManualRunPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  function createTestHostComponent() {
    testHostFixture = TestBed.createComponent(TestHostComponent);
    testHostComponent = testHostFixture.componentInstance;
    testHostComponent.manualRuns = [];
    testHostFixture.detectChanges();
  }

  it('should create', () => {
    createTestHostComponent();
    expect(testHostComponent).toBeTruthy();
  });

  // TODO: enable after non-prod testing
  // describe('Scenario: New manual trade option is enabled before 4:00PM EST cutoff time', () => {
  //   describe('Given the current time is 3:59PM', () => {
  //     beforeEach(function () {
  //       jasmine.clock().mockDate(new Date('July 3, 2019 15:59:00'));
  //     });

  //     describe('When the manual run panel is created', () => {
  //       beforeEach(function () {
  //         createTestHostComponent();
  //       });

  //       it('Then the option to create a new manual trade should be enabled', () => {
  //         expect(newTradeButton.disabled).toBe(false);
  //       });
  //     });
  //   });
  // });

  // describe('Scenario: New manual trade option is disabled after 4:00PM EST cutoff time', () => {
  //   describe('Given the current time is 3:59PM', () => {
  //     beforeEach(function () {
  //       jasmine.clock().mockDate(new Date('July 3, 2019 16:00:00'));
  //     });

  //     describe('When the manual run panel is created', () => {
  //       beforeEach(function () {
  //         createTestHostComponent();
  //       });

  //       it('Then the option to create a new manual trade should be disabled', () => {
  //         expect(newTradeButton.disabled).toBe(true);
  //       });
  //     });
  //   });
  // });

  describe('deleteTrades', () => {
    it('should call service to delete an existing trade', () => {
      createComponent();
      const run = new InvestmentDecisionRun(mockManualRuns[0]);
      const manualTrade = new ManualTrade(run);
      dialog.open.and.returnValue({
        afterClosed: () => of('confirm')
      });

      component.action(new ActionRequest(ACTION.DELETE, manualTrade));

      expect(tradeService.deleteManualTrades).toHaveBeenCalledWith([manualTrade.runId]);
    });
  });

  describe('releaseSelectedTrades', () => {
    // Convert to testHostComponent test
    it('should open the release confirm dialog', () => {
      createComponent();
      component.tableComponent = new ExportableReportComponent();
      component.tableComponent.customMatTable = new CustomMatTableComponent();
      component.tableComponent.customMatTable.displayedColumns = [];
      component.tableComponent.customMatTable.setupMultiSelection();

      component.releaseSelectedTrades(new MouseEvent('click'));

      expect(dialog.open).toHaveBeenCalledWith(ConfirmDialogComponent, { data: component.releaseConfirmDialogData });
    });
  });

  // describe('deleteSelectedTrades', () => {
  //   it('should open the delete confirm dialog for selected trades', () => {
  //     component.tableComponent.customMatTable.selection.select(...mockInvestmentDecisionRuns[0].trades);

  //     component.deleteSelectedTrades(new MouseEvent('click'));

  //     expect(component.panelOpenState).toEqual(true);
  //     expect(dialog.open).toHaveBeenCalledWith(mockInvestmentDecisionRuns[0].trades);
  //   });
  // });
});
