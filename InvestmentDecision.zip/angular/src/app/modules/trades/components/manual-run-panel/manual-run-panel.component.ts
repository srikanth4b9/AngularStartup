import { Component, Input, OnChanges } from '@angular/core';
import { faPlusCircle } from '@fortawesome/free-solid-svg-icons';

import { InvestmentDecisionRun, ManualTrade, ManualTradeReportDef } from '../../models';
import { RunPanelComponent } from '../run-panel/run-panel.component';

@Component({
  selector: 'app-manual-run-panel',
  templateUrl: './manual-run-panel.component.html',
  styleUrls: [
    './manual-run-panel.component.scss',
    '../run-panel/run-panel.component.scss'
  ]
})
export class ManualRunPanelComponent extends RunPanelComponent implements OnChanges {
  @Input() manualRuns: InvestmentDecisionRun[] = [];

  manualTrades: ManualTrade[];
  manualTradeReportDef = new ManualTradeReportDef();

  faPlusCircle = faPlusCircle;

  ngOnChanges() {
    this.manualTrades = this.manualRuns.map(run => new ManualTrade(run));
  }

  protected deleteTrades(trades: ManualTrade[]) {
    this.tradeService.deleteManualTrades(trades.map(trade => trade.runId));
  }

  releaseSelectedTrades(event: MouseEvent) {
    event.stopPropagation();
    this.openReleaseConfirmDialog(this.tableComponent.customMatTable.selection.selected);
  }
}
