import { SelectionChange } from '@angular/cdk/collections';
import { Component, Input, OnChanges, ViewChild } from '@angular/core';
import { MatDialog, MatSortable } from '@angular/material';
import { Router } from '@angular/router';
import { ConfirmDialogComponent } from '@app/components';
import { ExportableReportComponent } from '@app/shared/components';
import { ACTION, ActionRequest, ConfirmDialogModel } from '@app/shared/models';
import { faChevronDown, faChevronRight, faShare, faTrash } from '@fortawesome/free-solid-svg-icons';
import { ProductType } from '@fund-maintenance/models';
import {
  InvestmentDecisionRun,
  ManualTrade,
  RunStatus,
  RunType,
  StatusBadgeClasses,
  Trade,
  TradeReportDef,
} from '@trades/models';

import { TradeService } from '../../services';
import { DateTimeUtils } from '@app/shared/utils';

@Component({
  selector: 'app-run-panel',
  templateUrl: './run-panel.component.html',
  styleUrls: ['./run-panel.component.scss']
})
export class RunPanelComponent implements OnChanges {
  @Input() run: InvestmentDecisionRun = new InvestmentDecisionRun(undefined);
  @ViewChild(ExportableReportComponent, { static: false }) tableComponent: ExportableReportComponent;

  trades: Trade[];
  panelOpenState: boolean = false;
  tradeReportDef = new TradeReportDef();
  sortBy: MatSortable = { id: 'portId', start: 'asc', disableClear: false };
  hasSelectedTrades: boolean = false;

  faChevronRight = faChevronRight;
  faChevronDown = faChevronDown;
  faShare = faShare;
  faTrash = faTrash;

  releaseConfirmDialogData: ConfirmDialogModel = {
    title: 'Are You Sure?',
    confirmButtonText: 'Release',
    confirmButtonIcon: faShare
  };

  deleteConfirmDialogData: ConfirmDialogModel = {
    title: 'Are You Sure?',
    message: 'Trades will be deleted permanently',
    confirmButtonText: 'Delete',
    confirmButtonIcon: faTrash
  };

  constructor(
    protected router: Router,
    protected dialog: MatDialog,
    protected tradeService: TradeService
  ) { }

  ngOnChanges() {
    this.trades = this.run.trades.map(trade => new Trade(trade));
    if (this.run.isActionsEnabled()) {
      this.trades.forEach(trade => trade.setActions([ACTION.DELETE]));
    } else {
      this.tradeReportDef.hasActions = false;
    }
  }

  get productType(): string {
    return ProductType[this.run.productTypes[0]];
  }
  get runType(): string {
    return RunType[this.run.runType];
  }
  get runStatus(): string {
    return RunStatus[this.run.status];
  }
  get badgeClass(): string {
    return StatusBadgeClasses[this.run.status];
  }

  updateHasSelectedTrades(change: SelectionChange<Trade>) {
    this.hasSelectedTrades = change.source.selected.length > 0;
  }

  action(actionRequest: ActionRequest) {
    if (actionRequest.action === ACTION.RELEASE) {
      this.openReleaseConfirmDialog([actionRequest.object]);
    }
    if (actionRequest.action === ACTION.EDIT) {
      const manualTrade: ManualTrade = actionRequest.object;
      this.router.navigate(['/trades/edit', manualTrade.runId]);
    }
    if (actionRequest.action === ACTION.DELETE) {
      this.openDeleteConfirmDialog([actionRequest.object]);
    }
  }

  deleteSelectedTrades(event: MouseEvent) {
    event.stopPropagation();
    this.openDeleteConfirmDialog(this.tableComponent.customMatTable.selection.selected);
  }

  releaseRun(event: MouseEvent) {
    event.stopPropagation();
    this.openReleaseConfirmDialog([this.run]);
  }

  protected openReleaseConfirmDialog(runs: InvestmentDecisionRun[]) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, { data: this.releaseConfirmDialogData });
    dialogRef.afterClosed().subscribe(data => {
      if (data === 'confirm') {
        this.tradeService.releaseTrades(runs.map(run => run.runId));
      }
    });
  }

  private openDeleteConfirmDialog(trades: Trade[]) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, { data: this.deleteConfirmDialogData });
    dialogRef.afterClosed().subscribe(data => {
      if (data === 'confirm') {
        this.deleteTrades(trades);
      }
    });
  }

  protected deleteTrades(trades: Trade[]) {
    this.tradeService.deleteTrades(this.run.runId, trades.map(trade => trade.holdingId));
  }

  get isTradingMarketClosed(): boolean {
    return DateTimeUtils.isTradingMarketClosed();
  }
}
