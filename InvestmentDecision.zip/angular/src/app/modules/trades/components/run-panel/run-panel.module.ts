import { NgModule } from '@angular/core';
import { ExportableReportModule } from '@app/shared/components';
import { MatExpansionModule, MatButtonModule } from '@angular/material';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { RunPanelComponent } from './run-panel.component';
import { CommonModule } from '@angular/common';
import { ManualRunPanelComponent } from '../manual-run-panel/manual-run-panel.component';
import { ManualRunCountModule } from '../manual-run-count';


@NgModule({
  imports: [
    CommonModule,
    MatExpansionModule,
    MatButtonModule,
    ExportableReportModule,
    FontAwesomeModule,
    ManualRunCountModule
  ],
  declarations: [RunPanelComponent, ManualRunPanelComponent],
  exports: [RunPanelComponent, ManualRunPanelComponent]
})
export class RunPanelModule {}
