import { SelectionChange, SelectionModel } from '@angular/cdk/collections';
import { Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatButtonModule, MatDialog, MatExpansionModule } from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { ConfirmDialogComponent } from '@app/components';
import { ExportableReportModule } from '@app/shared/components';
import { ACTION, ActionRequest, MockDialog } from '@app/shared/models';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

import {
  InvestmentDecisionRun,
  ManualTrade,
  mockInvestmentDecisionRuns,
  mockManualRuns,
  mockSystemRuns,
  Trade,
} from '../../models';
import { MockTradeService, TradeService } from '../../services';
import { RunPanelComponent } from './run-panel.component';

@Component({
  selector: 'app-host-component',
  template: '<app-run-panel run="run"></app-run-panel>'
})
class TestHostComponent {
  run = mockInvestmentDecisionRuns[0];
}

describe('RunPanelComponent', () => {
  let component: RunPanelComponent;
  let fixture: ComponentFixture<RunPanelComponent>;
  let router: Router;
  let dialog: MockDialog;
  let tradeService: MockTradeService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        NoopAnimationsModule,
        MatExpansionModule,
        MatButtonModule,
        ExportableReportModule,
        FontAwesomeModule
      ],
      declarations: [
        RunPanelComponent,
        TestHostComponent
      ],
      providers: [
        { provide: TradeService, useClass: MockTradeService },
        { provide: MatDialog, useValue: new MockDialog() }
      ]
    })
      .compileComponents();

    router = TestBed.get(Router);
    dialog = TestBed.get(MatDialog);
    tradeService = TestBed.get(TradeService);
  });

  function createComponent(mockRun = mockSystemRuns[0]) {
    fixture = TestBed.createComponent(RunPanelComponent);
    component = fixture.componentInstance;
    component.run = new InvestmentDecisionRun(mockRun);
    fixture.detectChanges();
  }

  beforeEach(() => {
    createComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('ngOnChanges', () => {
    it('should initialize run level information', () => {
      component.ngOnChanges();

      expect(component.trades).toBeDefined();

      expect(component.productType).toBeDefined();
      expect(component.runType).toBeDefined();
      expect(component.runStatus).toBeDefined();
      expect(component.badgeClass).toBeDefined();
    });

    it('should set table actions to false if run actions are disabled', () => {
      spyOn(component.run, 'isActionsEnabled').and.returnValue(false);

      component.ngOnChanges();

      expect(component.tradeReportDef.hasActions).toEqual(false);
    });
  });

  describe('updateHasSelectedTrades', () => {
    let mockSelectionChange: SelectionChange<Trade>;
    beforeEach(function () {
      mockSelectionChange = {
        source: new SelectionModel(true, []),
        added: [],
        removed: []
      };
    });

    it('should set hasSelectedTrades to false if no rows are selected', () => {
      component.updateHasSelectedTrades(mockSelectionChange);

      expect(component.hasSelectedTrades).toEqual(false);
    });

    it('should set hasSelectedTrades to true if any rows are selected', () => {
      mockSelectionChange.source.select(...mockInvestmentDecisionRuns[0].trades);

      component.updateHasSelectedTrades(mockSelectionChange);

      expect(component.hasSelectedTrades).toEqual(true);
    });
  });

  describe('action', () => {
    let run: InvestmentDecisionRun;
    let manualTrade: ManualTrade;
    beforeEach(function () {
      run = new InvestmentDecisionRun(mockManualRuns[0]);
      manualTrade = new ManualTrade(run);
    });

    describe('RELEASE', () => {
      let actionRequest: ActionRequest;
      beforeEach(function() {
        actionRequest = new ActionRequest(ACTION.RELEASE, manualTrade);
      });

      it('should open the release confirm dialog for a RELEASE action', () => {
        component.action(actionRequest);

        expect(dialog.open).toHaveBeenCalledWith(ConfirmDialogComponent, { data: component.releaseConfirmDialogData });
      });

      it('should call service to release an existing manual trade', () => {
        dialog.mockConfirm();

        component.action(actionRequest);

        expect(tradeService.releaseTrades).toHaveBeenCalledWith([manualTrade.runId]);
      });
    });

    describe('EDIT', () => {
      it('should navigate to the edit trade page for an EDIT action', () => {
        spyOn(router, 'navigate');
        component.action(new ActionRequest(ACTION.EDIT, manualTrade));

        expect(router.navigate).toHaveBeenCalledWith(['/trades/edit', manualTrade.runId]);
      });
    });

    describe('DELETE', () => {
      let actionRequest: ActionRequest;
      beforeEach(function() {
        actionRequest = new ActionRequest(ACTION.DELETE, manualTrade);
      });

      it('should open the delete confirm dialog for a DELETE action', () => {
        component.action(actionRequest);

        expect(dialog.open).toHaveBeenCalledWith(ConfirmDialogComponent, { data: component.deleteConfirmDialogData });
      });

      it('should call service to delete an existing trade', () => {
        dialog.mockConfirm();

        component.action(actionRequest);

        expect(tradeService.deleteTrades).toHaveBeenCalledWith(component.run.runId, [manualTrade.holdingId]);
      });
    });
  });

  describe('releaseRun', () => {
    let event: MouseEvent;
    beforeEach(function() {
      event = new MouseEvent('click');
    });

    it('should open the release confirm dialog', () => {
      component.releaseRun(event);

      expect(dialog.open).toHaveBeenCalledWith(ConfirmDialogComponent, { data: component.releaseConfirmDialogData });
    });

    it('should call service to release a system run', () => {
      dialog.mockConfirm();

      component.releaseRun(event);

      expect(tradeService.releaseTrades).toHaveBeenCalledWith([component.run.runId]);
    });
  });


  // describe('deleteSelectedTrades', () => {
  //   it('should open the delete confirm dialog for selected trades', () => {
  //     component.tableComponent.customMatTable.selection.select(...mockInvestmentDecisionRuns[0].trades);

  //     component.deleteSelectedTrades(new MouseEvent('click'));

  //     expect(component.panelOpenState).toEqual(true);
  //     expect(dialog.open).toHaveBeenCalledWith(mockInvestmentDecisionRuns[0].trades);
  //   });
  // });
});
