import { ACTION, ColumnDefBuilder, ColumnType, TableDef } from '@app/shared/models';
import { BehaviorSubject, Observable } from 'rxjs';

import { RunType } from './run.model';

export type TransactionType = 'BUY' | 'SELL';

export class Trade {
  holdingId: number;
  portId: string;
  fundName: string;
  accountingSecurityId: string;
  securityName: string;
  tradeDate: string;
  settlementDate: string;
  tradeType: RunType = 'MANUAL';
  tradeSubmissionMethod: string;
  transactionType: TransactionType = 'BUY';
  amount: number;
  usePriorTradeDate?: boolean = false;

  private readonly actionOptions?: BehaviorSubject<ACTION[]>;
  actionOptions$?: Observable<ACTION[]>;

  constructor(trade: Trade) {
    if (trade) {
      this.holdingId = trade.holdingId;
      this.portId = trade.portId;
      this.fundName = trade.fundName;
      this.accountingSecurityId = trade.accountingSecurityId;
      this.securityName = trade.securityName;
      this.tradeDate = trade.tradeDate;
      this.settlementDate = trade.settlementDate;
      this.tradeType = trade.tradeType;
      this.tradeSubmissionMethod = trade.tradeSubmissionMethod;
      this.transactionType = trade.transactionType;
      this.amount = trade.amount;
      this.usePriorTradeDate = trade.usePriorTradeDate;
    }

    this.actionOptions = new BehaviorSubject([]);
    this.actionOptions$ = this.actionOptions.asObservable();
  }

  setActions?(actions: ACTION[]): void {
    this.actionOptions.next(actions);
  }

  hasActions?(): boolean {
    return this.actionOptions.value.length > 0;
  }
}

export class TradeReportDef extends TableDef {
  constructor() {
    super(
      [
        new ColumnDefBuilder('Port ID', 'portId', ColumnType.STRING).build(),
        new ColumnDefBuilder('Fund Name', 'fundName', ColumnType.STRING).build(),
        new ColumnDefBuilder('Accounting Security ID', 'accountingSecurityId', ColumnType.STRING).build(),
        new ColumnDefBuilder('Security Name', 'securityName', ColumnType.STRING).build(),
        new ColumnDefBuilder('Trade Date', 'tradeDate', ColumnType.DATE).build(),
        new ColumnDefBuilder('Settlement Date', 'settlementDate', ColumnType.DATE).build(),
        new ColumnDefBuilder('Trade Type', 'tradeType', ColumnType.ENUM).build(),
        new ColumnDefBuilder('Trade Submission Method', 'tradeSubmissionMethod', ColumnType.ENUM).build(),
        new ColumnDefBuilder('Transaction Type', 'transactionType', ColumnType.STRING).build(),
        new ColumnDefBuilder('Trade Amount', 'amount', ColumnType.CURRENCY).build()
      ],
      true,
      true
    );
  }
}
