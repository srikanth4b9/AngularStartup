import { mockManualTrades } from './mock-json';
import { Trade } from './trade.model';
import { ACTION } from '@app/shared/models';

describe('Trade', () => {
  describe('constructor', () => {
    it('should create new trade', () => {
      const trade: Trade = new Trade(mockManualTrades[0]);
      expect(trade.holdingId).toBe(100);
    });

    it('should not set fields if no trade is given', () => {
      const trade: Trade = new Trade(undefined);
      expect(trade.holdingId).not.toBeDefined();
    });
  });

  describe('hasActions', () => {
    let trade: Trade;
    beforeEach(function() {
      trade = new Trade(mockManualTrades[0]);
    });

    it('should return true if trade has any actions', () => {
      trade.setActions([ACTION.DELETE]);

      expect(trade.hasActions()).toEqual(true);
    });

    it('should return false if trade has no actions', () => {
      expect(trade.hasActions()).toEqual(false);
    });
  });
});
