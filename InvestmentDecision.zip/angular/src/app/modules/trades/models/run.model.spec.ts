import { DateTimeUtils } from '@app/shared/utils';

import { mockManualRuns, mockSystemRuns } from './mock-json';
import { InvestmentDecisionRun } from './run.model';

describe('InvestmentDecisionRun', () => {
  describe('constructor', () => {
    it('should create new trade', () => {
      const run: InvestmentDecisionRun = new InvestmentDecisionRun(mockSystemRuns[0]);
      expect(run.runId).toBe(268);
    });

    it('should not set fields if no trade is given', () => {
      const run: InvestmentDecisionRun = new InvestmentDecisionRun(undefined);
      expect(run.runId).not.toBeDefined();
    });
  });

  describe('isManualRun', () => {
    let run: InvestmentDecisionRun;
    it('should return false if runType is not MANUAL', () => {
      run = new InvestmentDecisionRun(mockSystemRuns[0]);
      expect(run.isManualRun()).toEqual(false);
    });
    it('should return true if runType is MANUAL', () => {
      run = new InvestmentDecisionRun(mockManualRuns[0]);
      expect(run.isManualRun()).toEqual(true);
    });
  });

  describe('isActionsEnabled', () => {
    let run: InvestmentDecisionRun;
    let marketClosedSpy: jasmine.Spy;
    beforeEach(function () {
      run = new InvestmentDecisionRun(mockSystemRuns[0]);
      marketClosedSpy = spyOn(DateTimeUtils, 'isTradingMarketClosed').and.returnValue(false);
    });

    it('should return false if market is closed', () => {
      marketClosedSpy.and.returnValue(true);

      expect(run.isActionsEnabled()).toEqual(false);
      expect(marketClosedSpy).toHaveBeenCalledWith(run.productTypes[0]);
    });

    it('should return false if status is not PENDING_REVIEW', () => {
      run.status = 'SUBMITTED';

      expect(run.isActionsEnabled()).toEqual(false);
    });

    it('should return true if status is PENDING_REVIEW', () => {
      run.status = 'PENDING_REVIEW';

      expect(run.isActionsEnabled()).toEqual(true);
    });

    it('should pass undefined as productType if the run is MANUAL', () => {
      run = new InvestmentDecisionRun(mockManualRuns[0]);
      run.isActionsEnabled();

      expect(marketClosedSpy).toHaveBeenCalledWith(undefined);
    });
  });
});
