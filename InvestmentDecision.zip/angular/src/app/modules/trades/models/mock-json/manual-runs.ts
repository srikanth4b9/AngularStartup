import { mockManualTrades } from './manual-trades';
import { InvestmentDecisionRun } from '../run.model';

export const mockManualRuns: InvestmentDecisionRun[] = [
  {
    'type': 'capstockActivityRun',
    'productTypes': ['LEGACY_FUND_OF_FUND'],
    'runId': 768,
    'runTimestamp': '2019-10-02T19:32:41.212Z',
    'runType': 'MANUAL',
    'status': 'PENDING_REVIEW',
    'trades': mockManualTrades
  },
  {
    'type': 'capstockActivityRun',
    'productTypes': ['LEGACY_FUND_OF_FUND'],
    'runId': 769,
    'runTimestamp': '2019-10-02T19:32:41.212Z',
    'runType': 'MANUAL',
    'status': 'RELEASED',
    'trades': mockManualTrades

  }
];
