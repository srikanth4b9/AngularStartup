import { InvestmentDecisionRun } from '@app/modules/trades/models/run.model';

export const mockSystemRuns: InvestmentDecisionRun[] = [
  {
    'type': 'capstockActivityRun',
    'productTypes': ['CUSTOM_TARGET_DATE_FUND'],
    'runId': 268,
    'status': 'AWAITING_SUBMISSION',
    'runTimestamp': '2019-06-05T18:57:00.547Z',
    'runType': 'CAPSTOCK_ACTIVITY',
    'trades': [
      {
        'holdingId': 110,
        'portId': '5828',
        'fundName': 'CLARK COMPANY CONTRIBUTION',
        'accountingSecurityId': '732',
        'securityName': 'SHORT TERM BOND INDEX',
        'tradeDate': '2019-06-04T00:00:00-04:00',
        'settlementDate': '2019-06-04T00:00:00-04:00',
        'tradeType': 'CAPSTOCK_ACTIVITY',
        'tradeSubmissionMethod': 'NSCC',
        'transactionType': 'BUY',
        'amount': 231.15
      },
      {
        'holdingId': 111,
        'portId': '5828',
        'fundName': 'CLARK COMPANY CONTRIBUTION',
        'accountingSecurityId': '11',
        'securityName': 'VGI TREASURY MONEY MKT',
        'tradeDate': '2019-06-04T00:00:00-04:00',
        'settlementDate': '2019-06-04T00:00:00-04:00',
        'tradeType': 'CAPSTOCK_ACTIVITY',
        'tradeSubmissionMethod': 'NSCC',
        'transactionType': 'BUY',
        'amount': 60.05
      }
    ]
  },
  // {
  //   'type': 'capstockActivityRun',
  //   'productType': 'CUSTOM_TARGET_DATE_FUND',
  //   'runId': 766,
  //   'runTimestamp': '2019-10-02T09:00:04.103Z',
  //   'runType': 'CAPSTOCK_ACTIVITY',
  //   'status': 'AWAITING_SUBMISSION',
  //   'trades': [
  //     {
  //       'holdingId': 132,
  //       'portId': '2041',
  //       'tradeType': 'CAPSTOCK_ACTIVITY',
  //       'fundName': '500 INDEX TRUST WITH MULTILEVEL DIRECTIVES ',
  //       'accountingSecurityId': 'MFS4837',
  //       'securityName': 'MFS MID CAP VALUE R6',
  //       'tradeDate': '2019-10-01T00:00:00-04:00',
  //       'settlementDate': '2019-10-02T00:00:00-04:00',
  //       'tradeSubmissionMethod': 'NSCC',
  //       'transactionType': 'BUY',
  //       'amount': 8975.65
  //     },
  //     {
  //       'holdingId': 131,
  //       'portId': '2041',
  //       'tradeType': 'CAPSTOCK_ACTIVITY',
  //       'fundName': '500 INDEX TRUST WITH MULTILEVEL DIRECTIVES ',
  //       'accountingSecurityId': 'HRTFD2047',
  //       'securityName': 'HARTFORD INT\'L OPP HLS IA',
  //       'tradeDate': '2019-10-01T00:00:00-04:00',
  //       'settlementDate': '2019-10-02T00:00:00-04:00',
  //       'tradeSubmissionMethod': 'NSCC',
  //       'transactionType': 'BUY',
  //       'amount': 2991.88
  //     },
  //     {
  //       'holdingId': 130,
  //       'portId': '2041',
  //       'tradeType': 'CAPSTOCK_ACTIVITY',
  //       'fundName': '500 INDEX TRUST WITH MULTILEVEL DIRECTIVES ',
  //       'accountingSecurityId': 'COHEN6623',
  //       'securityName': 'COHEN & STEERS REAL EST Z',
  //       'tradeDate': '2019-10-01T00:00:00-04:00',
  //       'settlementDate': '2019-10-02T00:00:00-04:00',
  //       'tradeSubmissionMethod': 'NSCC',
  //       'transactionType': 'BUY',
  //       'amount': 997.29
  //     }
  //   ]
  // },
  // {
  //   'type': 'capstockActivityRun',
  //   'productType': 'LEGACY_FUND_OF_FUND',
  //   'runId': 767,
  //   'runTimestamp': '2019-10-02T13:00:08.064Z',
  //   'runType': 'CAPSTOCK_ACTIVITY',
  //   'status': 'PENDING_REVIEW',
  //   'trades': [
  //     {
  //       'holdingId': 199,
  //       'portId': '0430',
  //       'tradeType': 'CAPSTOCK_ACTIVITY',
  //       'fundName': 'AGGRESSIVE GRWTH PORT',
  //       'accountingSecurityId': '1870',
  //       'securityName': 'TTL INTL STK IDX INST PLS',
  //       'tradeDate': '2019-10-02T00:00:00-04:00',
  //       'settlementDate': '2019-10-03T00:00:00-04:00',
  //       'tradeSubmissionMethod': 'DIRECT',
  //       'transactionType': 'BUY',
  //       'amount': 1013.16
  //     },
  //     {
  //       'holdingId': 200,
  //       'portId': '0430',
  //       'tradeType': 'CAPSTOCK_ACTIVITY',
  //       'fundName': 'AGGRESSIVE GRWTH PORT',
  //       'accountingSecurityId': '871',
  //       'securityName': 'TTL STK MKT IDX INST PLUS',
  //       'tradeDate': '2019-10-02T00:00:00-04:00',
  //       'settlementDate': '2019-10-03T00:00:00-04:00',
  //       'tradeSubmissionMethod': 'DIRECT',
  //       'transactionType': 'BUY',
  //       'amount': 1013.14
  //     }
  //   ]
  // }
];
