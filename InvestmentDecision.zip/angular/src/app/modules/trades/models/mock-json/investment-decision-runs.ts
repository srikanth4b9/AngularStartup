import { InvestmentDecisionRun } from '@app/modules/trades/models/run.model';
import { mockManualRuns } from './manual-runs';
import { mockSystemRuns } from './system-runs';

export const mockInvestmentDecisionRuns: InvestmentDecisionRun[] = [
  ...mockSystemRuns,
  ...mockManualRuns
];
