import { Trade } from '../trade.model';

export const mockManualTrades: Trade[] = [
  {
    'holdingId': 100,
    'portId': '4255',
    'tradeType': 'MANUAL',
    'fundName': 'NISSAN OPTION A',
    'accountingSecurityId': 'HAR2510',
    'securityName': 'HARBOR SMALL CAP GROWTH',
    'tradeDate': '2019-10-02T00:00:00-04:00',
    'settlementDate': '1969-12-31T19:00:00-05:00',
    'tradeSubmissionMethod': 'NSCC',
    'transactionType': 'BUY',
    'amount': 8000.09
  },
  {
    'holdingId': 573,
    'portId': '0430',
    'tradeType': 'MANUAL',
    'fundName': 'NISSAN OPTION A',
    'accountingSecurityId': 'HAR2510',
    'securityName': 'HARBOR SMALL CAP GROWTH',
    'tradeDate': '2019-10-02T00:00:00-04:00',
    'settlementDate': '1969-12-31T19:00:00-05:00',
    'tradeSubmissionMethod': 'NSCC',
    'transactionType': 'BUY',
    'amount': 532975234.00
  }
];
