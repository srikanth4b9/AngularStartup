import { Trade } from './trade.model';
import { DateTimeUtils } from '@app/shared/utils';

export type ProductType = 'CUSTOM_TARGET_DATE_FUND' | 'LEGACY_FUND_OF_FUND' | 'LEGACY_AM_FUND_OF_FUND';

export type RunType = 'CAPSTOCK_ACTIVITY' | 'CAPSTOCK_ACTIVITY_REBALANCE' | 'REBALANCE' | 'MANUAL' | 'NONE';
export const RunType = {
  'CAPSTOCK_ACTIVITY': 'Cap Stock Activity',
  'CAPSTOCK_ACTIVITY_REBALANCE': 'Cap Stock Activity / Rebalance',
  'REBALANCE': 'Rebalance',
  'MANUAL': 'Manual',
  'NONE': 'None'
};

export type RunStatus =
  'INITIATED' |
  'NO_TRADES' |
  'PENDING_REVIEW' |
  'RELEASED' |
  'SUBMITTED' |
  'FAILED' |
  'MISSED_CUTOFF' |
  'NONE' |
  'AWAITING_SUBMISSION' | // remove
  'RECEIVED'; // remove
export const RunStatus = {
  'INITIATED': 'Initiated',
  'NO_TRADES': 'No Trades',
  'PENDING_REVIEW': 'Pending Review',
  'RELEASED': 'Released',
  'SUBMITTED': 'Submitted',
  'FAILED': 'Failed',
  'MISSED_CUTOFF': 'Missed Cutoff',
  'NONE': 'None',
  'AWAITING_SUBMISSION': 'Awaiting Submission', // remove
  'RECEIVED': 'Received' // remove
};

export const StatusBadgeClasses = {
  'INITIATED': 'badge-secondary',
  'NO_TRADES': 'badge-warning',
  'PENDING_REVIEW': 'badge-secondary',
  'RELEASED': 'badge-info',
  'SUBMITTED': 'badge-success',
  'FAILED': 'badge-danger',
  'MISSED_CUTOFF': 'badge-warning',
  'NONE': 'badge-secondary',
  'AWAITING_SUBMISSION': 'badge-secondary',
  'RECEIVED': 'badge-success'
};

export class InvestmentDecisionRun {
  runId: number;
  productTypes: ProductType[] = [];
  type: string = 'manualTradeRun';
  runType: RunType = 'MANUAL';
  runTimestamp: string;
  status: RunStatus;
  trades: Trade[] = [new Trade(undefined)];

  constructor(run: InvestmentDecisionRun) {
    if (run) {
      this.runId = run.runId;
      this.productTypes = run.productTypes;
      this.type = run.type;
      this.runType = run.runType;
      this.runTimestamp = run.runTimestamp;
      this.status = run.status;
      this.trades = run.trades;
    }
  }

  isManualRun?() {
    return this.runType === 'MANUAL';
  }

  isActionsEnabled?() {
    const productType = this.isManualRun() ? undefined : this.productTypes[0];
    return !DateTimeUtils.isTradingMarketClosed(productType) && this.status === 'PENDING_REVIEW';
  }
}
