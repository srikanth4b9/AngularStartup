import { ACTION, ColumnDefBuilder, ColumnType } from '@app/shared/models';

import { InvestmentDecisionRun, RunStatus } from './run.model';
import { Trade, TradeReportDef } from './trade.model';

export class ManualTrade extends Trade {
  runId: number;
  status: RunStatus;

  constructor(run: InvestmentDecisionRun) {
    super(run.trades[0]);

    this.runId = run.runId;
    this.status = run.status;
    this.setActions(run.isActionsEnabled() ? [ACTION.RELEASE, ACTION.EDIT, ACTION.DELETE] : []);
  }
}

export class ManualTradeReportDef extends TradeReportDef {
  constructor() {
    super();
    this.columns.push(new ColumnDefBuilder('Status', 'status', ColumnType.STATUS).build());
  }
}
