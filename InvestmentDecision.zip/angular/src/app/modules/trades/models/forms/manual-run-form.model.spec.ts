import { FormArray } from '@angular/forms';

import { ManualRunForm } from './manual-run-form.model';
import { InvestmentDecisionRun } from '../run.model';
import { mockManualRuns } from '../mock-json';

describe('ManualRunForm', () => {
  let manualRunForm: ManualRunForm;

  beforeEach(function() {
    manualRunForm = new ManualRunForm(new InvestmentDecisionRun(mockManualRuns[0]));
  });

  describe('constructor', () => {
    it('should create a blank manual trade form', () => {
      expect(manualRunForm).toBeDefined();
    });
  });

  describe('Control Getters', () => {
    formControlGetterTest('holdingId');
    formControlGetterTest('usePriorTradeDate');
    formControlGetterTest('settlementDate');
    formControlGetterTest('transactionType');
    formControlGetterTest('amount');

    formArrayControlGetterTest('trade', 'trades');
    formArrayControlGetterTest('productType', 'productTypes');

    it(`should create a getter for runId`, () => {
      expect(manualRunForm.runId).toEqual(mockManualRuns[0].runId);
    });

    it(`should create a getter for portId`, () => {
      expect(manualRunForm.portId).toEqual(mockManualRuns[0].trades[0].portId);
    });

    it(`should create a getter for securityName`, () => {
      expect(manualRunForm.securityName).toEqual(mockManualRuns[0].trades[0].securityName);
    });
  });

  function formControlGetterTest(controlName: string) {
    it(`should create a control getter for ${controlName}`, () => {
      expect(manualRunForm[controlName]).toEqual(manualRunForm.trade[controlName]);
    });
  }

  function formArrayControlGetterTest(controlName: string, arrayName: string) {
    it(`should create an array control getter for ${controlName}`, () => {
      expect(manualRunForm[controlName]).toEqual((manualRunForm.get(arrayName) as FormArray).controls[0]);
    });
  }

  describe('isSubmitDisabled', () => {
    it('should return result of trade submitIsDisabled', () => {
      spyOnProperty(manualRunForm.trade, 'isSubmitDisabled').and.returnValue(false);
      expect(manualRunForm.isSubmitDisabled).toEqual(false);
    });
  });

});
