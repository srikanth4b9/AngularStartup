import { AbstractControl, FormArray, FormControl, FormGroup } from '@angular/forms';

import { ManualTradeForm } from './manual-trade-form.model';
import { InvestmentDecisionRun } from '../run.model';

// tslint:disable: no-use-before-declare
export class ManualRunForm extends FormGroup {
  private manualRun: InvestmentDecisionRun;

  /* istanbul ignore next */
  constructor(manualRun: InvestmentDecisionRun = new InvestmentDecisionRun(undefined)) {
    super({
      type: new FormControl(manualRun.type),
      productTypes: new FormArray([new FormControl(manualRun.productTypes[0])]),
      runType: new FormControl(manualRun.runType),
      trades: new FormArray([new ManualTradeForm(manualRun.trades[0])])
    });
    this.manualRun = manualRun;

    this.holdingId.statusChanges.subscribe(status => {
      if (status === 'VALID') {
        this.usePriorTradeDate.enable();
        this.settlementDate.enable();
        this.transactionType.enable();
        this.amount.enable();
      } else {
        this.usePriorTradeDate.disable();
        this.settlementDate.disable();
        this.transactionType.disable();
        this.amount.disable();
      }
    });
  }

  get runId(): number { return this.manualRun.runId; }
  get portId(): string { return this.manualRun.trades[0].portId; }
  get securityName(): string { return this.manualRun.trades[0].securityName; }

  get trade(): ManualTradeForm { return (this.get('trades') as FormArray).controls[0] as ManualTradeForm; }
  get productType(): AbstractControl { return (this.get('productTypes') as FormArray).controls[0]; }
  get holdingId(): AbstractControl { return this.trade.holdingId; }
  get usePriorTradeDate(): AbstractControl { return this.trade.usePriorTradeDate; }
  get settlementDate(): AbstractControl { return this.trade.settlementDate; }
  get transactionType(): AbstractControl { return this.trade.transactionType; }
  get amount(): AbstractControl { return this.trade.amount; }

  get isSubmitDisabled(): boolean {
    return this.trade.isSubmitDisabled;
  }

  getValidationError(formControlName: string): string {
    return this.trade.getValidationError(formControlName);
  }
}
