import { AbstractControl, FormControl, FormGroup, Validators } from '@angular/forms';
import { FormUtils } from '@app/modules/fund-maintenance/models';
import * as moment from 'moment';

import { Trade } from '../trade.model';

const MIN_AMOUNT = 0.01;
const MAX_AMOUNT = 999999999999999.99;

export class ManualTradeForm extends FormGroup {
  private trade: Trade;

  /* istanbul ignore next */
  constructor(trade: Trade = new Trade(undefined)) {
    super({
      holdingId: new FormControl(trade.holdingId, [Validators.required]),
      tradeType: new FormControl(trade.tradeType),
      usePriorTradeDate: new FormControl(trade.usePriorTradeDate, [Validators.required]),
      settlementDate: new FormControl(trade.settlementDate, [Validators.required]),
      transactionType: new FormControl(trade.transactionType, [Validators.required]),
      amount: new FormControl(trade.amount,
        [
          Validators.required, Validators.min(MIN_AMOUNT), Validators.max(MAX_AMOUNT),
          Validators.pattern(/^(?:\d{1,15})(?:\.\d{1,2})?$/)
        ])
    });
    this.trade = trade;
    this.usePriorTradeDate.setValue(this.setUsePriorTradeDate(trade.tradeDate));
  }

  get holdingId(): AbstractControl { return this.get('holdingId'); }
  get usePriorTradeDate(): AbstractControl { return this.get('usePriorTradeDate'); }
  get settlementDate(): AbstractControl { return this.get('settlementDate'); }
  get transactionType(): AbstractControl { return this.get('transactionType'); }
  get amount(): AbstractControl { return this.get('amount'); }

  get isSubmitDisabled(): boolean {
    return this.pristine || this.invalid || !FormUtils.isFormDirty(this, this.trade);
  }

  private setUsePriorTradeDate(tradeDate: string) {
    return this.trade.usePriorTradeDate = !moment(tradeDate).isSame(moment(), 'day');
  }

  getValidationError(formControlName: string): string {
    const errors = this.get(formControlName).errors;
    if (errors) {
      return errors.min ? `Must be >= $${errors.min.min}` :
        errors.max ? `Amount is too large` :
          errors.pattern ? 'Invalid Amount' :
            '';
    }
  }
}
