import { ManualTradeForm } from './manual-trade-form.model';
import { mockManualTrades } from '../mock-json';

describe('ManualTradeForm', () => {
  let tradeForm: ManualTradeForm;
  beforeEach(function () {
    tradeForm = new ManualTradeForm(mockManualTrades[0]);
  });

  describe('constructor', () => {
    it('should create a trade form', () => {
      expect(tradeForm).toBeDefined();
    });
  });

  describe('Control Getters', () => {
    formControlGetterTest('holdingId');
    formControlGetterTest('usePriorTradeDate');
    formControlGetterTest('settlementDate');
    formControlGetterTest('transactionType');
    formControlGetterTest('amount');
  });

  function formControlGetterTest(controlName: string) {
    it(`should create a control getter for ${controlName}`, () => {
      expect(tradeForm[controlName]).toEqual(tradeForm.get(controlName));
    });
  }

  describe('getValidationError', () => {
    it('should return message for amount minimum', () => {
      tradeForm.amount.setValue(-1);

      expect(tradeForm.getValidationError('amount')).toEqual('Must be >= $0.01');
    });

    it('should return message for amount maximum', () => {
      tradeForm.amount.setValue(100000000000000000);

      expect(tradeForm.getValidationError('amount')).toEqual('Amount is too large');
    });

    it('should return undefined when there are no validation errors', () => {
      expect(tradeForm.getValidationError('amount')).toEqual(undefined);
    });
  });

  describe('isSubmitDisabled', () => {
    it('should return true if trade form is pristine', () => {
      expect(tradeForm.isSubmitDisabled).toEqual(true);
    });

    it('should return true if trade form is invalid', () => {
      tradeForm.markAsDirty();
      tradeForm.amount.setValue(-1);
      tradeForm.updateValueAndValidity();

      expect(tradeForm.isSubmitDisabled).toEqual(true);
    });

    it('should return true if trade form controls are not dirty', () => {
      tradeForm.markAsDirty();

      expect(tradeForm.isSubmitDisabled).toEqual(true);
    });

    it('should return false if trade form is dirty', () => {
      tradeForm.markAsDirty();
      tradeForm.amount.setValue(mockManualTrades[0].amount + 1000);

      expect(tradeForm.isSubmitDisabled).toEqual(false);
    });
  });
});
