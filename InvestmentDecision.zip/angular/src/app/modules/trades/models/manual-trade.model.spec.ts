import { ACTION } from '@app/shared/models';

import { ManualTrade } from './manual-trade.model';
import { mockManualRuns } from './mock-json';
import { DateTimeUtils } from '@app/shared/utils';
import { InvestmentDecisionRun } from './run.model';

describe('ManualTrade', () => {
  let manualTrade: ManualTrade;
  let run: InvestmentDecisionRun;
  let actionsEnabledSpy: jasmine.Spy;
  beforeEach(function() {
    run = new InvestmentDecisionRun(mockManualRuns[0]);
    actionsEnabledSpy = spyOn(run, 'isActionsEnabled').and.returnValue(true);
  });

  it('should set run level info', () => {
    manualTrade = new ManualTrade(run);

    expect(manualTrade.runId).toBe(run.runId);
    expect(manualTrade.status).toBe(run.status);
  });

  it('should add RELEASE, EDIT, DELETE to allowed actions if actions are enabled', () => {
    manualTrade = new ManualTrade(run);

    manualTrade.actionOptions$.subscribe(
      actionOptions => {
        expect(actionOptions).toEqual([ACTION.RELEASE, ACTION.EDIT, ACTION.DELETE]);
      });
  });

  it('should not set allowed actions if disabled', () => {
    actionsEnabledSpy.and.returnValue(false);
    manualTrade = new ManualTrade(run);

    manualTrade.actionOptions$.subscribe(
      actionOptions => {
        expect(actionOptions).toEqual([]);
      });
  });
});
