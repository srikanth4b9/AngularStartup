import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TradesViewComponent, EditTradeViewComponent } from './views';

const routes: Routes = [
  {
    path: '',
    component: TradesViewComponent
  },
  {
    path: 'create',
    component: EditTradeViewComponent
  },
  {
    path: 'edit/:runId',
    component: EditTradeViewComponent
  }
];

@NgModule({
  declarations: [],
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TradesRoutingModule { }
