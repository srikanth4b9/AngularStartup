import { of } from 'rxjs';
import { mockInvestmentDecisionRuns, InvestmentDecisionRun } from '../models';
import { } from 'jasmine';

export class MockTradeService {
  investmentDecisionRuns$ = of(mockInvestmentDecisionRuns.map(run => new InvestmentDecisionRun(run)));
  getInvestmentDecisionRuns = jasmine.createSpy().and.callFake(() => this.investmentDecisionRuns$);
  saveManualTrade = jasmine.createSpy().and.returnValue(of({}));
  releaseTrades = jasmine.createSpy().and.returnValue(of({}));
  deleteTrades = jasmine.createSpy().and.returnValue(of({}));
  deleteManualTrades = jasmine.createSpy().and.returnValue(of({}));
  exportTradesReport = jasmine.createSpy().and.returnValue(of({}));
  recalculateTrades = jasmine.createSpy().and.returnValue(of({}));
}
