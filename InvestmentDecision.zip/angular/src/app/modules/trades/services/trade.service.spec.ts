import { TestBed } from '@angular/core/testing';
import { RestService } from '@app/services';
import { environment } from '@env';
import { of } from 'rxjs';

import { InvestmentDecisionRun, mockInvestmentDecisionRuns, mockManualRuns, mockSystemRuns } from '../models';
import { TradeService } from './trade.service';


class MockRestService {
  getData = jasmine.createSpy().and.returnValue(of(mockInvestmentDecisionRuns));
  postData = jasmine.createSpy().and.returnValue(of({}));
  putData = jasmine.createSpy().and.returnValue(of({}));
  deleteData = jasmine.createSpy().and.returnValue(of({}));
  exportData = jasmine.createSpy();
}

describe('TradeService', () => {
  let service: TradeService;
  let restService: MockRestService;
  let getRunsSpy: jasmine.Spy;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [{ provide: RestService, useClass: MockRestService }]
    });

    service = TestBed.get(TradeService);
    restService = TestBed.get(RestService);
    getRunsSpy = spyOn(service, 'getInvestmentDecisionRuns').and.callThrough();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('getInvestmentDecisionRuns:', () => {
    it('should call rest service to get the run data', () => {
      const expectedRuns = mockInvestmentDecisionRuns.map(run => new InvestmentDecisionRun(run));

      service.getInvestmentDecisionRuns();

      service.investmentDecisionRuns$.subscribe(data => {
        expect(data).toEqual(expectedRuns);
      });

      expect(restService.getData).toHaveBeenCalledWith(environment.INVESTMENT_DECISION_RUNS, 'Load Trades');
    });
  });

  describe('exportTradesReport:', () => {
    it('should call rest service to export the trades report', () => {
      const exportDate = '2018-12-17';
      const apiUrl = `${environment.INVESTMENT_DECISION_RUNS}?runDate=${exportDate}`;
      const fileName = `trades-${exportDate}`;

      service.exportTradesReport(exportDate);

      expect(restService.exportData).toHaveBeenCalledWith(apiUrl, fileName, 'Export Trades report');
    });
  });

  describe('createTrade:', () => {
    it('should call rest service to create a manual trade', () => {
      const manualRun: InvestmentDecisionRun = new InvestmentDecisionRun(mockSystemRuns[0]);

      service.saveManualTrade(manualRun, true);

      expect(restService.postData).toHaveBeenCalledWith(environment.INVESTMENT_DECISION_RUNS, manualRun, 'Create Manual Trade');
    });
  });

  describe('updateTrade:', () => {
    it('should call rest service to update a manual trade', () => {
      const run = mockInvestmentDecisionRuns[0];
      const trade = run.trades[0];

      service.saveManualTrade(run, false, run.runId);

      expect(restService.putData)
        .toHaveBeenCalledWith(`${environment.INVESTMENT_DECISION_RUNS}/${run.runId}${environment.TRADES}/${trade.holdingId}`,
          trade, 'Edit Manual Trade');
    });
  });

  describe('releaseTrades:', () => {
    it('should call rest service to release trades for given Run IDs', () => {
      const runIds = [...mockManualRuns.map(run => run.runId)];

      service.releaseTrades(runIds);

      expect(restService.putData)
        .toHaveBeenCalledWith(`${environment.INVESTMENT_DECISION_RUNS}?action=RELEASE`, runIds, 'Release Trades');
    });
  });

  describe('deleteManualTrades:', () => {
    it('should call rest service to delete a list of manual trades', () => {
      const runIds = mockManualRuns.map(run => run.runId);

      service.deleteManualTrades(runIds);

      expect(restService.deleteData)
        .toHaveBeenCalledWith(environment.INVESTMENT_DECISION_RUNS, runIds, 'Delete Manual Trades');
    });
  });

  describe('deleteTrades:', () => {
    it('should call rest service to delete a list of system trades', () => {
      const run = mockSystemRuns[0];
      const holdingIds = run.trades.map(trade => trade.holdingId);

      service.deleteTrades(run.runId, holdingIds);

      expect(restService.deleteData)
        .toHaveBeenCalledWith(`${environment.INVESTMENT_DECISION_RUNS}/${run.runId}${environment.TRADES}`,
          holdingIds, 'Delete Trades');
    });
  });

  describe('recalculateTrades:', () => {
    it('should call rest service to delete a list of system trades', () => {
      service.recalculateTrades();

      expect(restService.putData)
        .toHaveBeenCalledWith(`${environment.INVESTMENT_DECISION_RUNS}?action=RECALC`,
          null, 'Recalculate Trades');
      expect(getRunsSpy).toHaveBeenCalled();
    });
  });
});
