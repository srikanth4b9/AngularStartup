import { Injectable } from '@angular/core';
import { InvestmentDecisionRun } from '@app/modules/trades/models/run.model';
import { RestService } from '@app/services';
import { environment } from '@env';
import { BehaviorSubject, Observable, Subscription } from 'rxjs';
import { tap, map, finalize } from 'rxjs/operators';

import { Trade, ManualRunForm } from '../models';

@Injectable({
  providedIn: 'root'
})

export class TradeService {
  private runsSubject: BehaviorSubject<InvestmentDecisionRun[]> = new BehaviorSubject(undefined);
  investmentDecisionRuns$: Observable<InvestmentDecisionRun[]> = this.runsSubject.asObservable();

  constructor(private restService: RestService) { }

  getInvestmentDecisionRuns(): void {
    this.restService.getData<InvestmentDecisionRun[]>(environment.INVESTMENT_DECISION_RUNS, 'Load Trades')
      .pipe(
        map(runs => runs.map(run => new InvestmentDecisionRun(run))),
        tap(data => this.runsSubject.next(data))
      )
      .subscribe();
  }

  exportTradesReport(exportDate: string): Subscription {
    const apiUrl = `${environment.INVESTMENT_DECISION_RUNS}?runDate=${exportDate}`;
    const fileName = `trades-${exportDate}`;
    return this.restService.exportData(apiUrl, fileName, 'Export Trades report');
  }

  saveManualTrade(manualRun: InvestmentDecisionRun, isNewTrade: boolean, runId: number = null): Observable<any> {
    return isNewTrade ?
      this.createTrade(manualRun) :
      this.updateTrade(runId, manualRun.trades[0]);
  }

  private createTrade(manualRun: InvestmentDecisionRun): Observable<any> {
    return this.restService.postData<InvestmentDecisionRun>(environment.INVESTMENT_DECISION_RUNS, manualRun, 'Create Manual Trade');
  }

  private updateTrade(runId: number, trade: Trade): Observable<any> {
    return this.restService.putData<Trade>(
      `${environment.INVESTMENT_DECISION_RUNS}/${runId}${environment.TRADES}/${trade.holdingId}`,
      trade,
      'Edit Manual Trade');
  }

  releaseTrades(runIds: number[]): void {
    this.restService.putData<number[]>(
      `${environment.INVESTMENT_DECISION_RUNS}?action=RELEASE`,
      runIds,
      'Release Trades')
      .pipe(
        finalize(() => this.getInvestmentDecisionRuns())
      )
      .subscribe();
  }

  deleteManualTrades(runIds: number[]): void {
    this.restService.deleteData<number[]>(
      environment.INVESTMENT_DECISION_RUNS,
      runIds,
      'Delete Manual Trades')
      .pipe(
        finalize(() => this.getInvestmentDecisionRuns())
      )
      .subscribe();
  }

  deleteTrades(runId: number, holdingIds: number[]): void {
    this.restService.deleteData<number[]>(
      `${environment.INVESTMENT_DECISION_RUNS}/${runId}${environment.TRADES}`,
      holdingIds,
      'Delete Trades')
      .pipe(
        finalize(() => this.getInvestmentDecisionRuns())
      )
      .subscribe();
  }

  recalculateTrades(): void {
    this.restService.putData<InvestmentDecisionRun>(`${environment.INVESTMENT_DECISION_RUNS}?action=RECALC`,
      null, 'Recalculate Trades')
      .subscribe(() => this.getInvestmentDecisionRuns());
  }
}
