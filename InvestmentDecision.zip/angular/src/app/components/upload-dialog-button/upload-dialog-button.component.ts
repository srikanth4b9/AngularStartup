import { Component, OnInit, Input } from '@angular/core';
import { faFileUpload } from '@fortawesome/free-solid-svg-icons';
import { MatDialog } from '@angular/material';
import { UploadDialogComponent } from '../upload-dialog/upload-dialog.component';

@Component({
  selector: 'app-upload-dialog-button',
  templateUrl: './upload-dialog-button.component.html',
  styleUrls: ['./upload-dialog-button.component.scss']
})
export class UploadDialogButtonComponent implements OnInit {

  @Input() label: string;

  faFileUpload = faFileUpload;

  constructor(private dialog: MatDialog) { }

  ngOnInit() {
  }

  openUploadDialog() {
    this.dialog.open(UploadDialogComponent, {
      data: { type: 'manual-cash', title: 'Upload Manual Cash' }
    });
  }

}
