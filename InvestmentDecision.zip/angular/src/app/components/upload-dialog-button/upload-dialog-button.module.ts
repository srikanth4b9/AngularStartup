import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UploadDialogButtonComponent } from './upload-dialog-button.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { MatButtonModule, MatDialogModule } from '@angular/material';
import { UploadDialogModule } from '../upload-dialog/upload-dialog.module';

@NgModule({
  declarations: [UploadDialogButtonComponent],
  imports: [
    CommonModule,
    MatButtonModule,
    MatDialogModule,
    FontAwesomeModule,
    UploadDialogModule
  ],
  exports: [UploadDialogButtonComponent]
})
export class UploadDialogButtonModule { }
