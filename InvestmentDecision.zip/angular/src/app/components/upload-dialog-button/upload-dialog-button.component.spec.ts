import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatButtonModule, MatDialog, MatDialogModule } from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

import { UploadDialogComponent } from '../upload-dialog/upload-dialog.component';
import { UploadDialogButtonComponent } from './upload-dialog-button.component';

class MockDialog {
  open = jasmine.createSpy();
}

describe('UploadDialogButtonComponent', () => {
  let component: UploadDialogButtonComponent;
  let fixture: ComponentFixture<UploadDialogButtonComponent>;
  let dialog: MockDialog;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule,
        MatButtonModule,
        MatDialogModule,
        FontAwesomeModule
      ],
      declarations: [ UploadDialogButtonComponent ],
      providers: [
        { provide: MatDialog, useClass: MockDialog}
      ]
    })
    .compileComponents();

    dialog = TestBed.get(MatDialog);
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UploadDialogButtonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('openUploadDialog:', () => {
    it('should open the upload dialog component', () => {
      component.openUploadDialog();

      expect(dialog.open).toHaveBeenCalledWith(UploadDialogComponent, {
        data: { type: 'manual-cash', title: 'Upload Manual Cash' }
      });
    });
  });

});
