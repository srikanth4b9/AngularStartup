import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { SnackBarService } from '@app/services';
import { ExportDatePickerModule } from '@app/shared/components';

import { ExportDialogComponent } from './export-dialog.component';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';


describe('ExportDialogComponent', () => {
  let component: ExportDialogComponent;
  let fixture: ComponentFixture<ExportDialogComponent>;

  const mockDialogRef = {
    close: jasmine.createSpy()
  };

  const mockDialogData = {
    title: 'Dialog Title'
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule,
        MatDialogModule,
        ExportDatePickerModule
      ],
      declarations: [
        ExportDialogComponent
      ],
      providers: [
        { provide: MatDialogRef, useValue: mockDialogRef },
        { provide: MAT_DIALOG_DATA, useValue: mockDialogData }
      ]
    })
      .compileComponents();
  });

  function createComponent() {
    fixture = TestBed.createComponent(ExportDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  it('should create', () => {
    createComponent();

    expect(component).toBeTruthy();
    expect(component.title).toEqual(mockDialogData.title);
  });

  describe('close:', () => {
    it('should close the dialog', () => {
      createComponent();

      component.close();

      expect(mockDialogRef.close).toHaveBeenCalled();
    });
  });

  describe('export:', () => {
    it('should pass the export date and close the dialog', () => {
      const exportDate = '2018-12-17';
      createComponent();

      component.export(exportDate);

      expect(mockDialogRef.close).toHaveBeenCalledWith({ exportDate });
    });
  });
});
