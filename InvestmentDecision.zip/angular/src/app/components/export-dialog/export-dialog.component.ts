import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { faFileUpload, faTrash } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-export-dialog',
  templateUrl: './export-dialog.component.html',
  styleUrls: ['./export-dialog.component.scss']
})

export class ExportDialogComponent {
  currentDate = new Date();
  title: string;

  constructor(
    private dialogRef: MatDialogRef<ExportDialogComponent>,
    @Inject(MAT_DIALOG_DATA) data) {
    this.title = data.title;
  }

  close() {
    this.dialogRef.close();
  }

  export(exportDate: string): void {
    this.dialogRef.close({ exportDate });
  }
}
