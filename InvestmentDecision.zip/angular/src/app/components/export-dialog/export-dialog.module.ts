import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatDialogModule } from '@angular/material';
import { ExportDatePickerModule } from '@app/shared/components';

import { ExportDialogComponent } from './export-dialog.component';

@NgModule({
  imports: [
    CommonModule,
    MatDialogModule,
    ExportDatePickerModule
  ],
  declarations: [ExportDialogComponent],
  exports: [ExportDialogComponent]
})
export class ExportDialogModule { }
