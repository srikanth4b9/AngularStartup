import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDialogModule, MatButtonModule } from '@angular/material';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

import { UploadDialogComponent } from './upload-dialog.component';
import { RouterModule } from '@angular/router';
import { FileUploadModule } from 'ng2-file-upload';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    MatDialogModule,
    MatButtonModule,
    FontAwesomeModule,
    FileUploadModule
  ],
  declarations: [UploadDialogComponent],
  exports: [UploadDialogComponent]
})
export class UploadDialogModule { }
