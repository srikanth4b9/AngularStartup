import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatButtonModule, MatSnackBarModule } from '@angular/material';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { SnackBarService } from '@app/services';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { FileUploadModule } from 'ng2-file-upload';

import { UploadDialogComponent } from './upload-dialog.component';

class MockSnackBarService {
  success = jasmine.createSpy();
  error = jasmine.createSpy();
}

describe('UploadDialogComponent', () => {
  let component: UploadDialogComponent;
  let fixture: ComponentFixture<UploadDialogComponent>;
  let router: Router;
  let snackBarService: MockSnackBarService;

  const mockDialogRef = {
    close: jasmine.createSpy()
  };

  const mockDialogData = {
    type: 'Manual Cash',
    title: 'Dialog Title'
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        RouterTestingModule,
        MatDialogModule,
        MatButtonModule,
        FontAwesomeModule,
        MatSnackBarModule,
        FileUploadModule
      ],
      declarations: [
        UploadDialogComponent
      ],
      providers: [
        { provide: MatDialogRef, useValue: mockDialogRef },
        { provide: MAT_DIALOG_DATA, useValue: mockDialogData },
        { provide: SnackBarService, useClass: MockSnackBarService }
      ]
    })
      .compileComponents();

    router = TestBed.get(Router);
    snackBarService = TestBed.get(SnackBarService);
  });

  function createComponent() {
    fixture = TestBed.createComponent(UploadDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  it('should create', () => {
    createComponent();

    expect(component).toBeTruthy();
    expect(component.title).toEqual(mockDialogData.title);
    expect(component.type).toEqual(mockDialogData.type);
  });

  describe('close:', () => {
    it('should close the dialog', () => {
      createComponent();

      component.close();

      expect(mockDialogRef.close).toHaveBeenCalled();
    });
  });

  describe('onWhenAddingFileFailed:', () => {
    function testFileFailure(title: string, filterName: string, errorMessage: string) {
      it(title, () => {
        createComponent();

        component.onWhenAddingFileFailed({}, { name: filterName }, {});

        expect(snackBarService.error).toHaveBeenCalledWith(errorMessage);
      });
    }

    testFileFailure('should display snackbar error for exceeding maximum file size',
      'fileSize', 'Upload Error: File exceeds maximum file size of 1MB');
    testFileFailure('should display snackbar error for an invalid file type',
      'mimeType', 'Upload Error: File Type is Invalid');
    testFileFailure('should display a generic snackbar error for an unknown failure',
      'unknown', 'Upload Error');
  });

  describe('onCompleteItem:', () => {
    function testUploadComplete(title: string, status: number, spyMethod: string, message: string) {
      it(title, () => {
        spyOn(router, 'navigate');

        createComponent();

        component.onCompleteItem({}, '', status, {});

        expect(snackBarService[spyMethod]).toHaveBeenCalledWith(message);
      });
    }
    testUploadComplete('should display snackbar success when upload is successful with 200 status',
      200, 'success', 'Manual Cash Upload Completed');
    testUploadComplete('should display snackbar success when upload is successful with 201 status',
      201, 'success', 'Manual Cash Upload Completed');
    testUploadComplete('should display snackbar error when upload fails',
      403, 'error', 'Manual Cash Upload Failed');
  });
});
