import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

import { faTrash, faFileUpload } from '@fortawesome/free-solid-svg-icons';
import { environment } from '@env';
import { SnackBarService } from '@app/services';
import { HttpXsrfTokenExtractor } from '@angular/common/http';
import { Router } from '@angular/router';
import { FileUploader, Headers, FileUploaderOptions } from 'ng2-file-upload';

const BYTES_1024 = 1024;
const MAX_FILE_SIZE = 1 * BYTES_1024 * BYTES_1024;
const RESPONSE_OK = 200;
const RESPONSE_CREATED = 201;

@Component({
  selector: 'app-upload-dialog',
  templateUrl: './upload-dialog.component.html',
  styleUrls: ['./upload-dialog.component.scss']
})

export class UploadDialogComponent {
  type: string;
  title: string;
  uploader: FileUploader;
  private fileUploaderOptions: FileUploaderOptions = {
    url: `${environment.IXS_REST_BASE}${environment.MANUAL_CASH}`,
    headers: new Array<Headers>(),
    itemAlias: 'file0',
    queueLimit: 1,
    allowedMimeType: ['application/vnd.ms-excel'],
    maxFileSize: MAX_FILE_SIZE
  };

  faFileUpload = faFileUpload;
  faTrash = faTrash;

  constructor(
    private dialogRef: MatDialogRef<UploadDialogComponent>,
    private snackBarService: SnackBarService,
    private tokenExtractor: HttpXsrfTokenExtractor,
    private router: Router,
    @Inject(MAT_DIALOG_DATA) data) {
    this.type = data.type;
    this.title = data.title;
    this.fileUploaderOptions.headers.push({ name: 'X-XSRF-TOKEN', value: this.tokenExtractor.getToken() });
    this.uploader = new FileUploader(this.fileUploaderOptions);
    this.uploader.onCompleteItem = this.onCompleteItem.bind(this);
    this.uploader.onWhenAddingFileFailed = this.onWhenAddingFileFailed.bind(this);
  }

  close() {
    this.dialogRef.close();
  }

  onWhenAddingFileFailed(_item, filter: any, _options) {
    let errorMessage: string = 'Upload Error';
    if (filter.name === 'fileSize') {
      errorMessage += ': File exceeds maximum file size of 1MB';
    } else if (filter.name === 'mimeType') {
      errorMessage += ': File Type is Invalid';
    }
    this.snackBarService.error(errorMessage);
  }

  onCompleteItem(_item, _response, status: number, _headers) {
    if (status === RESPONSE_OK || status === RESPONSE_CREATED) {
      this.snackBarService.success('Manual Cash Upload Completed');
      this.router.navigate(['/reports/manual-cash']);
    } else {
      this.snackBarService.error('Manual Cash Upload Failed');
    }
    this.close();
  }
}
