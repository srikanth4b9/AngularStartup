import { Component, Input } from '@angular/core';
import { environment } from '@env';

@Component({
  selector: 'app-toolbar',
  templateUrl: './toolbar.component.html',
  styleUrls: ['./toolbar.component.scss']
})
export class AppToolbarComponent {
  @Input() mainContent: any;
  version = environment.VERSION;
}
