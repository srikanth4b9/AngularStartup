import {
  MdcButtonModule,
  MdcElevationModule,
  MdcIconModule,
  MdcMenuModule,
  MdcTopAppBarModule,
  MdcTypographyModule,
} from '@angular-mdc/web';
import { CommonModule } from '@angular/common';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';

import { AppToolbarComponent } from './toolbar.component';

describe('ToolbarComponent', () => {
  let component: AppToolbarComponent;
  let fixture: ComponentFixture<AppToolbarComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        CommonModule,
        RouterTestingModule,
        MdcTopAppBarModule,
        MdcButtonModule,
        MdcElevationModule,
        MdcIconModule,
        MdcTypographyModule,
        MdcMenuModule
      ],
      declarations: [AppToolbarComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AppToolbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
