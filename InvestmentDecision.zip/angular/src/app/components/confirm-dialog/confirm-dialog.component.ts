import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

import { faExclamationTriangle, IconDefinition } from '@fortawesome/free-solid-svg-icons';
import { ConfirmDialogModel } from '@app/shared/models';

@Component({
  selector: 'app-confirm-dialog',
  templateUrl: './confirm-dialog.component.html',
  styleUrls: ['./confirm-dialog.component.scss']
})
export class ConfirmDialogComponent {
  title: string;
  message: string;
  confirmButtonText: string;
  confirmButtonIcon: IconDefinition;

  faExclamationTriangle = faExclamationTriangle;

  constructor(
    private dialogRef: MatDialogRef<ConfirmDialogComponent>,
    @Inject(MAT_DIALOG_DATA) data: ConfirmDialogModel) {
    this.title = data.title;
    this.message = data.message;
    this.confirmButtonText = data.confirmButtonText;
    this.confirmButtonIcon = data.confirmButtonIcon;
  }

  close() {
    this.dialogRef.close();
  }

  confirm() {
    this.dialogRef.close('confirm');
  }
}
