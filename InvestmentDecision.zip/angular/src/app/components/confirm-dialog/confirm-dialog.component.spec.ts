import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatButtonModule } from '@angular/material';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { ConfirmDialogModel } from '@app/shared/models';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { VuiButtonModule } from 'vg-vui-ng/button';

import { ConfirmDialogComponent } from './confirm-dialog.component';
import { faShare } from '@fortawesome/free-solid-svg-icons';

describe('ConfirmDialogComponent', () => {
  let component: ConfirmDialogComponent;
  let fixture: ComponentFixture<ConfirmDialogComponent>;

  const mockDialogRef = {
    close: jasmine.createSpy()
  };

  const mockDialogData: ConfirmDialogModel = {
    title: 'Dialog Title',
    message: 'Dialog Message',
    confirmButtonText: 'Button Text',
    confirmButtonIcon: faShare
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        MatDialogModule,
        MatButtonModule,
        FontAwesomeModule,
        VuiButtonModule
      ],
      declarations: [
        ConfirmDialogComponent
      ],
      providers: [
        { provide: MatDialogRef, useValue: mockDialogRef },
        { provide: MAT_DIALOG_DATA, useValue: mockDialogData }
      ]
    });
  });

  function createComponent() {
    TestBed.compileComponents();
    fixture = TestBed.createComponent(ConfirmDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  it('should create', () => {
    createComponent();

    expect(component).toBeTruthy();
    expect(component.title).toEqual(mockDialogData.title);
    expect(component.message).toEqual(mockDialogData.message);
    expect(component.confirmButtonText).toEqual(mockDialogData.confirmButtonText);
    expect(component.confirmButtonIcon).toEqual(mockDialogData.confirmButtonIcon);
  });

  describe('close:', () => {
    it('should close the dialog', () => {
      createComponent();

      component.close();

      expect(mockDialogRef.close).toHaveBeenCalled();
    });
  });

  describe('confirm:', () => {
    it('should close the dialog with a confirm result', () => {
      createComponent();

      component.confirm();

      expect(mockDialogRef.close).toHaveBeenCalledWith('confirm');
    });
  });

});
