import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LoadingIndicatorService } from '@app/services';

import { LoadingIndicatorComponent } from './loading-indicator.component';

describe('LoadingIndicatorComponent', () => {
  let component: LoadingIndicatorComponent;
  let fixture: ComponentFixture<LoadingIndicatorComponent>;
  let loadingIndicatorService: LoadingIndicatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [LoadingIndicatorComponent],
      providers: [LoadingIndicatorService]
    }).compileComponents();

    loadingIndicatorService = TestBed.get(LoadingIndicatorService);
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoadingIndicatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set showLoadingIndicator to true when the service state changes', () => {
    loadingIndicatorService.showSpinner();
    expect(component.showLoadingIndicator).toBe(true);
  });

  it('should set showLoadingIndicator to false when the service state changes', () => {
    loadingIndicatorService.hideSpinner();
    expect(component.showLoadingIndicator).toBe(false);
  });
});
