import { Component, OnInit } from '@angular/core';
import { NavLink } from '@app/shared/models';

@Component({
  selector: 'app-tab-group',
  templateUrl: './tab-group.component.html',
  styleUrls: ['./tab-group.component.scss']
})
export class TabGroupComponent implements OnInit {

  navLinks: NavLink[] = [
    {path: '/trades', label: 'Trades'},
    {path: '/reports', label: 'Reports'},
    {path: '/fund-maintenance', label: 'Fund Master'},
    {path: '/security-master', label: 'Security Master'}
  ];

  constructor() { }

  ngOnInit() {
  }

}
