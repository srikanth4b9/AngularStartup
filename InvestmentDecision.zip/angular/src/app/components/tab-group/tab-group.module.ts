import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { TabGroupComponent } from './tab-group.component';
import { MatTabsModule } from '@angular/material/tabs';

@NgModule({
  declarations: [TabGroupComponent],
  imports: [
    CommonModule,
    RouterModule,
    MatTabsModule
  ],
  exports: [TabGroupComponent]
})
export class TabGroupComponentModule { }
