export * from './tab-group.module';
export * from './tab-group.component';
