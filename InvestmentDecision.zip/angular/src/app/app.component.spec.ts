import { MdcTypographyModule } from '@angular-mdc/web';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppToolbarComponentModule, LoadingIndicatorModule, TabGroupComponentModule } from '@app/components';

import { AppComponent } from './app.component';

describe('AppComponent', () => {
  const title = 'Investment Decision Application';
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        MdcTypographyModule,
        LoadingIndicatorModule,
        AppToolbarComponentModule,
        TabGroupComponentModule
      ],
      declarations: [AppComponent],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

  it('should render toolbar with app title', () => {
    const fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('.app-app-title').textContent).toContain(title);
  });
});
