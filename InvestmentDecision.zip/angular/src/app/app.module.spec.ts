import { AppModule } from './app.module';

describe('AppModule', () => {
    let appModule: AppModule;

    beforeEach(() => {
        appModule = new AppModule('investment-decision');
    });

    it('should create an instance', () => {
        expect(appModule).toBeTruthy();
    });
});
