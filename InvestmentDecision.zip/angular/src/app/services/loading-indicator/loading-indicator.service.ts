import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoadingIndicatorService {
  indicatorSubject = new BehaviorSubject<boolean>(false);

  constructor() {}

  showSpinner() {
    this.indicatorSubject.next(true);
  }

  hideSpinner() {
    this.indicatorSubject.next(false);
  }
}
