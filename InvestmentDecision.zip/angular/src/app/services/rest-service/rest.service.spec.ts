import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { PLATFORM_ID } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { mockFund5828 } from '@app/modules/fund-maintenance/models';
import { environment } from '@env';
import { mockInvestableCashReport } from '@reports/modules/investable-cash/models';
import { mockDirectives } from '@security-master/modules/directives/models';
import * as FileSaver from 'file-saver/FileSaver';

import { SnackBarService } from '../snack-bar';
import { RestService } from './rest.service';

class MockSnackBarService {
  success = jasmine.createSpy();
  error = jasmine.createSpy();
}

function getErrorMessage(title) {
  return `${title} Failed`;
}

describe('RestService', () => {
  let service: RestService;
  let httpMock: HttpTestingController;
  let snackBarService: SnackBarService;
  let path: string;
  let apiPath: string;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        RestService,
        { provide: SnackBarService, useClass: MockSnackBarService },
        { provide: PLATFORM_ID, useValue: 'browser' }
      ]
    });

    service = TestBed.get(RestService);
    httpMock = TestBed.get(HttpTestingController);
    snackBarService = TestBed.get(SnackBarService);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('getData', () => {
    beforeEach(() => {
      path = environment.INVESTABLE_CASH_REPORT;
      apiPath = `${environment.IXS_REST_BASE}${path}`;
    });

    it('should make an http request to get data', () => {
      service.getData(path, 'Investable cash report').subscribe(data => {
        expect(data).toEqual(mockInvestableCashReport);
      });

      const getDataMockCall = httpMock.expectOne(apiPath);
      expect(getDataMockCall.request.method).toBe('GET');
      getDataMockCall.flush(mockInvestableCashReport);
    });

    it('should default to GET Request if no title is defined', () => {
      service.getData(path).subscribe(res => {}, err => {});

      const getDataMockCall = httpMock.expectOne(apiPath);
      expect(getDataMockCall.request.method).toBe('GET');
      getDataMockCall.flush('invalid', { status: 400, statusText: 'Bad GET Request' });

      expect(snackBarService.error).toHaveBeenCalledWith('GET Request Failed');
    });

    it('should no nothing if rendered on the server', () => {
      (<any>service).platformId = 'server';
      service.getData(path, 'Investable cash report').subscribe(data => {
        expect(data).not.toBeDefined();
      });

      httpMock.expectNone(apiPath);

      expect(snackBarService.error).not.toHaveBeenCalled();
    });

    // it('should make an http request to get data and fail', () => {
    //   service.getData(path, 'Investable cash report').subscribe();
    //   const getDataMockCall = httpMock.expectOne(apiPath);
    //   expect(getDataMockCall.request.method).toBe('GET');
    //   getDataMockCall.flush(null, mockError);
    //   const errorMessage = getErrorMessage('Investable cash report');
    //   expect(snackBarService.error).toHaveBeenCalledWith(errorMessage);
    // });
  });

  describe('postData', () => {
    beforeEach(() => {
      path = environment.DIRECTIVES;
      apiPath = `${environment.IXS_REST_BASE}${path}`;
    });

    it('should make an http request to post data', () => {
      service.postData(path, {}, 'title').subscribe(data => {
        expect(data).toEqual(mockDirectives);
      });

      const postMockCall = httpMock.expectOne(apiPath);
      expect(postMockCall.request.method).toBe('POST');
      postMockCall.flush(mockDirectives);
    });

    it('should fail to make a post call', () => {
      service.postData(path, {}, 'title').subscribe(res => {}, err => {});

      const postMockCall = httpMock.expectOne(apiPath);
      expect(postMockCall.request.method).toBe('POST');
      postMockCall.flush(null, { status: 400, statusText: 'Bad POST Request' });
      const errorMessage = getErrorMessage('title');
      expect(snackBarService.error).toHaveBeenCalledWith(errorMessage);
    });
  });

  describe('putData', () => {
    beforeEach(() => {
      path = environment.DIRECTIVES;
      apiPath = `${environment.IXS_REST_BASE}${path}`;
    });

    it('should make an http request to update data using PUT', () => {
      service.putData(`${path}/61`, {}, 'title').subscribe(data => {
        expect(data).toEqual(mockDirectives);
      });

      const putMockCall = httpMock.expectOne(`${apiPath}/61`);
      expect(putMockCall.request.method).toBe('POST');
      putMockCall.flush(mockDirectives);
    });

    it('should fail to make a put call', () => {
      service.putData(path, {}, 'title').subscribe(res => {}, err => {});

      const putDataMockCall = httpMock.expectOne(apiPath);
      putDataMockCall.flush(null, { status: 400, statusText: 'Bad PUT Request' });
      const errorMessage = getErrorMessage('title');
      expect(snackBarService.error).toHaveBeenCalledWith(errorMessage);
    });
  });

  describe('deleteData', () => {
    beforeEach(() => {
      path = environment.FUND_PROFILES;
      apiPath = `${environment.IXS_REST_BASE}${path}`;
    });

    it('should make a http request to delete the data using DELETE', () => {
      service.deleteData(path, {}, 'title').subscribe(data => {
        expect(data).toEqual(mockFund5828);
      });

      const deleteMockCall = httpMock.expectOne(apiPath);
      expect(deleteMockCall.request.method).toBe('POST');
      deleteMockCall.flush(mockFund5828);
    });

    it('should fail to make a http request to delete the data using DELETE', () => {
      service.deleteData(path, {}, 'title').subscribe(res => {}, err => {});

      const deleteMockCall = httpMock.expectOne(apiPath);
      deleteMockCall.flush('invalid', { status: 400, statusText: 'Bad DELETE Request' });
      const errorMessage = getErrorMessage('title');
      expect(snackBarService.error).toHaveBeenCalledWith(errorMessage);
    });
  });

  describe('exportData', () => {
    const testDate = '2018-11-14';
    const fileName = `investable-cash-${testDate}`;
    beforeEach(() => {
      path = `${environment.FUND_PROFILES}?runDate=${testDate}`;
      apiPath = `${environment.IXS_REST_BASE}${path}`;
    });

    it('should make an http request to export data', () => {
      const saveAsSpy = spyOn(FileSaver, 'saveAs');
      service.exportData(path, fileName);

      const exportMockCall = httpMock.expectOne(apiPath);
      expect(exportMockCall.request.method).toBe('GET');
      expect(exportMockCall.request.responseType).toBe('text');
      exportMockCall.flush(mockInvestableCashReport);

      expect(saveAsSpy).toHaveBeenCalled();
    });

    it('should return an error message if export request fails', () => {
      service.exportData(path, fileName, 'Investable cash report');

      const exportMockCall = httpMock.expectOne(apiPath);
      exportMockCall.flush(null, { status: 400, statusText: 'Bad EXPORT Request' });

      expect(snackBarService.error).toHaveBeenCalledWith('Investable cash report Failed');
    });
  });

  describe('create Error Message', () => {
    it('create error Message from error Body', () => {
      const mockBody = { value: 'INVALID_PORT_ID' };
      const errorMessage = service.createErrorMessage('title', mockBody);
      expect(errorMessage).toBe('title Failed - Invalid port ID');
    });
  });
});
