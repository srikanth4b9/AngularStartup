import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { LoadingIndicatorService } from '@app/services/loading-indicator';
import { Observable } from 'rxjs';
import { finalize, map, retry } from 'rxjs/operators';

@Injectable()
export class HttpConfigInterceptor implements HttpInterceptor {
  constructor(
    private loadingService: LoadingIndicatorService) { }

  intercept(httpRequest: HttpRequest<any>, httpHandler: HttpHandler): Observable<HttpEvent<any>> {
    this.loadingService.showSpinner();

    const newRequest = httpRequest.clone({
      headers: httpRequest.headers.set('Cache-Control', 'no-cache')
    });

    return httpHandler.handle(newRequest).pipe(
      retry(1),
      map(response => {
        if (response instanceof HttpResponse) {
          response = response.clone({
            headers: response.headers.set('Access-Control-Allow-Origin', '*')
          });
        }
        return response;
      }),
      finalize(() => this.loadingService.hideSpinner())
    );
  }
}
