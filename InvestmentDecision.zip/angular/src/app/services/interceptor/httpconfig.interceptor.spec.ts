import { HTTP_INTERCEPTORS, HttpClient } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { RestService } from '@app/services';
import { LoadingIndicatorService } from '@app/services/loading-indicator';

import { HttpConfigInterceptor } from './httpconfig.interceptor';

class MockLoadingIndicatorService {
  showSpinner = jasmine.createSpy();
  hideSpinner = jasmine.createSpy();
}

describe('HttpConfigInterceptor', () => {
  let http: HttpClient;
  let httpMock: HttpTestingController;
  let loadingService: MockLoadingIndicatorService;

  const apiUrl = 'api/investable-cash';

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        RestService,
        { provide: HTTP_INTERCEPTORS, useClass: HttpConfigInterceptor, multi: true },
        { provide: LoadingIndicatorService, useClass: MockLoadingIndicatorService }
      ]
    });

    http = TestBed.get(HttpClient);
    httpMock = TestBed.get(HttpTestingController);
    loadingService = TestBed.get(LoadingIndicatorService);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should show & hide the loading indicator', () => {
    let response: any;
    let errResponse: any;

    http.get(apiUrl).subscribe(res => (response = res), err => (errResponse = err));

    expect(loadingService.showSpinner).toHaveBeenCalled();

    httpMock.expectOne(apiUrl).flush([{}]);

    expect(loadingService.hideSpinner).toHaveBeenCalled();
  });
});
