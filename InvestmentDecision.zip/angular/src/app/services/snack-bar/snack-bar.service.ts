import { Injectable, OnDestroy } from '@angular/core';
import { MatSnackBar, MatSnackBarConfig, MatSnackBarDismiss } from '@angular/material';
import { BehaviorSubject, Subject, Observable } from 'rxjs';
import { filter, tap, map, takeUntil, delay, take } from 'rxjs/operators';

export interface SnackBarQueueItem {
  message: string;
  beingDispatched: boolean;
  config?: MatSnackBarConfig;
}

export interface ErrorConfig {
  default: string;
  responseMessage: string;
}

@Injectable({
  providedIn: 'root'
})
export class SnackBarService {
  snackBarConfig: { [s: string]: MatSnackBarConfig; } = {
    success: { panelClass: 'success' },
    error: { panelClass: 'error' }
  };

  constructor(private readonly snackBar: MatSnackBar) { }

  public success(message: string) {
    this.showSnackbar(message, this.snackBarConfig.success);
  }

  public error(message: string) {
    this.showSnackbar(message, this.snackBarConfig.error);
  }

  private showSnackbar(message: string, config: MatSnackBarConfig) {
    this.snackBar.open(message, undefined, config);
  }
}
