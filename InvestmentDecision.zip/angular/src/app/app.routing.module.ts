import { NgModule } from '@angular/core';
import { Routes, RouterModule, PreloadAllModules } from '@angular/router';

const routes: Routes = [
  {
    path: 'trades',
    loadChildren: './modules/trades/trades.module#TradesModule'
  },
  {
    path: 'reports',
    loadChildren: './modules/reports/reports.module#ReportsModule'
  },
  {
    path: 'fund-maintenance',
    loadChildren: './modules/fund-maintenance/fund-maintenance.module#FundMaintenanceModule'
  },
  {
    path: 'security-master',
    loadChildren: './modules/security-master/security-master.module#SecurityMasterModule'
  },
  {
    path: '',
    redirectTo: 'trades',
    pathMatch: 'full'
  },
  {
    path: '**',
    redirectTo: 'trades',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    preloadingStrategy: PreloadAllModules,
    onSameUrlNavigation: 'reload'
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
