declare namespace Express {
  export interface Request {
    vgBaseHref?: string
    vgStaticPath?: string
  }
}
