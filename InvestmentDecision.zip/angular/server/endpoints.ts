/**
 * Add config to the endpoints array for each service your application uses
 */
const T_NUMBER = 'tXXXXX'; // Replace with your T-Number locally, Do not commit
const LOCAL_PORT = '8080';
const DOMAINS = {
  ON_PREM: {
    NON_PRD: `https://satapii.vanguard.com:1443`,
    NON_PRD_DCT: `https://satapii.vanguard.com:53443`,
    PRD: 'https://apii.vanguard.com'
  },
  AWS: {
    NON_PRD: 'https://satapii.cf.opst.c1.vanguard.com',
    PRD: 'https://apii.cf.opsp.c1.vanguard.com'
  }
};
const SERVICE_RTE_BASES = {
  DEFAULT: '/rs/cf',
  DCT: '/rs/cfv/global'
};
const SERVICE_NAME = 'investment-decision-webservice';
const SERVICE_RTES = {
  DCT: `${SERVICE_RTE_BASES.DCT}/${SERVICE_NAME}`,
  AWS: `${SERVICE_RTE_BASES.DEFAULT}/${SERVICE_NAME}`
};
const PRF_RTE = '-prfp';
const BASE_PATH = '/rs/ixs';

const LOCAL_URL = `http://${T_NUMBER}.vanguard.com:${LOCAL_PORT}${BASE_PATH}`;

const DCT_SAT_URL = `${DOMAINS.ON_PREM.NON_PRD_DCT}${SERVICE_RTES.DCT}${BASE_PATH}`;
const DCT_PRF_URL = `${DOMAINS.ON_PREM.NON_PRD_DCT}${SERVICE_RTES.DCT}${PRF_RTE}${BASE_PATH}`;
const DCT_PRD_URL = `${DOMAINS.ON_PREM.PRD}${SERVICE_RTES.DCT}${BASE_PATH}`;

const AWS_SAT_URL = `${DOMAINS.AWS.NON_PRD}${SERVICE_RTES.AWS}${BASE_PATH}`;
const AWS_PRF_URL = `${DOMAINS.AWS.NON_PRD}${SERVICE_RTES.AWS}${PRF_RTE}${BASE_PATH}`;
const AWS_PRD_URL = `${DOMAINS.AWS.PRD}${SERVICE_RTES.AWS}${BASE_PATH}`;

export const endpoints = [
  {
    name: 'IXS_REST_BASE',
    uri: 'api',
    local: DCT_SAT_URL, // Replace with LOCAL_URL to use local webservice
    regions: {
      'development': AWS_SAT_URL,
      'development-dct': DCT_SAT_URL,
      'test-dct': DCT_SAT_URL,
      'performance-dct': DCT_PRF_URL,
      'production-dct': DCT_PRD_URL,
      'test-us-east-1': AWS_SAT_URL,
      'performance-us-east-1': AWS_PRF_URL,
      'production-us-east-1': AWS_PRD_URL
    }
  }
];

export const devEnvMap = endpoints.reduce((acc, cur) => {
  return {
    ...acc,
    [cur.name]: cur.local
  };
}, {});

export const buildEnvMap = endpoints.reduce((acc, cur) => {
  return {
    ...acc,
    [cur.name]: cur.uri
  };
}, {});
