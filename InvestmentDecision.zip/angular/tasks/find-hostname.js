const os = require('os');

export function getHost() {
  const ipRegExp = /^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  const hostname = require('os').hostname().toLowerCase();
  if (ipRegExp.test(hostname)) {
    return hostname;
  }
  return `${hostname.split('.')[0]}.vanguard.com`;
}

export const HOSTNAME = getHost();
console.log(HOSTNAME);
