const { TEST_UNIT_COVERAGE_REPORT_DIRECTORY } = require('../environment-variables');
const path = require('path');
console.log(path.resolve(TEST_UNIT_COVERAGE_REPORT_DIRECTORY, 'lcov.info'));
