const portscanner = require("portscanner");
const _ = require("lodash");
const ENV = require("../environment-variables");
// http://crewhub.vanguard.com/rs/projects1/selenium/SitePages/allowedSaucelabs.aspx
// available ports: ​​1080, 2080, 3080, ..., 9080, 9081-9100
const PORT_RANGE_START = ENV.SAUCELABS.saucePortEnd;
const PORT_RANGE_END = ENV.SAUCELABS.saucePortStart;
const LOOPBACK_ADDRESS = "127.0.0.1";

async function isAvailable(port) {
  let status = await portscanner.checkPortStatus(port, LOOPBACK_ADDRESS);
  return status === "closed";
}

async function findAvailablePort() {
  let port = _.random(PORT_RANGE_START, PORT_RANGE_END);
  if (!(await isAvailable(port))) {
    await findAvailablePort();
  } else {
    console.log(port);
  }
}
findAvailablePort();
