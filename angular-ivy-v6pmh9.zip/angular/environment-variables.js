const os = require('os');
const path = require('path');

const PLATFORM = process.platform;
const PLAN_KEY = process.env.bamboo_shortPlanName || 'local';
const REPO_NAME = process.env.bamboo_repository_name || 'Rate Reset';
const PLATFORM_IS_WINDOWS = PLATFORM === 'win32';
const PLATFORM_IS_MAC = PLATFORM === 'darwin';
const NODE_ENV = getNodeEnv();
const ENVIRONMENT_IS_LOCAL = NODE_ENV === 'local';

const BAMBOO_AGENT_IS_AWS = process.env.bamboo_capability_aws_agent === 'true';

const NAME = `${REPO_NAME}-${PLAN_KEY}`;
const DOMAIN = 'vanguard.com';
const HOSTNAME = hostname();
const FALLBACK_PORT = 8080;
const PORT = process.env.PORT || FALLBACK_PORT;
const BASE_URL = `${HOSTNAME}:${PORT}`.toLowerCase();

const HTTP_PROXY =
  process.env.bamboo_http_proxy || 'http://np-proxy.np-vanguard.com:80';
const PROXY_BYPASS = '*.vanguard.com';
const CYPRESS_USERNAME = 'T1RXS01';
const CYPRESS_PASSWORD = 'Summer18';

const SAUCELABS = {
  sauceUser: process.env.bamboo_SAUCE_USERNAME || process.env.SAUCE_USERNAME, // Should never be hard coded, ENV vars only!
  sauceKey:
    process.env.bamboo_SAUCE_ACCESS_KEY_PASSWORD ||
    process.env.SAUCE_ACCESS_KEY, // See https://bitbucket.vanguard.com:8443/projects/CAA/repos/bamboo-saucelabs-cred-retriever-plugin/browse
  sauceHost: `dvlna088.${DOMAIN}`.toLowerCase(),
  sauceHostPort: '4444',
  sauceParentTunnel: 'VanguardRoot',
  saucePortStart: 9081,
  saucePortEnd: 9800,
  sauceBuild: process.env.bamboo_buildResultKey || `Local Run: ${HOSTNAME}`
};

const TEST_UNIT_COVERAGE_REPORT_DIRECTORY = path.join(
  __dirname,
  'reports',
  'coverage'
);
const TEST_UNIT_REPORT_DIRECTORY = path.join(__dirname, 'reports', 'tests');
const TEST_E2E_REPORT_FILE = 'reports/cucumber/report.json';
const TEST_E2E_REPORT_DIRECTORY = path.join(__dirname, 'reports', 'cucumber');
const REQUIREMENTS_EVIDENCE_FILE = path.join(
  __dirname,
  'reports',
  'cucumber',
  'requirements-evidence.html'
);

module.exports = {
  NODE_ENV,
  PLATFORM,
  NAME,
  HOSTNAME,
  DOMAIN,
  SAUCELABS,
  PORT,
  BASE_URL,
  HTTP_PROXY,
  PROXY_BYPASS,
  CYPRESS_USERNAME,
  CYPRESS_PASSWORD,
  ENVIRONMENT_IS_LOCAL,
  BAMBOO_AGENT_IS_AWS,
  TEST_UNIT_COVERAGE_REPORT_DIRECTORY,
  TEST_UNIT_REPORT_DIRECTORY,
  TEST_E2E_REPORT_FILE,
  TEST_E2E_REPORT_DIRECTORY,
  REQUIREMENTS_EVIDENCE_FILE
};

function getNodeEnv() {
  const NODE_ENV_VAR = (process.env.NODE_ENV || '').toLowerCase();
  if (!(NODE_ENV_VAR in { local: 1, bamboo: 1 })) {
    if (PLATFORM_IS_WINDOWS || PLATFORM_IS_MAC) {
      return 'local';
    }
    return 'bamboo';
  }
  return NODE_ENV_VAR;
}

function hostname() {
  let host = os.hostname();
  if (!BAMBOO_AGENT_IS_AWS && !host.toLowerCase().endsWith(DOMAIN)) {
    host += `.${DOMAIN}`;
  }
  return host.toLowerCase();
}
