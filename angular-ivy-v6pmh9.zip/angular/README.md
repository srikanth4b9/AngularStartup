# Rate Reset (RXU)

Rate Reset web application
- using [Angular](https://angular.io/) version 8.


## Getting started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes.

### Additional Documentation and Examples

Please read the [Angular Exemplar wiki](http://confluence.vanguard.com:8090/display/NGEXEMPLAR) for additional documentation and examples.

## Prerequisites

- Install [git](https://git-scm.com/) >= 2.9.3
- Install [node](https://nodejs.org/en/) >= 10.14
- Install [npm](https://www.npmjs.com/package/npm) >= 5.6.0
- Install [@angular/cli](https://github.com/angular/angular-cli/wiki) >= 8.0.2
- Configure [npm](https://www.npmjs.com/package/npm) (**Windows only**)
- Set saucelabs config variables
- Set Bitbucket default reviewers
- Install project dependencies
- Set local environment variables (optional)


## Install git

#### Windows

Request **GIT CLIENT - Version 2.93** or newer from [ServiceNow](https://vanguard.service-now.com/vanguard?id=vanguard_service_catalog)

#### OSX

Install the latest version of XCode from **Self Service.app** (XCode includes Git).

## Install node

#### Windows
Request **NODE.JS - Version 10.14** from [ServiceNow](https://vanguard.service-now.com/vanguard?id=vanguard_service_catalog)

#### OSX
Install the latest version of NodeJs from **Self Service.app**. (Must be v10.14 or greater)

## Install npm

Run the following from command line (iTerm, git-bash, cygwin)

```bash
npm install -g npm@6.1.0
```

## Install @angular/cli

Run the following from command line (iTerm, git-bash, cygwin)

```bash
npm install -g @angular/cli@^8.0.2
```

## Configure npm to execute scripts using bash (**Windows Only**)

set [script-shell](https://docs.npmjs.com/misc/config#script-shell) to bash (using git-bash or cygwin)

```bash
npm config set script-shell "C:\Program Files\Git\bin\bash.exe"     // replace with your bash path
```

## Configure Saucelabs

1. #### Get Saucelabs user settings

    - Sign in to [Saucelabs](http://saucelabs/)
    - Get [Saucelabs User Settings](https://saucelabs.com/beta/user-settings)

 2. #### Set bamboo environment variables

 3. #### Edit environment-variables.js with your favorite IDE

    Find the following constants in `environment-variables.js` and update the strings to match your saucelabs username and key.

    ```
    const SAUCELABS_USERNAME = process.env.SAUCELABS_USERNAME || 'sso-vanguard-firstname_lastname' // replace string with your team's perferred Saucelabs username
    const SAUCELABS_ACCESS_KEY = process.env.SAUCELABS_ACCESS_KEY || 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx' // replace string with your team's perferred Saucelabs user access key
    ```

## Set Bitbucket default reviewers

Open cloudproject.json in your favorite IDE and set your team's preferred default reviewers

```json
{
  "defaultReviewers": "uid1;uid2;uid3;" // replace with your team's preferred default reviewers
}
```

## Install project dependencies

```bash
npm install
```

## Set environment variables (optional)

The following environment variables can optionally be added to your `~/.bash_profile`, or `~/.bashrc` to override the defaults set in `environment-variables.js`

```bash
export NODE_ENV=local                                            // options: local, docker, bamboo
export HOSTNAME=txxxxx                                           // replace with your t-number
export SAUCELABS_USERNAME=sso-vanguard-firstname_lastname        // replace with your saucelabs username
export SAUCELABS_ACCESS_KEY=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx // replace with your saucelabs access key
export SAUCELABS_PORT_RANGE_START=8080
export SAUCELABS_PORT_RANGE_END=9080
```

## Developing

Available tasks

```bash
npm run lint              // lints code
npm run ng:serve          // serves ui in development mode
npm run serve:prod        // serves ui in production mode
npm run test              // runs unit tests and watches for changes
npm run test:coverage     // runs unit tests once with coverage reporting
npm run test:e2e          // runs e2e tests
```

## Building

Please read [node-webapp-build-plan.md](https://bitbucket.vanguard.com:8443/projects/CAA/repos/nga-bamboo-specs/browse/docs/build-plans/node-webapp-build-plan.md) for details on building the application on Bamboo.

## Deploying

Please read [common-deploy-plan.md](https://bitbucket.vanguard.com:8443/projects/CAA/repos/nga-bamboo-specs/browse/docs/deploy-plans/common-deploy-plan.md) for details on deploying the application on Bamboo.

## Built with

- [angular](https://angular.io/)
- [@angular/cli](https://github.com/angular/angular-cli/wiki)
- [@angular-mdc/web](https://trimox.github.io/angular-mdc-web)
- [angular universal](https://github.com/angular/universal)
- [cross-env](https://www.npmjs.com/package/cross-env)
- [express](http://expressjs.com/)
- [grunt](https://gruntjs.com/)
- [npm](https://www.npmjs.com/)
- [rxjs](https://github.com/ReactiveX/rxjs)
- [typescript](https://www.typescriptlang.org/)

## Maintainers

- [Julian Strothers](http://crewnet.vanguard.com/CrewNetPortal/CrewSearch?id=043953)
- [Scott W. Ayres](http://crewnet.vanguard.com/CrewNetPortal/CrewSearch?id=032777)
- [Uma Saketh Gorrepati ](http://crewnet.vanguard.com/CrewNetPortal/CrewSearch?id=066668)
- [Dinesh Easterline Kennedy](http://crewnet.vanguard.com/CrewNetPortal/CrewSearch?id=059100)
- [Julian Rios ](http://crewnet.vanguard.com/CrewNetPortal/CrewSearch?id=103711)
