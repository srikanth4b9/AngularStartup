import { Controller, Res, Req, All, Header } from '@nestjs/common';
import { Response } from 'express';
import { join } from 'path';
import { readFileSync } from 'fs';

@Controller()
export class ServerController {
  @All()
  @Header('Content-Type', 'text/html')
  root(@Req() request: any, @Res() response: Response) {
    response.send(
      readFileSync(join(__dirname, process.env.ANGULAR_ENV, 'index.html'), {
        encoding: 'utf8'
      })
        .replace(/{BASE_HREF}/, `${request.vgBaseHref}`)
        .replace(/{STATIC_PATH}/, `${request.vgStaticPath}`)
    );
  }
}
