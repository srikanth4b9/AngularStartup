import { TableDef } from './table-def.model';

describe('TableDef', () => {
  describe('constructor', () => {
    let tableDef: TableDef;

    it('should set hasActions to false by default', () => {
      tableDef = new TableDef();
      expect(tableDef.hasActions).toEqual(false);
    });
  });
});
