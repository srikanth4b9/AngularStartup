import { FormGroup } from '@angular/forms';

/* istanbul ignore next */
export abstract class CustomForm<T> extends FormGroup {
  object: T;
  isNew: boolean = true;

  abstract get objectName(): string;
  abstract get uri(): string;
  abstract get idAttribute(): string;
}
