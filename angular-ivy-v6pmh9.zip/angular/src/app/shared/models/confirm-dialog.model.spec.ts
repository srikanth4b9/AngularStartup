import { ConfirmDialogModel } from './confirm-dialog.model';
import { faShare } from '@fortawesome/free-solid-svg-icons';

describe('ConfirmDialogModel', () => {
  describe('constructor', () => {
    it('should set default parameters', () => {
      const model = new ConfirmDialogModel();

      expect(model.title).toEqual('Are You Sure?');
      expect(model.message).toEqual(null);
      expect(model.confirmButtonText).toEqual('OK');
    });

    it('should set dialog parameters', () => {
      const title = 'title';
      const message = 'message';
      const confirmButtonText = 'Confirm';
      const confirmButtonIcon = faShare;
      const model = new ConfirmDialogModel(title, message, confirmButtonText, confirmButtonIcon);

      expect(model.title).toEqual(title);
      expect(model.message).toEqual(message);
      expect(model.confirmButtonText).toEqual(confirmButtonText);
      expect(model.confirmButtonIcon).toEqual(confirmButtonIcon);
    });
  });
});
