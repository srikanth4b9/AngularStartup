import { ColumnDef } from './column-def.model';

export enum ACTION {
  EDIT = 'Edit',
  DEACTIVATE = 'Deactivate',
  REACTIVATE = 'Reactivate',
  APPROVE = 'Approve',
  REJECT = 'Reject',
  REVERT = 'Revert'
}

export class ActionRequest<T> {
  action: ACTION;
  object: T;

  constructor(action: ACTION, object: T) {
    this.action = action;
    this.object = object;
  }
}

export class UpdateRequest<T> extends ActionRequest<T> {
  path: string;
  objectName: string;

  constructor(actionRequest: ActionRequest<T>, path: string, objectName = '') {
    super(actionRequest.action, actionRequest.object);
    this.path = path;
    this.objectName = objectName;
  }
}

export class TableDef {
  columns: ColumnDef[];
  hasActions = false;

  constructor(columns: ColumnDef[] = [], hasActions = false) {
    this.columns = columns;
    this.hasActions = hasActions;
  }
}
