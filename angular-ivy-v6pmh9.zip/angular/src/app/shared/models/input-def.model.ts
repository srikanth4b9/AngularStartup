import { UpdateAction } from '@home/models';

export class InputDef {
  action: UpdateAction;
  overrideFlag?: string;

  constructor(action: UpdateAction, overrideFlag?: string) {
    this.action = action;
    this.overrideFlag = overrideFlag;
  }
}
