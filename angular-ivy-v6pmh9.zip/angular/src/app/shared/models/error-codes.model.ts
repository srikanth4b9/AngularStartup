export const ERROR_CODES = {
  MUST_BE_UNIQUE_ASSET_ID: 'Asset ID must be unique',
  MUST_BE_A_UNIQUE_ASSET_NAME: 'Asset Name must be unique',
  INVALID_AS_OF_DATE: 'As-Of Date is invalid',
  INVALID_EFFECTIVE_DATE: 'Effective Date is invalid',
  RATE_RESET_ALREADY_EXISTS: 'Rate reset already exists for the given Contract ID & Effective Date',
  INVALID_REQUEST_FOR_STANDARD_RATE_RESET: 'Invalid request for standard rate reset',
  INSURER_CANNOT_BE_DEACTIVATED_WITH_ACTIVE_CONTRACTS:
    'Insurer with active contracts cannot be deactivated',
  CANNOT_MODIFY_INACTIVE_CONTRACT: 'Deactivated contracts cannot be modified',
  CANNOT_DEACTIVATE_WHEN_RATE_RESET_IN_PROGRESS:
    'Contract cannot be deactivated when a rate reset is in progress',
  NT_CONTRACT_NOT_IN_ABOR: 'Contract does not exist in ABOR Hub',
  MUST_BE_UNIQUE_CONTRACT_ID:
    'Contract ID already exists. If this is a deactivated contract, please reactivate the existing contract instead.',
  MISSING_RATE_FREQUENCY: 'Contract Reset Frequency is missing',
  MISSING_RESET_START_DATE: 'Contract Reset Start Date is missing',
  MISSING_STABLE_VALUE_FUND: 'Contract Stable Value Fund is missing',
  OTHER_CONTRACT_FOUND_IN_ABOR:
    'Contract ID exists in ABOR Hub. Confirm if the Accounting Service Provider should be Northern Trust or choose a different Contract ID',
  OUTSIDE_PORT_ID_EXISTS_IN_EIP:
    'Stable Value Port ID exists in EIP. Confirm if the Accounting Service Provider should be Northern Trust or choose a different Port ID',
  OUTSIDE_FUND_NAME_EXISTS_IN_EIP:
    'Stable Value Fund Name exists in EIP. Confirm if the Accounting Service Provider should be Northern Trust or choose a different Fund Name',
  EXTERNAL_ASSET_ID_CANNOT_MATCH_INTERNAL_ID:
    'Asset exists in EIP. Confirm if this asset should be internal or choose a different Asset ID',
  INVALID_INTERNAL_ASSET: "Asset ID doesn't exist in EIP"
};
