export interface NavLink {
  path: string;
  label: string;
  disabled?: boolean;
}
