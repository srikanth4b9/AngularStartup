import { UpdateAction } from '@home/models';

import { InputDef } from './input-def.model';

export enum ColumnType {
  BOOLEAN,
  STRING,
  NUMBER,
  CURRENCY,
  PERCENT,
  DATE,
  WORKFLOW_TYPE,
  CONTRACT_ID,
  STATUS,
  SYSTEM_FILTERED_STRING,
  VIEW_CONTRACTS
}

export class ColumnDef {
  header: string;
  attribute: string;
  type: ColumnType;
  headerClass: string;
  align?: string;
  enumType?: any;
  violation?: Violation;
  formatter?: string;
  editable?: boolean;
  action?: UpdateAction;
  overrideFlag?: string;

  constructor(builder: ColumnDefBuilder) {
    this.header = builder._header;
    this.attribute = builder._attribute;
    this.type = builder._type;
    this.headerClass = builder._headerClass;
    this.align = builder._align;
    this.enumType = builder._enumType;
    this.violation = builder._violation;
    this.formatter = builder._formatter;
    this.editable = builder._editable;
    this.action = builder._action;
    this.overrideFlag = builder._overrideFlag;
  }
}

export class Violation {
  title: string;
  flag: string;
}

export class ColumnDefBuilder {
  _header: string;
  _attribute: string;
  _type: ColumnType;
  _headerClass = 'header-cell-text';
  _align = 'left';
  _enumType: any = null;
  _violation: Violation;
  _formatter: string;
  _editable = false;
  _action: UpdateAction;
  _overrideFlag: string;

  constructor(header: string, attribute: string, type: ColumnType) {
    this._header = header;
    this._attribute = attribute;
    this._type = type;

    if (
      [ColumnType.NUMBER, ColumnType.CURRENCY, ColumnType.PERCENT, ColumnType.BOOLEAN].indexOf(
        type
      ) !== -1
    ) {
      this._headerClass = 'header-cell-number';
      this._align = 'right';
    }
    if (type === ColumnType.PERCENT) {
      this._formatter = '1.3';
    }
    if (type === ColumnType.DATE) {
      this._formatter = 'MM/dd/yyyy';
    }
  }

  format(formatString: string): ColumnDefBuilder {
    this._formatter = formatString;
    return this;
  }

  editable(inputDef: InputDef): ColumnDefBuilder {
    this._editable = true;
    this._action = inputDef.action;
    this._overrideFlag = inputDef.overrideFlag;
    return this;
  }

  violationFlag(title, flag): ColumnDefBuilder {
    this._violation = { title, flag };
    return this;
  }

  build(): ColumnDef {
    return new ColumnDef(this);
  }
}
