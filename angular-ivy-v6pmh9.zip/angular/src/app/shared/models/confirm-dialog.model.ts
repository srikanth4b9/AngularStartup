import { IconDefinition } from '@fortawesome/free-solid-svg-icons';

const DEFAULT_CONFIRM_TITLE = 'Are You Sure?';

export class ConfirmDialogModel {
  title: string;
  message?: string;
  confirmButtonText?: string;
  confirmButtonIcon?: IconDefinition;

  constructor(title = DEFAULT_CONFIRM_TITLE, message = null, confirmButtonText = 'OK', confirmButtonIcon = null) {
    this.title = title;
    this.message = message;
    this.confirmButtonText = confirmButtonText;
    this.confirmButtonIcon = confirmButtonIcon;
  }
}

export const activeStatusConfirmDialogData: { [key: string]: ConfirmDialogModel } = {
  'Deactivate': {
    title: DEFAULT_CONFIRM_TITLE,
    confirmButtonText: 'Deactivate'
  },
  'Reactivate': {
    title: DEFAULT_CONFIRM_TITLE,
    confirmButtonText: 'Reactivate'
  }
};
