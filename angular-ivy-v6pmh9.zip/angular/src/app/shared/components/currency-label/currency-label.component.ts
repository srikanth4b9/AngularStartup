import { Component, Input } from '@angular/core';

@Component({
  selector: 'rxu-currency-label',
  templateUrl: './currency-label.component.html',
  styleUrls: ['./currency-label.component.scss']
})
export class CurrencyLabelComponent {
  @Input() inputValue: any;
}
