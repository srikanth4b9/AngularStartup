export * from './currency-label.component';
export * from './currency-label.module';
