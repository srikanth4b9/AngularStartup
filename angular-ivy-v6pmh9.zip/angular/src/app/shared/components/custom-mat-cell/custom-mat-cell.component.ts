import { Component, Input, OnChanges } from '@angular/core';
import { FormGroup } from '@angular/forms';
import {
  ResetStatusLabels,
  StatusBadgeClasses
} from '@app/modules/home/models';
import { ColumnDef, ColumnType } from '@app/shared/models';
import { WorkflowType } from '@maintenance/modules/contracts/models';
import {
  faChevronRight,
  IconDefinition
} from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'rxu-custom-mat-cell',
  templateUrl: './custom-mat-cell.component.html',
  styleUrls: ['./custom-mat-cell.component.scss']
})
export class CustomMatCellComponent implements OnChanges {
  @Input() column: ColumnDef;
  @Input() element: any;

  value: any;

  ColumnType = ColumnType;
  WorkflowType = WorkflowType;
  ResetStatus = ResetStatusLabels;
  StatusBadgeClasses = StatusBadgeClasses;
  faChevronRight: IconDefinition = faChevronRight;

  ngOnChanges() {
    this.value = this.isFormData
      ? this.element[this.column.attribute].value
      : this.element[this.column.attribute];
  }

  get isFormData() {
    return this.element instanceof FormGroup;
  }

  get hasDetailsView() {
    return (
      this.status !== 'NOT_CALCULATED' && this.workflowType !== 'ENTER_RATES'
    );
  }

  get status() {
    return this.isFormData
      ? this.element.resetStatus.value
      : this.element.status;
  }

  get workflowType() {
    return this.isFormData
      ? this.element.workflowType.value
      : this.element.workflowType;
  }
}
