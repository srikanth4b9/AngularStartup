import { MdcCheckboxModule } from '@angular-mdc/web';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { ColumnDefBuilder, ColumnType } from '@app/shared/models';
import { CustomCurrencyModule, SystemToBlankModule } from '@app/shared/pipes';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { RateReset, RateResetForm } from '@home/models';

import { CustomMatCellComponent } from './custom-mat-cell.component';

describe('CustomMatCellComponent', () => {
  let component: CustomMatCellComponent;
  let fixture: ComponentFixture<CustomMatCellComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        FormsModule,
        CustomCurrencyModule,
        MdcCheckboxModule,
        NoopAnimationsModule,
        SystemToBlankModule,
        FontAwesomeModule
      ],
      declarations: [CustomMatCellComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomMatCellComponent);
    component = fixture.componentInstance;
    component.element = new RateReset();
    component.column = new ColumnDefBuilder('Net Rate', 'netRate', ColumnType.PERCENT).build();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('isFormData:', () => {
    it('should equal false if element is not a form', () => {
      expect(component.isFormData).toEqual(false);
    });
    it('should equal true if element is a form', () => {
      component.element = new RateResetForm();
      expect(component.isFormData).toEqual(true);
    });
  });

  describe('hasDetailsView:', () => {
    it('should equal false if status is NOT_CALCULATED', () => {
      component.element.status = 'NOT_CALCULATED';
      expect(component.hasDetailsView).toEqual(false);
    });
    it('should equal false for a form if status is NOT_CALCULATED', () => {
      component.element = new RateResetForm();
      component.element.resetStatus.setValue('NOT_CALCULATED');
      expect(component.hasDetailsView).toEqual(false);
    });
    it('should equal true if status is anything other than NOT_CALCULATED', () => {
      component.element.status = 'PENDING';
      expect(component.hasDetailsView).toEqual(true);
    });
  });
});
