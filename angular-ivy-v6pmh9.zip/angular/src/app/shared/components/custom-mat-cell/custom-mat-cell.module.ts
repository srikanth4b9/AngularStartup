import { MdcCheckboxModule } from '@angular-mdc/web';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule, MatTooltipModule } from '@angular/material';
import { RouterModule } from '@angular/router';
import { CustomCurrencyModule, SystemToBlankModule } from '@app/shared/pipes';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

import { CustomMatCellComponent } from './custom-mat-cell.component';

@NgModule({
  declarations: [CustomMatCellComponent],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    CustomCurrencyModule,
    SystemToBlankModule,
    MdcCheckboxModule,
    MatButtonModule,
    MatTooltipModule,
    FontAwesomeModule
  ],
  exports: [CustomMatCellComponent]
})
export class CustomMatCellModule { }
