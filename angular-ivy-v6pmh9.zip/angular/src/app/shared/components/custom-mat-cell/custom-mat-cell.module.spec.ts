import { CustomMatCellModule } from './custom-mat-cell.module';

describe('CustomMatCellModule', () => {
    let customMatCellModule: CustomMatCellModule;

    beforeEach(() => {
        customMatCellModule = new CustomMatCellModule();
    });

    it('should create an instance', () => {
        expect(customMatCellModule).toBeTruthy();
    });
});
