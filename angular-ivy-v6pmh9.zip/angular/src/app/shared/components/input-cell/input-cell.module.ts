import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { CurrencyInputCellModule } from './currency-input-cell';
import { DateInputCellModule } from './date-input-cell';
import { InputCellComponent } from './input-cell.component';
import { NumberInputCellModule } from './number-input-cell';
import { PercentInputCellModule } from './percent-input-cell';

@NgModule({
  imports: [
    CommonModule,
    CurrencyInputCellModule,
    DateInputCellModule,
    NumberInputCellModule,
    PercentInputCellModule
  ],
  declarations: [InputCellComponent],
  exports: [InputCellComponent]
})
export class InputCellModule {}
