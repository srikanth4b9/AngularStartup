import { Component, EventEmitter, Input, OnChanges, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { AssetYieldDuration } from '@app/modules/maintenance/modules/yield-and-duration/models/yield-and-duration.model';
import { ColumnDef, ColumnType } from '@app/shared/models';
import { AttributeUpdateRequest, RateReset, RateResetForm } from '@home/models';

@Component({
  selector: 'rxu-input-cell',
  templateUrl: './input-cell.component.html',
  styleUrls: ['./input-cell.component.scss']
})
export class InputCellComponent implements OnChanges {
  @Input() parentForm: FormGroup;
  @Input() inputForm: FormGroup;
  @Input() column: ColumnDef;
  @Output() update: EventEmitter<
    AttributeUpdateRequest<RateReset | AssetYieldDuration>
  > = new EventEmitter();

  ColumnType = ColumnType;

  ngOnChanges() {
    if (!this.inputForm) {
      this.inputForm = this.parentForm;
    }
  }

  get isManualOverride(): boolean {
    return this.column.attribute === 'netRate'
      ? (this.inputForm as RateResetForm).workflowType.value !== 'ENTER_RATES' &&
          this.isOverrideFlagSet
      : this.isOverrideFlagSet;
  }

  private get isOverrideFlagSet() {
    const overrideFlag = this.column.overrideFlag;
    return overrideFlag ? this.inputForm[overrideFlag].value : false;
  }
}
