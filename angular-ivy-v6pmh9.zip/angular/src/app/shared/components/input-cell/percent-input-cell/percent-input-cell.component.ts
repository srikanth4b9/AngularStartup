import { Component } from '@angular/core';
import { FormUtils } from '@app/shared/utils';

import { AbstractInputCellComponent } from '../abstract-input-cell.component';

@Component({
  selector: 'rxu-percent-input-cell',
  templateUrl: './percent-input-cell.component.html',
  styleUrls: ['./percent-input-cell.component.scss']
})
export class PercentInputCellComponent extends AbstractInputCellComponent {
  protected updateValue(value): void {
    const oldValue = this.inputForm.value[this.column.attribute];
    const newValue = FormUtils.toPercentDecimalValue(value);
    if (newValue !== oldValue) {
      this.inputForm[this.column.attribute].setValue(newValue, {
        emitEvent: false
      });
      this.setOverrideFlag();
      this.emitUpdate();
    }
  }
}
