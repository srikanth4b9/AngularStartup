import { async, ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ColumnDefBuilder, ColumnType, InputDef } from '@app/shared/models';
import {
  AttributeUpdateRequest,
  mockRateResetList,
  RateReset,
  RateResetForm,
  UpdateAction
} from '@home/models';

import { PercentLabelModule } from '../../percent-label';
import { PercentInputCellComponent } from './percent-input-cell.component';

describe('PercentInputCellComponent', () => {
  let component: PercentInputCellComponent;
  let fixture: ComponentFixture<PercentInputCellComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PercentInputCellComponent],
      imports: [NoopAnimationsModule, ReactiveFormsModule, MatInputModule, PercentLabelModule]
    }).compileComponents();
  }));

  function createComponent() {
    fixture = TestBed.createComponent(PercentInputCellComponent);
    component = fixture.componentInstance;
    component.column = new ColumnDefBuilder('Net Rate', 'netRate', ColumnType.PERCENT)
      .editable(new InputDef(UpdateAction.NET_RATE, 'netRateOverride'))
      .build();
    component.parentForm = new RateResetForm(mockRateResetList[0]);
    component.inputForm = component.parentForm;
    fixture.detectChanges();
    component.ngOnChanges();
  }

  beforeEach(() => {
    createComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('valueChanges:', () => {
    it('should update override flag & emit update event', fakeAsync(() => {
      const value = 0.004503459;
      const expectedValue = 0.0045;
      const updateSpy = spyOn(component.update, 'emit');
      const expectedForm: RateResetForm = Object.assign(new RateResetForm(), component.parentForm);
      expectedForm.netRate.setValue(expectedValue);
      expectedForm.netRateOverride.setValue(true);
      const expectedRequest: AttributeUpdateRequest<RateReset> = {
        object: expectedForm.getRawValue(),
        action: component.column.action
      };

      (component.parentForm as RateResetForm).netRate.setValue(value);
      tick();
      fixture.detectChanges();

      expect(updateSpy).toHaveBeenCalledWith(expectedRequest);
    }));
  });
});
