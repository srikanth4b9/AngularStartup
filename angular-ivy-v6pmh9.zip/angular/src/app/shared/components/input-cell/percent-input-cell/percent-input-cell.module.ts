import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PercentInputCellComponent } from './percent-input-cell.component';
import { ReactiveFormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material';
import { PercentLabelModule } from '../../percent-label';

@NgModule({
  declarations: [PercentInputCellComponent],
  imports: [CommonModule, ReactiveFormsModule, MatInputModule, PercentLabelModule],
  exports: [PercentInputCellComponent]
})
export class PercentInputCellModule {}
