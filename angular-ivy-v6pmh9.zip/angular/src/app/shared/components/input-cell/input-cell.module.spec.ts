import { InputCellModule } from './input-cell.module';

describe('InputCellModule', () => {
    let inputCellModule: InputCellModule;

    beforeEach(() => {
        inputCellModule = new InputCellModule();
    });

    it('should create an instance', () => {
        expect(inputCellModule).toBeTruthy();
    });
});
