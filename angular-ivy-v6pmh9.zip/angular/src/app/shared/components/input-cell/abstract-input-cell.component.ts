import { EventEmitter, Input, OnChanges, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { ColumnDef } from '@app/shared/models';
import { FormUtils } from '@app/shared/utils';
import { RateResetForm, AttributeUpdateRequest } from '@home/models';

export abstract class AbstractInputCellComponent implements OnChanges {
  @Input() parentForm: FormGroup;
  @Input() inputForm: FormGroup;
  @Input() column: ColumnDef;
  @Output() update: EventEmitter<AttributeUpdateRequest<any>> = new EventEmitter();

  ngOnChanges() {
    if (this.isEditable) {
      this.setValueChanges();
    }
  }

  get isEditable(): boolean {
    switch (this.column.attribute) {
      case 'yield':
      case 'duration':
        return true;
      default:
        const form = this.parentForm as RateResetForm;
        return FormUtils.isNumberEditable(
          form.resetStatus.value,
          form.workflowType.value,
          this.column.attribute
        );
    }
  }

  protected abstract updateValue(value): void;

  protected setValueChanges() {
    this.inputForm[this.column.attribute].valueChanges.subscribe(value => this.updateValue(value));
  }

  protected setOverrideFlag(): void {
    const overrideFlag = this.column.overrideFlag;
    if (overrideFlag) {
      this.inputForm[overrideFlag].setValue(true);
    }
  }

  protected emitUpdate(): void {
    this.update.emit({
      object: this.parentForm.getRawValue(),
      action: this.column.action
    });
  }
}
