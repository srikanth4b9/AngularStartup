import { Component, ViewChild } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import {
  ContractAssetForm,
  mockContractAssets,
  mockRateResetList,
  RateResetForm,
  UpdateAction
} from '@home/models';
import { ColumnDef, ColumnDefBuilder, ColumnType, InputDef } from '@shared/models';

import { CurrencyInputCellModule } from './currency-input-cell';
import { DateInputCellModule } from './date-input-cell';
import { InputCellComponent } from './input-cell.component';
import { NumberInputCellModule } from './number-input-cell';
import { PercentInputCellModule } from './percent-input-cell';

let defaultColumn: ColumnDef = new ColumnDefBuilder('Net Rate', 'netRate', ColumnType.PERCENT)
  .editable(new InputDef(UpdateAction.NET_RATE))
  .build();

@Component({
  selector: `rxu-host-component`,
  template: `
    <rxu-input-cell [column]="column" [parentForm]="rateResetForm"> </rxu-input-cell>
  `
})
class TestHostComponent {
  @ViewChild(InputCellComponent, { static: true })
  public inputCellComponent: InputCellComponent;

  column = defaultColumn;
  rateResetForm = new RateResetForm(mockRateResetList[0]);
  contractAssetForm = new ContractAssetForm(mockContractAssets[0]);
}

describe('InputCellComponent', () => {
  // let component: InputCellComponent;
  // let fixture: ComponentFixture<InputCellComponent>;
  let testHostComponent: TestHostComponent;
  let testHostFixture: ComponentFixture<TestHostComponent>;
  // let inputElement: HTMLInputElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [InputCellComponent, TestHostComponent],
      imports: [
        NoopAnimationsModule,
        CurrencyInputCellModule,
        DateInputCellModule,
        NumberInputCellModule,
        PercentInputCellModule
      ]
    }).compileComponents();
  });

  function createTestHostComponent() {
    testHostFixture = TestBed.createComponent(TestHostComponent);
    testHostComponent = testHostFixture.componentInstance;
    testHostFixture.detectChanges();
    // inputElement = testHostFixture.nativeElement.querySelector('input');
  }

  it('should create', () => {
    createTestHostComponent();
    expect(testHostComponent).toBeTruthy();
  });

  // describe('isManualOverride:', () => {
  //   it('should return false for marketValue if override flag is not set', () => {
  //     column.attribute = 'marketValue';
  //     createComponent();

  //     expect(testHostComponent.inputCellComponent.isManualOverride).toEqual(false);
  //   });

  //   isManualOverrideTest('bookValue', 'bookValueOverride');

  //   it(`should return marketValueOverride flag for marketValue`, () => {
  //     column.attribute = 'marketValue';
  //     createComponent();

  //     expect(testHostComponent.inputCellComponent.isManualOverride)
  //       .toEqual(testHostComponent.inputCellComponent.contractAssetForm.marketValueOverride.value);
  //   });
  // });

  // function isManualOverrideTest(attribute: string, flag: string) {
  //   it(`should return ${flag} flag for ${attribute}`, () => {
  //     column.attribute = attribute;
  //     createComponent();

  //     expect(testHostComponent.inputCellComponent.isManualOverride)
  //       .toEqual(testHostComponent.inputCellComponent.rateResetForm[flag].value);
  //   });
  // }
});
