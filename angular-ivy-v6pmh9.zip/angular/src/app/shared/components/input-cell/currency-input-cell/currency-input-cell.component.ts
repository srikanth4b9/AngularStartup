import { Component } from '@angular/core';

import { AbstractInputCellComponent } from '../abstract-input-cell.component';

@Component({
  selector: 'rxu-currency-input-cell',
  templateUrl: './currency-input-cell.component.html',
  styleUrls: ['./currency-input-cell.component.scss']
})
export class CurrencyInputCellComponent extends AbstractInputCellComponent {
  protected updateValue(value): void {
    const oldValue = this.inputForm.value[this.column.attribute];
    if (value !== oldValue) {
      this.setOverrideFlag();
      this.emitUpdate();
    }
  }
}
