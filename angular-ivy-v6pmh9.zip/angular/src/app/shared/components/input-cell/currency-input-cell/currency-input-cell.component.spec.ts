import { async, ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import {
  AttributeUpdateRequest,
  mockRateResetList,
  RateReset,
  RateResetForm,
  UpdateAction
} from '@app/modules/home/models';
import { ColumnDefBuilder, ColumnType, InputDef } from '@app/shared/models';
import { CustomCurrencyModule } from '@app/shared/pipes';

import { CurrencyLabelModule } from '../../currency-label';
import { CurrencyInputCellComponent } from './currency-input-cell.component';

describe('CurrencyInputCellComponent', () => {
  let component: CurrencyInputCellComponent;
  let fixture: ComponentFixture<CurrencyInputCellComponent>;
  let mockRateReset: RateReset;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CurrencyInputCellComponent],
      imports: [
        NoopAnimationsModule,
        ReactiveFormsModule,
        MatInputModule,
        CurrencyLabelModule,
        CustomCurrencyModule
      ]
    }).compileComponents();

    mockRateReset = Object.assign({}, mockRateResetList[0]);
    mockRateReset.status = 'PENDING';
  }));

  function createComponent() {
    fixture = TestBed.createComponent(CurrencyInputCellComponent);
    component = fixture.componentInstance;
    component.column = new ColumnDefBuilder('Book Value', 'bookValue', ColumnType.CURRENCY)
      .editable(new InputDef(UpdateAction.BOOK_VALUE))
      .build();
    component.parentForm = new RateResetForm(mockRateReset);
    component.inputForm = component.parentForm;
    fixture.detectChanges();
    component.ngOnChanges();
  }

  beforeEach(() => {
    createComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('valueChanges:', () => {
    it('should update override flag & emit update event', fakeAsync(() => {
      const value = 543745660.01;
      const updateSpy = spyOn(component.update, 'emit');
      const expectedForm: RateResetForm = Object.assign(new RateResetForm(), component.parentForm);
      expectedForm.bookValue.setValue(value);
      const expectedRequest: AttributeUpdateRequest<RateReset> = {
        object: expectedForm.getRawValue(),
        action: component.column.action
      };

      (component.parentForm as RateResetForm).bookValue.setValue(value);
      tick();
      fixture.detectChanges();

      expect(updateSpy).toHaveBeenCalledWith(expectedRequest);
    }));
  });
});
