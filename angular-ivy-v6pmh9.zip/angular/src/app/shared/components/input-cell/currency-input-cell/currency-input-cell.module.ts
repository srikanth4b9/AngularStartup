import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material';
import { CurrencyLabelModule } from '../../currency-label';
import { CustomCurrencyModule } from '@app/shared/pipes';
import { CurrencyInputCellComponent } from './currency-input-cell.component';

@NgModule({
  declarations: [CurrencyInputCellComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatInputModule,
    CurrencyLabelModule,
    CustomCurrencyModule
  ],
  exports: [CurrencyInputCellComponent]
})
export class CurrencyInputCellModule {}
