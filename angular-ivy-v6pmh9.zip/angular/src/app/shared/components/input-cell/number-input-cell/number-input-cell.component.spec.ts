import { async, ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { AttributeUpdateRequest, UpdateAction } from '@app/modules/home/models';
import { mockYieldAndDuration } from '@app/modules/maintenance/modules/yield-and-duration/models/mock-json';
import { AssetYieldDurationForm } from '@app/modules/maintenance/modules/yield-and-duration/models/yield-and-duration-form.model';
import { AssetYieldDuration } from '@app/modules/maintenance/modules/yield-and-duration/models/yield-and-duration.model';
import { ColumnDefBuilder, ColumnType, InputDef } from '@app/shared/models';

import { NumberInputCellComponent } from './number-input-cell.component';

describe('NumberInputCellComponent', () => {
  let component: NumberInputCellComponent;
  let fixture: ComponentFixture<NumberInputCellComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [NumberInputCellComponent],
      imports: [NoopAnimationsModule, ReactiveFormsModule, MatInputModule]
    }).compileComponents();
  }));

  function createComponent() {
    fixture = TestBed.createComponent(NumberInputCellComponent);
    component = fixture.componentInstance;
    component.column = new ColumnDefBuilder('Duration', 'duration', ColumnType.NUMBER)
      .editable(new InputDef(UpdateAction.DURATION, 'durationOverride'))
      .build();
    component.parentForm = new AssetYieldDurationForm(mockYieldAndDuration[0]);
    component.inputForm = component.parentForm;
    fixture.detectChanges();
    component.ngOnChanges();
  }

  beforeEach(() => {
    createComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('valueChanges:', () => {
    it('should update override flag & emit update event', fakeAsync(() => {
      const value = 1.924083459;
      const expectedValue = 1.924;
      const updateSpy = spyOn(component.update, 'emit');
      const expectedForm: AssetYieldDurationForm = Object.assign(
        new AssetYieldDurationForm(),
        component.parentForm
      );
      expectedForm.duration.setValue(expectedValue);
      expectedForm.durationOverride.setValue(true);
      const expectedRequest: AttributeUpdateRequest<AssetYieldDuration> = {
        object: expectedForm.getRawValue(),
        action: component.column.action
      };

      (component.parentForm as AssetYieldDurationForm).duration.setValue(value);
      tick();
      fixture.detectChanges();

      expect(updateSpy).toHaveBeenCalledWith(expectedRequest);
    }));
  });
});
