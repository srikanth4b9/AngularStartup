import { Component } from '@angular/core';
import { FormUtils } from '@app/shared/utils';

import { AbstractInputCellComponent } from '../abstract-input-cell.component';

@Component({
  selector: 'rxu-number-input-cell',
  templateUrl: './number-input-cell.component.html',
  styleUrls: ['./number-input-cell.component.scss']
})
export class NumberInputCellComponent extends AbstractInputCellComponent {
  protected updateValue(value): void {
    const oldValue = this.inputForm.value[this.column.attribute];
    const newValue = FormUtils.toNumberDecimalValue(value);
    if (newValue !== oldValue) {
      this.inputForm[this.column.attribute].setValue(newValue, {
        emitEvent: false
      });
      this.setOverrideFlag();
      this.emitUpdate();
    }
  }
}
