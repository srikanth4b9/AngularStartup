import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material';

import { NumberInputCellComponent } from './number-input-cell.component';

@NgModule({
  declarations: [NumberInputCellComponent],
  imports: [CommonModule, ReactiveFormsModule, MatInputModule],
  exports: [NumberInputCellComponent]
})
export class NumberInputCellModule {}
