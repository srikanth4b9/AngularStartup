import { Component } from '@angular/core';
import { DateTimeUtils, FormUtils } from '@app/shared/utils';

import { AbstractInputCellComponent } from '../abstract-input-cell.component';
import { RateResetForm } from '@app/modules/home/models';

@Component({
  selector: 'rxu-date-input-cell',
  templateUrl: './date-input-cell.component.html',
  styleUrls: ['./date-input-cell.component.scss']
})
export class DateInputCellComponent extends AbstractInputCellComponent {
  get isEditable(): boolean {
    const form = this.parentForm as RateResetForm;
    return FormUtils.isDateEditable(
      form.resetStatus.value,
      form.rateResetProcessType.value,
      this.column.attribute
    );
  }

  protected updateValue(value): void {
    const oldValue = this.inputForm.value[this.column.attribute];
    if (value !== oldValue) {
      const newDate = DateTimeUtils.toISOString(value);
      this.inputForm[this.column.attribute].setValue(newDate, {
        emitEvent: false
      });
      this.emitUpdate();
    }
  }
}
