import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DateInputCellComponent } from './date-input-cell.component';
import { MatInputModule } from '@angular/material';
import { ReactiveFormsModule } from '@angular/forms';
import { CustomDatepickersModule } from '../../custom-datepickers';

@NgModule({
  declarations: [DateInputCellComponent],
  imports: [CommonModule, ReactiveFormsModule, MatInputModule, CustomDatepickersModule],
  exports: [DateInputCellComponent]
})
export class DateInputCellModule {}
