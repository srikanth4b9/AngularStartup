import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import {
  mockRateResetList,
  RateResetForm,
  UpdateAction,
  AttributeUpdateRequest,
  RateReset
} from '@app/modules/home/models';
import { ColumnDefBuilder, ColumnType, InputDef } from '@app/shared/models';

import { CustomDatepickersModule } from '../../custom-datepickers';
import { DateInputCellComponent } from './date-input-cell.component';
import moment = require('moment');

describe('DateInputCellComponent', () => {
  let component: DateInputCellComponent;
  let fixture: ComponentFixture<DateInputCellComponent>;
  let mockRateReset: RateReset;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [DateInputCellComponent],
      imports: [NoopAnimationsModule, ReactiveFormsModule, MatInputModule, CustomDatepickersModule]
    }).compileComponents();

    mockRateReset = Object.assign({}, mockRateResetList[0]);
    mockRateReset.rateResetProcessType = 'AD_HOC';
    mockRateReset.status = 'PENDING';
  }));

  function createComponent() {
    fixture = TestBed.createComponent(DateInputCellComponent);
    component = fixture.componentInstance;
    component.column = new ColumnDefBuilder('Effective Date', 'rateEffectiveDate', ColumnType.DATE)
      .editable(new InputDef(UpdateAction.EFFECTIVE_DATE))
      .build();
    component.parentForm = new RateResetForm(mockRateReset);
    component.inputForm = component.parentForm;
    fixture.detectChanges();
    component.ngOnChanges();
  }

  beforeEach(() => {
    createComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit update event', fakeAsync(() => {
    const value = moment.utc('2019-09-20T00:00:00.000Z');
    const expectedValue = '2019-09-20T00:00:00.000Z';
    const updateSpy = spyOn(component.update, 'emit');
    const expectedForm: RateResetForm = Object.assign(new RateResetForm(), component.inputForm);
    expectedForm.rateEffectiveDate.setValue(expectedValue, {
      emitEvent: false
    });
    const expectedRequest: AttributeUpdateRequest<RateReset> = {
      object: expectedForm.getRawValue(),
      action: component.column.action
    };

    (component.inputForm as RateResetForm).rateEffectiveDate.setValue(value);
    tick();
    fixture.detectChanges();

    expect(updateSpy).toHaveBeenCalledWith(expectedRequest);
  }));
});
