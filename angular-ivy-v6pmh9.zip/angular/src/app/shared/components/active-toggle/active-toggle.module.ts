import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActiveToggleComponent } from './active-toggle.component';
import { FormsModule } from '@angular/forms';
import { VuiSwitchModule } from 'vg-vui-ng/switch';

@NgModule({
  declarations: [ActiveToggleComponent],
  imports: [
    CommonModule,
    FormsModule,
    VuiSwitchModule
  ],
  exports: [ActiveToggleComponent]
})
export class ActiveToggleModule { }
