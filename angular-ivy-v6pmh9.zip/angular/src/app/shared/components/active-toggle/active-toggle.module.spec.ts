import { ActiveToggleModule } from './active-toggle.module';

describe('ActiveToggleModule', () => {
  let activeToggleModule: ActiveToggleModule;

  beforeEach(() => {
    activeToggleModule = new ActiveToggleModule();
  });

  it('should create an instance', () => {
    expect(activeToggleModule).toBeTruthy();
  });
});
