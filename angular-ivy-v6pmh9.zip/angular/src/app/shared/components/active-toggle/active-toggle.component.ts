import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'rxu-active-toggle',
  templateUrl: './active-toggle.component.html',
  styleUrls: ['./active-toggle.component.scss']
})
export class ActiveToggleComponent {
  @Input() id: string = 'active-toggle';
  @Input() isActive: boolean = true;
  @Output() isActiveChange: EventEmitter<boolean> = new EventEmitter();
}
