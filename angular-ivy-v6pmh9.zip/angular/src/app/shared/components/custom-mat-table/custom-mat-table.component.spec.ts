import { MdcCheckboxModule } from '@angular-mdc/web';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { MatSortModule, MatTableModule } from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { RateResetSummaryTableDef } from '@app/modules/home/models';
import { ACTION, ActionRequest, TableDef } from '@app/shared/models';
import { CustomCurrencyModule, SystemToBlankModule } from '@app/shared/pipes';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import {
  mockUnderlyingAssets,
  UnderlyingAssetTableDef
} from '@maintenance/modules/underlying-assets/models';

import { ActionSelectModule } from '../action-select';
import { CustomMatCellModule } from '../custom-mat-cell';
import { InputCellModule } from '../input-cell';
import { CustomMatTableComponent } from './custom-mat-table.component';

describe('CustomMatTableComponent', () => {
  let component: CustomMatTableComponent;
  let fixture: ComponentFixture<CustomMatTableComponent>;
  let setupTableDefSpy: jasmine.Spy;
  let setupTableDataSpy;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        FormsModule,
        CustomCurrencyModule,
        MatTableModule,
        MatSortModule,
        MdcCheckboxModule,
        NoopAnimationsModule,
        SystemToBlankModule,
        InputCellModule,
        CustomMatCellModule,
        FontAwesomeModule,
        ActionSelectModule
      ],
      declarations: [CustomMatTableComponent]
    }).compileComponents();
  });

  function createComponent(tableDef: TableDef = new RateResetSummaryTableDef()) {
    fixture = TestBed.createComponent(CustomMatTableComponent);
    component = fixture.componentInstance;
    component.tableDef = tableDef;
    setupTableDefSpy = spyOn(component, 'setupTableDef').and.callThrough();
    setupTableDataSpy = spyOn(component, 'setupTableData').and.callThrough();
    fixture.detectChanges();
  }

  it('should create', () => {
    createComponent();
    expect(component).toBeTruthy();
  });

  describe('ngOnInit:', () => {
    it('should setup table definition', () => {
      createComponent();

      component.ngOnInit();

      expect(setupTableDefSpy).toHaveBeenCalled();
    });
  });

  describe('ngOnChanges:', () => {
    it('should setup table data', () => {
      createComponent();

      component.ngOnChanges();

      expect(setupTableDataSpy).toHaveBeenCalled();
    });
  });

  describe('setupTableDef:', () => {
    let tableDef: UnderlyingAssetTableDef;
    beforeEach(function() {
      tableDef = new UnderlyingAssetTableDef();
    });

    it('should setup displayed columns by using the table definition', () => {
      const expectedColumns = [
        'assetId',
        'assetName',
        'expenseRatio',
        'isExternal',
        'crewUserId',
        'lastUpdatedTimestamp',
        'actions'
      ];
      createComponent(tableDef);

      component.setupTableDef();

      expect(component.displayedColumns).toEqual(expectedColumns);
    });

    it('should add actions to displayedColumns if table definition has actions', () => {
      createComponent(tableDef);

      component.setupTableDef();

      expect(component.displayedColumns).toContain('actions');
    });

    it('should not add actions to displayedColumns if table definition does not have actions', () => {
      tableDef = new TableDef([]);
      createComponent(tableDef);

      component.setupTableDef();

      expect(component.displayedColumns).not.toContain('actions');
    });
  });

  describe('setupTableData:', () => {
    beforeEach(function() {
      createComponent();
    });

    it('should setup material table data source', () => {
      component.tableData = mockUnderlyingAssets;
      component.setupTableData();

      expect(component.dataSource.data).toEqual(mockUnderlyingAssets);
      expect(component.dataSource.sort).toBeDefined();
    });

    it('should setup material table data source if there is no data', () => {
      component.tableData = [];
      component.setupTableData();

      expect(component.dataSource).toBeDefined();
    });

    it('should not setup material table data source if the data is undefined', () => {
      component.setupTableData();
      expect(component.dataSource).not.toBeDefined();
    });

    it('should not sort data source if the sort is unchanged', () => {
      const sortSpy = spyOn(component.sort, 'sort');
      component.sort.active = null;
      component.sort.direction = 'asc';
      component.tableData = mockUnderlyingAssets;

      component.setupTableData();

      expect(sortSpy).not.toHaveBeenCalled();
    });

    it('should apply active filter if active toggle should be applied', () => {
      component.applyActiveToggle = true;
      component.tableData = mockUnderlyingAssets;
      spyOn(component, 'applyActiveFilter');

      component.setupTableData();

      expect(component.dataSource.filterPredicate).toEqual(component.activeFilterPredicate);
      expect(component.applyActiveFilter).toHaveBeenCalled();
    });
  });

  describe('emitAction:', () => {
    it('should emit action event passing ActionRequest', () => {
      const action = ACTION.EDIT;
      const element = mockUnderlyingAssets[0];
      createComponent();
      component.tableDef = new RateResetSummaryTableDef();
      const actionSpy = spyOn(component.action, 'emit');

      component.emitAction(action, element);

      expect(actionSpy).toHaveBeenCalledWith(new ActionRequest(action, element));
    });
  });

  describe('activeFilterPredicate:', () => {
    let data;
    let filter: string;
    beforeEach(function() {
      data = { isActive: true };
    });

    it('should return true if filter is active', () => {
      createComponent();
      filter = 'true';
      component.setupTableData();

      expect(component.activeFilterPredicate(data, filter)).toEqual(true);
    });
    it('should return false if filter is inactive', () => {
      createComponent();
      filter = 'false';
      component.setupTableData();

      expect(component.activeFilterPredicate(data, filter)).toEqual(false);
    });
  });

  describe('apply Filter:', () => {
    it('should apply filter to table dataSource', () => {
      createComponent();
      component.tableData = mockUnderlyingAssets;
      component.setupTableData();

      component.applyActiveFilter();

      expect(component.dataSource.filter).toBe('true');
    });
  });
});
