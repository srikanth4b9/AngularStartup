import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  ViewChild
} from '@angular/core';
import { AbstractControl } from '@angular/forms';
import { MatSort, MatSortable, MatTableDataSource } from '@angular/material';
import { AssetYieldDuration } from '@app/modules/maintenance/modules/yield-and-duration/models/yield-and-duration.model';
import { ACTION, ActionRequest, TableDef } from '@app/shared/models/table-def.model';
import { faEdit, IconDefinition } from '@fortawesome/free-solid-svg-icons';
import { AttributeUpdateRequest, RateReset, RateResetSummaryTableDef } from '@home/models';

@Component({
  selector: 'rxu-custom-mat-table',
  templateUrl: './custom-mat-table.component.html',
  styleUrls: ['./custom-mat-table.component.scss']
})
export class CustomMatTableComponent implements OnInit, OnChanges {
  @Input() tableDef: TableDef = new TableDef([]);
  @Input() tableData: Array<any>;
  @Input() sortBy: MatSortable = { id: null, start: 'desc', disableClear: false };
  @Input() applyActiveToggle: boolean = false;
  @Input() activeToggle: boolean = true;
  @Output() loadData: EventEmitter<null> = new EventEmitter<null>(true);
  @Output() recalculate: EventEmitter<
    AttributeUpdateRequest<RateReset | AssetYieldDuration>
  > = new EventEmitter();
  @Output() action: EventEmitter<ActionRequest<any>> = new EventEmitter();

  displayedColumns: string[];
  dataSource: MatTableDataSource<any>;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  faEdit: IconDefinition = faEdit;

  ngOnInit() {
    this.setupTableDef();
  }

  ngOnChanges() {
    this.setupTableData();
  }

  setupTableDef(): void {
    this.displayedColumns = this.tableDef.columns.map(def => def.attribute);

    if (this.tableDef.hasActions) {
      this.displayedColumns.push('actions');
    }
  }

  setupTableData(): void {
    if (this.tableData) {
      this.dataSource = new MatTableDataSource(this.tableData);

      this.dataSource.sortingDataAccessor = (data: any, sortHeaderId: string) => {
        const dataValue = data[sortHeaderId];
        return dataValue instanceof AbstractControl ? dataValue.value : dataValue;
      };
      this.dataSource.sort = this.sort;

      const currentSortState = JSON.stringify({
        id: this.sort.active,
        direction: this.sort.direction
      });
      const defaultSortState = JSON.stringify({ id: this.sortBy.id, direction: this.sort.start });
      if (currentSortState !== defaultSortState) {
        this.sort.sort(this.sortBy);
      }

      if (this.applyActiveToggle) {
        this.dataSource.filterPredicate = this.activeFilterPredicate;
        this.applyActiveFilter();
      }
    }
  }

  activeFilterPredicate(data: any, filter: string): boolean {
    return data.isActive.toString() === filter;
  }

  applyActiveFilter() {
    this.dataSource.filter = this.activeToggle.toString();
  }

  emitAction(action: ACTION, element: any) {
    this.action.emit(new ActionRequest(action, element));
  }

  get isRateResetTable() {
    return this.tableDef instanceof RateResetSummaryTableDef;
  }
}
