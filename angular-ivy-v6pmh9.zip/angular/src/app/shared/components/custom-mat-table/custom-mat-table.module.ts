import { MdcCheckboxModule } from '@angular-mdc/web';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule, MatSortModule, MatTableModule, MatTooltipModule } from '@angular/material';
import { RouterModule } from '@angular/router';
import { CustomCurrencyModule, SystemToBlankModule } from '@app/shared/pipes';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

import { ActionSelectModule } from '../action-select';
import { CustomMatCellModule } from '../custom-mat-cell';
import { InputCellModule } from '../input-cell';
import { CustomMatTableComponent } from './custom-mat-table.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    CustomCurrencyModule,
    MatButtonModule,
    MatTableModule,
    MatSortModule,
    MdcCheckboxModule,
    MatTooltipModule,
    SystemToBlankModule,
    RouterModule,
    InputCellModule,
    CustomMatCellModule,
    FontAwesomeModule,
    ActionSelectModule
  ],
  declarations: [CustomMatTableComponent],
  exports: [CustomMatTableComponent]
})
export class CustomMatTableModule { }
