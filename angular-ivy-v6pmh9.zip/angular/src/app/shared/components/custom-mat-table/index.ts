export * from './custom-mat-table.component';
export * from './custom-mat-table.module';
