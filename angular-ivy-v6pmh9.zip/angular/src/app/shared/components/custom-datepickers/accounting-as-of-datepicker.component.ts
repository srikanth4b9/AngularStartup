import { Component } from '@angular/core';
import { CustomDatepickerComponent } from './custom-datepicker.component';
import * as moment from 'moment';
type Moment = moment.Moment;

@Component({
  selector: 'rxu-accounting-as-of-datepicker',
  templateUrl: './custom-datepicker.component.html',
  styleUrls: ['./custom-datepicker.component.scss']
})
export class AccountingAsOfDatepickerComponent extends CustomDatepickerComponent {
  controlName = 'accountingAsOfDate';
  placeholder = 'Accounting As Of Date';

  dateFilter(datepickerMoment: Moment): boolean {
    const currentMoment: Moment = moment();
    return datepickerMoment.isSameOrBefore(currentMoment, 'day');
  }
}
