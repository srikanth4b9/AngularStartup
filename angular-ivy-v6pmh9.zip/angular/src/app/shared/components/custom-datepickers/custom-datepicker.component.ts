import { Input } from '@angular/core';
import { RateResetForm } from '@app/modules/home/models';
import { Moment } from 'moment';

export abstract class CustomDatepickerComponent {
  @Input() parentForm: RateResetForm;

  abstract dateFilter(datepickerMoment: Moment): boolean;

}
