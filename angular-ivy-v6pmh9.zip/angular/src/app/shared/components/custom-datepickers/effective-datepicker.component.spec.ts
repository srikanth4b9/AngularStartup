import { Component } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { MatDatepickerModule, MatInputModule } from '@angular/material';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RateResetForm } from '@app/modules/home/models';
import * as moment from 'moment';

import { EffectiveDatepickerComponent } from './effective-datepicker.component';

@Component({
  selector: `rxu-host-component`,
  template: `<rxu-effective-datepicker [parentForm]="parentForm"></rxu-effective-datepicker>`
})
class TestHostComponent {
  parentForm: RateResetForm = new RateResetForm();
}

describe('EffectiveDatepickerComponent', () => {
  let testHostComponent: TestHostComponent;
  let testHostFixture: ComponentFixture<TestHostComponent>;
  let component: EffectiveDatepickerComponent;
  let fixture: ComponentFixture<EffectiveDatepickerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [EffectiveDatepickerComponent, TestHostComponent],
      imports: [
        NoopAnimationsModule,
        ReactiveFormsModule,
        MatDatepickerModule,
        MatMomentDateModule,
        MatInputModule
      ]
    })
      .compileComponents();
  }));

  function createComponent() {
    fixture = TestBed.createComponent(EffectiveDatepickerComponent);
    component = fixture.componentInstance;
    component.parentForm = new RateResetForm();
    fixture.detectChanges();
  }

  function createTestHostComponent() {
    testHostFixture = TestBed.createComponent(TestHostComponent);
    testHostComponent = testHostFixture.componentInstance;
    testHostFixture.detectChanges();
  }

  it('should create', () => {
    createTestHostComponent();
    expect(testHostComponent).toBeTruthy();
  });

  describe('dateFilter:', () => {
    beforeEach(function() {
      createComponent();
    });

    it('should return false if date is before current date', () => {
      expect(component.dateFilter(moment().subtract(1, 'days'))).toEqual(false);
    });

    it('should return false if date is more than 60 days away', () => {
      expect(component.dateFilter(moment().add(61, 'days'))).toEqual(false);
    });

    it('should return true if date is within the valid range', () => {
      expect(component.dateFilter(moment())).toEqual(true);
    });
  });
});
