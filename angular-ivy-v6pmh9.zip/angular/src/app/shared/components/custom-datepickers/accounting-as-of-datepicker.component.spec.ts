import { Component } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { MatDatepickerModule, MatInputModule } from '@angular/material';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RateResetForm } from '@app/modules/home/models';
import * as moment from 'moment';

import { AccountingAsOfDatepickerComponent } from './accounting-as-of-datepicker.component';

@Component({
  selector: `rxu-host-component`,
  template: `<rxu-accounting-as-of-datepicker [parentForm]="parentForm"></rxu-accounting-as-of-datepicker>`
})
class TestHostComponent {
  parentForm: RateResetForm = new RateResetForm();
}

describe('AccountingAsOfDatepickerComponent', () => {
  let testHostComponent: TestHostComponent;
  let testHostFixture: ComponentFixture<TestHostComponent>;
  let component: AccountingAsOfDatepickerComponent;
  let fixture: ComponentFixture<AccountingAsOfDatepickerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AccountingAsOfDatepickerComponent, TestHostComponent],
      imports: [
        NoopAnimationsModule,
        ReactiveFormsModule,
        MatDatepickerModule,
        MatMomentDateModule,
        MatInputModule
      ]
    })
      .compileComponents();
  }));

  function createComponent() {
    fixture = TestBed.createComponent(AccountingAsOfDatepickerComponent);
    component = fixture.componentInstance;
    component.parentForm = new RateResetForm();
    fixture.detectChanges();
  }

  function createTestHostComponent() {
    testHostFixture = TestBed.createComponent(TestHostComponent);
    testHostComponent = testHostFixture.componentInstance;
    testHostFixture.detectChanges();
  }

  it('should create', () => {
    createTestHostComponent();
    expect(testHostComponent).toBeTruthy();
  });

  describe('dateFilter:', () => {
    beforeEach(function () {
      createComponent();
    });

    it('should return false if date is after current date', () => {
      expect(component.dateFilter(moment().add(1, 'days'))).toEqual(false);
    });

    it('should return true if date is on current date', () => {
      expect(component.dateFilter(moment())).toEqual(true);
    });

    it('should return true if date is before current date', () => {
      expect(component.dateFilter(moment().subtract(1, 'days'))).toEqual(true);
    });
  });
});
