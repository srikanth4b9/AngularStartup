import { Component } from '@angular/core';
import { CustomDatepickerComponent } from './custom-datepicker.component';
import * as moment from 'moment';
type Moment = moment.Moment;

const MAX_DAYS = 60;

@Component({
  selector: 'rxu-effective-datepicker',
  templateUrl: './custom-datepicker.component.html',
  styleUrls: ['./custom-datepicker.component.scss']
})
export class EffectiveDatepickerComponent extends CustomDatepickerComponent {
  controlName = 'rateEffectiveDate';
  placeholder = 'Effective Date';

  dateFilter(datepickerMoment: Moment): boolean {
    const currentMoment: Moment = moment();
    const isCurrentDateMin = datepickerMoment.isSameOrAfter(
      currentMoment,
      'day'
    );
    const is60DayMax = datepickerMoment.isSameOrBefore(
      currentMoment.add(MAX_DAYS, 'days'),
      'day'
    );

    return isCurrentDateMin && is60DayMax;
  }
}
