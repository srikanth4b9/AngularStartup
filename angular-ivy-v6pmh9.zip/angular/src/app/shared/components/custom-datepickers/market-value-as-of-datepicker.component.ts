import { Component } from '@angular/core';
import { CustomDatepickerComponent } from './custom-datepicker.component';
import * as moment from 'moment';
type Moment = moment.Moment;

const SUNDAY = 0;
const SATURDAY = 6;

@Component({
  selector: 'rxu-market-value-as-of-datepicker',
  templateUrl: './custom-datepicker.component.html',
  styleUrls: ['./custom-datepicker.component.scss']
})
export class MarketValueAsOfDatepickerComponent extends CustomDatepickerComponent {
  controlName = 'marketValueAsOfDate';
  placeholder = 'Market Value As Of Date';

  dateFilter(datepickerMoment: Moment): boolean {
    const day = datepickerMoment.day();
    // Prevent Saturday and Sunday from being selected.
    const isWeekday: boolean = day !== SUNDAY && day !== SATURDAY;
    return isWeekday && this.asOfDateFilter(datepickerMoment);
  }

  private asOfDateFilter(datepickerMoment: Moment): boolean {
    const currentMoment: Moment = moment();
    return datepickerMoment.isSameOrBefore(currentMoment, 'day');
  }
}
