import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatDatepickerModule, MatInputModule } from '@angular/material';
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MatMomentDateModule } from '@angular/material-moment-adapter';

import { AccountingAsOfDatepickerComponent } from './accounting-as-of-datepicker.component';
import { EffectiveDatepickerComponent } from './effective-datepicker.component';
import { MarketValueAsOfDatepickerComponent } from './market-value-as-of-datepicker.component';

@NgModule({
  declarations: [
    EffectiveDatepickerComponent,
    AccountingAsOfDatepickerComponent,
    MarketValueAsOfDatepickerComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatDatepickerModule,
    MatMomentDateModule,
    MatInputModule
  ],
  providers: [
    { provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: { useUtc: true } }
  ],
  exports: [
    EffectiveDatepickerComponent,
    AccountingAsOfDatepickerComponent,
    MarketValueAsOfDatepickerComponent
  ]
})
export class CustomDatepickersModule { }
