import { CustomDatepickersModule } from './custom-datepicker.module';

describe('CustomDatepickersModule', () => {
    let customDatepickersModule: CustomDatepickersModule;

    beforeEach(() => {
        customDatepickersModule = new CustomDatepickersModule();
    });

    it('should create an instance', () => {
        expect(customDatepickersModule).toBeTruthy();
    });
});
