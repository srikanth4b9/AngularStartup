import { Component } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { MatDatepickerModule, MatInputModule } from '@angular/material';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RateResetForm } from '@app/modules/home/models';
import * as moment from 'moment';

import { MarketValueAsOfDatepickerComponent } from './market-value-as-of-datepicker.component';

@Component({
  selector: `rxu-host-component`,
  template: `<rxu-market-value-as-of-datepicker [parentForm]="parentForm"></rxu-market-value-as-of-datepicker>`
})
class TestHostComponent {
  parentForm: RateResetForm = new RateResetForm();
}

describe('MarketValueAsOfDatepickerComponent', () => {
  let testHostComponent: TestHostComponent;
  let testHostFixture: ComponentFixture<TestHostComponent>;
  let component: MarketValueAsOfDatepickerComponent;
  let fixture: ComponentFixture<MarketValueAsOfDatepickerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [MarketValueAsOfDatepickerComponent, TestHostComponent],
      imports: [
        NoopAnimationsModule,
        ReactiveFormsModule,
        MatDatepickerModule,
        MatMomentDateModule,
        MatInputModule
      ]
    })
      .compileComponents();
  }));

  function createComponent() {
    fixture = TestBed.createComponent(MarketValueAsOfDatepickerComponent);
    component = fixture.componentInstance;
    component.parentForm = new RateResetForm();
    fixture.detectChanges();
  }

  function createTestHostComponent() {
    testHostFixture = TestBed.createComponent(TestHostComponent);
    testHostComponent = testHostFixture.componentInstance;
    testHostFixture.detectChanges();
  }

  it('should create', () => {
    createTestHostComponent();
    expect(testHostComponent).toBeTruthy();
  });

  describe('dateFilter:', () => {
    beforeEach(function () {
      createComponent();
    });

    it('should return false if date is on Sunday', () => {
      expect(component.dateFilter(moment().day(0))).toEqual(false);
    });

    it('should return false if date is on Saturday', () => {
      expect(component.dateFilter(moment().day(6))).toEqual(false);
    });

    it('should return false if date is after current date', () => {
      expect(component.dateFilter(moment().add(1, 'days'))).toEqual(false);
    });

    it('should return true if date is before current date', () => {
      expect(component.dateFilter(moment().day(-2))).toEqual(true);
    });
  });
});
