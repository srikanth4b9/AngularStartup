import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PercentLabelComponent } from './percent-label.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [PercentLabelComponent],
  exports: [PercentLabelComponent]
})
export class PercentLabelModule { }
