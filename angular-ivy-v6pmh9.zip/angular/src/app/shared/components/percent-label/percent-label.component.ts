import { Component, Input } from '@angular/core';

@Component({
  selector: 'rxu-percent-label',
  templateUrl: './percent-label.component.html',
  styleUrls: ['./percent-label.component.scss']
})
export class PercentLabelComponent {
  @Input() inputValue: any;
  @Input() format: string;
}
