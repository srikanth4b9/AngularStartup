import { ActionSelectModule } from './action-select.module';

describe('ActionSelectModule', () => {
    let actionSelectModule: ActionSelectModule;

    beforeEach(() => {
        actionSelectModule = new ActionSelectModule();
    });

    it('should create an instance', () => {
        expect(actionSelectModule).toBeTruthy();
    });
});
