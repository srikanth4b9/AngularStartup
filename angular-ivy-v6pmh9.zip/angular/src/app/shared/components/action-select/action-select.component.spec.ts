import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {
  MatButtonModule,
  MatInputModule,
  MatSelectModule
} from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ACTION } from '@app/shared/models';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { of } from 'rxjs';

import { ActionSelectComponent } from './action-select.component';

describe('ActionSelectComponent', () => {
  let component: ActionSelectComponent;
  let fixture: ComponentFixture<ActionSelectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ActionSelectComponent],
      imports: [
        NoopAnimationsModule,
        MatButtonModule,
        MatInputModule,
        MatSelectModule,
        FontAwesomeModule
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActionSelectComponent);
    component = fixture.componentInstance;
    component.actionOptions = of([ACTION.EDIT, ACTION.DEACTIVATE]);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Action Emit', () => {
    let mockMatSelectChange;

    beforeEach(function() {
      mockMatSelectChange = {
        source: { writeValue: jasmine.createSpy() },
        value: ACTION.EDIT
      };
      spyOn(component.action, 'emit');
    });

    it('should emit action event when action is selected', () => {
      component.emitAction(mockMatSelectChange);

      expect(component.action.emit).toHaveBeenCalledWith(
        mockMatSelectChange.value
      );
    });

    it('should do nothing if an action is not selected', () => {
      mockMatSelectChange.value = null;

      component.emitAction(mockMatSelectChange);

      expect(component.action.emit).not.toHaveBeenCalled();
    });
  });
});
