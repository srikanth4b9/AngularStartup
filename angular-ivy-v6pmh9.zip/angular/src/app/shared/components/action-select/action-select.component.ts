import { Component, EventEmitter, Input, Output } from '@angular/core';
import { MatSelectChange } from '@angular/material';
import { ACTION } from '@app/shared/models';
import {
  faEdit,
  faThumbsDown,
  faThumbsUp,
  faTrash,
  faTrashRestore,
  faUndo,
  IconDefinition
} from '@fortawesome/free-solid-svg-icons';
import { Observable } from 'rxjs';

@Component({
  selector: 'rxu-action-select',
  templateUrl: './action-select.component.html',
  styleUrls: ['./action-select.component.scss']
})
export class ActionSelectComponent {
  @Input() actionOptions: Observable<ACTION[]>;
  @Output() action: EventEmitter<ACTION> = new EventEmitter();

  actionIcons: { [key: string]: IconDefinition } = {
    Edit: faEdit,
    Deactivate: faTrash,
    Reactivate: faTrashRestore,
    Approve: faThumbsUp,
    Reject: faThumbsDown,
    Revert: faUndo
  };

  emitAction(selectChange: MatSelectChange): void {
    if (selectChange.value) {
      this.action.emit(selectChange.value);

      selectChange.source.writeValue(null);
    }
  }
}
