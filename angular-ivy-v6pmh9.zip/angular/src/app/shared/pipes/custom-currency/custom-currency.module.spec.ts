import { CustomCurrencyModule } from '@app/shared/pipes';


describe('CustomCurrencyPipe', () => {
  let customCurrencyModule: CustomCurrencyModule;

  beforeEach(() => {
    customCurrencyModule = new CustomCurrencyModule();
  });

  it('should create an instance', () => {
    expect(customCurrencyModule).toBeTruthy();
  });
});
