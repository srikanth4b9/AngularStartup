import { CustomCurrencyPipe } from './custom-currency.pipe';
import { CurrencyPipe } from '@angular/common';

describe('CustomCurrencyPipe', () => {
  const currencyPipe = new CurrencyPipe('en-US');
  const pipe = new CustomCurrencyPipe(currencyPipe);
  it('create an instance', () => {
    expect(pipe).toBeTruthy();
  });

  it('should wrap negative strings in parethesis', () => {
    const result = pipe.transform('-500');
    expect(result).toBe('($500.00)');
  });

  it('should not wrap positive strings in parethesis', () => {
    const result = pipe.transform('500');
    expect(result).toBe('$500.00');
  });

  it('should wrap negative numbers in parethesis', () => {
    const result = pipe.transform(-500);
    expect(result).toBe('($500.00)');
  });

  it('should not wrap positive numbers in parethesis', () => {
    const result = pipe.transform(500);
    expect(result).toBe('$500.00');
  });

  it('should return null value when passed null', () => {
    const result = pipe.transform(null);
    expect(result).toBe(null);
  });
});
