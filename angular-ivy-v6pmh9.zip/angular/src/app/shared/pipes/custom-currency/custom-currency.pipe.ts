import { Pipe, PipeTransform } from '@angular/core';
import { CurrencyPipe } from '@angular/common';

@Pipe({
  name: 'customCurrency'
})
export class CustomCurrencyPipe implements PipeTransform {

  constructor(private readonly currencyPipe: CurrencyPipe) { }

  transform(value: string | number): any {
    if (value === null || value === undefined) {
      return value;
    } else {
      const strValue = value.toString();
      if (strValue.charAt(0) === '-') {
        const transformedValue =  strValue.substring(1, strValue.length);
        return `(${this.currencyPipe.transform(transformedValue)})`;
      } else {
        return this.currencyPipe.transform(strValue);
      }
    }
  }
}
