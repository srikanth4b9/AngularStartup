import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'systemToBlank'
})
export class SystemToBlankPipe implements PipeTransform {

  transform(value: string): any {
    return value && value.toLowerCase().indexOf('system') !== -1 ? '' : value;
  }
}
