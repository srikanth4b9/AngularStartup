import { SystemToBlankPipe } from './system-to-blank.pipe';

describe('SystemToBlankPipe', () => {
  let systemToBlankPipe: SystemToBlankPipe;

  beforeEach(() => {
    systemToBlankPipe = new SystemToBlankPipe();
  });

  it('should create an instance', () => {
    expect(systemToBlankPipe).toBeTruthy();
  });

  describe('Transform Value', () => {

    it('should convert blank to SYSTEM', () => {
      expect(systemToBlankPipe.transform('SYSTEM')).toEqual('');
    });

    it('should return original value if not SYSTEM', () => {
      expect(systemToBlankPipe.transform('test')).toEqual('test');
    });
  });
});
