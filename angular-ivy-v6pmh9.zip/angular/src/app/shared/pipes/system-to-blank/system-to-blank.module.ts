import { NgModule } from '@angular/core';
import { SystemToBlankPipe } from './system-to-blank.pipe';

@NgModule({
  declarations: [SystemToBlankPipe],
  exports: [SystemToBlankPipe]
})
export class SystemToBlankModule { }
