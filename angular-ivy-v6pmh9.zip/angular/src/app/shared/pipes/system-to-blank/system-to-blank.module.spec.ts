import { SystemToBlankModule } from './system-to-blank.module';

describe('SystemToBlankModule', () => {
  let systemToBlankModule: SystemToBlankModule;

  beforeEach(() => {
    systemToBlankModule = new SystemToBlankModule();
  });

  it('should create an instance', () => {
    expect(systemToBlankModule).toBeTruthy();
  });
});
