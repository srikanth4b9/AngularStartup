import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'camelToCapitalCase' })
export class CamelToCapitalCasePipe implements PipeTransform {
  transform(str: string) {
    return str.replace(/([A-Z][a-z])/g, ' $1').replace(/^(\w)/, (first) => first.toUpperCase());
  }
}
