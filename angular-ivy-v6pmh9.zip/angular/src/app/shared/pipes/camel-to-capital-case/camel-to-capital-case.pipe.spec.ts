import { CamelToCapitalCasePipe } from './camel-to-capital-case.pipe';

describe('CamelToCapitalCasePipe', () => {
  let capitalToCamelCasePipe: CamelToCapitalCasePipe;

  beforeEach(() => {
    capitalToCamelCasePipe = new CamelToCapitalCasePipe();
  });

  it('should create an instance', () => {
    expect(capitalToCamelCasePipe).toBeTruthy();
  });

  it('should convert caMel to Capital Case', () => {
    expect(capitalToCamelCasePipe.transform('camelCase')).toEqual('Camel Case');
  });
});
