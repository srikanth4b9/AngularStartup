import { NgModule } from '@angular/core';
import { CamelToCapitalCasePipe } from './camel-to-capital-case.pipe';

@NgModule({
  declarations: [CamelToCapitalCasePipe],
  exports: [CamelToCapitalCasePipe]
})
export class CamelToCapitalCaseModule { }
