export * from './camel-to-capital-case.pipe';
export * from './camel-to-capital-case.module';
