import { CamelToCapitalCaseModule } from './camel-to-capital-case.module';

describe('CamelToCapitalCaseModule', () => {
  let camelToCapitalCaseModule: CamelToCapitalCaseModule;

  beforeEach(() => {
    camelToCapitalCaseModule = new CamelToCapitalCaseModule();
  });

  it('should create an instance', () => {
    expect(camelToCapitalCaseModule).toBeTruthy();
  });
});
