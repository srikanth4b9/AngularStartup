import { AbstractControl } from '@angular/forms';

import { CustomForm } from '../models/custom-form.model';
import { WorkflowType } from '@app/modules/maintenance/modules/contracts/models';
import { ResetStatus, RateResetProcessType } from '@app/modules/home/models';

const NUMBER_DECIMAL_VALUE = 3;
const PERCENT_DECIMAL_VALUE = 5;

export class FormUtils {
  private static VALIDATION_ERRORS = {
    valueExists: attribute => `${attribute} already exists`,
    emptyArray: name => `Must have at least one ${name}`,
    required: () => 'Please enter a value',
    min: min => `Must be greater than ${min.min}`,
    max: max => `Must be less than ${max.max}`,
    maxlength: maxLength => `Maximum ${maxLength.requiredLength} characters`
  };
  private static editableStatus: string[] = ['MISSING_DATA', 'PENDING', 'MANUAL_OVERRIDE'];
  private static editableFieldsByWorkflow = {
    CONFIRM_RATES: ['netRate', 'bookValue', 'marketValue', 'insurerRate'],
    PROVIDE_RATES: ['netRate', 'bookValue', 'marketValue'],
    ENTER_RATES: ['netRate']
  };
  private static readOnlyFieldsByProcessType = {
    STANDARD: ['rateEffectiveDate', 'accountingAsOfDate', 'marketValueAsOfDate'],
    AD_HOC: []
  };

  static isSubmitDisabled(form: CustomForm<any>): boolean {
    return form.pristine || form.invalid || !FormUtils.isFormDirty(form);
  }

  static isFormDirty(form: CustomForm<any>): boolean {
    const formControlKeys = Object.keys(form.controls);
    return formControlKeys.some(controlKey => FormUtils.isFieldDirty(form, controlKey));
  }

  static isFieldDirty(form: CustomForm<any>, attributeName: string): boolean {
    return FormUtils.isControlValueDirty(form.get(attributeName).value, form.object[attributeName]);
  }

  static isControlValueDirty(controlValue: any, modelValue: any): boolean {
    return modelValue !== undefined ? controlValue !== modelValue : controlValue !== null;
  }

  static getValidationErrorMessage(control: AbstractControl): string {
    const controlErrors = control.errors;
    if (controlErrors) {
      const firstKey = Object.keys(controlErrors)[0];
      const getError = this.VALIDATION_ERRORS[firstKey];
      return getError(controlErrors[firstKey]);
    }
  }

  static trimWhitespace<T>(payload: T) {
    Object.keys(payload).forEach(
      key => (payload[key] = typeof payload[key] === 'string' ? payload[key].trim() : payload[key])
    );
  }

  // static toPercentString(value: number): string {
  //   return +((value * 100).toFixed(3)) + '%';
  // }

  static toNumberDecimalValue(value: string): number {
    return +parseFloat(value).toFixed(NUMBER_DECIMAL_VALUE);
  }

  static toPercentDecimalValue(value: string): number {
    return +parseFloat(value).toFixed(PERCENT_DECIMAL_VALUE);
  }

  static isNumberEditable(
    resetStatus: ResetStatus,
    workflowType: WorkflowType,
    attribute: string
  ): boolean {
    return (
      this.isEditableByStatus(resetStatus) && this.isEditableByWorkflow(workflowType, attribute)
    );
  }

  static isDateEditable(
    resetStatus: ResetStatus,
    processType: RateResetProcessType,
    attribute: string
  ): boolean {
    return (
      this.isEditableByStatus(resetStatus) && this.isEditableByProcessType(processType, attribute)
    );
  }

  private static isEditableByStatus(resetStatus: ResetStatus): boolean {
    return this.editableStatus.indexOf(resetStatus) !== -1;
  }

  private static isEditableByWorkflow(workflowType: WorkflowType, attribute: string): boolean {
    return this.editableFieldsByWorkflow[workflowType].indexOf(attribute) !== -1;
  }

  private static isEditableByProcessType(
    processType: RateResetProcessType,
    attribute: string
  ): boolean {
    return this.readOnlyFieldsByProcessType[processType].indexOf(attribute) === -1;
  }
}
