import * as moment from 'moment';

type Moment = moment.Moment;

export class DateTimeUtils {
  private static timezone: string = 'America/New_York';
  private static URI_DATE_FORMAT = 'MM-DD-YYYY';
  private static REPORT_NAME_FORMAT = 'MMDDYYYY';
  private static DISPLAY_DATE_FORMAT = 'M/D/YYYY';

  static toISOString(date: any): string {
    return date.toISOString ? date.toISOString() : date;
  }

  static toFormattedDate(moment: Moment): string {
    return moment.format(this.URI_DATE_FORMAT);
  }

  static toFormattedDisplayDate(moment: Moment): string {
    return moment.format(this.DISPLAY_DATE_FORMAT);
  }

  static toReportNameFormat(date: string): string {
    return moment.parseZone(date).format(this.REPORT_NAME_FORMAT);
  }
}
