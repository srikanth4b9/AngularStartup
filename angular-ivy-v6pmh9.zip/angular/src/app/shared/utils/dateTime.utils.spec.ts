import * as moment from 'moment';

import { DateTimeUtils } from './dateTime.utils';

describe('DateTimeUtils', () => {
  let dateString: string;
  let date: moment.Moment;
  beforeEach(function() {
    dateString = '2019-10-02T00:00:00-04:00';
    date = moment(dateString);
  });

  describe('toISOString:', () => {
    it('should ISO string if date is a moment object', () => {
      const expectedISOString = '2019-10-02T04:00:00.000Z';
      expect(DateTimeUtils.toISOString(date)).toEqual(expectedISOString);
    });

    it('should return date if not a moment object', () => {
      expect(DateTimeUtils.toISOString(dateString)).toEqual(dateString);
    });
  });

  describe('toFormattedDate:', () => {
    it('should convert moment to formatted date string', () => {
      expect(DateTimeUtils.toFormattedDate(date)).toEqual('10-02-2019');
    });
  });

  describe('toFormattedDisplayDate:', () => {
    it('should convert moment to formatted display date string', () => {
      expect(DateTimeUtils.toFormattedDisplayDate(date)).toEqual('10/2/2019');
    });
  });
});
