import { FormControl, Validators } from '@angular/forms';
import { Insurer, mockInsurerList } from '@app/modules/maintenance/modules/insurers/models';
import { InsurerForm } from '@app/modules/maintenance/modules/insurers/models/forms';

import { FormUtils } from './form.utils';
import { ResetStatus, RateResetProcessType } from '@app/modules/home/models';
import { WorkflowType } from '@app/modules/maintenance/modules/contracts/models';

describe('FormUtils', () => {
  describe('isSubmitDisabled', () => {
    let form: InsurerForm;
    beforeEach(() => {
      form = new InsurerForm(mockInsurerList[0]);
    });

    it('should return true if trade form is pristine', () => {
      expect(FormUtils.isSubmitDisabled(form)).toEqual(true);
    });

    it('should return true if trade form is invalid', () => {
      form.markAsDirty();
      form.insurerCode.setValue('PRU');
      form.updateValueAndValidity();

      expect(FormUtils.isSubmitDisabled(form)).toEqual(true);
    });

    it('should return true if trade form controls are not dirty', () => {
      form.markAsDirty();

      expect(FormUtils.isSubmitDisabled(form)).toEqual(true);
    });

    it('should return false if trade form is dirty', () => {
      form.markAsDirty();
      form.insurerCode.setValue(mockInsurerList[0].insurerCode + 1000);

      expect(FormUtils.isSubmitDisabled(form)).toEqual(false);
    });
  });

  describe('isFormDirty', () => {
    let form: InsurerForm;
    beforeEach(() => {
      form = new InsurerForm(mockInsurerList[0]);
    });

    it('should return false if no fields are dirty', () => {
      spyOn(FormUtils, 'isFieldDirty').and.returnValue(false);

      expect(FormUtils.isFormDirty(form)).toEqual(false);
    });

    it('should return true if any field is dirty', () => {
      form.insurerCode.setValue('III');
      expect(FormUtils.isFormDirty(form)).toEqual(true);
    });
  });

  describe('isFieldDirty', () => {
    let form: InsurerForm;
    let attributeName: string;
    let model: Insurer;

    it('should return result from is control value dirty', () => {
      model = mockInsurerList[0];
      form = new InsurerForm(model);
      attributeName = 'insurerCode';

      spyOn(FormUtils, 'isControlValueDirty').and.returnValue(true);

      expect(FormUtils.isFieldDirty(form, attributeName)).toEqual(true);
      expect(FormUtils.isControlValueDirty).toHaveBeenCalledWith(
        form.get(attributeName).value,
        model[attributeName]
      );
    });
  });

  describe('isControlValueDirty', () => {
    let controlValue;
    let modelValue;

    it('should return false when model value is undefined and control value is null', () => {
      controlValue = null;
      modelValue = undefined;

      expect(FormUtils.isControlValueDirty(controlValue, modelValue)).toEqual(false);
    });

    it('should return true when model value is undefined and control value is set', () => {
      controlValue = 500;
      modelValue = undefined;

      expect(FormUtils.isControlValueDirty(controlValue, modelValue)).toEqual(true);
    });

    it('should return false when model value and control value are equal', () => {
      controlValue = 500;
      modelValue = 500;

      expect(FormUtils.isControlValueDirty(controlValue, modelValue)).toEqual(false);
    });

    it('should return true when model value and control value are not equal', () => {
      controlValue = 500;
      modelValue = 650;

      expect(FormUtils.isControlValueDirty(controlValue, modelValue)).toEqual(true);
    });
  });

  describe('getValidationErrorMessage', () => {
    let control: FormControl;

    function expectValidationMessage(formControl: FormControl, message: string) {
      expect(FormUtils.getValidationErrorMessage(formControl)).toEqual(message);
    }

    it('should display "required" validation error', () => {
      control = new FormControl('', Validators.required);

      expectValidationMessage(control, 'Please enter a value');
    });

    it('should display "max length" validation error', () => {
      control = new FormControl(
        'Insurance Insurance Insurance Insurance Insurance Insurance',
        Validators.maxLength(20)
      );

      expectValidationMessage(control, 'Maximum 20 characters');
    });

    it('should validate the value and throw error if the value already exists', () => {
      control = new FormControl('Test Asset');
      control.setErrors({ valueExists: 'Asset Name' });

      expectValidationMessage(control, 'Asset Name already exists');
    });

    it('should display the emptyArray validation error', () => {
      control = new FormControl('Test Asset');
      control.setErrors({ emptyArray: 'underlying asset' });

      expectValidationMessage(control, 'Must have at least one underlying asset');
    });

    it('should validate the value and throw error for min value', () => {
      control = new FormControl(-3, Validators.min(0));

      expectValidationMessage(control, 'Must be greater than 0');
    });

    it('should validate the value and throw error for max value', () => {
      control = new FormControl(2, Validators.max(1));

      expectValidationMessage(control, 'Must be less than 1');
    });
  });

  describe('trimWhitespace', () => {
    it('should trim whitespace from string values', () => {
      const payload: Insurer = {
        insurerCode: '  T-INS   ',
        insurerId: 56,
        insurerName: '  INSURER NAME   ',
        isActive: true
      };
      FormUtils.trimWhitespace(payload);

      expect(payload.insurerCode).toEqual('T-INS');
      expect(payload.insurerName).toEqual('INSURER NAME');
      expect(payload.insurerId).toEqual(56);
    });
  });

  describe('isNumberEditable:', () => {
    describe('Status:', () => {
      numberEditableStatusTest('NOT_CALCULATED', false);
      numberEditableStatusTest('MISSING_DATA', true);
      numberEditableStatusTest('PENDING', true);
      numberEditableStatusTest('MANUAL_OVERRIDE', true);
      numberEditableStatusTest('APPROVED', false);
      numberEditableStatusTest('REJECTED', false);
      numberEditableStatusTest('SENT', false);
      numberEditableStatusTest('NONE', false);

      function numberEditableStatusTest(status: ResetStatus, result: boolean) {
        it(`should return ${result} when the Rate Reset status is ${status}`, () => {
          expect(FormUtils.isNumberEditable(status, 'CONFIRM_RATES', 'netRate')).toBe(result);
        });
      }
    });

    describe('Workflow:', () => {
      editableByWorkflowTest('CONFIRM_RATES', 'netRate', true);
      editableByWorkflowTest('CONFIRM_RATES', 'bookValue', true);
      editableByWorkflowTest('CONFIRM_RATES', 'marketValue', true);
      editableByWorkflowTest('CONFIRM_RATES', 'insurerRate', true);
      editableByWorkflowTest('CONFIRM_RATES', 'rateEffectiveDate', false);
      editableByWorkflowTest('PROVIDE_RATES', 'netRate', true);
      editableByWorkflowTest('PROVIDE_RATES', 'bookValue', true);
      editableByWorkflowTest('PROVIDE_RATES', 'marketValue', true);
      editableByWorkflowTest('PROVIDE_RATES', 'insurerRate', false);
      editableByWorkflowTest('ENTER_RATES', 'netRate', true);
      editableByWorkflowTest('ENTER_RATES', 'bookValue', false);

      function editableByWorkflowTest(
        workflowType: WorkflowType,
        attribute: string,
        result: boolean
      ) {
        it(`should return ${result} when the Rate Reset workfow is ${workflowType} and attribute is ${attribute}`, () => {
          expect(FormUtils.isNumberEditable('PENDING', workflowType, attribute)).toBe(result);
        });
      }
    });
  });

  describe('isDateEditable:', () => {
    describe('Status:', () => {
      numberEditableStatusTest('NOT_CALCULATED', false);
      numberEditableStatusTest('MISSING_DATA', true);
      numberEditableStatusTest('PENDING', true);
      numberEditableStatusTest('MANUAL_OVERRIDE', true);
      numberEditableStatusTest('APPROVED', false);
      numberEditableStatusTest('REJECTED', false);
      numberEditableStatusTest('SENT', false);
      numberEditableStatusTest('NONE', false);

      function numberEditableStatusTest(status: ResetStatus, result: boolean) {
        it(`should return ${result} when the Rate Reset status is ${status}`, () => {
          expect(FormUtils.isDateEditable(status, 'STANDARD', 'effectiveDate')).toBe(result);
        });
      }
    });

    describe('Process Type:', () => {
      editableByProcessTypeTest('AD_HOC', 'rateEffectiveDate', true);
      editableByProcessTypeTest('AD_HOC', 'accountingAsOfDate', true);
      editableByProcessTypeTest('AD_HOC', 'marketValueAsOfDate', true);
      editableByProcessTypeTest('STANDARD', 'rateEffectiveDate', false);
      editableByProcessTypeTest('STANDARD', 'accountingAsOfDate', false);
      editableByProcessTypeTest('STANDARD', 'marketValueAsOfDate', false);

      function editableByProcessTypeTest(
        processType: RateResetProcessType,
        attribute: string,
        result: boolean
      ) {
        it(`should return ${result} when the Rate Reset process type is ${processType} and attribute is ${attribute}`, () => {
          expect(FormUtils.isDateEditable('PENDING', processType, attribute)).toBe(result);
        });
      }
    });
  });
});
