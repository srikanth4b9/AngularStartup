import { MdcTypographyModule } from '@angular-mdc/web';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { APP_ID, Inject, NgModule } from '@angular/core';
import {
  MAT_DIALOG_DEFAULT_OPTIONS,
  MAT_SNACK_BAR_DEFAULT_OPTIONS,
  MatSnackBarModule
} from '@angular/material';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {
  ConfirmDialogComponent,
  ConfirmDialogModule,
  ExemplarToolbarComponentModule,
  LoadingIndicatorModule,
  TabGroupComponentModule
} from './components';
import { AdhocDialogComponent } from './modules/home/components/adhoc-dialog/adhoc-dialog.component';
import { AdhocDialogModule } from './modules/home/components/adhoc-dialog/adhoc-dialog.module';
import {
  InsurerDialogComponent,
  InsurerDialogModule
} from './modules/maintenance/modules/insurers/components/insurer-dialog';
import {
  UnderlyingAssetDialogComponent,
  UnderlyingAssetDialogModule
} from './modules/maintenance/modules/underlying-assets/components';
import { HttpConfigInterceptor } from './services';

const DEFAULT_SNACK_BAR_DURATION = 5000;
// Angular Universal requires HttpClientModule to be declared at app level
// https://www.thecodecampus.de/blog/angular-universal-xmlhttprequest-not-defined-httpclient/
@NgModule({
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    HttpClientModule,
    MdcTypographyModule,
    ExemplarToolbarComponentModule,
    LoadingIndicatorModule,
    TabGroupComponentModule,
    MatSnackBarModule,
    AdhocDialogModule,
    UnderlyingAssetDialogModule,
    InsurerDialogModule,
    ConfirmDialogModule
  ],
  declarations: [AppComponent],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpConfigInterceptor,
      multi: true
    },
    {
      provide: MAT_SNACK_BAR_DEFAULT_OPTIONS,
      useValue: { duration: DEFAULT_SNACK_BAR_DURATION }
    },
    {
      provide: MAT_DIALOG_DEFAULT_OPTIONS,
      useValue: { hasBackdrop: true, autoFocus: false, disableClose: true }
    }
  ],
  bootstrap: [AppComponent],
  entryComponents: [
    AdhocDialogComponent,
    UnderlyingAssetDialogComponent,
    InsurerDialogComponent,
    ConfirmDialogComponent
  ]
})
export class AppModule {
  constructor(@Inject(APP_ID) private readonly appId: string) {
    console.log(`Running with appId=${appId}`);
  }
}
