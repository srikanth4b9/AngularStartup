import { Component } from '@angular/core';

@Component({
  selector: 'rxu-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent { }
