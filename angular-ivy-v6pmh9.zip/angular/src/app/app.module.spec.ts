import { AppModule } from './app.module';

describe('AppModule', () => {
    let appModule: AppModule;

    beforeEach(() => {
        appModule = new AppModule('rate-reset');
    });

    it('should create an instance', () => {
        expect(appModule).toBeTruthy();
    });
});
