import { TabGroupComponentModule } from './tab-group.module';

describe('TabGroupComponentModule', () => {
  let tabGroupComponentModule: TabGroupComponentModule;

  beforeEach(() => {
    tabGroupComponentModule = new TabGroupComponentModule();
  });

  it('should create an instance', () => {
    expect(tabGroupComponentModule).toBeTruthy();
  });
});
