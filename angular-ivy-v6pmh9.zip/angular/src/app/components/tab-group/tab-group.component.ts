import { Component } from '@angular/core';
import { NavLink } from '@app/shared/models';

@Component({
  selector: 'rxu-tab-group',
  templateUrl: './tab-group.component.html',
  styleUrls: ['./tab-group.component.scss']
})
export class TabGroupComponent {
  navLinks: NavLink[] = [
    { path: '/home', label: 'Home' },
    { path: '/reports', label: 'Reports' },
    { path: '/maintenance', label: 'Maintenance' }
  ];
}
