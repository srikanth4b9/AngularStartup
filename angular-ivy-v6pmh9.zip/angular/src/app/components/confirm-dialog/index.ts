export * from './confirm-dialog.component';
export * from './confirm-dialog.module';
