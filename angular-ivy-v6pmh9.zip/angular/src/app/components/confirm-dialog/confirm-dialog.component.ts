import { Component, Inject, Optional } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

import { faExclamationTriangle, IconDefinition } from '@fortawesome/free-solid-svg-icons';
import { ConfirmDialogModel } from '@app/shared';

@Component({
  selector: 'rxu-confirm-dialog',
  templateUrl: './confirm-dialog.component.html',
  styleUrls: ['./confirm-dialog.component.scss']
})
export class ConfirmDialogComponent {
  title: string;
  message: string;
  confirmButtonText: string;

  faExclamationTriangle: IconDefinition = faExclamationTriangle;

  constructor(
    private readonly dialogRef: MatDialogRef<ConfirmDialogComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) data: ConfirmDialogModel) {
    this.title = data.title;
    this.message = data.message;
    this.confirmButtonText = data.confirmButtonText;
  }

  close() {
    this.dialogRef.close();
  }

  confirm() {
    this.dialogRef.close('confirm');
  }
}
