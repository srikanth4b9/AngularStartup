import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDialogModule, MatButtonModule } from '@angular/material';

import { ConfirmDialogComponent } from './confirm-dialog.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { VuiButtonModule } from 'vg-vui-ng/button';

@NgModule({
  imports: [
    CommonModule,
    MatDialogModule,
    MatButtonModule,
    FontAwesomeModule,
    VuiButtonModule
  ],
  declarations: [ConfirmDialogComponent],
  exports: [ConfirmDialogComponent]
})
export class ConfirmDialogModule { }
