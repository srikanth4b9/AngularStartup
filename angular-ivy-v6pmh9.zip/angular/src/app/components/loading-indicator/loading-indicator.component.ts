import { Component } from '@angular/core';
import { LoadingIndicatorService } from '@app/services';

@Component({
  selector: 'rxu-loading-indicator',
  templateUrl: './loading-indicator.component.html',
  styleUrls: ['./loading-indicator.component.scss']
})
export class LoadingIndicatorComponent {
  showLoadingIndicator: boolean;

  constructor(private readonly loadingService: LoadingIndicatorService) {
    loadingService.indicatorSubject.subscribe(value => {
      this.showLoadingIndicator = value;
    });
  }
}
