import { LoadingIndicatorModule } from './loading-indicator.module';

describe('LoadingIndicatorModule', () => {
  let loadingIndicatorModule: LoadingIndicatorModule;

  beforeEach(() => {
    loadingIndicatorModule = new LoadingIndicatorModule();
  });

  it('should create an instance', () => {
    expect(loadingIndicatorModule).toBeTruthy();
  });
});
