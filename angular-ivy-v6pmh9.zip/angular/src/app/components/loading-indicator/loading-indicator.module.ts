import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoadingIndicatorComponent } from './loading-indicator.component';
import { LoadingIndicatorModule as VuiLoadingIndicatorModule } from 'vg-vui-ng/loading-indicator';

@NgModule({
  imports: [
    CommonModule,
    VuiLoadingIndicatorModule
  ],
  declarations: [LoadingIndicatorComponent],
  exports: [LoadingIndicatorComponent]
})
export class LoadingIndicatorModule { }
