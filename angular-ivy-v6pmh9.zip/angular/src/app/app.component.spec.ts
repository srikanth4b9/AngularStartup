import { MdcTypographyModule } from '@angular-mdc/web';
import { async, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ExemplarToolbarComponentModule, LoadingIndicatorModule, TabGroupComponentModule } from '@app/components';

import { AppComponent } from './app.component';
import { InsurerDialogModule } from './modules/maintenance/modules/insurers/components/insurer-dialog';

describe('AppComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        MdcTypographyModule,
        ExemplarToolbarComponentModule,
        LoadingIndicatorModule,
        TabGroupComponentModule,
        InsurerDialogModule
      ],
      declarations: [
        AppComponent
      ],
    }).compileComponents();
  }));

  it('should create the app', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  }));

  it('should render toolbar with app title', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('.rxu-app-title').textContent).toContain('Rate Reset Application');
  }));
});
