import { SnackBarService } from '@app/services/snack-bar';
import { TestBed } from '@angular/core/testing';
import { MatSnackBar, MatSnackBarModule } from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';

class MockMatSnackBar {
  open = jasmine.createSpy();
}

describe('SnackBarService', () => {
  let service: SnackBarService;
  let snackBar: MockMatSnackBar;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule,
        MatSnackBarModule],
      providers: [{ provide: MatSnackBar, useClass: MockMatSnackBar }]
    });
    service = TestBed.get(SnackBarService);
    snackBar = TestBed.get(MatSnackBar);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('success:', () => {
    it('should show success snackBar message', () => {
      const message = 'SUCCESS';

      service.success(message);

      expect(snackBar.open).toHaveBeenCalledWith(message, undefined, service.snackBarConfig.success);
    });
  });

  describe('error:', () => {
    it('should show error snackBar message', () => {
      const message = 'ERROR';

      service.error(message);

      expect(snackBar.open).toHaveBeenCalledWith(message, undefined, service.snackBarConfig.error);
    });
  });
});
