import { Injectable } from '@angular/core';
import { MatSnackBar, MatSnackBarConfig } from '@angular/material';

@Injectable({
  providedIn: 'root'
})
export class SnackBarService {
  snackBarConfig: { [s: string]: MatSnackBarConfig; } = {
    success: { panelClass: 'success' },
    error: { panelClass: 'error' }
  };

  constructor(private readonly snackBar: MatSnackBar) { }

  public success(message: string) {
    this.showMessage(message, this.snackBarConfig.success);
  }

  public error(message: string) {
    this.showMessage(message, this.snackBarConfig.error);
  }

  private showMessage(message, config) {
    this.snackBar.open(message, undefined, config);
  }
}
