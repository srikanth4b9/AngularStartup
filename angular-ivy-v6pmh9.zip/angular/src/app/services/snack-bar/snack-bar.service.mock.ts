import { } from 'jasmine';

export class MockSnackBarService {
  success = jasmine.createSpy();
  error = jasmine.createSpy();
}
