import { isPlatformBrowser } from '@angular/common';
import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
  HttpXsrfTokenExtractor
} from '@angular/common/http';
import { Inject, Injectable, PLATFORM_ID } from '@angular/core';
import { FormUtils } from '@app/shared';
import { ERROR_CODES } from '@app/shared/models';
import { environment } from '@env';
import { saveAs } from 'file-saver';
import { EMPTY, Observable, Subscription, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';

import { SnackBarService } from '../snack-bar';

@Injectable({
  providedIn: 'root'
})
export class RestService {
  private TEXT: string = 'text';
  private TEXT_CSV: string = 'text/csv';

  constructor(
    private readonly http: HttpClient,
    private readonly tokenExtractor: HttpXsrfTokenExtractor,
    @Inject(PLATFORM_ID) private readonly platformId: Object,
    private readonly snackBarService: SnackBarService
  ) {}

  private getOptions() {
    return {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      withCredentials: true
    };
  }

  private getPostOptions() {
    const XSRF_TOKEN = this.tokenExtractor.getToken();
    const postOptions = this.getOptions();
    postOptions.headers = postOptions.headers.set('X-XSRF-TOKEN', XSRF_TOKEN);
    return postOptions;
  }

  public getData<T>(title: string, path: string): Observable<T> {
    if (isPlatformBrowser(this.platformId)) {
      return this.http
        .get<T>(`${environment.RXS_REST_BASE}${path}`, this.getOptions())
        .pipe(catchError(error => this.errorMessage(title, error)));
    } else {
      return EMPTY;
    }
  }

  public postData<T>(
    title: string,
    path: string,
    payload: T,
    postOptions = this.getPostOptions()
  ): Observable<any> {
    FormUtils.trimWhitespace(payload);
    return this.http.post<T>(`${environment.RXS_REST_BASE}${path}`, payload, postOptions).pipe(
      tap(() => this.successMessage(title)),
      catchError(error => this.errorMessage(title, error))
    );
  }

  public putData<T>(title: string, path: string, payload: T): Observable<any> {
    const putOptions = this.getPostOptions();
    putOptions.headers = putOptions.headers.set('X-HTTP-Method-Override', 'PUT');

    return this.postData<T>(title, path, payload, putOptions);
  }

  public deleteData<T>(title: string, path: string, payload: T): Observable<any> {
    const deleteOptions = this.getPostOptions();
    deleteOptions.headers = deleteOptions.headers.set('X-HTTP-Method-Override', 'DELETE');

    return this.postData<T>(title, path, payload, deleteOptions);
  }

  public exportData<T>(title: string, path: string, payload: T, fileName: string): Subscription {
    const exportOptions = this.getPostOptions();
    exportOptions.headers = exportOptions.headers.set('Accept', this.TEXT_CSV);
    (exportOptions as any).responseType = this.TEXT;

    return this.postData<T>(title, path, payload, exportOptions).subscribe(
      res => {
        saveAs(new Blob([res], { type: this.TEXT_CSV }), `${fileName}.csv`);
        this.successMessage(title);
      },
      err => {
        this.errorMessage(title, err);
      }
    );
  }

  private successMessage(title): void {
    this.snackBarService.success(`${title} Completed`);
  }

  private errorMessage(title, error: HttpErrorResponse) {
    const errorBody: ErrorType = error.error || {};
    const snackBarMessage = this.createErrorMessage(title, errorBody);
    this.snackBarService.error(snackBarMessage);
    return throwError(error);
  }

  private createErrorMessage(title, errorBody) {
    const message = `${title} Failed`;
    const errorCode = errorBody.value;
    return errorCode ? `${message} - ${ERROR_CODES[errorCode]}` : message;
  }
}

interface ErrorType {
  value?: string;
  message?: any;
}
