import { of } from 'rxjs';

export class MockRestService {
  getData = jasmine.createSpy().and.returnValue(of({}));
  postData = jasmine.createSpy().and.returnValue(of({}));
  putData = jasmine.createSpy().and.returnValue(of({}));
  deleteData = jasmine.createSpy().and.returnValue(of({}));
  exportData = jasmine.createSpy().and.returnValue(of({}));
}
