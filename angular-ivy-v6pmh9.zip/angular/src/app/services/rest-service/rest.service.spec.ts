import { HttpRequest } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { PLATFORM_ID } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { mockRateResetList } from '@app/modules/home/models';
import { MockSnackBarService, SnackBarService } from '@app/services/snack-bar';
import { FormUtils } from '@app/shared';
import { environment } from '@env';
import { mockInsurerList } from '@insurers/models';
import * as FileSaver from 'file-saver';

import { RestService } from './rest.service';

describe('RestService', () => {
  let service: RestService;
  let httpMock: HttpTestingController;
  let snackBarService: MockSnackBarService;
  let path: string;
  let apiPath: string;

  const title = 'Action';

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        { provide: SnackBarService, useValue: new MockSnackBarService() },
        { provide: PLATFORM_ID, useValue: 'browser' }
      ]
    });

    service = TestBed.get(RestService);
    httpMock = TestBed.get(HttpTestingController);
    snackBarService = TestBed.get(SnackBarService);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('getData', () => {
    beforeEach(() => {
      path = environment.INSURERS_URI;
      apiPath = `${environment.RXS_REST_BASE}${path}`;
    });

    it('should make an http request to get data', () => {
      service.getData(title, path).subscribe(data => {
        expect(data).toEqual(mockInsurerList);
      });

      const getDataMockCall = httpMock.expectOne(apiPath);
      expect(getDataMockCall.request.method).toBe('GET');
      getDataMockCall.flush(mockInsurerList);
    });

    it('should display a message when an error occurs', () => {
      service.getData(title, path).subscribe(
        () => {},
        () => {}
      );

      httpMock.expectOne(apiPath).flush('Request Error', { status: 400, statusText: 'Failed' });

      expect(snackBarService.error).toHaveBeenCalledWith(`${title} Failed`);
    });

    it('should display a specific message when an error occurs with an error code', () => {
      service.getData(title, path).subscribe(
        () => {},
        () => {}
      );

      httpMock
        .expectOne(apiPath)
        .flush({ value: 'MUST_BE_UNIQUE_ASSET_ID' }, { status: 400, statusText: 'Failed' });

      expect(snackBarService.error).toHaveBeenCalledWith(
        `${title} Failed - Asset ID must be unique`
      );
    });

    it('should no nothing if rendered on the server', () => {
      (<any>service).platformId = 'server';
      service.getData(title, path).subscribe(data => {
        expect(data).not.toBeDefined();
      });

      httpMock.expectNone(apiPath);
    });
  });

  describe('postData', () => {
    beforeEach(() => {
      path = environment.INSURERS_URI;
      apiPath = `${environment.RXS_REST_BASE}${path}`;
    });

    it('should trim whitespace from payload', () => {
      const payload = {
        insurerCode: '  T-INS   ',
        insurerId: 56,
        insurerName: '  INSURER NAME   ',
        isActive: true
      };
      spyOn(FormUtils, 'trimWhitespace');

      service.postData(title, path, payload).subscribe(() => {
        expect(FormUtils.trimWhitespace).toHaveBeenCalledWith(payload);
      });

      httpMock.expectOne(apiPath).flush(mockInsurerList);
    });

    it('should make an http request to post data', () => {
      service.postData(title, path, {}).subscribe(data => {
        expect(data).toEqual(mockInsurerList);
      });

      const getDataMockCall = httpMock.expectOne(apiPath);
      expect(getDataMockCall.request.method).toBe('POST');
      getDataMockCall.flush(mockInsurerList);
      expect(snackBarService.success).toHaveBeenCalled();
    });

    it('should display a message when an error occurs', () => {
      service.postData(title, path, {}).subscribe(
        () => {},
        () => {}
      );

      httpMock.expectOne(apiPath).flush('Request Error', { status: 400, statusText: 'Failed' });

      expect(snackBarService.error).toHaveBeenCalledWith(`${title} Failed`);
    });
  });

  describe('putData', () => {
    beforeEach(() => {
      path = environment.INSURERS_URI;
      apiPath = `${environment.RXS_REST_BASE}${path}`;
    });

    it('should make an http request to update data using PUT', () => {
      service.putData(title, `${path}/61`, {}).subscribe(data => {
        expect(data).toEqual(mockInsurerList);
      });

      const getDataMockCall = httpMock.expectOne(`${apiPath}/61`);
      expect(getDataMockCall.request.method).toBe('POST');
      getDataMockCall.flush(mockInsurerList);
      expect(snackBarService.success).toHaveBeenCalled();
    });
  });

  describe('deleteData', () => {
    beforeEach(() => {
      path = environment.INSURERS_URI;
      apiPath = `${environment.RXS_REST_BASE}${path}`;
    });

    it('should make an http request to update data using DELETE', () => {
      service.deleteData(title, `${path}/61`, {}).subscribe(data => {
        expect(data).toEqual(mockInsurerList);
      });

      const getDataMockCall = httpMock.expectOne(`${apiPath}/61`);
      expect(getDataMockCall.request.method).toBe('POST');
      getDataMockCall.flush(mockInsurerList);
      expect(snackBarService.success).toHaveBeenCalled();
    });
  });

  describe('exportData', () => {
    const testDate = '2018-11-14';
    const fileName = `details-${testDate}`;
    beforeEach(() => {
      path = environment.REPORTS_URI;
      apiPath = `${environment.RXS_REST_BASE}${path}`;
    });

    it('should make an http request to export report data', () => {
      const saveAsSpy = spyOn(FileSaver, 'saveAs');
      service.exportData(title, path, {}, fileName);

      httpMock
        .expectOne((request: HttpRequest<any>) => {
          return (
            request.url === apiPath && request.method === 'POST' && request.responseType === 'text'
          );
        })
        .flush(mockRateResetList);

      expect(saveAsSpy).toHaveBeenCalled();
      expect(snackBarService.success).toHaveBeenCalled();
    });

    it('should return an error message if export request fails', () => {
      service.exportData(title, path, {}, fileName);

      httpMock.expectOne(apiPath).flush('Request Error', { status: 400, statusText: 'Failed' });

      expect(snackBarService.error).toHaveBeenCalledWith(`${title} Failed`);
    });
  });
});
