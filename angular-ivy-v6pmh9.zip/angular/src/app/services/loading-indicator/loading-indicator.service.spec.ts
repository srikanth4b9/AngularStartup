import { TestBed } from '@angular/core/testing';

import { LoadingIndicatorService } from './loading-indicator.service';

describe('LoadingIndicatorService', () => {
  let service: LoadingIndicatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.get(LoadingIndicatorService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('showSpinner', () => {
    it('should set the indicatorSubject to true', () => {
      service.showSpinner();
      expect(service.indicatorSubject.getValue()).toBe(true);
    });
  });

  describe('hideSpinner', () => {
    it('should set the indicatorSubject to false', () => {
      service.hideSpinner();
      expect(service.indicatorSubject.getValue()).toBe(false);
    });
  });
});
