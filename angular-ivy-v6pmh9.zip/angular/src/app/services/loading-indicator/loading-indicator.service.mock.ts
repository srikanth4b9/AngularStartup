import { } from 'jasmine';

export class MockLoadingIndicatorService {
  showSpinner = jasmine.createSpy();
  hideSpinner = jasmine.createSpy();
}
