import {
  LoadingIndicatorService,
  MockLoadingIndicatorService
} from '@app/services/loading-indicator';
import { TestBed } from '@angular/core/testing';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { HttpConfigInterceptor } from './httpconfig.interceptor';
import { RestService } from '@app/services';
import { MatSnackBarModule } from '@angular/material';
import { environment } from '@env';

describe('HttpConfigInterceptor', () => {
  let restService: RestService;
  let httpMock: HttpTestingController;
  let loadingService: LoadingIndicatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, MatSnackBarModule],
      providers: [
        RestService,
        {
          provide: HTTP_INTERCEPTORS,
          useClass: HttpConfigInterceptor,
          multi: true
        },
        {
          provide: LoadingIndicatorService,
          useClass: MockLoadingIndicatorService
        }
      ]
    });

    restService = TestBed.get(RestService);
    httpMock = TestBed.get(HttpTestingController);
    loadingService = TestBed.get(LoadingIndicatorService);
  });

  it('should show & hide the loading indicator', () => {
    const path = environment.INSURERS_URI;

    restService.getData('title', path).subscribe(
      () => {},
      () => {}
    );

    expect(loadingService.showSpinner).toHaveBeenCalled();

    httpMock.expectOne(`${environment.RXS_REST_BASE}${path}`).flush([{}]);

    expect(loadingService.hideSpinner).toHaveBeenCalled();
  });
});
