import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { ReportsRoutingModule } from './reports-routing.module';
import { ReportsViewModule } from './views';

@NgModule({
  declarations: [],
  imports: [CommonModule, ReportsRoutingModule, ReportsViewModule]
})
export class ReportsModule {}
