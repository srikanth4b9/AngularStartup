export type ReportType = 'DETAILS' | 'FUND' | 'INSURER';
export const ReportType = {
  DETAILS: 'Rate Reset Details',
  INSURER: 'By Insurer',
  FUND: 'By Fund'
};

export class ReportRequest {
  type: ReportType = 'DETAILS';
  effectiveDate: string;
  insurerId?: number;
  portId?: string;
}
