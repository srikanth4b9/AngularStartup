import { environment } from '@env';

import { ReportRequestForm } from './report-request-form.model';

describe('ReportRequestForm', () => {
  let requestForm: ReportRequestForm;

  beforeEach(function() {
    requestForm = new ReportRequestForm();
  });

  describe('constructor', () => {
    formControlGetterTest('type');
    formControlGetterTest('effectiveDate');

    it('should set custom form attributes', () => {
      expect(requestForm.objectName).toEqual('Report Request');
      expect(requestForm.uri).toEqual(environment.REPORTS_URI);
      expect(requestForm.idAttribute).toEqual('type');
    });
  });

  describe('Details Report', () => {
    it('should not define id controls', () => {
      expect(requestForm.insurerId).toBeNull();
      expect(requestForm.portId).toBeNull();
    });
  });

  describe('By Insurer Report', () => {
    beforeEach(function() {
      requestForm.type.setValue('INSURER');
    });

    formControlGetterTest('insurerId');

    it('should not define portId control', () => {
      expect(requestForm.portId).toBeNull();
    });
  });

  describe('By Fund Report', () => {
    beforeEach(function() {
      requestForm.type.setValue('FUND');
    });

    formControlGetterTest('portId');

    it('should not define insurerId control', () => {
      expect(requestForm.insurerId).toBeNull();
    });
  });

  function formControlGetterTest(controlName: string) {
    it(`should create a control getter for ${controlName}`, async () => {
      expect(requestForm[controlName]).toBeDefined();
    });
  }
});
