import { ReportRequest } from '../report-request.model';

export const mockDetailsReportRequest: ReportRequest = {
  type: 'DETAILS',
  effectiveDate: '2020-01-30T00:00:00.000Z'
};

export const mockInsurerReportRequest: ReportRequest = {
  type: 'INSURER',
  effectiveDate: '2020-01-30T00:00:00.000Z',
  insurerId: 2
};

export const mockFundReportRequest: ReportRequest = {
  type: 'FUND',
  effectiveDate: '2020-01-30T00:00:00.000Z',
  portId: '9822'
};
