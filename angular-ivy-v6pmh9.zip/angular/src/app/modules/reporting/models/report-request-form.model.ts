import { AbstractControl, FormControl, Validators } from '@angular/forms';
import { CustomForm } from '@app/shared';
import { environment } from '@env';

import { ReportRequest, ReportType } from './report-request.model';

export class ReportRequestForm extends CustomForm<ReportRequest> {
  /* istanbul ignore next */
  constructor() {
    super({
      type: new FormControl(null, [Validators.required]),
      effectiveDate: new FormControl(null, [Validators.required])
    });
    this.object = new ReportRequest();

    this.type.valueChanges.subscribe(() => this.setRequiredFields());
    this.setRequiredFields();
  }

  get objectName() {
    return 'Report Request';
  }
  get uri() {
    return environment.REPORTS_URI;
  }
  get idAttribute() {
    return 'type';
  }

  private setRequiredFields() {
    switch (this.type.value as ReportType) {
      case 'DETAILS':
        this.removeControl('insurerId');
        this.removeControl('portId');
        break;
      case 'INSURER':
        this.addControl('insurerId', new FormControl(null, [Validators.required]));
        this.removeControl('portId');
        break;
      case 'FUND':
        this.addControl('portId', new FormControl(null, [Validators.required]));
        this.removeControl('insurerId');
        break;
    }
  }

  get type(): AbstractControl {
    return this.get('type');
  }
  get effectiveDate(): AbstractControl {
    return this.get('effectiveDate');
  }
  get insurerId(): AbstractControl {
    return this.get('insurerId');
  }
  get portId(): AbstractControl {
    return this.get('portId');
  }
}
