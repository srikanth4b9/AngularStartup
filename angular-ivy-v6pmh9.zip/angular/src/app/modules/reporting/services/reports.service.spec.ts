import { TestBed } from '@angular/core/testing';
import { mockInsurerList } from '@app/modules/maintenance/modules/insurers/models';
import { MaintenanceService, MockMaintenanceService } from '@app/modules/maintenance/services';
import { RestService } from '@app/services';
import { MockRestService } from '@app/services/rest-service/rest.service.mock';
import { environment } from '@env';

import { ReportRequest } from '../models/report-request.model';
import { ReportService } from './reports.service';

describe('ReportService', () => {
  let service: ReportService;
  let restService: MockRestService;
  let maintenanceService: MockMaintenanceService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: RestService, useValue: new MockRestService() },
        { provide: MaintenanceService, useValue: new MockMaintenanceService() }
      ]
    });

    service = TestBed.get(ReportService);
    restService = TestBed.get(RestService);
    maintenanceService = TestBed.get(MaintenanceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('exportReport', () => {
    let request: ReportRequest;
    let expectedFilename: string;

    beforeEach(function() {
      request = new ReportRequest();
      request.effectiveDate = '2020-01-30T00:00:00.000Z';
    });

    it('should make a rest call to export a details report', () => {
      expectedFilename = 'crediting_rate_details_01302020';

      service.exportReport(request);

      expect(restService.exportData).toHaveBeenCalledWith(
        'Export Report',
        environment.REPORTS_URI,
        request,
        expectedFilename
      );
    });

    it('should make a rest call to export a rates by fund report', () => {
      request.type = 'FUND';
      request.portId = '9892';
      expectedFilename = 'crediting_rates_by_fund_01302020_9892';

      service.exportReport(request);

      expect(restService.exportData).toHaveBeenCalledWith(
        'Export Report',
        environment.REPORTS_URI,
        request,
        expectedFilename
      );
    });

    it('should make a rest call to export a rates by insurer report', () => {
      request.type = 'INSURER';
      const insurer = mockInsurerList[0];
      request.insurerId = insurer.insurerId;
      expectedFilename = `crediting_rates_by_insurer_01302020_${insurer.insurerCode}`;
      const insurersSpy = spyOn(maintenanceService.insurers$, 'pipe').and.callThrough();

      service.exportReport(request);

      expect(insurersSpy).toHaveBeenCalled();
      expect(restService.exportData).toHaveBeenCalledWith(
        'Export Report',
        environment.REPORTS_URI,
        request,
        expectedFilename
      );
    });
  });
});
