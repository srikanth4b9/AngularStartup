import { of } from 'rxjs';

export class MockReportService {
  exportReport = jasmine.createSpy().and.returnValue(of({}));
}
