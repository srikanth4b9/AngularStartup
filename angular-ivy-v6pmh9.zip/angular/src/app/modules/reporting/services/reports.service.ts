import { Injectable } from '@angular/core';
import { RestService } from '@app/services';
import { environment } from '@env';

import { ReportRequest } from '../models/report-request.model';
import { DateTimeUtils } from '@app/shared';
import { MaintenanceService } from '@app/modules/maintenance/services';
import { map, first } from 'rxjs/operators';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ReportService {
  reportTypeFilenames = {
    DETAILS: 'crediting_rate_details',
    INSURER: 'crediting_rates_by_insurer',
    FUND: 'crediting_rates_by_fund'
  };

  constructor(
    private readonly restService: RestService,
    private readonly maintenanceService: MaintenanceService
  ) {}

  exportReport(reportRequest: ReportRequest): void {
    this.getReportFileName(reportRequest)
      .pipe(first())
      .subscribe(fileName => {
        this.restService.exportData<any>(
          'Export Report',
          environment.REPORTS_URI,
          reportRequest,
          fileName
        );
      });
  }

  private getReportFileName(reportRequest: ReportRequest): Observable<string> {
    let fileName = this.reportTypeFilenames[reportRequest.type];
    fileName += '_' + DateTimeUtils.toReportNameFormat(reportRequest.effectiveDate);
    switch (reportRequest.type) {
      case 'DETAILS':
        return of(fileName);
      case 'INSURER':
        return this.getInsurerCode(reportRequest.insurerId).pipe(
          map(insurerCode => `${fileName}_${insurerCode}`)
        );
      case 'FUND':
        return of(`${fileName}_${reportRequest.portId}`);
    }
  }

  private getInsurerCode(insurerId: number): Observable<string> {
    return this.maintenanceService.insurers$.pipe(
      map(insurers => {
        const insurer = insurers.filter(insurer => insurer.insurerId === insurerId)[0];
        return insurer.insurerCode;
      })
    );
  }
}
