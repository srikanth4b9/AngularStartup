import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import {
  MatDatepickerModule,
  MatInputModule,
  MatSelectModule,
  MatToolbarModule
} from '@angular/material';
import {
  FundSelectModule,
  InsurerSelectModule
} from '@app/modules/maintenance/modules/contracts/components';
import { VuiButtonModule } from 'vg-vui-ng/button';
import { SvgModule } from 'vg-vui-ng/svg';

import { ReportsViewComponent } from './reports-view.component';

@NgModule({
  declarations: [ReportsViewComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatToolbarModule,
    MatDatepickerModule,
    MatInputModule,
    MatSelectModule,
    VuiButtonModule,
    SvgModule,
    InsurerSelectModule,
    FundSelectModule
  ],
  exports: [ReportsViewComponent]
})
export class ReportsViewModule {}
