import { Component } from '@angular/core';

import { ReportRequestForm } from '../../models/report-request-form.model';
import { ReportType } from '../../models/report-request.model';
import { ReportService } from '../../services';

@Component({
  selector: 'rxu-reports-view',
  templateUrl: './reports-view.component.html',
  styleUrls: ['./reports-view.component.scss']
})
export class ReportsViewComponent {
  reportForm: ReportRequestForm = new ReportRequestForm();

  ReportType = ReportType;
  keys = Object.keys;

  constructor(private readonly reportService: ReportService) {}

  isReportType(type: ReportType): boolean {
    return this.reportForm.type.value === type;
  }

  exportReport() {
    console.log(JSON.stringify(this.reportForm.value));
    this.reportService.exportReport(this.reportForm.value);
  }
}
