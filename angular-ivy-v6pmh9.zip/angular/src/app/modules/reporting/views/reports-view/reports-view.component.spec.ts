import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import {
  MatDatepickerModule,
  MatInputModule,
  MatSelectModule,
  MatToolbarModule
} from '@angular/material';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import {
  InsurerSelectModule,
  FundSelectModule
} from '@app/modules/maintenance/modules/contracts/components';
import { VuiButtonModule } from 'vg-vui-ng/button';
import { SvgModule } from 'vg-vui-ng/svg';

import { ReportType } from '../../models/report-request.model';
import { MockReportService, ReportService } from '../../services';
import { ReportsViewComponent } from './reports-view.component';

describe('ReportsViewComponent', () => {
  let component: ReportsViewComponent;
  let fixture: ComponentFixture<ReportsViewComponent>;
  let reportService: MockReportService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ReportsViewComponent],
      imports: [
        NoopAnimationsModule,
        ReactiveFormsModule,
        MatToolbarModule,
        MatDatepickerModule,
        MatMomentDateModule,
        MatInputModule,
        MatSelectModule,
        VuiButtonModule,
        SvgModule,
        InsurerSelectModule,
        FundSelectModule
      ],
      providers: [{ provide: ReportService, useValue: new MockReportService() }]
    }).compileComponents();

    reportService = TestBed.get(ReportService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportsViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  function reportTypeTest(type: ReportType) {
    it(`should return true when the report form type matches the given type ${type}`, () => {
      component.reportForm.type.setValue(type);
      expect(component.isReportType(type)).toBe(true);
    });
  }

  describe('isReportType', () => {
    reportTypeTest('DETAILS');
    reportTypeTest('INSURER');
    reportTypeTest('FUND');
  });

  describe('exportReport', () => {
    it('should call report service to export data', () => {
      component.exportReport();

      expect(reportService.exportReport).toHaveBeenCalledWith(component.reportForm.value);
    });
  });
});
