import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeViewComponent, DetailsViewComponent } from '@home/views';

const routes: Routes = [
  {
    path: '',
    component: HomeViewComponent
  },
  {
    path: ':creditRateResetId',
    component: DetailsViewComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomeRoutingModule { }
