import { ContractAssetForm } from './rate-reset-asset-form.model';
import { mockContractAssets } from './mock-json';

describe('ContractAssetForm', () => {
  let assetForm: ContractAssetForm;

  describe('constructor', () => {
    it('should create controls for a new Rate Reset', async () => {
      assetForm = new ContractAssetForm();
      expect(assetForm).toBeDefined();
    });
  });

  describe('Control Getters', () => {
    beforeEach(function () {
      assetForm = new ContractAssetForm(mockContractAssets[0]);
    });

    formControlGetterTest('key');
    formControlGetterTest('weightedRatio');
    formControlGetterTest('weightedYield');
    formControlGetterTest('weightedDuration');
    formControlGetterTest('marketValue');
    formControlGetterTest('marketValueOverride');
    formControlGetterTest('yield');
    formControlGetterTest('netYield');
    formControlGetterTest('duration');
    formControlGetterTest('expenseRatio');

    it(`should create a control getter for assetId`, async () => {
      expect(assetForm.assetId.value).toEqual(mockContractAssets[0].key.assetId);
    });
  });

  function formControlGetterTest(controlName: string) {
    it(`should create a control getter for ${controlName}`, async () => {
      expect(assetForm[controlName].value).toEqual(mockContractAssets[0][controlName]);
    });
  }
});
