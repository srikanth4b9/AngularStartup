import { RateReset } from '../rate-reset.model';

export const mockResetStatusViolation: RateReset = {
  contractId: 'AG1644144',
  creditRateResetId: 0,
  insurerCode: 'AG',
  portIdList: ['853'],
  rateEffectiveDate: '2019-07-01',
  status: 'NOT_CALCULATED',
  workflowType: 'PROVIDE_RATES',
  marketValueAsOfDate: '2019-07-01',
  netRate: 0,
  priorRate: 0,
  insurerRate: 0,
  insurerDiff: 0,
  insurerDiffViolated: true,
  netChange: 0,
  approvalUserId: 'Bob',
  crewUserId: 'System',
  lastUpdatedTimestamp: '2019-07-01',
  accountingAsOfDate: '2019-07-02',
  includeWrapFee: true,
  wrapFee: 0.001
};
