import { ContractAsset } from '../rate-reset-asset.model';

export const mockContractAssets: ContractAsset[] =
  [
    {
      key: {
        assetId: '465',
      },
      weightedRatio: 0.59964,
      weightedYield: 2.08023,
      weightedDuration: 2.38477,
      marketValue: 36827909.01,
      marketValueOverride: false,
      yield: 0.034691254,
      netYield: 0.034491254,
      duration: 3.977003278,
      expenseRatio: 0.0002
    },
    {
      key: {
        assetId: '472'
      },
      weightedRatio: 0.40036,
      weightedYield: 1.25552,
      weightedDuration: 0.72937,
      marketValue: 24588447.30,
      marketValueOverride: false,
      yield: 0.031359847,
      netYield: 0.031159847,
      duration: 1.821781855,
      expenseRatio: 0.0002
    }
  ];
