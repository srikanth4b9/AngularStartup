import { FormGroup, FormControl, Validators, AbstractControl } from '@angular/forms';
import { ContractAsset } from './rate-reset-asset.model';

export class ContractAssetForm extends FormGroup {
  /* istanbul ignore next */
  constructor(underlyingAsset: ContractAsset = new ContractAsset()) {
    super({
      key: new FormGroup({
        assetId: new FormControl(underlyingAsset.key.assetId, Validators.required)
      }),
      weightedRatio: new FormControl(underlyingAsset.weightedRatio),
      weightedYield: new FormControl(underlyingAsset.weightedYield),
      weightedDuration: new FormControl(underlyingAsset.weightedDuration),
      marketValue: new FormControl(underlyingAsset.marketValue, {updateOn: 'blur'}),
      marketValueOverride: new FormControl(underlyingAsset.marketValueOverride),
      yield: new FormControl(underlyingAsset.yield),
      netYield: new FormControl(underlyingAsset.netYield),
      duration: new FormControl(underlyingAsset.duration),
      expenseRatio: new FormControl(underlyingAsset.expenseRatio)
    });
  }

  get key(): AbstractControl { return this.get('key'); }
  get assetId(): AbstractControl { return this.key.get('assetId'); }
  get weightedRatio(): AbstractControl { return this.get('weightedRatio'); }
  get weightedYield(): AbstractControl { return this.get('weightedYield'); }
  get weightedDuration(): AbstractControl { return this.get('weightedDuration'); }
  get marketValue(): AbstractControl { return this.get('marketValue'); }
  get marketValueOverride(): AbstractControl { return this.get('marketValueOverride'); }
  get yield(): AbstractControl { return this.get('yield'); }
  get netYield(): AbstractControl { return this.get('netYield'); }
  get duration(): AbstractControl { return this.get('duration'); }
  get expenseRatio(): AbstractControl { return this.get('expenseRatio'); }
}
