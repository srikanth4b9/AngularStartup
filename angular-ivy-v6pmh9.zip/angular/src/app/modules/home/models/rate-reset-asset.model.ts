import { ColumnDef, ColumnDefBuilder, ColumnType, InputDef } from '@app/shared/models';
import { UpdateAction } from './rate-reset.model';

export class ContractAssetKey {
  assetId: string;
}

export class ContractAsset {
  key: ContractAssetKey = new ContractAssetKey();
  weightedRatio: number;
  weightedYield: number;
  weightedDuration: number;
  marketValue?: number;
  marketValueOverride: boolean;
  yield: number;
  netYield: number;
  duration: number;
  expenseRatio?: number;
  lastUpdatedTimestamp?: string;
}

export const resetAssetTableDef: ColumnDef[] = [
  new ColumnDefBuilder('Asset ID', 'assetId', ColumnType.STRING).build(),
  new ColumnDefBuilder('Market Value', 'marketValue', ColumnType.CURRENCY)
    .editable(new InputDef(UpdateAction.ASSET_MARKET_VALUE, 'marketValueOverride'))
    .build(),
  new ColumnDefBuilder('Weighted Ratio', 'weightedRatio', ColumnType.PERCENT).build(),
  new ColumnDefBuilder('Weighted Yield', 'weightedYield', ColumnType.PERCENT).build(),
  new ColumnDefBuilder('Weighted Duration', 'weightedDuration', ColumnType.NUMBER).build(),
  new ColumnDefBuilder('Expense Ratio', 'expenseRatio', ColumnType.PERCENT).build()
];
