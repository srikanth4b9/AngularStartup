import { ContractAsset } from './rate-reset-asset.model';

export class RateReset {
  creditRateResetId: number;
  insurerCode: string;
  contractId: string;
  portIdList: string[];
  status: ResetStatus = 'NOT_CALCULATED';
  workflowType: WorkflowType;
  rateEffectiveDate: string;
  includeWrapFee: boolean;
  insurerDiffViolated: boolean;
  wrapFee?: number;
  rateResetProcessType?: string;
  netRate?: number;
  priorRate?: number;
  insurerRate?: number;
  insurerDiff?: number;
  netChange?: number;
  approvalUserId?: string;
  crewUserId?: string;
  lastUpdatedTimestamp?: string;
  accountingAsOfDate?: string;
  marketValueAsOfDate?: string;
  bookValue?: number;
  bookValueOverride?: boolean;
  durationAdjustmentFactor?: number;
  marketValue?: number;
  duration?: number;
  yieldToMaturity?: number;
  grossRate?: number;
  wrapFeeOverride?: boolean;
  netRateOverride?: boolean;
  contractAssetCalculations?: ContractAsset[];
}

export class AdhocRateReset {
  insurerCode: string;
  contractId: string;
  rateEffectiveDate: string;
  accountingAsOfDate: string;
  marketValueAsOfDate: string;
}

export enum UpdateAction {
  NET_RATE = 'NET_RATE',
  INSURER_RATE = 'INSURER_RATE',
  BOOK_VALUE = 'BOOK_VALUE',
  WRAP_FEE = 'WRAP_FEE',
  ASSET_MARKET_VALUE = 'ASSET_MARKET_VALUE',
  EFFECTIVE_DATE = 'EFFECTIVE_DATE',
  ACCOUNTING_AS_OF_DATE = 'ACCOUNTING_AS_OF_DATE',
  MARKET_VALUE_AS_OF_DATE = 'MARKET_VALUE_AS_OF_DATE',
  YIELD = 'YIELD',
  DURATION = 'DURATION'
}
export class AttributeUpdateRequest<T> {
  object: T;
  action: UpdateAction;
}

export type ResetStatus =
  | 'NOT_CALCULATED'
  | 'MISSING_DATA'
  | 'PENDING'
  | 'MANUAL_OVERRIDE'
  | 'APPROVED'
  | 'REJECTED'
  | 'SENT'
  | 'NONE';
export const ResetStatusLabels = {
  NOT_CALCULATED: 'Not Calculated',
  MISSING_DATA: 'Missing Data',
  PENDING: 'Pending',
  MANUAL_OVERRIDE: 'Manual Override',
  APPROVED: 'Approved',
  REJECTED: 'Rejected',
  SENT: 'Sent',
  NONE: 'None'
};

export const StatusBadgeClasses = {
  NOT_CALCULATED: 'badge-secondary',
  NONE: 'badge-secondary',
  MANUAL_OVERRIDE: 'badge-primary',
  PENDING: 'badge-info',
  MISSING_DATA: 'badge-warning',
  SENT: 'badge-success',
  APPROVED: 'badge-success',
  REJECTED: 'badge-danger'
};

export type RateResetProcessType = 'STANDARD' | 'AD_HOC';
type WorkflowType = 'CONFIRM_RATES' | 'ENTER_RATES' | 'PROVIDE_RATES' | 'NONE';
