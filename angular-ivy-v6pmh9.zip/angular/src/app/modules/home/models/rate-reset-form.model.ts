import { AbstractControl, FormArray, FormControl, FormGroup, Validators } from '@angular/forms';
import { BehaviorSubject, Observable } from 'rxjs';

import { ContractAssetForm } from './rate-reset-asset-form.model';
import { RateReset } from './rate-reset.model';
import { ACTION } from '@app/shared';

type ResetStatus =
  | 'NOT_CALCULATED'
  | 'MISSING_DATA'
  | 'PENDING'
  | 'MANUAL_OVERRIDE'
  | 'APPROVED'
  | 'REJECTED'
  | 'SENT'
  | 'NONE';
type WorkflowType = 'CONFIRM_RATES' | 'ENTER_RATES' | 'PROVIDE_RATES' | 'NONE';

export const allowedActionsByStatus: { [key: string]: ACTION[] } = {
  NOT_CALCULATED: [],
  MISSING_DATA: [ACTION.REJECT],
  PENDING: [ACTION.APPROVE, ACTION.REJECT],
  MANUAL_OVERRIDE: [ACTION.APPROVE, ACTION.REJECT],
  APPROVED: [ACTION.REVERT],
  REJECTED: [ACTION.REVERT],
  SENT: [],
  NONE: []
};

export class RateResetForm extends FormGroup {
  private readonly actionOptions: BehaviorSubject<ACTION[]> = new BehaviorSubject([]);
  actionOptions$: Observable<ACTION[]>;

  /* istanbul ignore next */
  constructor(rateReset: RateReset = new RateReset()) {
    super({
      creditRateResetId: new FormControl(rateReset.creditRateResetId, Validators.required),
      insurerCode: new FormControl(rateReset.insurerCode, Validators.required),
      contractId: new FormControl(rateReset.contractId, Validators.required),
      portIdList: new FormControl(rateReset.portIdList),
      status: new FormControl(rateReset.status),
      workflowType: new FormControl(rateReset.workflowType),
      rateEffectiveDate: new FormControl(rateReset.rateEffectiveDate, { updateOn: 'blur' }),
      accountingAsOfDate: new FormControl(rateReset.accountingAsOfDate, { updateOn: 'blur' }),
      marketValueAsOfDate: new FormControl(rateReset.marketValueAsOfDate, { updateOn: 'blur' }),
      rateResetProcessType: new FormControl(rateReset.rateResetProcessType),
      netRate: new FormControl(rateReset.netRate, { updateOn: 'blur' }),
      netRateOverride: new FormControl(rateReset.netRateOverride),
      grossRate: new FormControl(rateReset.grossRate),
      priorRate: new FormControl(rateReset.priorRate),
      insurerRate: new FormControl(rateReset.insurerRate, { updateOn: 'blur' }),
      insurerDiff: new FormControl(rateReset.insurerDiff),
      insurerDiffViolated: new FormControl(rateReset.insurerDiffViolated),
      netChange: new FormControl(rateReset.netChange),
      marketValue: new FormControl(rateReset.marketValue),
      bookValue: new FormControl(rateReset.bookValue, { updateOn: 'blur' }),
      bookValueOverride: new FormControl(rateReset.bookValueOverride),
      duration: new FormControl(rateReset.duration),
      yieldToMaturity: new FormControl(rateReset.yieldToMaturity),
      durationAdjustmentFactor: new FormControl(rateReset.durationAdjustmentFactor),
      wrapFee: new FormControl(rateReset.wrapFee),
      approvalUserId: new FormControl(rateReset.approvalUserId),
      crewUserId: new FormControl(rateReset.crewUserId),
      lastUpdatedTimestamp: new FormControl(rateReset.lastUpdatedTimestamp),
      contractAssetCalculations: new FormArray(
        (rateReset.contractAssetCalculations || []).map(asset => new ContractAssetForm(asset))
      )
    });

    this.actionOptions$ = this.actionOptions.asObservable();
    this.actionOptions.next(allowedActionsByStatus[this.resetStatus.value]);
  }

  get creditRateResetId(): AbstractControl {
    return this.get('creditRateResetId');
  }
  get insurerCode(): AbstractControl {
    return this.get('insurerCode');
  }
  get contractId(): AbstractControl {
    return this.get('contractId');
  }
  get portIdList(): AbstractControl {
    return this.get('portIdList');
  }
  get resetStatus(): AbstractControl {
    return this.get('status');
  }
  get workflowType(): AbstractControl {
    return this.get('workflowType');
  }
  get rateEffectiveDate(): AbstractControl {
    return this.get('rateEffectiveDate');
  }
  get accountingAsOfDate(): AbstractControl {
    return this.get('accountingAsOfDate');
  }
  get marketValueAsOfDate(): AbstractControl {
    return this.get('marketValueAsOfDate');
  }
  get rateResetProcessType(): AbstractControl {
    return this.get('rateResetProcessType');
  }
  get netRate(): AbstractControl {
    return this.get('netRate');
  }
  get netRateOverride(): AbstractControl {
    return this.get('netRateOverride');
  }
  get grossRate(): AbstractControl {
    return this.get('grossRate');
  }
  get priorRate(): AbstractControl {
    return this.get('priorRate');
  }
  get insurerRate(): AbstractControl {
    return this.get('insurerRate');
  }
  get insurerDiff(): AbstractControl {
    return this.get('insurerDiff');
  }
  get insurerDiffViolated(): AbstractControl {
    return this.get('insurerDiffViolated');
  }
  get netChange(): AbstractControl {
    return this.get('netChange');
  }
  get marketValue(): AbstractControl {
    return this.get('marketValue');
  }
  get bookValue(): AbstractControl {
    return this.get('bookValue');
  }
  get bookValueOverride(): AbstractControl {
    return this.get('bookValueOverride');
  }
  get duration(): AbstractControl {
    return this.get('duration');
  }
  get yieldToMaturity(): AbstractControl {
    return this.get('yieldToMaturity');
  }
  get durationAdjustmentFactor(): AbstractControl {
    return this.get('durationAdjustmentFactor');
  }
  get wrapFee(): AbstractControl {
    return this.get('wrapFee');
  }
  get wrapFeeOverride(): AbstractControl {
    return this.get('wrapFeeOverride');
  }
  get approvalUserId(): AbstractControl {
    return this.get('approvalUserId');
  }
  get crewUserId(): AbstractControl {
    return this.get('crewUserId');
  }
  get lastUpdatedTimestamp(): AbstractControl {
    return this.get('lastUpdatedTimestamp');
  }
  get contractAssetCalculations(): FormArray {
    return this.get('contractAssetCalculations') as FormArray;
  }

  get isAdhoc(): boolean {
    return this.rateResetProcessType.value === 'AD_HOC';
  }
}

export class AdhocRateResetForm extends FormGroup {
  /* istanbul ignore next */
  constructor() {
    super({
      insurerId: new FormControl(null, Validators.required),
      contractId: new FormControl(null, Validators.required),
      rateEffectiveDate: new FormControl(null, Validators.required),
      accountingAsOfDate: new FormControl(null, Validators.required),
      marketValueAsOfDate: new FormControl(null, Validators.required)
    });

    this.insurerId.valueChanges.subscribe(() => {
      this.contractId.reset();
    });
  }

  get insurerId(): AbstractControl {
    return this.get('insurerId');
  }
  get contractId(): AbstractControl {
    return this.get('contractId');
  }
  get rateEffectiveDate(): AbstractControl {
    return this.get('rateEffectiveDate');
  }
  get accountingAsOfDate(): AbstractControl {
    return this.get('accountingAsOfDate');
  }
  get marketValueAsOfDate(): AbstractControl {
    return this.get('marketValueAsOfDate');
  }
}
