import { ACTION } from '@app/shared';

import { mockRateResetList } from './mock-json';
import { AdhocRateResetForm, RateResetForm } from './rate-reset-form.model';
import { ResetStatus } from './rate-reset.model';

describe('RateResetForm', () => {
  let rateResetForm: RateResetForm;

  describe('constructor', () => {
    it('should create controls for a new Rate Reset', async () => {
      rateResetForm = new RateResetForm();
      expect(rateResetForm).toBeDefined();
    });

    it('should create controls for a Rate Reset', async () => {
      rateResetForm = new RateResetForm(mockRateResetList[0]);
      expect(rateResetForm).toBeDefined();
      expect(rateResetForm.netRate.value).toEqual(mockRateResetList[0].netRate);
    });
  });

  describe('actionOptions$', () => {
    function actionOptionsTest(status: ResetStatus, expectedOptions: ACTION[]) {
      it(`should return ${expectedOptions} for ${status} status`, () => {
        mockRateResetList[0].status = status;
        rateResetForm = new RateResetForm(mockRateResetList[0]);
        rateResetForm.actionOptions$.subscribe(options => expect(options).toEqual(expectedOptions));
      });
    }

    actionOptionsTest('NOT_CALCULATED', []);
    actionOptionsTest('MISSING_DATA', [ACTION.REJECT]);
    actionOptionsTest('PENDING', [ACTION.APPROVE, ACTION.REJECT]);
    actionOptionsTest('MANUAL_OVERRIDE', [ACTION.APPROVE, ACTION.REJECT]);
    actionOptionsTest('APPROVED', [ACTION.REVERT]);
    actionOptionsTest('REJECTED', [ACTION.REVERT]);
    actionOptionsTest('SENT', []);
    actionOptionsTest('NONE', []);
  });
});

describe('AdhocRateResetForm', () => {
  let adhocRateResetForm: AdhocRateResetForm;
  beforeEach(() => {
    adhocRateResetForm = new AdhocRateResetForm();
  });

  describe('constructor', () => {
    it('should create controls for a new Ad hoc Rate Reset', async () => {

      expect(adhocRateResetForm).toBeDefined();
    });
  });

  describe('Control Getters', () => {
    beforeEach(function () {
      adhocRateResetForm = new AdhocRateResetForm();
    });

    formControlGetterTest('insurerId');
    formControlGetterTest('contractId');
    formControlGetterTest('rateEffectiveDate');
    formControlGetterTest('accountingAsOfDate');
    formControlGetterTest('marketValueAsOfDate');
  });

  function formControlGetterTest(controlName: string) {
    it(`should create a control getter for ${controlName}`, async () => {
      expect(adhocRateResetForm[controlName]).toEqual(adhocRateResetForm.get(controlName));
    });
  }

  describe('insurerId value change', () => {
    it('should reset contract ID control when Insurer ID changes', async () => {
      adhocRateResetForm.contractId.setValue('AG1907452');
      adhocRateResetForm.patchValue({
        insurerId: 1234
      });

      expect(adhocRateResetForm.contractId.value).toEqual(null);
    });
  });
});
