import { ColumnDef, ColumnDefBuilder, ColumnType, InputDef, TableDef } from '@app/shared/models';

import { UpdateAction } from './rate-reset.model';

const insurerCodeColumn = new ColumnDefBuilder(
  'Insurer Code',
  'insurerCode',
  ColumnType.STRING
).build();
const contractIdColumn = new ColumnDefBuilder(
  'Contract ID',
  'contractId',
  ColumnType.CONTRACT_ID
).build();
const portIdColumn = new ColumnDefBuilder('Port ID', 'portIdList', ColumnType.STRING).build();
const statusColumn = new ColumnDefBuilder('Status', 'resetStatus', ColumnType.STATUS).build();
const workflowTypeColumn = new ColumnDefBuilder(
  'Workflow',
  'workflowType',
  ColumnType.WORKFLOW_TYPE
).build();
const effectiveDateColumn = new ColumnDefBuilder(
  'Effective Date',
  'rateEffectiveDate',
  ColumnType.DATE
)
  .editable(new InputDef(UpdateAction.EFFECTIVE_DATE))
  .build();
const asOfDateColumn = new ColumnDefBuilder('As-Of Date', 'accountingAsOfDate', ColumnType.DATE)
  .editable(new InputDef(UpdateAction.ACCOUNTING_AS_OF_DATE))
  .build();
const netRateColumn = new ColumnDefBuilder('Net Rate', 'netRate', ColumnType.PERCENT)
  .editable(new InputDef(UpdateAction.NET_RATE, 'netRateOverride'))
  .build();
const priorRateColumn = new ColumnDefBuilder('Prior Rate', 'priorRate', ColumnType.PERCENT).build();
const insurerRateColumn = new ColumnDefBuilder('Insurer Rate', 'insurerRate', ColumnType.PERCENT)
  .editable(new InputDef(UpdateAction.INSURER_RATE))
  .build();
const insurerDiffColumn = new ColumnDefBuilder(
  'Insurer Rate Diff',
  'insurerDiff',
  ColumnType.PERCENT
)
  .violationFlag('Insurer Rate Diff Violation', 'insurerDiffViolated')
  .build();
const netChangeColumn = new ColumnDefBuilder('Net Change', 'netChange', ColumnType.PERCENT).build();
const approvalUserIdColumn = new ColumnDefBuilder(
  'Approved By',
  'approvalUserId',
  ColumnType.STRING
).build();
const crewUserIdColumn = new ColumnDefBuilder(
  'Last Updated By',
  'crewUserId',
  ColumnType.SYSTEM_FILTERED_STRING
).build();
const lastUpdatedTimestampColumn = new ColumnDefBuilder(
  'Last Updated Timestamp',
  'lastUpdatedTimestamp',
  ColumnType.DATE
)
  .format('MM/dd/yyyy hh:mm a')
  .build();
const accountingAsOfDateColumn = new ColumnDefBuilder(
  'Accounting As-Of Date',
  'accountingAsOfDate',
  ColumnType.DATE
)
  .editable(new InputDef(UpdateAction.ACCOUNTING_AS_OF_DATE))
  .build();
const marketValueAsOfDateColumn = new ColumnDefBuilder(
  'Market Value As-Of Date',
  'marketValueAsOfDate',
  ColumnType.DATE
)
  .editable(new InputDef(UpdateAction.MARKET_VALUE_AS_OF_DATE))
  .build();
const grossRateColumn = new ColumnDefBuilder('Gross Rate', 'grossRate', ColumnType.PERCENT).build();
const marketValueColumn = new ColumnDefBuilder(
  'Market Value',
  'marketValue',
  ColumnType.CURRENCY
).build();
const bookValueColumn = new ColumnDefBuilder('Book Value', 'bookValue', ColumnType.CURRENCY)
  .editable(new InputDef(UpdateAction.BOOK_VALUE, 'bookValueOverride'))
  .build();
const durationColumn = new ColumnDefBuilder('Duration', 'duration', ColumnType.NUMBER).build();
const yieldToMaturityColumn = new ColumnDefBuilder(
  'Yield (YTM)',
  'yieldToMaturity',
  ColumnType.PERCENT
).build();
const durationAdjustmentFactorColumn = new ColumnDefBuilder(
  'Adjustment Factor',
  'durationAdjustmentFactor',
  ColumnType.PERCENT
).build();
const wrapFeeColumn = new ColumnDefBuilder('Wrap Fee', 'wrapFee', ColumnType.PERCENT).build();

export class RateResetSummaryTableDef extends TableDef {
  constructor() {
    super(
      [
        insurerCodeColumn,
        contractIdColumn,
        portIdColumn,
        statusColumn,
        workflowTypeColumn,
        effectiveDateColumn,
        asOfDateColumn,
        netRateColumn,
        priorRateColumn,
        insurerRateColumn,
        insurerDiffColumn,
        netChangeColumn,
        approvalUserIdColumn,
        crewUserIdColumn,
        lastUpdatedTimestampColumn
      ],
      true
    );
  }
}

export const resetHeaderSectionDef: ColumnDef[] = [
  insurerCodeColumn,
  contractIdColumn,
  portIdColumn,
  workflowTypeColumn,
  effectiveDateColumn,
  accountingAsOfDateColumn,
  marketValueAsOfDateColumn,
  statusColumn,
  approvalUserIdColumn,
  crewUserIdColumn,
  lastUpdatedTimestampColumn
];

export const resetCreditingRatesSectionDef: ColumnDef[] = [
  netRateColumn,
  grossRateColumn,
  priorRateColumn,
  insurerRateColumn,
  insurerDiffColumn,
  netChangeColumn
];

export const resetDetailsSectionDef: ColumnDef[] = [
  marketValueColumn,
  bookValueColumn,
  durationColumn,
  yieldToMaturityColumn,
  durationAdjustmentFactorColumn,
  wrapFeeColumn
];
