import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HomeRoutingModule } from './home-routing.module';
import { HomeViewModule } from './views/home-view/home-view.module';
import { DetailsViewModule } from './views';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    HomeRoutingModule,
    HomeViewModule,
    DetailsViewModule
  ]
})
export class HomeModule { }
