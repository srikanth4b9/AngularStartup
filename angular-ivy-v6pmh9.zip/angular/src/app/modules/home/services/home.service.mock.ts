import { mockRateResetList, RateReset } from '@home/models';
import { of, Observable } from 'rxjs';
import { } from 'jasmine';

export class MockHomeService {
  rateResets$: Observable<RateReset[]> = of(mockRateResetList);
  getRateResets = jasmine.createSpy().and.callFake(() => this.rateResets$);
  getRateReset = jasmine.createSpy().and.returnValue(of(mockRateResetList[0]));
  calculateRateResets = jasmine.createSpy().and.returnValue(of({}));
  recalculateRateReset = jasmine.createSpy().and.returnValue(of({}));
  recalculateRateResetsForContract = jasmine.createSpy().and.returnValue(of({}));
  recalculateRateResetsForAsset = jasmine.createSpy().and.returnValue(of({}));
  updateRateResetApprovalStatus = jasmine.createSpy().and.returnValue(of({}));
  createAdhocRateReset = jasmine.createSpy().and.returnValue(of({}));
}
