import { Injectable } from '@angular/core';
import { RestService } from '@app/services';
import { ActionRequest } from '@app/shared';
import { environment } from '@env';
import { AdhocRateReset, RateReset, RateResetForm, AttributeUpdateRequest } from '@home/models';
import { BehaviorSubject, Observable } from 'rxjs';
import { finalize, tap } from 'rxjs/operators';

const DEFAULT_DAY_OFFSET = 45;

@Injectable({
  providedIn: 'root'
})
export class HomeService {
  private readonly rateResetsSubject: BehaviorSubject<RateReset[]> = new BehaviorSubject(undefined);
  rateResets$: Observable<RateReset[]> = this.rateResetsSubject.asObservable();
  dayOffset = DEFAULT_DAY_OFFSET;

  constructor(private readonly restService: RestService) {}

  getRateResets(dayOffset: number = this.dayOffset): void {
    this.dayOffset = dayOffset;
    this.restService
      .getData<RateReset[]>('Load Rate Resets', `${environment.RATE_RESET_URI}?offset=${dayOffset}`)
      .pipe(tap(data => this.rateResetsSubject.next(data)))
      .subscribe();
  }

  calculateRateResets(): void {
    this.restService
      .postData<any>('Calculate Rate Resets', environment.RATE_RESET_URI, {})
      .subscribe(() => this.getRateResets());
  }

  recalculateRateReset(recalcRequest: AttributeUpdateRequest<RateReset>): void {
    this.restService
      .putData<any>(
        'Recalculate Rate Reset',
        `${environment.RATE_RESET_URI}/${recalcRequest.object.creditRateResetId}?action=${recalcRequest.action}`,
        recalcRequest.object
      )
      .pipe(finalize(() => this.getRateResets()))
      .subscribe();
  }

  recalculateRateResetsForContract(contractId: string): void {
    this.restService
      .putData<any>(
        'Recalculate Rate Resets',
        `${environment.RATE_RESET_URI}?contractId=${contractId}&action=REINITIATE`,
        {}
      )
      .pipe(finalize(() => this.getRateResets()))
      .subscribe();
  }

  recalculateRateResetsForAsset(assetId: string): void {
    this.restService
      .putData<any>(
        'Recalculate Rate Resets',
        `${environment.RATE_RESET_URI}?assetId=${assetId}&action=REINITIATE`,
        {}
      )
      .pipe(finalize(() => this.getRateResets()))
      .subscribe();
  }

  updateRateResetApprovalStatus(approvalRequest: ActionRequest<RateResetForm>): void {
    const title = `${approvalRequest.action.charAt(0)}${approvalRequest.action
      .slice(1)
      .toLowerCase()} Rate Reset`;
    this.restService
      .putData<any>(
        title,
        // tslint:disable-next-line:max-line-length
        `${environment.RATE_RESET_URI}/${
          approvalRequest.object.creditRateResetId.value
        }/approval-status?action=${approvalRequest.action.toUpperCase()}`,
        {}
      )
      .subscribe(() => this.getRateResets());
  }

  createAdhocRateReset(rateReset: AdhocRateReset): void {
    this.restService
      .postData<any>('Create Ad Hoc Rate Reset', environment.RATE_RESET_URI, rateReset)
      .subscribe(() => this.getRateResets());
  }
}
