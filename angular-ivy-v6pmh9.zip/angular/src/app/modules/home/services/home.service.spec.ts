import { TestBed } from '@angular/core/testing';
import { RestService } from '@app/services';
import { ACTION, ActionRequest } from '@app/shared';
import { environment } from '@env';
import {
  AdhocRateReset,
  mockRateResetList,
  UpdateAction,
  AttributeUpdateRequest,
  RateResetForm,
  RateReset
} from '@home/models';
import { of } from 'rxjs';

import { HomeService } from './home.service';
import { MockRestService } from '@app/services/rest-service/rest.service.mock';
import { mockContractsData } from '@app/modules/maintenance/modules/contracts/models';
import { mockUnderlyingAssets } from '@app/modules/maintenance/modules/underlying-assets/models';

const dayOffset: number = 60;
const creditRateResetId: number = mockRateResetList[0].creditRateResetId;
const recalculateAction: UpdateAction = UpdateAction.NET_RATE;
const approveAction: ACTION = ACTION.APPROVE;
const API = {
  rateReset: environment.RATE_RESET_URI,
  putRateReset: `${environment.RATE_RESET_URI}/${creditRateResetId}?action=${recalculateAction}`,
  approveRateReset: `${
    environment.RATE_RESET_URI
  }/${creditRateResetId}/approval-status?action=${approveAction.toUpperCase()}`
};

describe('HomeService', () => {
  let service: HomeService;
  let restService: MockRestService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [{ provide: RestService, useValue: new MockRestService() }]
    });

    service = TestBed.get(HomeService);
    restService = TestBed.get(RestService);
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    restService.getData.and.callFake((_, apiPath) => {
      if (apiPath.indexOf(API.rateReset) !== -1) {
        return of(mockRateResetList);
      } else {
        return of(null);
      }
    });
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('getRateResets', () => {
    it('should try to fetch the data if not loaded', () => {
      service.getRateResets(dayOffset);
      expect(service.dayOffset).toEqual(dayOffset);
      service.rateResets$.subscribe(data => {
        expect(data).toEqual(mockRateResetList);
      });

      expect(restService.getData).toHaveBeenCalledWith(
        'Load Rate Resets',
        `${API.rateReset}?offset=${dayOffset}`
      );
    });
    it('should use default day offset if not provided', () => {
      service.getRateResets();
      expect(service.dayOffset).toEqual(45);
      service.rateResets$.subscribe(data => {
        expect(data).toEqual(mockRateResetList);
      });

      expect(restService.getData).toHaveBeenCalledWith(
        'Load Rate Resets',
        `${API.rateReset}?offset=45`
      );
    });
  });

  describe('Update Rate Resets', () => {
    let getRateResetsSpy: jasmine.Spy;

    beforeEach(function() {
      getRateResetsSpy = spyOn(service, 'getRateResets');
    });

    describe('calculateRateResets', () => {
      it('should make a post call', () => {
        service.calculateRateResets();

        expect(restService.postData).toHaveBeenCalledWith(
          'Calculate Rate Resets',
          API.rateReset,
          {}
        );
        expect(getRateResetsSpy).toHaveBeenCalled();
      });
    });

    describe('calculateRateResets', () => {
      it('should make a post call', () => {
        service.calculateRateResets();

        expect(restService.postData).toHaveBeenCalledWith(
          'Calculate Rate Resets',
          API.rateReset,
          {}
        );
        expect(getRateResetsSpy).toHaveBeenCalled();
      });
    });

    describe('recalculateRateReset', () => {
      it('should make a put call', () => {
        const expectedRequest: AttributeUpdateRequest<RateReset> = {
          object: mockRateResetList[0],
          action: recalculateAction
        };

        service.recalculateRateReset(expectedRequest);

        expect(restService.putData).toHaveBeenCalledWith(
          'Recalculate Rate Reset',
          API.putRateReset,
          expectedRequest.object
        );
        expect(getRateResetsSpy).toHaveBeenCalled();
      });
    });

    describe('recalculateRateResetsForContract', () => {
      it('should make a put call to reinitiate rate resets for a given contract ID', () => {
        const contractId = mockContractsData[0].contractId;

        service.recalculateRateResetsForContract(contractId);

        expect(restService.putData).toHaveBeenCalledWith(
          'Recalculate Rate Resets',
          `${environment.RATE_RESET_URI}?contractId=${contractId}&action=REINITIATE`,
          {}
        );
        expect(getRateResetsSpy).toHaveBeenCalled();
      });
    });

    describe('recalculateRateResetsForAsset', () => {
      it('should make a put call to reinitiate rate resets for a given asset ID', () => {
        const assetId = mockUnderlyingAssets[0].assetId;

        service.recalculateRateResetsForAsset(assetId);

        expect(restService.putData).toHaveBeenCalledWith(
          'Recalculate Rate Resets',
          `${environment.RATE_RESET_URI}?assetId=${assetId}&action=REINITIATE`,
          {}
        );
        expect(getRateResetsSpy).toHaveBeenCalled();
      });
    });

    describe('updateRateResetApprovalStatus', () => {
      it('should make a put call', () => {
        const expectedRequest: ActionRequest<RateResetForm> = {
          object: new RateResetForm(mockRateResetList[0]),
          action: approveAction
        };

        service.updateRateResetApprovalStatus(expectedRequest);

        expect(restService.putData).toHaveBeenCalledWith(
          'Approve Rate Reset',
          API.approveRateReset,
          {}
        );
        expect(getRateResetsSpy).toHaveBeenCalled();
      });
    });

    describe('createAdhocRateReset', () => {
      it('should make a put call', () => {
        const rateReset: AdhocRateReset = new AdhocRateReset();

        service.createAdhocRateReset(rateReset);

        expect(restService.postData).toHaveBeenCalledWith(
          'Create Ad Hoc Rate Reset',
          API.rateReset,
          rateReset
        );
        expect(getRateResetsSpy).toHaveBeenCalled();
      });
    });
  });
});
