import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule, MatSelectModule } from '@angular/material';

import { DayOffsetSelectComponent } from './day-offset-select.component';

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatSelectModule
  ],
  declarations: [DayOffsetSelectComponent],
  exports: [DayOffsetSelectComponent]
})
export class DayOffsetSelectModule { }
