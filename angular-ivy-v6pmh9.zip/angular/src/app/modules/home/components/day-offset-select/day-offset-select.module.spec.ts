import { DayOffsetSelectModule } from './day-offset-select.module';

describe('DayOffsetSelectModule', () => {
    let dayOffsetSelectModule: DayOffsetSelectModule;

    beforeEach(() => {
        dayOffsetSelectModule = new DayOffsetSelectModule();
    });

    it('should create an instance', () => {
        expect(dayOffsetSelectModule).toBeTruthy();
    });
});
