import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule, MatSelectModule } from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';

import { DayOffsetSelectComponent } from './day-offset-select.component';

describe('DayOffsetSelectComponent', () => {
  let component: DayOffsetSelectComponent;
  let fixture: ComponentFixture<DayOffsetSelectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [DayOffsetSelectComponent],
      imports: [
        NoopAnimationsModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatSelectModule
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DayOffsetSelectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('ngOnInit:', () => {
    it('should emit selectedDayOffsetChange on change', () => {
      const selectedDayOffset = 60;
      const changeSpy = spyOn(component.selectedDayOffsetChange, 'emit');

      component.dayOffsetCtrl.setValue(selectedDayOffset);

      expect(component.selectedDayOffset).toEqual(selectedDayOffset);
      expect(changeSpy).toHaveBeenCalledWith(60);
    });

    it('should not emit selectedDayOffsetChange if there is no value', () => {
      const changeSpy = spyOn(component.selectedDayOffsetChange, 'emit');

      component.dayOffsetCtrl.setValue(undefined);

      expect(component.selectedDayOffset).toBeUndefined();
      expect(changeSpy).not.toHaveBeenCalled();
    });
  });

  it('should have the following options: 15, 30, 45, 60', () => {
    expect(component.dayOffsetOptions).toEqual([15, 30, 45, 60]);
  });
});
