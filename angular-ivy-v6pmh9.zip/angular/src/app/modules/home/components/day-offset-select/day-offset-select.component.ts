import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { FormControl } from '@angular/forms';

const OFFSET_15 = 15;
const OFFSET_30 = 30;
const OFFSET_45 = 45;
const OFFSET_60 = 60;

@Component({
  selector: 'rxu-day-offset-select',
  templateUrl: './day-offset-select.component.html',
  styleUrls: ['./day-offset-select.component.scss']
})
export class DayOffsetSelectComponent implements OnInit {
  dayOffsetOptions: number[] = [OFFSET_15, OFFSET_30, OFFSET_45, OFFSET_60];
  dayOffsetCtrl: FormControl;
  @Input() selectedDayOffset: number;
  @Output() selectedDayOffsetChange: EventEmitter<number> = new EventEmitter<
    number
  >();

  ngOnInit() {
    this.dayOffsetCtrl = new FormControl(this.selectedDayOffset);
    this.dayOffsetCtrl.valueChanges.subscribe(value => {
      this.selectedDayOffset = value;
      if (value) {
        this.selectedDayOffsetChange.emit(value);
      }
    });
  }
}
