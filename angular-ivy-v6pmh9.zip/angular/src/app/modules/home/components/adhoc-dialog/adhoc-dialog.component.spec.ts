import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { MAT_DIALOG_DATA, MatButtonModule, MatDialogModule, MatDialogRef, MatToolbarModule } from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { MaintenanceService, MockMaintenanceService } from '@app/modules/maintenance/services';
import { CustomDatepickersModule } from '@app/shared/components';
import { ContractIdSelectModule, InsurerSelectModule } from '@contracts/components';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import * as moment from 'moment';

import { AdhocDialogComponent } from './adhoc-dialog.component';


describe('AdhocDialogComponent', () => {
  let component: AdhocDialogComponent;
  let fixture: ComponentFixture<AdhocDialogComponent>;

  const mockDialogRef = {
    close: jasmine.createSpy()
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdhocDialogComponent ],
      imports: [
        HttpClientTestingModule,
        NoopAnimationsModule,
        ReactiveFormsModule,
        MatDialogModule,
        MatButtonModule,
        MatToolbarModule,
        InsurerSelectModule,
        ContractIdSelectModule,
        CustomDatepickersModule,
        FontAwesomeModule
      ],
      providers: [
        { provide: MaintenanceService, useClass: MockMaintenanceService },
        { provide: MatDialogRef, useValue: mockDialogRef },
        { provide: MAT_DIALOG_DATA, useValue: {} }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdhocDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('close:', () => {
    it('should close the dialogRef', () => {
      component.close();

      expect(mockDialogRef.close).toHaveBeenCalled();
    });
  });

  describe('createAdhocRateReset:', () => {
    it('should close the dialog with a rate reset form as data', () => {
      component.rateResetForm.rateEffectiveDate.setValue(moment());
      component.rateResetForm.accountingAsOfDate.setValue(moment());
      component.rateResetForm.marketValueAsOfDate.setValue(moment());
      component.createAdhocRateReset();

      expect(mockDialogRef.close).toHaveBeenCalledWith(component.rateResetForm.value);
    });
  });
});
