import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdhocDialogComponent } from './adhoc-dialog.component';
import {
  MatDialogModule, MatButtonModule, MatToolbarModule
} from '@angular/material';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { ContractIdSelectModule, InsurerSelectModule } from '@contracts/components';
import { ReactiveFormsModule } from '@angular/forms';
import { CustomDatepickersModule } from '@app/shared/components/custom-datepickers/custom-datepicker.module';

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatToolbarModule,
    InsurerSelectModule,
    ContractIdSelectModule,
    CustomDatepickersModule,
    FontAwesomeModule
  ],
  declarations: [AdhocDialogComponent],
  exports: [AdhocDialogComponent]
})
export class AdhocDialogModule { }
