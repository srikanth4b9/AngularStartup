import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { Moment } from 'moment';

import { AdhocRateReset, AdhocRateResetForm } from '../../models';

@Component({
  selector: 'rxu-adhoc-dialog',
  templateUrl: './adhoc-dialog.component.html',
  styleUrls: ['./adhoc-dialog.component.scss']
})
export class AdhocDialogComponent {
  rateResetForm: AdhocRateResetForm = new AdhocRateResetForm();

  constructor(private readonly dialogRef: MatDialogRef<AdhocDialogComponent>) {}

  close() {
    this.dialogRef.close();
  }

  createAdhocRateReset() {
    const adhocRateReset: AdhocRateReset = this.formatDates(
      this.rateResetForm.value
    );
    this.dialogRef.close(adhocRateReset);
  }

  formatDates(rateReset: AdhocRateReset): AdhocRateReset {
    rateReset.rateEffectiveDate = ((rateReset.rateEffectiveDate as unknown) as Moment).toISOString();
    rateReset.accountingAsOfDate = ((rateReset.accountingAsOfDate as unknown) as Moment).toISOString();
    rateReset.marketValueAsOfDate = ((rateReset.marketValueAsOfDate as unknown) as Moment).toISOString();
    return rateReset;
  }
}
