import { AdhocDialogModule } from './adhoc-dialog.module';

describe('AdhocDialogModule', () => {
    let adhocDialogModule: AdhocDialogModule;

    beforeEach(() => {
        adhocDialogModule = new AdhocDialogModule();
    });

    it('should create an instance', () => {
        expect(adhocDialogModule).toBeTruthy();
    });
});
