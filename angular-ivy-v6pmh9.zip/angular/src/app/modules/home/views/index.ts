export * from './home-view';
export * from './details-view';
