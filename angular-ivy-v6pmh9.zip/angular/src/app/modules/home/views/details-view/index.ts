export * from './details-view.component';
export * from './details-view.module';
