import { DetailsViewModule } from './details-view.module';

describe('DetailsViewModule', () => {
    let detailsViewModule: DetailsViewModule;

    beforeEach(() => {
        detailsViewModule = new DetailsViewModule();
    });

    it('should create an instance', () => {
        expect(detailsViewModule).toBeTruthy();
    });
});
