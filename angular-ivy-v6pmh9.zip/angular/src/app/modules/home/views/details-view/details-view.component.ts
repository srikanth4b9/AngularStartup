import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { WorkflowType } from '@app/modules/maintenance/modules/contracts/models';
import { ColumnDef, ActionRequest, ACTION } from '@app/shared/models';
import { faChevronLeft, IconDefinition } from '@fortawesome/free-solid-svg-icons';
import {
  RateReset,
  AttributeUpdateRequest,
  resetCreditingRatesSectionDef,
  resetDetailsSectionDef,
  resetHeaderSectionDef,
  ResetStatusLabels
} from '@home/models';
import { HomeService } from '@home/services';

import { resetAssetTableDef } from '../../models/rate-reset-asset.model';
import { RateResetForm } from '../../models/rate-reset-form.model';

@Component({
  selector: 'rxu-details-view',
  templateUrl: './details-view.component.html',
  styleUrls: ['./details-view.component.scss']
})
export class DetailsViewComponent implements OnInit {
  creditRateResetId: number;
  rateResetForm: RateResetForm;
  readonly resetHeaderSectionDef: ColumnDef[] = resetHeaderSectionDef;
  readonly resetCreditingRatesSectionDef: ColumnDef[] = resetCreditingRatesSectionDef;
  readonly resetDetailsSectionDef: ColumnDef[] = resetDetailsSectionDef;
  readonly resetAssetTableDef: ColumnDef[] = resetAssetTableDef;

  @Output() recalculate: EventEmitter<RateReset> = new EventEmitter();

  ResetStatus = ResetStatusLabels;
  WorkflowType = WorkflowType;
  faChevronLeft: IconDefinition = faChevronLeft;

  constructor(private readonly route: ActivatedRoute, private readonly homeService: HomeService) {}

  ngOnInit() {
    this.loadRateResetDetails();
  }

  loadRateResetDetails() {
    this.creditRateResetId = +this.route.snapshot.params.creditRateResetId;
    if (this.creditRateResetId) {
      this.homeService.rateResets$.subscribe(rateResets => {
        if (!rateResets) {
          this.homeService.getRateResets();
        } else {
          const rateReset = this.findRateReset(rateResets, this.creditRateResetId);
          this.rateResetForm = new RateResetForm(rateReset);
        }
      });
    }
  }

  private findRateReset(rateResets: RateReset[], creditRateResetId: number): RateReset {
    return rateResets.filter(rateReset => rateReset.creditRateResetId === creditRateResetId)[0];
  }

  recalculateRateReset(request: AttributeUpdateRequest<RateReset>): void {
    this.homeService.recalculateRateReset(request);
  }

  updateRateResetApprovalStatus(action: ACTION): void {
    this.homeService.updateRateResetApprovalStatus(new ActionRequest(action, this.rateResetForm));
  }
}
