import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatToolbarModule, MatButtonModule } from '@angular/material';

import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { RouterModule } from '@angular/router';

import { CustomCurrencyModule } from '@app/shared/pipes';
import { DetailsViewComponent } from './details-view.component';
import { InputCellModule, CustomMatCellModule, ActionSelectModule } from '@app/shared/components';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    MatButtonModule,
    MatToolbarModule,
    FontAwesomeModule,
    CustomCurrencyModule,
    InputCellModule,
    CustomMatCellModule,
    ActionSelectModule
  ],
  declarations: [DetailsViewComponent],
  exports: [DetailsViewComponent]
})
export class DetailsViewModule { }
