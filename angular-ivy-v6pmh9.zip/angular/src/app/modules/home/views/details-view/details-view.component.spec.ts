import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { MatToolbarModule } from '@angular/material';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { CustomCurrencyModule } from '@app/shared/pipes';
import { mockRateResetList, UpdateAction, AttributeUpdateRequest, RateReset } from '../../models';
import { DetailsViewComponent } from './details-view.component';
import { HomeService, MockHomeService } from '@home/services';
import { ActivatedRoute } from '@angular/router';
import { InputCellModule, CustomMatCellModule, ActionSelectModule } from '@app/shared/components';
import { of } from 'rxjs';
import { ActionRequest, ACTION } from '@app/shared';

class MockActivatedRoute {
  snapshot = { params: { creditRateResetId: undefined } };
}

describe('DetailsViewComponent', () => {
  let component: DetailsViewComponent;
  let fixture: ComponentFixture<DetailsViewComponent>;
  let activatedRoute: MockActivatedRoute;
  let homeService: MockHomeService;

  beforeEach(() => {
    activatedRoute = new MockActivatedRoute();
  });

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [DetailsViewComponent],
      imports: [
        RouterTestingModule,
        NoopAnimationsModule,
        MatToolbarModule,
        FontAwesomeModule,
        CustomCurrencyModule,
        InputCellModule,
        CustomMatCellModule,
        ActionSelectModule
      ],
      providers: [
        { provide: HomeService, useValue: new MockHomeService() },
        { provide: ActivatedRoute, useValue: activatedRoute }
      ]
    }).compileComponents();

    homeService = TestBed.get(HomeService);
  }));

  function createComponent() {
    fixture = TestBed.createComponent(DetailsViewComponent);
    component = fixture.componentInstance;
    // component.rateResetForm = new RateResetForm(mockRateResetList[0]);
    fixture.detectChanges();
  }

  function setCreditRateResetIdRoute() {
    const creditRateResetId = '117';
    activatedRoute.snapshot.params.creditRateResetId = creditRateResetId;
  }

  it('should create', () => {
    createComponent();
    expect(component).toBeTruthy();
  });

  describe('ngOnInIt', () => {
    it('should not load Rate Reset if Contract ID is not set', () => {
      createComponent();
      component.ngOnInit();

      expect(component.rateResetForm).not.toBeDefined();
    });

    it('should load Rate Reset details', () => {
      setCreditRateResetIdRoute();
      createComponent();

      component.ngOnInit();

      expect(component.rateResetForm).toBeDefined();
    });

    it('should call home service if rate reset is undefined', () => {
      homeService.rateResets$ = of(undefined);
      setCreditRateResetIdRoute();
      createComponent();

      component.ngOnInit();

      expect(homeService.getRateResets).toHaveBeenCalled();
    });
  });

  describe('Update Rate Reset', () => {
    beforeEach(function() {
      setCreditRateResetIdRoute();
      createComponent();
    });

    describe('recalculateRateReset:', () => {
      it('should recalculate Rate Resets and reload Rate Resets', () => {
        const request: AttributeUpdateRequest<RateReset> = {
          object: mockRateResetList[0],
          action: UpdateAction.NET_RATE
        };

        component.recalculateRateReset(request);

        expect(homeService.recalculateRateReset).toHaveBeenCalledWith(request);
      });
    });

    describe('updateRateResetApprovalStatus:', () => {
      it('should update Rate Reset approval status and reload Rate Resets', () => {
        component.updateRateResetApprovalStatus(ACTION.APPROVE);

        expect(homeService.updateRateResetApprovalStatus).toHaveBeenCalledWith(
          new ActionRequest(ACTION.APPROVE, component.rateResetForm)
        );
      });
    });
  });
});
