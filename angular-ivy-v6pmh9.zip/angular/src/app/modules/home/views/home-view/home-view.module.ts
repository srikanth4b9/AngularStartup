import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatToolbarModule, MatButtonModule, MatDialogModule } from '@angular/material';

import { DayOffsetSelectModule } from '@home/components';
import { CustomMatTableModule } from '@shared/components';

import { HomeViewComponent } from './home-view.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

@NgModule({
  imports: [
    CommonModule,
    MatToolbarModule,
    DayOffsetSelectModule,
    CustomMatTableModule,
    MatButtonModule,
    MatDialogModule,
    FontAwesomeModule
  ],
  declarations: [HomeViewComponent],
  exports: [HomeViewComponent]
})
export class HomeViewModule { }
