import { HomeViewModule } from './home-view.module';

describe('HomeViewModule', () => {
    let homeViewModule: HomeViewModule;

    beforeEach(() => {
        homeViewModule = new HomeViewModule();
    });

    it('should create an instance', () => {
        expect(homeViewModule).toBeTruthy();
    });
});
