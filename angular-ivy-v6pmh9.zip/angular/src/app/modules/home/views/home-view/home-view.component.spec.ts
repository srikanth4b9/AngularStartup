import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialog, MatToolbarModule } from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { MockSnackBarService } from '@app/services/snack-bar';
import { SnackBarService } from '@app/services/snack-bar/snack-bar.service';
import { ACTION, ActionRequest } from '@app/shared';
import { CustomMatTableModule } from '@app/shared/components';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { DayOffsetSelectModule } from '@home/components';
import { AdhocRateReset, mockRateResetList, RateResetForm, UpdateAction } from '@home/models';
import { HomeService, MockHomeService } from '@home/services';
import { of } from 'rxjs';

import { HomeViewComponent } from './home-view.component';

class MockDialog {
  open = jasmine.createSpy().and.returnValue({
    afterClosed: jasmine.createSpy().and.returnValue(of({}))
  });
}

describe('HomeViewComponent', () => {
  let component: HomeViewComponent;
  let fixture: ComponentFixture<HomeViewComponent>;
  let homeService: MockHomeService;
  let dialog: MockDialog;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [HomeViewComponent],
      imports: [
        RouterTestingModule,
        NoopAnimationsModule,
        MatToolbarModule,
        DayOffsetSelectModule,
        CustomMatTableModule,
        FontAwesomeModule
      ],
      providers: [
        { provide: HomeService, useValue: new MockHomeService() },
        { provide: SnackBarService, useClass: MockSnackBarService },
        { provide: MatDialog, useClass: MockDialog }
      ]
    }).compileComponents();

    homeService = TestBed.get(HomeService);
    dialog = TestBed.get(MatDialog);
  }));

  function createComponent() {
    fixture = TestBed.createComponent(HomeViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  it('should create', () => {
    createComponent();

    expect(component).toBeTruthy();
  });

  it('should use an empty array when no data is returned', () => {
    homeService.rateResets$ = of(undefined);
    createComponent();

    expect(component.rateResetData).toEqual([]);
  });

  describe('updateSelectedDayOffset:', () => {
    it('should update the selected insurer ID and navigate to the proper route', () => {
      const dayOffset: number = 15;
      createComponent();

      component.updateSelectedDayOffset(dayOffset);

      expect(component.selectedDayOffset).toBe(dayOffset);
      expect(homeService.getRateResets).toHaveBeenCalled();
    });
  });

  describe('Update Rate Reset', () => {
    beforeEach(() => {
      createComponent();
    });

    describe('calculateRateResets:', () => {
      it('should calculate Rate Resets, display snackbar success, and reload Rate Resets', () => {
        component.calculateRateResets();

        expect(homeService.calculateRateResets).toHaveBeenCalled();
      });
    });

    describe('recalculateRateReset:', () => {
      it('should recalculate Rate Resets and reload Rate Resets', () => {
        const request = {
          object: mockRateResetList[0],
          action: UpdateAction.NET_RATE
        };

        component.recalculateRateReset(request);

        expect(homeService.recalculateRateReset).toHaveBeenCalledWith(request);
      });
    });

    describe('approveRateReset:', () => {
      it('should make request to approve Rate Reset', () => {
        const request: ActionRequest<RateResetForm> = {
          object: new RateResetForm(mockRateResetList[0]),
          action: ACTION.APPROVE
        };

        component.updateRateResetApprovalStatus(request);

        expect(homeService.updateRateResetApprovalStatus).toHaveBeenCalledWith(request);
      });
    });
  });

  describe('Rate Reset Summary Columns: ', () => {
    const creditingRateColumns: string[] = [
      'As-Of Date',
      'Net Rate',
      'Prior Rate',
      'Insurer Rate',
      'Insurer Rate Diff',
      'Net Change',
      'Approved By',
      'Last Updated By',
      'Last Updated Timestamp'
    ];
    const scheduleColumns: string[] = [
      'Insurer Code',
      'Contract ID',
      'Port ID',
      'Status',
      'Workflow',
      'Effective Date'
    ];
    checkHomeviewHeaderColumns(creditingRateColumns);
    checkHomeviewHeaderColumns(scheduleColumns);
  });

  function checkHomeviewHeaderColumns(expectedColumns: string[]) {
    for (let i = 0; i < expectedColumns.length; i++) {
      const column = expectedColumns[i];
      it(`should include the column: ${column}`, () => {
        createComponent();
        const element = fixture.nativeElement;
        expect(element.querySelector('.mat-header-row').textContent).toContain(column);
      });
    }
  }

  describe('openAdhocDialog', () => {
    beforeEach(() => {
      createComponent();
    });

    it('should open the ad hoc rate reset dialog', () => {
      component.openAdhocDialog();

      expect(dialog.open).toHaveBeenCalled();
    });

    it('should call service to create an ad hoc rate reset if confirmed', () => {
      const adhocRateReset = new AdhocRateReset();
      dialog.open.and.returnValue({
        afterClosed: jasmine.createSpy().and.returnValue(of(adhocRateReset))
      });

      component.openAdhocDialog();

      expect(homeService.createAdhocRateReset).toHaveBeenCalledWith(adhocRateReset);
      expect(homeService.getRateResets).toHaveBeenCalled();
    });

    it('should do nothing if no data is returned', () => {
      dialog.open.and.returnValue({
        afterClosed: jasmine.createSpy().and.returnValue(of(undefined))
      });

      component.openAdhocDialog();

      expect(homeService.createAdhocRateReset).not.toHaveBeenCalled();
    });
  });
});
