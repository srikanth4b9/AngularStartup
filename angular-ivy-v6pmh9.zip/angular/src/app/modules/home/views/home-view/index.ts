export * from './home-view.component';
export * from './home-view.module';
