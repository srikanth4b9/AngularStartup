import { Component } from '@angular/core';
import { MatDialog, MatSortable } from '@angular/material';
import { ActionRequest } from '@app/shared';
import { faCalculator, faPlusCircle, IconDefinition } from '@fortawesome/free-solid-svg-icons';
import { AttributeUpdateRequest, RateResetSummaryTableDef, RateReset } from '@home/models';
import { HomeService } from '@home/services';

import { AdhocDialogComponent } from '../../components/adhoc-dialog/adhoc-dialog.component';
import { RateResetForm } from '../../models/rate-reset-form.model';

const DEFAULT_DAY_OFFSET = 45;

@Component({
  selector: 'rxu-home-view',
  templateUrl: './home-view.component.html',
  styleUrls: ['./home-view.component.scss']
})
export class HomeViewComponent {
  selectedDayOffset = DEFAULT_DAY_OFFSET;
  readonly tableDef = new RateResetSummaryTableDef();
  rateResetData: RateResetForm[] = [];
  rateResetSortBy: MatSortable = {
    id: 'rateEffectiveDate',
    start: 'desc',
    disableClear: true
  };
  faCalculator: IconDefinition = faCalculator;
  faPlusCircle: IconDefinition = faPlusCircle;

  constructor(private readonly homeService: HomeService, private readonly dialog: MatDialog) {
    this.getRateResets();
  }

  private getRateResets(): void {
    this.homeService.rateResets$.subscribe(
      data => (this.rateResetData = (data || []).map(rateReset => new RateResetForm(rateReset)))
    );
    this.homeService.getRateResets(this.selectedDayOffset);
  }

  updateSelectedDayOffset(dayOffset: number): void {
    this.selectedDayOffset = dayOffset;
    this.homeService.getRateResets(this.selectedDayOffset);
  }

  calculateRateResets(): void {
    this.homeService.calculateRateResets();
  }

  recalculateRateReset(request: AttributeUpdateRequest<RateReset>): void {
    this.homeService.recalculateRateReset(request);
  }

  updateRateResetApprovalStatus(request: ActionRequest<RateResetForm>): void {
    this.homeService.updateRateResetApprovalStatus(request);
  }

  openAdhocDialog() {
    const dialogRef = this.dialog.open(AdhocDialogComponent);
    dialogRef.afterClosed().subscribe(data => {
      if (data) {
        this.homeService.createAdhocRateReset(data);
      }
    });
  }
}
