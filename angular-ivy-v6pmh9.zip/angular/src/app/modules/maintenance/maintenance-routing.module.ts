import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MaintenanceTabsComponent } from './views/maintenance-tabs/maintenance-tabs.component';

export const routes: Routes = [
  {
    path: '',
    component: MaintenanceTabsComponent,
    children: [
      {
        path: '',
        redirectTo: 'insurers',
        pathMatch: 'full'
      },
      {
        path: 'insurers',
        loadChildren: () => import('./modules/insurers/insurers.module').then(m => m.InsurersModule)
      },
      {
        path: 'contracts',
        loadChildren: () =>
          import('./modules/contracts/contracts.module').then(m => m.ContractsModule)
      },
      {
        path: 'underlying-assets',
        loadChildren: () =>
          import('./modules/underlying-assets/underlying-assets.module').then(
            m => m.UnderlyingAssetsModule
          )
      },
      {
        path: 'yield-and-duration',
        loadChildren: () =>
          import('./modules/yield-and-duration/yield-and-duration.module').then(
            m => m.YieldAndDurationModule
          )
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MaintenanceRoutingModule {}
