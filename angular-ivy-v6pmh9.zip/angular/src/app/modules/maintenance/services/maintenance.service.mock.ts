import {
  Contract,
  mockContractIdList,
  mockContractsData,
  StableValueFund
} from '@contracts/models';
import { Insurer, mockInsurerList } from '@insurers/models';
import { mockUnderlyingAssets, UnderlyingAsset } from '@underlying-assets/models';
import { Observable, of } from 'rxjs';

import { mockStableValueFunds } from '../modules/contracts/models/mock-json/stable-value-funds';
import { mockYieldAndDuration } from '../modules/yield-and-duration/models/mock-json';
import { AssetYieldDuration } from '../modules/yield-and-duration/models/yield-and-duration.model';

export class MockMaintenanceService {
  insurers$: Observable<Insurer[]> = of(mockInsurerList.map(insurer => new Insurer(insurer)));
  underlyingAssets$: Observable<UnderlyingAsset[]> = of(
    mockUnderlyingAssets.map(asset => new UnderlyingAsset(asset))
  );
  yieldsDurations$: Observable<AssetYieldDuration[]> = of(mockYieldAndDuration);
  outsideFunds$: Observable<StableValueFund[]> = of(mockStableValueFunds);
  funds$: Observable<StableValueFund[]> = of(mockStableValueFunds);

  getContractDetails = jasmine.createSpy().and.returnValue(of(new Contract(mockContractsData[0])));
  getInsurers = jasmine.createSpy();
  getUnderlyingAssets = jasmine.createSpy();
  getOutsideFunds = jasmine.createSpy();
  getFunds = jasmine.createSpy();
  getYieldsDurations = jasmine.createSpy();
  getContractIds = jasmine.createSpy().and.callFake(() => of(mockContractIdList));

  resetContractIds = jasmine.createSpy();

  saveInsurer = jasmine.createSpy();
  saveContract = jasmine.createSpy().and.returnValue(of({}));
  saveUnderlyingAsset = jasmine.createSpy().and.returnValue(of({}));
  saveYieldDuration = jasmine.createSpy().and.returnValue(of({}));
  updateActiveStatus = jasmine.createSpy().and.returnValue(of({}));
}
