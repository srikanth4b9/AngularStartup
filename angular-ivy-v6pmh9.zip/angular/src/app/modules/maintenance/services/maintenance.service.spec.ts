import { TestBed } from '@angular/core/testing';
import { RestService } from '@app/services';
import {
  ContractForm,
  mockContractIdList,
  mockContractsData,
  mockStableValueFunds,
  Contract
} from '@contracts/models';
import { environment } from '@env';
import { Insurer, mockInsurerList } from '@insurers/models';
import { mockUnderlyingAssets, UnderlyingAsset } from '@underlying-assets/models';
import { of } from 'rxjs';

import { InsurerForm } from '../modules/insurers/models/forms';
import { MaintenanceService } from './maintenance.service';
import { ActionRequest, ACTION, UpdateRequest } from '@app/shared';
import { UnderlyingAssetForm } from '../modules/underlying-assets/models/forms';
import { MockRestService } from '@app/services/rest-service/rest.service.mock';
import { mockYieldAndDuration } from '../modules/yield-and-duration/models/mock-json';
import { AssetYieldDurationForm } from '../modules/yield-and-duration/models/yield-and-duration-form.model';

const insurerId: number = 1;
const contractId: string = 'MET32782';
const asOfDate = '2020-01-10';
const API = {
  insurers: environment.INSURERS_URI,
  contractIds: `${environment.INSURERS_URI}/${insurerId}${environment.CONTRACTS_URI}`,
  contracts: environment.CONTRACTS_URI,
  contractDetails: `${environment.CONTRACTS_URI}/${contractId}`,
  underlyingAssets: environment.ASSETS_URI,
  funds: environment.FUNDS_URI,
  outsideFunds: environment.OUTSIDE_FUNDS_URI,
  yieldsDurations: `${environment.YIELDS_DURATIONS_URI}/${asOfDate}`
};

describe('MaintenanceService', () => {
  let service: MaintenanceService;
  let restService: MockRestService;
  let getInsurersSpy: jasmine.Spy;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [{ provide: RestService, useValue: new MockRestService() }]
    });

    service = TestBed.get(MaintenanceService);
    restService = TestBed.get(RestService);
    // eslint-disable-next-line @typescript-eslint/no-unused-vars, complexity
    restService.getData.and.callFake((_, apiPath) => {
      if (apiPath === API.insurers) {
        return of(mockInsurerList);
      } else if (apiPath === API.contractIds) {
        return of(mockContractIdList);
      } else if (apiPath === API.underlyingAssets) {
        return of(mockUnderlyingAssets);
      } else if (apiPath === API.funds) {
        return of(mockStableValueFunds);
      } else if (apiPath === API.outsideFunds) {
        return of(mockStableValueFunds);
      } else if (apiPath === API.yieldsDurations) {
        return of(mockYieldAndDuration);
      } else {
        return of(mockContractsData[0]);
      }
    });

    getInsurersSpy = spyOn(service, 'getInsurers').and.callThrough();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('getInsurers', () => {
    it('should try to fetch the data if not loaded', () => {
      const expectedInsurers = mockInsurerList.map(insurer => new Insurer(insurer));

      service.getInsurers();

      service.insurers$.subscribe(data => {
        expect(data).toEqual(expectedInsurers);
      });

      expect(restService.getData).toHaveBeenCalledWith('Load Insurers', API.insurers);
    });
  });

  describe('getContractIds', () => {
    it('should try to fetch the data if not loaded', () => {
      service.getContractIds(insurerId).subscribe(data => {
        expect(data).toEqual(mockContractIdList);
      });

      expect(restService.getData).toHaveBeenCalledWith('Load Contract IDs', API.contractIds);
      expect(service.contractIdMap.get(insurerId)).toEqual(mockContractIdList);
    });

    it('should try to fetch the data if list is empty', () => {
      service.contractIdMap.set(insurerId, []);
      service.getContractIds(insurerId).subscribe(data => {
        expect(data).toEqual(mockContractIdList);
      });

      expect(restService.getData).toHaveBeenCalledWith('Load Contract IDs', API.contractIds);
      expect(service.contractIdMap.get(insurerId)).toEqual(mockContractIdList);
    });

    it('should return data directly if already loaded', () => {
      service.contractIdMap.set(insurerId, mockContractIdList);
      service.getContractIds(insurerId).subscribe(data => {
        expect(data).toEqual(mockContractIdList);
      });

      expect(restService.getData).not.toHaveBeenCalled();
    });
  });

  describe('resetContractIds', () => {
    it('should remove an entry from the contract ID map', () => {
      service.contractIdMap.set(insurerId, []);

      service.resetContractIds(insurerId);

      expect(service.contractIdMap.get(insurerId)).not.toBeDefined();
    });
  });

  describe('getContractDetails', () => {
    it('should try to fetch the data if not loaded', () => {
      service.getContractDetails(contractId).subscribe(data => {
        expect(data).toEqual(new Contract(mockContractsData[0]));
      });

      expect(restService.getData).toHaveBeenCalledWith(
        'Load Contract Details',
        API.contractDetails
      );
    });
  });

  describe('getUnderlyingAssets', () => {
    it('should fetch the underlying asset data', () => {
      const expectedAssets = mockUnderlyingAssets.map(asset => new UnderlyingAsset(asset));

      service.getUnderlyingAssets();
      service.underlyingAssets$.subscribe(data => {
        expect(data).toEqual(expectedAssets);
      });

      expect(restService.getData).toHaveBeenCalledWith(
        'Load Underlying Assets',
        API.underlyingAssets
      );
    });
  });

  describe('getFunds', () => {
    it('should fetch the list of port IDs', () => {
      service.getFunds();
      service.funds$.subscribe(data => {
        expect(data).toEqual(mockStableValueFunds);
      });

      expect(restService.getData).toHaveBeenCalledWith('Load Funds', API.funds);
    });
  });

  describe('getOutsideFunds', () => {
    it('should fetch the list of outside funds', () => {
      service.getOutsideFunds();
      service.outsideFunds$.subscribe(data => {
        expect(data).toEqual(mockStableValueFunds);
      });

      expect(restService.getData).toHaveBeenCalledWith('Load Outside Funds', API.outsideFunds);
    });
  });

  describe('getYieldsDurations', () => {
    it('should fetch the yields & durations data', () => {
      service.getYieldsDurations(asOfDate);
      service.yieldsDurations$.subscribe(data => {
        expect(data).toEqual(mockYieldAndDuration);
      });

      expect(restService.getData).toHaveBeenCalledWith(
        'Load Yields & Durations',
        API.yieldsDurations
      );
    });
  });

  describe('saveUnderlyingAsset', () => {
    it('should create a new underlying asset', () => {
      const getSpy = spyOn(service, 'getUnderlyingAssets');
      const assetForm = new UnderlyingAssetForm();

      service.saveUnderlyingAsset(assetForm).subscribe(() => {});

      expect(restService.postData).toHaveBeenCalledWith(
        'Create New Underlying Asset',
        `${API.underlyingAssets}`,
        assetForm.getRawValue()
      );
      expect(getSpy).toHaveBeenCalled();
    });

    it('should update an existing underlying asset', () => {
      const getSpy = spyOn(service, 'getUnderlyingAssets');
      const asset = new UnderlyingAsset(undefined);
      asset.assetId = '6432643';
      const assetForm = new UnderlyingAssetForm(asset);

      service.saveUnderlyingAsset(assetForm).subscribe(() => {});

      expect(restService.putData).toHaveBeenCalledWith(
        'Save Underlying Asset',
        `${API.underlyingAssets}/${asset.assetId}`,
        assetForm.getRawValue()
      );
      expect(getSpy).toHaveBeenCalled();
    });
  });

  describe('saveInsurer', () => {
    it('should create a new insurer', () => {
      const insurer = new Insurer(null);
      insurer.insurerId = 1;
      insurer.isActive = false;
      const insurerForm = new InsurerForm(insurer);
      insurerForm.isNew = true;

      service.saveInsurer(insurerForm);

      expect(restService.postData).toHaveBeenCalledWith(
        'Create New Insurer',
        `${API.insurers}`,
        insurerForm.value
      );
      expect(getInsurersSpy).toHaveBeenCalled();
    });

    it('should update an existing insurer', () => {
      const insurer = new Insurer(null);
      insurer.insurerId = 1;
      insurer.isActive = false;
      const insurerForm = new InsurerForm(insurer);
      insurerForm.isNew = false;

      service.saveInsurer(insurerForm);

      expect(restService.putData).toHaveBeenCalledWith(
        'Save Insurer',
        `${API.insurers}/${insurer.insurerId}`,
        insurerForm.value
      );
      expect(getInsurersSpy).toHaveBeenCalled();
    });
  });

  describe('saveContract', () => {
    it('should create a new contract', () => {
      const contractForm = new ContractForm();

      service.saveContract(contractForm).subscribe(() => {});

      expect(restService.postData).toHaveBeenCalledWith(
        'Create New Contract',
        API.contracts,
        contractForm.getRawValue()
      );
    });

    it('should update an existing contract', () => {
      const contractForm = new ContractForm(mockContractsData[0]);

      service.saveContract(contractForm).subscribe(() => {});

      expect(restService.putData).toHaveBeenCalledWith(
        'Save Contract',
        `${API.contracts}/${contractForm.getRawValue().contractId}`,
        contractForm.getRawValue()
      );
    });
  });

  describe('updateActiveStatus', () => {
    let asset: UnderlyingAsset;
    let path: string;
    let request: UpdateRequest<UnderlyingAsset>;
    beforeEach(function() {
      asset = mockUnderlyingAssets[0];
      path = `${environment.ASSETS_URI}/${asset.assetId}`;
    });

    it('should make a delete request to deactivate the object', () => {
      request = new UpdateRequest(new ActionRequest(ACTION.DEACTIVATE, asset), path);

      service.updateActiveStatus(request).subscribe(() => {});

      expect(restService.deleteData).toHaveBeenCalledWith('Deactivate', path, asset);
    });

    it('should make a post request to reactivate the object', () => {
      request = new UpdateRequest(new ActionRequest(ACTION.REACTIVATE, asset), path);

      service.updateActiveStatus(request).subscribe(() => {});

      expect(restService.postData).toHaveBeenCalledWith('Reactivate', path, asset);
    });
  });

  describe('saveYieldDuration', () => {
    it('should update a yield & duration entry', () => {
      const asOfDate = '2020-01-10';
      const yieldDuration = new AssetYieldDurationForm(mockYieldAndDuration[0]).getRawValue();
      service.saveYieldDuration(asOfDate, yieldDuration);

      expect(restService.putData).toHaveBeenCalledWith(
        'Save Yield & Duration',
        `${API.yieldsDurations}${environment.ASSETS_URI}/${yieldDuration.assetId}`,
        yieldDuration
      );
    });
  });
});
