import { Injectable } from '@angular/core';
import { RestService } from '@app/services';
import { ACTION, CustomForm, UpdateRequest } from '@app/shared';
import { Contract, ContractForm, ContractId, StableValueFund } from '@contracts/models';
import { environment } from '@env';
import { Insurer } from '@insurers/models';
import { UnderlyingAsset } from '@underlying-assets/models';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { map, tap } from 'rxjs/operators';

import { InsurerForm } from '../modules/insurers/models/forms';
import { UnderlyingAssetForm } from '../modules/underlying-assets/models/forms';
import { AssetYieldDuration } from '../modules/yield-and-duration/models/yield-and-duration.model';

@Injectable({
  providedIn: 'root'
})
export class MaintenanceService {
  contractIdMap: Map<number, ContractId[]> = new Map();

  private readonly assetsSubject: BehaviorSubject<UnderlyingAsset[]> = new BehaviorSubject([]);
  underlyingAssets$: Observable<UnderlyingAsset[]> = this.assetsSubject.asObservable();

  private readonly insurersSubject: BehaviorSubject<Insurer[]> = new BehaviorSubject([]);
  insurers$: Observable<Insurer[]> = this.insurersSubject.asObservable();

  private readonly fundsSubject: BehaviorSubject<StableValueFund[]> = new BehaviorSubject([]);
  funds$: Observable<StableValueFund[]> = this.fundsSubject.asObservable();

  private readonly outsideFundsSubject: BehaviorSubject<StableValueFund[]> = new BehaviorSubject(
    []
  );
  outsideFunds$: Observable<StableValueFund[]> = this.outsideFundsSubject.asObservable();

  private readonly yieldsDurationsSubject: BehaviorSubject<
    AssetYieldDuration[]
  > = new BehaviorSubject([]);
  yieldsDurations$: Observable<AssetYieldDuration[]> = this.yieldsDurationsSubject.asObservable();

  constructor(private readonly restService: RestService) {}

  getInsurers(): void {
    this.restService
      .getData<Insurer[]>('Load Insurers', environment.INSURERS_URI)
      .pipe(
        map(insurers => insurers.map(insurer => new Insurer(insurer))),
        tap(data => this.insurersSubject.next(data))
      )
      .subscribe();
  }

  getContractIds(insurerId: number): Observable<ContractId[]> {
    const mapEntry = this.contractIdMap.get(insurerId);
    if (!mapEntry || mapEntry.length === 0) {
      return this.restService
        .getData<ContractId[]>(
          'Load Contract IDs',
          `${environment.INSURERS_URI}/${insurerId}${environment.CONTRACTS_URI}`
        )
        .pipe(
          map(data => {
            this.contractIdMap.set(insurerId, data);
            return data;
          })
        );
    } else {
      return of(this.contractIdMap.get(insurerId));
    }
  }

  resetContractIds(insurerId): void {
    this.contractIdMap.delete(insurerId);
  }

  getContractDetails(contractId: string): Observable<Contract> {
    return this.restService
      .getData<Contract>('Load Contract Details', `${environment.CONTRACTS_URI}/${contractId}`)
      .pipe(map(contract => new Contract(contract)));
  }

  getUnderlyingAssets(): void {
    this.restService
      .getData<UnderlyingAsset[]>('Load Underlying Assets', environment.ASSETS_URI)
      .pipe(
        map(assets => assets.map(asset => new UnderlyingAsset(asset))),
        tap(data => this.assetsSubject.next(data))
      )
      .subscribe();
  }

  getFunds(): void {
    this.restService
      .getData<StableValueFund[]>('Load Funds', environment.FUNDS_URI)
      .pipe(tap(data => this.fundsSubject.next(data)))
      .subscribe();
  }

  getOutsideFunds(): void {
    this.restService
      .getData<StableValueFund[]>('Load Outside Funds', environment.OUTSIDE_FUNDS_URI)
      .pipe(tap(data => this.outsideFundsSubject.next(data)))
      .subscribe();
  }

  getYieldsDurations(asOfDate: string): void {
    this.restService
      .getData<AssetYieldDuration[]>(
        'Load Yields & Durations',
        `${environment.YIELDS_DURATIONS_URI}/${asOfDate}`
      )
      .pipe(tap(data => this.yieldsDurationsSubject.next(data)))
      .subscribe();
  }

  saveUnderlyingAsset(assetForm: UnderlyingAssetForm): Observable<any> {
    return this.getSaveRequest(assetForm).pipe(tap(() => this.getUnderlyingAssets()));
  }

  saveInsurer(insurerForm: InsurerForm): void {
    this.getSaveRequest(insurerForm).subscribe(() => this.getInsurers());
  }

  saveContract(contractForm: ContractForm): Observable<any> {
    return this.getSaveRequest(contractForm);
  }

  private getSaveRequest<T>(form: CustomForm<T>): Observable<any> {
    const payload = form.getRawValue();
    const request = form.isNew
      ? this.restService.postData<T>(`Create New ${form.objectName}`, form.uri, payload)
      : this.restService.putData<T>(
          `Save ${form.objectName}`,
          `${form.uri}/${payload[form.idAttribute]}`,
          payload
        );
    return request;
  }

  saveYieldDuration(asOfDate: string, yieldDuration: AssetYieldDuration): void {
    this.restService
      .putData<AssetYieldDuration>(
        `Save Yield & Duration`,
        `${environment.YIELDS_DURATIONS_URI}/${asOfDate}` +
          `${environment.ASSETS_URI}/${yieldDuration.assetId}`,
        yieldDuration
      )
      .subscribe(() => this.getYieldsDurations(asOfDate));
  }

  updateActiveStatus<T>(statusRequest: UpdateRequest<T>): Observable<any> {
    const request =
      statusRequest.action === ACTION.DEACTIVATE
        ? this.restService.deleteData<T>('Deactivate', statusRequest.path, statusRequest.object)
        : this.restService.postData<T>('Reactivate', statusRequest.path, statusRequest.object);

    return request;
  }
}
