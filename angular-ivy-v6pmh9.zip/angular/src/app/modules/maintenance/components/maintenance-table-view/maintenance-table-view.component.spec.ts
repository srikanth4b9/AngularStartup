import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {
  MatButtonModule,
  MatDialog,
  MatDialogModule,
  MatToolbarModule
} from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ConfirmDialogComponent } from '@app/components';
import {
  ACTION,
  ActionRequest,
  activeStatusConfirmDialogData
} from '@app/shared';
import {
  ActiveToggleModule,
  CustomMatTableModule
} from '@app/shared/components';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { of } from 'rxjs';

import { InsurerDialogComponent } from '../../modules/insurers/components/insurer-dialog';
import { Insurer, mockInsurerList } from '../../modules/insurers/models';
import { InsurerForm } from '../../modules/insurers/models/forms';
import { MaintenanceService, MockMaintenanceService } from '../../services';
import { MaintenanceTableViewComponent } from './maintenance-table-view.component';

class MockDialog {
  open = jasmine.createSpy().and.returnValue({
    afterClosed: () => of({})
  });
}

describe('MaintenanceTableViewComponent', () => {
  let component: MaintenanceTableViewComponent;
  let fixture: ComponentFixture<MaintenanceTableViewComponent>;
  let maintenanceService: MockMaintenanceService;
  let dialog: MockDialog;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule,
        MatButtonModule,
        MatToolbarModule,
        MatDialogModule,
        FontAwesomeModule,
        CustomMatTableModule,
        ActiveToggleModule
      ],
      declarations: [MaintenanceTableViewComponent],
      providers: [
        { provide: MaintenanceService, useValue: new MockMaintenanceService() },
        { provide: MatDialog, useClass: MockDialog }
      ]
    }).compileComponents();

    maintenanceService = TestBed.get(MaintenanceService);
    dialog = TestBed.get(MatDialog);
  }));

  function createComponent() {
    fixture = TestBed.createComponent(MaintenanceTableViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  function mockDialogSave(object: any) {
    dialog.open.and.returnValue({
      afterClosed: () => of(object)
    });
  }

  beforeEach(() => {
    createComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('ngOnInit:', () => {
    it('should emit the loadData event', () => {
      createComponent();
      spyOn(component.loadData, 'emit');

      component.ngOnInit();

      expect(component.loadData.emit).toHaveBeenCalled();
    });
  });

  describe('handleActionRequest', () => {
    let actionRequest: ActionRequest<Insurer>;
    let actionObject;
    let saveSpy: jasmine.Spy;
    beforeEach(function() {
      createComponent();
      component.dialogType = InsurerDialogComponent;
      actionObject = mockInsurerList[0];
      saveSpy = spyOn(component.save, 'emit');
    });

    describe('EDIT', () => {
      beforeEach(function() {
        actionRequest = new ActionRequest(ACTION.EDIT, actionObject);
      });

      it('should emit the save event when dialog is saved', () => {
        const expectedForm = new InsurerForm(actionObject);
        mockDialogSave(expectedForm);

        component.handleActionRequest(actionRequest);

        expect(dialog.open).toHaveBeenCalledWith(InsurerDialogComponent, {
          data: actionObject
        });
        expect(saveSpy).toHaveBeenCalledWith(expectedForm);
      });
      it('should do nothing when no form is returned', () => {
        mockDialogSave(undefined);

        component.handleActionRequest(actionRequest);

        expect(saveSpy).not.toHaveBeenCalled();
      });
    });

    describe('DEACTIVATE', () => {
      beforeEach(function() {
        actionObject = new Insurer(mockInsurerList[0]);
        actionRequest = new ActionRequest(ACTION.DEACTIVATE, actionObject);
      });

      it('should deactivate the object when dialog is confirmed', () => {
        mockDialogSave('confirm');

        component.handleActionRequest(actionRequest);

        expect(dialog.open).toHaveBeenCalledWith(ConfirmDialogComponent, {
          data: activeStatusConfirmDialogData[ACTION.DEACTIVATE]
        });
      });

      it('should do nothing when dialog is not confirmed', () => {
        mockDialogSave(undefined);

        component.handleActionRequest(actionRequest);

        expect(maintenanceService.updateActiveStatus).not.toHaveBeenCalled();
      });
    });

    describe('REACTIVATE', () => {
      beforeEach(function() {
        actionObject = new Insurer(mockInsurerList[0]);
        actionRequest = new ActionRequest(ACTION.REACTIVATE, actionObject);
      });

      it('should reactivate the object when dialog is confirmed', () => {
        mockDialogSave('confirm');

        component.handleActionRequest(actionRequest);

        expect(dialog.open).toHaveBeenCalledWith(ConfirmDialogComponent, {
          data: activeStatusConfirmDialogData[ACTION.REACTIVATE]
        });
      });

      it('should do nothing when dialog is not confirmed', () => {
        mockDialogSave(undefined);

        component.handleActionRequest(actionRequest);

        expect(maintenanceService.updateActiveStatus).not.toHaveBeenCalled();
      });
    });
  });
});
