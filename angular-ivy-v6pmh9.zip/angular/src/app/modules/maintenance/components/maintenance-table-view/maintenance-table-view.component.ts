import { ComponentType } from '@angular/cdk/portal';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { MatDialog } from '@angular/material';
import { ConfirmDialogComponent } from '@app/components';
import { ACTION, ActionRequest, activeStatusConfirmDialogData, UpdateRequest, TableDef } from '@app/shared';
import { faPlusCircle, IconDefinition } from '@fortawesome/free-solid-svg-icons';

import { MaintenanceService } from '../../services';

@Component({
  selector: 'rxu-maintenance-table-view',
  templateUrl: './maintenance-table-view.component.html',
  styleUrls: ['./maintenance-table-view.component.scss']
})
export class MaintenanceTableViewComponent implements OnInit {
  @Input() tableDef: TableDef = new TableDef();
  @Input() tableData: any[] = [];
  @Input() dialogType: ComponentType<{}>;
  @Input() viewTitle: string;
  @Input() newButtonText: string;
  @Input() uri: string;
  @Input() idAttribute: string;

  isActive = true;

  faPlusCircle: IconDefinition = faPlusCircle;

  @Output() loadData: EventEmitter<any> = new EventEmitter();
  @Output() save: EventEmitter<any> = new EventEmitter();

  constructor(
    protected maintenanceService: MaintenanceService,
    protected dialog: MatDialog) {
  }

  ngOnInit() {
    this.loadData.emit();
  }

  handleActionRequest(actionRequest: ActionRequest<any>) {
    const action: ACTION = actionRequest.action;
    if (action === ACTION.EDIT) {
      this.openEditDialog(actionRequest.object);
    }
    if (action === ACTION.DEACTIVATE || action === ACTION.REACTIVATE) {
      this.openActiveStatusConfirmDialog(actionRequest);
    }
  }

  openEditDialog(object = null): void {
    const dialogRef = this.dialog.open(this.dialogType, { data: object });
    dialogRef.afterClosed().subscribe(form => {
      if (form) {
        this.save.emit(form);
      }
    });
  }

  protected openActiveStatusConfirmDialog(actionRequest: ActionRequest<any>): void {
    const dialogRef = this.dialog.open(ConfirmDialogComponent,
      { data: activeStatusConfirmDialogData[actionRequest.action] });
    dialogRef.afterClosed().subscribe(data => {
      if (data === 'confirm') {
        actionRequest.object = actionRequest.object.getRawValue();
        const path = `${this.uri}/${actionRequest.object[this.idAttribute]}`;
        const statusRequest = new UpdateRequest(actionRequest, path);

        this.maintenanceService.updateActiveStatus(statusRequest).subscribe(() => {
          this.loadData.emit();
        });
      }
    });
  }
}
