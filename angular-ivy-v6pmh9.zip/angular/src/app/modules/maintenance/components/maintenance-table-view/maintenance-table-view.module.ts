import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatButtonModule, MatToolbarModule, MatDialogModule } from '@angular/material';
import { ActiveToggleModule, CustomMatTableModule } from '@app/shared/components';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

import { MaintenanceTableViewComponent } from './maintenance-table-view.component';

@NgModule({
  declarations: [MaintenanceTableViewComponent],
  imports: [
    CommonModule,
    MatButtonModule,
    MatToolbarModule,
    MatDialogModule,
    FontAwesomeModule,
    CustomMatTableModule,
    ActiveToggleModule
  ],
  exports: [MaintenanceTableViewComponent]
})
export class MaintenanceTableViewModule { }
