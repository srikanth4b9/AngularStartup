import { MaintenanceTableViewModule } from './maintenance-table-view.module';

describe('MaintenanceTableViewModule', () => {
    let maintenanceTableViewModule: MaintenanceTableViewModule;

    beforeEach(() => {
        maintenanceTableViewModule = new MaintenanceTableViewModule();
    });

    it('should create an instance', () => {
        expect(maintenanceTableViewModule).toBeTruthy();
    });
});
