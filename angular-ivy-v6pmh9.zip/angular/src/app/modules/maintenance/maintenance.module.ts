import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MaintenanceRoutingModule } from './maintenance-routing.module';
import { MaintenanceTabsModule } from './views/maintenance-tabs';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    MaintenanceRoutingModule,
    MaintenanceTabsModule
  ]
})
export class MaintenanceModule { }
