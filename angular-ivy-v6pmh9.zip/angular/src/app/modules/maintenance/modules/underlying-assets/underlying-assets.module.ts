import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { UnderlyingAssetsViewModule } from '@underlying-assets/views';

import { UnderlyingAssetsRoutingModule } from './underlying-assets-routing.module';

@NgModule({
  imports: [
    CommonModule,
    UnderlyingAssetsRoutingModule,
    UnderlyingAssetsViewModule
  ]
})
export class UnderlyingAssetsModule {}
