import { Component, Inject, Optional } from '@angular/core';
import { AbstractControl, ValidationErrors } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { MaintenanceService } from '@app/modules/maintenance/services';
import { FormUtils } from '@app/shared';
import { Observable, of } from 'rxjs';
import { map, tap } from 'rxjs/operators';

import { UnderlyingAsset, underlyingAssetAttributeMap } from '../../models';
import { UnderlyingAssetForm } from '../../models/forms';

@Component({
  selector: 'rxu-underlying-asset-dialog',
  templateUrl: './underlying-asset-dialog.component.html',
  styleUrls: ['./underlying-asset-dialog.component.scss']
})
export class UnderlyingAssetDialogComponent {
  assetForm: UnderlyingAssetForm;

  FormUtils = FormUtils;

  constructor(
    private readonly dialogRef: MatDialogRef<UnderlyingAssetDialogComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) data,
    private readonly maintenanceService: MaintenanceService
  ) {
    this.assetForm = new UnderlyingAssetForm(data || undefined);
    this.assetForm.assetId.setAsyncValidators([
      this.validateAttributeValueExists.bind(this, 'assetId')
    ]);
    this.assetForm.assetName.setAsyncValidators([
      this.validateAttributeValueExists.bind(this, 'assetName')
    ]);
  }

  checkIfAttributeValueExists(
    attributeName: string,
    attributeValue: any
  ): Observable<boolean> {
    return this.maintenanceService.underlyingAssets$.pipe(
      map(assets => {
        return this.isExisting(assets, attributeName, attributeValue);
      })
    );
  }

  private isExisting(
    assets: UnderlyingAsset[],
    attributeName: string,
    attributeValue: any
  ): boolean {
    return (
      assets.filter(asset => asset[attributeName] === attributeValue).length > 0
    );
  }

  validateAttributeValueExists(
    attributeName: string,
    control: AbstractControl
  ): Observable<ValidationErrors> {
    if (
      !control.pristine &&
      FormUtils.isFieldDirty(this.assetForm, attributeName)
    ) {
      return this.checkIfAttributeValueExists(
        attributeName,
        control.value
      ).pipe(
        map((response: boolean) =>
          response
            ? { valueExists: underlyingAssetAttributeMap[attributeName] }
            : null
        ),
        tap(res => control.setErrors(res))
      );
    }
    return of(null);
  }

  close() {
    this.dialogRef.close();
  }

  saveUnderlyingAsset() {
    this.dialogRef.close(this.assetForm);
  }
}
