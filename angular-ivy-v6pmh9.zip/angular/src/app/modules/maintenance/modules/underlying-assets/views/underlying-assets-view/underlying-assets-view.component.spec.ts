import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { MaintenanceTableViewModule } from '@app/modules/maintenance/components';
import {
  MaintenanceService,
  MockMaintenanceService
} from '@maintenance/services';
import { mockUnderlyingAssets } from '@underlying-assets/models';

import { UnderlyingAssetForm } from '../../models/forms';
import { UnderlyingAssetsViewComponent } from './underlying-assets-view.component';
import { MockHomeService, HomeService } from '@app/modules/home/services';

describe('UnderlyingAssetsViewComponent', () => {
  let component: UnderlyingAssetsViewComponent;
  let fixture: ComponentFixture<UnderlyingAssetsViewComponent>;
  let maintenanceService: MockMaintenanceService;
  let homeService: MockHomeService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [NoopAnimationsModule, MaintenanceTableViewModule],
      declarations: [UnderlyingAssetsViewComponent],
      providers: [
        { provide: MaintenanceService, useClass: MockMaintenanceService },
        { provide: HomeService, useValue: new MockHomeService() }
      ]
    }).compileComponents();

    maintenanceService = TestBed.get(MaintenanceService);
    homeService = TestBed.get(HomeService);
  }));

  function createComponent() {
    fixture = TestBed.createComponent(UnderlyingAssetsViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  beforeEach(function() {
    createComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
    expect(component.tableData.length).toBeGreaterThan(0);
  });

  describe('loadAssets:', () => {
    it('should call the maintenance service to load assets', () => {
      component.loadAssets();

      expect(maintenanceService.getUnderlyingAssets).toHaveBeenCalled();
    });
  });

  describe('saveAsset', () => {
    it('should call the maintenance service to save the asset', () => {
      const expectedForm = new UnderlyingAssetForm(mockUnderlyingAssets[0]);

      component.saveAsset(expectedForm);

      expect(maintenanceService.saveUnderlyingAsset).toHaveBeenCalledWith(
        expectedForm
      );
      expect(homeService.recalculateRateResetsForAsset).toHaveBeenCalledWith(
        expectedForm.assetId.value
      );
    });

    it('should not recalculate rate resets if the asset is new', () => {
      component.saveAsset(new UnderlyingAssetForm());

      expect(homeService.recalculateRateResetsForAsset).not.toHaveBeenCalled();
    });
  });
});
