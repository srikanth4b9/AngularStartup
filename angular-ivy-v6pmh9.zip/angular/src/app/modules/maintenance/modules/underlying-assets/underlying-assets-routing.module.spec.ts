import { UnderlyingAssetsRoutingModule } from './underlying-assets-routing.module';

describe('UnderlyingAssetsRoutingModule', () => {
    let underlyingAssetsRoutingModule: UnderlyingAssetsRoutingModule;

    beforeEach(() => {
        underlyingAssetsRoutingModule = new UnderlyingAssetsRoutingModule();
    });

    it('should create an instance', () => {
        expect(underlyingAssetsRoutingModule).toBeTruthy();
    });
});
