import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MaintenanceTableViewModule } from '@app/modules/maintenance/components';

import { UnderlyingAssetsViewComponent } from './underlying-assets-view.component';

@NgModule({
  declarations: [UnderlyingAssetsViewComponent],
  imports: [
    CommonModule,
    MaintenanceTableViewModule
  ],
  exports: [UnderlyingAssetsViewComponent]
})
export class UnderlyingAssetsViewModule { }
