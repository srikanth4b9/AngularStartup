import { Component } from '@angular/core';
import { TableDef } from '@app/shared';
import { MaintenanceService } from '@maintenance/services';
import {
  UnderlyingAsset,
  UnderlyingAssetTableDef
} from '@underlying-assets/models';

import { UnderlyingAssetDialogComponent } from '../../components';
import { UnderlyingAssetForm } from '../../models/forms';
import { environment } from '@env';
import { HomeService } from '@app/modules/home/services';

@Component({
  selector: 'rxu-assets',
  templateUrl: './underlying-assets-view.component.html',
  styleUrls: ['./underlying-assets-view.component.scss']
})
export class UnderlyingAssetsViewComponent {
  tableDef: TableDef = new UnderlyingAssetTableDef();
  tableData: UnderlyingAsset[] = [];
  dialogType = UnderlyingAssetDialogComponent;
  uri = environment.ASSETS_URI;

  constructor(
    private readonly maintenanceService: MaintenanceService,
    private readonly homeService: HomeService
  ) {
    this.maintenanceService.underlyingAssets$.subscribe(assets => {
      this.tableData = assets;
    });
  }

  loadAssets(): void {
    this.maintenanceService.getUnderlyingAssets();
  }

  saveAsset(assetForm: UnderlyingAssetForm): void {
    this.maintenanceService
      .saveUnderlyingAsset(assetForm)
      .subscribe(() => this.recalculateRateResets(assetForm));
  }

  private recalculateRateResets(assetForm: UnderlyingAssetForm) {
    if (!assetForm.isNew) {
      this.homeService.recalculateRateResetsForAsset(assetForm.assetId.value);
    }
  }
}
