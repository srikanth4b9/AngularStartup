import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UnderlyingAssetsViewComponent } from '@underlying-assets/views';

const routes: Routes = [
  {
    path: '',
    component: UnderlyingAssetsViewComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class UnderlyingAssetsRoutingModule { }
