import { UnderlyingAssetDialogModule } from './underlying-asset-dialog.module';

describe('UnderlyingAssetDialogModule', () => {
    let underlyingAssetDialogModule: UnderlyingAssetDialogModule;

    beforeEach(() => {
        underlyingAssetDialogModule = new UnderlyingAssetDialogModule();
    });

    it('should create an instance', () => {
        expect(underlyingAssetDialogModule).toBeTruthy();
    });
});
