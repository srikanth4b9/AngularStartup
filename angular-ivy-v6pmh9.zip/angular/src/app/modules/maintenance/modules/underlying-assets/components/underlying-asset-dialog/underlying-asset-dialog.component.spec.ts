import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import {
  MAT_DIALOG_DATA,
  MatButtonModule,
  MatCheckboxModule,
  MatDialogModule,
  MatDialogRef,
  MatInputModule,
  MatSnackBarModule,
} from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { FormUtils } from '@app/shared';
import { PercentLabelModule } from '@app/shared/components';
import { MaintenanceService, MockMaintenanceService } from '@maintenance/services';
import { of } from 'rxjs';

import { mockUnderlyingAssets, underlyingAssetAttributeMap } from '../../models';
import { UnderlyingAssetDialogComponent } from './underlying-asset-dialog.component';

describe('UnderlyingAssetDialogComponent', () => {
  let component: UnderlyingAssetDialogComponent;
  let fixture: ComponentFixture<UnderlyingAssetDialogComponent>;

  const mockDialogRef = {
    close: jasmine.createSpy()
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [UnderlyingAssetDialogComponent],
      imports: [
        NoopAnimationsModule,
        ReactiveFormsModule,
        HttpClientTestingModule,
        MatDialogModule,
        MatButtonModule,
        MatCheckboxModule,
        MatInputModule,
        MatSnackBarModule,
        PercentLabelModule
      ],
      providers: [
        { provide: MaintenanceService, useValue: new MockMaintenanceService() },
        { provide: MatDialogRef, useValue: mockDialogRef },
        { provide: MAT_DIALOG_DATA, useValue: mockUnderlyingAssets[0] }
      ]
    });
  });

  function createComponent() {
    TestBed.compileComponents();
    fixture = TestBed.createComponent(UnderlyingAssetDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  it('should create', () => {
    createComponent();

    expect(component).toBeTruthy();
  });

  describe('constructor', () => {
    it('should load form with dialog data', () => {
      createComponent();

      expect(component.assetForm.assetId.value).toEqual(mockUnderlyingAssets[0].assetId);
    });

    it('should load form with undefined when there is no dialog data', () => {
      TestBed.overrideProvider(MAT_DIALOG_DATA, { useValue: undefined });

      createComponent();

      expect(component).toBeTruthy();
      expect(component.assetForm.isNew).toEqual(true);
    });
  });

  describe('close', () => {
    it('should close dialog', () => {
      createComponent();

      component.close();

      expect(mockDialogRef.close).toHaveBeenCalled();
    });
  });
  describe('close', () => {
    it('should close dialog', () => {
      createComponent();

      component.close();

      expect(mockDialogRef.close).toHaveBeenCalled();
    });
  });

  describe('saveUnderlyingAsset', () => {
    it('should save underlying asset', () => {
      createComponent();
      component.saveUnderlyingAsset();

      expect(mockDialogRef.close).toHaveBeenCalled();
    });
  });

  describe('checkIfAttributeValueExists:', () => {
    beforeEach(() => {
      createComponent();
      spyOn(fixture.componentInstance, 'checkIfAttributeValueExists').and.callThrough();
    });

    it('should return true if asset ID already exists', () => {
      component.checkIfAttributeValueExists('assetId', '472').subscribe(
        response => expect(response).toBe(true)
      );

      expect(component.checkIfAttributeValueExists).toHaveBeenCalled();
    });

    it('should return false if asset ID is unique', () => {
      component.checkIfAttributeValueExists('assetId', 'ABC').subscribe(
        response => expect(response).toBe(false)
      );

      expect(component.checkIfAttributeValueExists).toHaveBeenCalled();
    });
  });

  describe('validateAttributeValueExists', () => {
    const attributeName: string = 'assetId';
    let control: FormControl;

    beforeEach(() => {
      control = new FormControl('0465');
      createComponent();
    });

    it('should return null', () => {
      control.markAsPristine();

      component.validateAttributeValueExists(attributeName, control).subscribe(response => {
        expect(response).toBeNull();
      });
    });

    it('should validate attribute', () => {
      control.markAsDirty();

      spyOn(component, 'checkIfAttributeValueExists').and.returnValue(of(true));
      spyOn(FormUtils, 'isFieldDirty').and.returnValue(true);

      component.validateAttributeValueExists(attributeName, control).subscribe(response => {
        expect(response).toEqual({ valueExists: underlyingAssetAttributeMap[attributeName] });
        expect(component.checkIfAttributeValueExists).toHaveBeenCalledWith(attributeName, control.value);
      });

    });

    it('should return null', () => {
      control.markAsDirty();

      component.checkIfAttributeValueExists = jasmine.createSpy().and.returnValue(of(false));
      component.validateAttributeValueExists(attributeName, control).subscribe(response => {

        expect(response).toEqual(null);
      });
    });
  });

});
