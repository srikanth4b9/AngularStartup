import { mockUnderlyingAssets } from '../mock-json';
import { UnderlyingAsset } from '../underlying-asset.model';
import { UnderlyingAssetForm } from './underlying-asset.form.model';

describe('underlying asset form model', () => {
  let underlyingAssetForm: UnderlyingAssetForm;
  let underlyingAsset: UnderlyingAsset;

  describe('constructor', () => {
    it('should create a blank asset form ', () => {
      underlyingAsset = new UnderlyingAsset(null);
      underlyingAssetForm = new UnderlyingAssetForm(underlyingAsset);
      expect(underlyingAssetForm).toBeDefined();
    });
    it('should create a asset form without an aseet', () => {
      underlyingAssetForm = new UnderlyingAssetForm();
      expect(underlyingAssetForm).toBeDefined();
    });
  });
  describe('Name of the group', () => {
    beforeEach(() => {
      underlyingAssetForm = new UnderlyingAssetForm(mockUnderlyingAssets[0]);
    });
    formControlGetterTest('assetId');
    formControlGetterTest('assetName');
    formControlGetterTest('expenseRatio');
    formControlGetterTest('isExternal');
  });

  function formControlGetterTest(controlName: string) {
    it(`should create a control getter for ${controlName}`, () => {
      expect(underlyingAssetForm[controlName]).toEqual(
        underlyingAssetForm.get(controlName)
      );
    });
  }

  describe('assetForm valueChange', () => {

    it('should be disabled when isExternal is changed from true to false', () => {
      underlyingAssetForm = new UnderlyingAssetForm(mockUnderlyingAssets[1]);
      underlyingAssetForm.patchValue({
        isExternal: false
      });

      expect(underlyingAssetForm.assetName.disabled).toBe(true);
    });

    it('should be enabled when isExternal is changed from false to true', () => {
      underlyingAssetForm = new UnderlyingAssetForm(mockUnderlyingAssets[0]);
      underlyingAssetForm.patchValue({
        isExternal: true
      });

      expect(underlyingAssetForm.assetName.enabled).toBe(true);
    });

    it('form asset name should be disabled when isExternal is false', () => {
      underlyingAssetForm = new UnderlyingAssetForm(mockUnderlyingAssets[1]);
      expect(underlyingAssetForm.assetName.disabled).toBe(true);
    });

    it('form asset name should be disabled when isExternal is true', () => {
      underlyingAssetForm = new UnderlyingAssetForm(mockUnderlyingAssets[0]);
      expect(underlyingAssetForm.assetName.enabled).toBe(true);
    });
  });
});
