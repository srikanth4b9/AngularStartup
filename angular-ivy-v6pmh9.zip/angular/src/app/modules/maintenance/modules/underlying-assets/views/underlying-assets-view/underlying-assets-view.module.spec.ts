import { UnderlyingAssetsViewModule } from './underlying-assets-view.module';

describe('UnderlyingAssetsViewModule', () => {
    let underlyingAssetsViewModule: UnderlyingAssetsViewModule;

    beforeEach(() => {
        underlyingAssetsViewModule = new UnderlyingAssetsViewModule();
    });

    it('should create an instance', () => {
        expect(underlyingAssetsViewModule).toBeTruthy();
    });
});
