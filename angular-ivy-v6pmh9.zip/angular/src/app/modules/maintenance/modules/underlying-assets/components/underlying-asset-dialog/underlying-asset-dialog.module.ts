import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UnderlyingAssetDialogComponent } from './underlying-asset-dialog.component';
import { ReactiveFormsModule } from '@angular/forms';
import { MatDialogModule, MatButtonModule, MatInputModule, MatCheckboxModule } from '@angular/material';
import { PercentLabelModule } from '@app/shared/components';

@NgModule({
  declarations: [UnderlyingAssetDialogComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatCheckboxModule,
    MatInputModule,
    PercentLabelModule
  ],
  exports: [UnderlyingAssetDialogComponent]
})
export class UnderlyingAssetDialogModule { }
