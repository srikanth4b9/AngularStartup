import { AbstractControl, FormControl, Validators } from '@angular/forms';
import { CustomForm } from '@app/shared';
import { environment } from '@env';

import { UnderlyingAsset } from '../underlying-asset.model';

const ASSET_MAXLENGTH = 200;

export class UnderlyingAssetForm extends CustomForm<UnderlyingAsset> {
  /* istanbul ignore next */
  constructor(underlyingAsset: UnderlyingAsset = new UnderlyingAsset()) {
    super({
      assetId: new FormControl(underlyingAsset.assetId, Validators.required),
      assetName: new FormControl(
        { value: underlyingAsset.assetName, disabled: !underlyingAsset.isExternal },
        [Validators.required, Validators.maxLength(ASSET_MAXLENGTH)]
      ),
      expenseRatio: new FormControl(underlyingAsset.expenseRatio, [
        Validators.min(0),
        Validators.max(1)
      ]),
      isExternal: new FormControl(underlyingAsset.isExternal)
    });
    this.object = underlyingAsset;
    this.isNew = !underlyingAsset.assetId;

    this.isExternal.valueChanges.subscribe(value => {
      this.assetName.setValue(null);
      this.assetName[value ? 'enable' : 'disable']();
    });
  }

  get objectName() {
    return 'Underlying Asset';
  }
  get uri() {
    return environment.ASSETS_URI;
  }
  get idAttribute() {
    return 'assetId';
  }

  get assetId(): AbstractControl {
    return this.get('assetId');
  }
  get assetName(): AbstractControl {
    return this.get('assetName');
  }
  get expenseRatio(): AbstractControl {
    return this.get('expenseRatio');
  }
  get isExternal(): AbstractControl {
    return this.get('isExternal');
  }
}
