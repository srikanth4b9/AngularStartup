import { ACTION, ColumnType, ColumnDefBuilder, ColumnDef } from '@app/shared';

import { mockUnderlyingAssets } from './mock-json';
import { UnderlyingAsset, UnderlyingAssetTableDef } from './underlying-asset.model';

describe('UnderlyingAsset', () => {
  let asset: UnderlyingAsset;

  describe('constructor', () => {
    it('should set action options for an active asset', () => {
      asset = new UnderlyingAsset(mockUnderlyingAssets[0]);

      asset.actionOptions$.subscribe(options =>
        expect(options).toEqual([ACTION.EDIT, ACTION.DEACTIVATE])
      );
    });

    it('should set action options for an inactive contract', () => {
      const mockAsset = Object.assign({}, mockUnderlyingAssets[0]);
      mockAsset.isActive = false;
      asset = new UnderlyingAsset(mockAsset);

      asset.actionOptions$.subscribe(options => expect(options).toEqual([ACTION.REACTIVATE]));
    });
  });

  describe('getRawValue', () => {
    it('should get raw asset json object', () => {
      const asset = new UnderlyingAsset(mockUnderlyingAssets[0]);

      expect(asset.getRawValue()).toEqual(mockUnderlyingAssets[0]);
    });
  });
});

describe('UnderlyingAssetTableDef', () => {
  let assetTableDef: UnderlyingAssetTableDef;
  const updatedUserColumn: ColumnDef = new ColumnDefBuilder(
    'Last Updated User',
    'crewUserId',
    ColumnType.STRING
  ).build();

  it('should include update fields by default', () => {
    assetTableDef = new UnderlyingAssetTableDef();

    expect(assetTableDef.columns).toContain(updatedUserColumn);
  });

  it('should not include update fields if table does not have actions', () => {
    assetTableDef = new UnderlyingAssetTableDef(false);

    expect(assetTableDef.columns).not.toContain(updatedUserColumn);
  });
});
