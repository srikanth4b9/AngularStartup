import { UnderlyingAsset } from '@underlying-assets/models';

const mockExternalAsset: UnderlyingAsset = {
  assetId: '572',
  assetName: 'Fidelity – ITBF',
  expenseRatio: 0.0002,
  isExternal: true,
  isActive: true,
  crewUserId: 'UKRV',
  lastUpdatedTimestamp: '11/12/2019 10:03 PM'
};

export const mockUnderlyingAssets: UnderlyingAsset[] = [
  {
    assetId: '472',
    assetName: 'Vanguard – ITBF',
    expenseRatio: 0.0002,
    isExternal: true,
    isActive: true,
    crewUserId: 'UKRV',
    lastUpdatedTimestamp: '11/12/2019 10:03 PM'
  },
  {
    assetId: '465',
    assetName: 'Vanguard – STBF',
    expenseRatio: 0.0002,
    isExternal: false,
    isActive: false,
    crewUserId: 'UKRV',
    lastUpdatedTimestamp: '11/12/2019 11:03 PM'
  },
  mockExternalAsset
];
