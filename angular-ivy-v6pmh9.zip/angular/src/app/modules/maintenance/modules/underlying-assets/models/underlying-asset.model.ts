import { ACTION, ColumnDefBuilder, ColumnType, TableDef } from '@app/shared/models';
import { BehaviorSubject, Observable } from 'rxjs';

export class UnderlyingAsset {
  assetId: string;
  assetName: string;
  expenseRatio: number;
  isExternal: boolean;
  isActive: boolean = true;
  crewUserId: string;
  lastUpdatedTimestamp: string;

  private readonly actionOptions?: BehaviorSubject<ACTION[]> = new BehaviorSubject([]);
  actionOptions$?: Observable<ACTION[]>;

  constructor(asset?: UnderlyingAsset) {
    Object.assign(this, asset);

    this.actionOptions = new BehaviorSubject(
      this.isActive ? [ACTION.EDIT, ACTION.DEACTIVATE] : [ACTION.REACTIVATE]
    );
    this.actionOptions$ = this.actionOptions.asObservable();
  }

  getRawValue?(): UnderlyingAsset {
    return {
      assetId: this.assetId,
      assetName: this.assetName,
      expenseRatio: this.expenseRatio,
      isExternal: this.isExternal,
      isActive: this.isActive,
      crewUserId: this.crewUserId,
      lastUpdatedTimestamp: this.lastUpdatedTimestamp
    };
  }
}

export class UnderlyingAssetTableDef extends TableDef {
  constructor(hasActions = true) {
    super(
      [
        new ColumnDefBuilder('Asset ID', 'assetId', ColumnType.STRING).build(),
        new ColumnDefBuilder('Asset Name', 'assetName', ColumnType.STRING).build(),
        new ColumnDefBuilder('Expense Ratio', 'expenseRatio', ColumnType.PERCENT).build(),
        new ColumnDefBuilder('External Asset', 'isExternal', ColumnType.BOOLEAN).build()
      ],
      hasActions
    );

    if (hasActions) {
      this.columns.push(
        new ColumnDefBuilder('Last Updated User', 'crewUserId', ColumnType.STRING).build(),
        new ColumnDefBuilder('Last Updated Timestamp ', 'lastUpdatedTimestamp', ColumnType.DATE)
          .format('MM/dd/yyyy hh:mm a')
          .build()
      );
    }
  }
}

export const underlyingAssetAttributeMap = {
  assetId: 'Asset ID',
  assetName: 'Asset Name',
  expenseRatio: 'Expense Ratio'
};
