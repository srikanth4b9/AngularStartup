import { UnderlyingAssetsModule } from './underlying-assets.module';

describe('UnderlyingAssetsModule', () => {
    let underlyingAssetsModule: UnderlyingAssetsModule;

    beforeEach(() => {
        underlyingAssetsModule = new UnderlyingAssetsModule();
    });

    it('should create an instance', () => {
        expect(underlyingAssetsModule).toBeTruthy();
    });
});
