import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MaintenanceService } from '@app/modules/maintenance/services';
import { Contract, ContractSearchForm } from '@contracts/models';
import { faPlusCircle, IconDefinition } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'rxu-contracts-view',
  templateUrl: './contracts-view.component.html',
  styleUrls: ['./contracts-view.component.scss']
})
export class ContractsViewComponent implements OnInit {
  contractSearchForm: ContractSearchForm = new ContractSearchForm();
  contract: Contract;
  isActive = true;

  private readonly CONTRACTS_ROUTE = 'maintenance/contracts';
  faPlusCircle: IconDefinition = faPlusCircle;

  constructor(
    private readonly router: Router,
    private readonly maintenanceService: MaintenanceService,
    private readonly route: ActivatedRoute
  ) {
    this.contractSearchForm.insurerId.valueChanges.subscribe(insurerId => {
      if (insurerId) {
        this.router.navigate([this.CONTRACTS_ROUTE, insurerId]);
      }
    });
    this.contractSearchForm.contractId.valueChanges.subscribe(contractId => {
      if (contractId) {
        this.router.navigate([this.CONTRACTS_ROUTE, this.insurerId, contractId]);
      } else {
        this.contract = null;
      }
    });
  }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.contractSearchForm.insurerId.setValue(+params['insurerId']);
      this.contractSearchForm.contractId.setValue(params['contractId']);

      if (this.contractId) {
        this.loadContract();
      }
    });
  }

  get insurerId(): number {
    return this.contractSearchForm.insurerId.value;
  }

  get contractId(): string {
    return this.contractSearchForm.contractId.value;
  }

  loadContract() {
    this.maintenanceService.getContractDetails(this.contractId).subscribe(data => {
      this.contract = data;
      this.isActive = this.contract.isActive;
    });
  }

  addNewContract() {
    this.router.navigate([this.CONTRACTS_ROUTE, this.insurerId, 'create']);
  }
}
