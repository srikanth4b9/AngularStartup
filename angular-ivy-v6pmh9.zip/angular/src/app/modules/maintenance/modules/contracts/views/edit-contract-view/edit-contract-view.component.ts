import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HomeService } from '@app/modules/home/services';
import { MaintenanceService } from '@app/modules/maintenance/services';
import { DateTimeUtils, FormUtils } from '@app/shared';
import {
  faExclamationTriangle,
  faPlusCircle,
  faTrash,
  IconDefinition
} from '@fortawesome/free-solid-svg-icons';

import { Insurer } from '../../../insurers/models';
import {
  AccountingServiceProvider,
  ContractForm,
  RateSentType,
  ResetFrequencyType,
  WorkflowType
} from '../../models';

@Component({
  selector: 'rxu-edit-contract-view',
  templateUrl: './edit-contract-view.component.html',
  styleUrls: ['./edit-contract-view.component.scss']
})
export class EditContractViewComponent implements OnInit {
  insurerId: number;
  insurer: Insurer = new Insurer();
  contractId: string;
  contractForm: ContractForm = new ContractForm();

  AccountingServiceProvider = AccountingServiceProvider;
  ResetFrequencyType = ResetFrequencyType;
  RateSentType = RateSentType;
  WorkflowType = WorkflowType;
  FormUtils = FormUtils;
  keys = Object.keys;
  faExclamationTriangle: IconDefinition = faExclamationTriangle;
  faPlusCircle: IconDefinition = faPlusCircle;
  faTrash: IconDefinition = faTrash;

  constructor(
    private readonly router: Router,
    private readonly route: ActivatedRoute,
    private readonly maintenanceService: MaintenanceService,
    private readonly homeService: HomeService
  ) {}

  ngOnInit() {
    this.insurerId = +this.route.snapshot.params.insurerId;
    if (this.insurerId) {
      this.setInsurer(this.insurerId);
    }
    this.contractId = this.route.snapshot.params.contractId;
    if (this.contractId) {
      this.loadContractDetails(this.contractId);
    }
  }

  get viewTitle() {
    return `${this.contractForm.isNew ? 'Create New' : 'Edit'} Contract`;
  }

  get insurerTitle() {
    return `${this.insurer.insurerCode} - ${this.insurer.insurerName}`;
  }

  private setInsurer(insurerId: number) {
    this.maintenanceService.insurers$.subscribe(insurers => {
      if (insurers.length) {
        this.insurer = insurers.filter(insurer => insurer.insurerId === insurerId)[0];
        this.contractForm.insurerId.setValue(this.insurer.insurerId);
        this.contractForm.insurerName.setValue(this.insurer.insurerName);
      } else {
        this.maintenanceService.getInsurers();
      }
    });
  }

  private loadContractDetails(contractId: string) {
    this.maintenanceService.getContractDetails(contractId).subscribe(contract => {
      this.contractForm = new ContractForm(contract);
      this.setInsurer(this.insurerId);
    });
  }

  saveContract() {
    this.formatStartDate();
    this.maintenanceService.saveContract(this.contractForm).subscribe(() => {
      this.recalculateRateResets();
      this.navigateToContracts(this.contractForm.contractId.value);
    });
  }

  private formatStartDate() {
    if (this.contractForm.resetStartDate) {
      this.contractForm.resetStartDate.setValue(
        DateTimeUtils.toISOString(this.contractForm.resetStartDate.value)
      );
    }
  }

  private recalculateRateResets() {
    if (!this.contractForm.isNew) {
      this.homeService.recalculateRateResetsForContract(this.contractForm.contractId.value);
    }
  }

  navigateToContracts(contractId = this.contractId) {
    const contractsRoute = 'maintenance/contracts';
    const commands = contractId
      ? [contractsRoute, this.insurerId, contractId]
      : this.insurerId
      ? [contractsRoute, this.insurerId]
      : [contractsRoute];
    this.router.navigate(commands);
  }
}
