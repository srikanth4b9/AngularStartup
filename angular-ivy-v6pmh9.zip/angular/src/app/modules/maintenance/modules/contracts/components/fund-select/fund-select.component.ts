import { Component, Input, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MaintenanceService } from '@app/modules/maintenance/services';
import { StableValueFund } from '../../models';

@Component({
  selector: 'rxu-fund-select',
  templateUrl: './fund-select.component.html',
  styleUrls: ['./fund-select.component.scss']
})
export class FundSelectComponent implements OnInit {
  @Input() control: FormControl = new FormControl();

  funds: StableValueFund[] = [];

  constructor(private readonly maintenanceService: MaintenanceService) {}

  ngOnInit() {
    this.loadFunds();
  }

  loadFunds() {
    this.maintenanceService.funds$.subscribe(funds => {
      this.funds = funds;
      this.funds.sort();
    });
    this.maintenanceService.getFunds();
  }
}
