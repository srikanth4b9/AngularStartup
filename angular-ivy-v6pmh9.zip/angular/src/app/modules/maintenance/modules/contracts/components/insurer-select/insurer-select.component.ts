import { Component, Input } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MaintenanceService } from '@app/modules/maintenance/services/maintenance.service';
import { Insurer } from '@maintenance/modules/insurers/models';
import { map } from 'rxjs/operators';

@Component({
  selector: 'rxu-insurer-select',
  templateUrl: './insurer-select.component.html',
  styleUrls: ['./insurer-select.component.scss']
})
export class InsurerSelectComponent {
  @Input() control: FormControl = new FormControl();

  insurers: Insurer[] = [];

  constructor(private readonly maintenanceService: MaintenanceService) {
    this.loadInsurers();
  }

  private loadInsurers() {
    this.maintenanceService.insurers$
      .pipe(map(insurers => insurers.filter(insurer => insurer.isActive)))
      .subscribe(insurers => {
        this.insurers = insurers;
      });
    this.maintenanceService.getInsurers();
  }
}
