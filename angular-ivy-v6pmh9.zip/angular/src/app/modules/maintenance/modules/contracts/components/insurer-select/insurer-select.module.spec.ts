import { InsurerSelectModule } from './insurer-select.module';

describe('InsurerSelectModule', () => {
    let insurerSelectModule: InsurerSelectModule;

    beforeEach(() => {
        insurerSelectModule = new InsurerSelectModule();
    });

    it('should create an instance', () => {
        expect(insurerSelectModule).toBeTruthy();
    });
});
