import { AbstractControl, FormControl, Validators } from '@angular/forms';
import { CustomForm } from '@app/shared';

import { StableValueFund } from './stable-value-fund.model';

const MAX_PORT_ID = 4;
const MAX_STRING = 255;

export class StableValueFundForm extends CustomForm<StableValueFund> {
  /* istanbul ignore next */
  constructor(fund: StableValueFund = new StableValueFund()) {
    super({
      portId: new FormControl(fund.portId, [
        Validators.required,
        Validators.maxLength(MAX_PORT_ID)
      ]),
      fundName: new FormControl(fund.fundName, [
        Validators.required,
        Validators.maxLength(MAX_STRING)
      ])
    });
    this.object = fund;
  }

  get objectName() {
    return 'Stable Value Fund';
  }
  get uri() {
    return undefined;
  }
  get idAttribute() {
    return 'portId';
  }

  get portId(): AbstractControl {
    return this.get('portId');
  }
  get fundName(): AbstractControl {
    return this.get('fundName');
  }
}
