import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule, MatSelectModule } from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { MaintenanceService, MockMaintenanceService } from '@app/modules/maintenance/services';
import { ActiveToggleModule } from '@app/shared/components';
import { mockContractIdList } from '@contracts/models';

import { ContractIdSelectComponent } from './contract-id-select.component';

describe('ContractIdSelectComponent', () => {
  let component: ContractIdSelectComponent;
  let fixture: ComponentFixture<ContractIdSelectComponent>;
  let maintenanceService: MaintenanceService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatSelectModule,
        ActiveToggleModule
      ],
      declarations: [ContractIdSelectComponent],
      providers: [{ provide: MaintenanceService, useClass: MockMaintenanceService }]
    }).compileComponents();

    maintenanceService = TestBed.get(MaintenanceService);
  }));

  function createComponent() {
    fixture = TestBed.createComponent(ContractIdSelectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  it('should create', () => {
    createComponent();
    expect(component).toBeTruthy();
  });

  describe('loadContractIds:', () => {
    it('should call the service to get contract details', () => {
      createComponent();

      component.loadContractIds();

      expect(maintenanceService.getContractIds).toHaveBeenCalled();
      expect(component.contractIds).toEqual(mockContractIdList);
    });
  });

  describe('ngOnChanges:', () => {
    let loadContractIdsSpy: jasmine.Spy;
    beforeEach(function() {
      createComponent();
      loadContractIdsSpy = spyOn(component, 'loadContractIds');
    });

    it('should call loadContractIds if insurerId is set', () => {
      component.insurerId = 7;

      component.ngOnChanges();

      expect(loadContractIdsSpy).toHaveBeenCalled();
    });

    it('should not call loadContractIds if insurerId is undefined', () => {
      component.ngOnChanges();

      expect(loadContractIdsSpy).not.toHaveBeenCalled();
    });
  });

  describe('resetContractIds:', () => {
    it('should reset the control and filter the ID list', () => {
      createComponent();
      const filterSpy = spyOn(component, 'filterContractIds');

      component.resetContractIds();

      expect(component.control.value).toEqual(null);
      expect(filterSpy).toHaveBeenCalled();
    });
  });

  describe('activeToggle:', () => {
    it('should use the contract active status to filter if activeToggle is disabled', () => {
      createComponent();
      component.activeToggle = false;

      component.loadContractIds();

      expect(component.filteredIds.length).toEqual(2);
    });
  });
});
