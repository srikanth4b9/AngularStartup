import { Contract, ResetFrequencyType } from './contract.model';
import { mockContractsData } from './mock-json';
import { ACTION } from '@app/shared';

describe('Contract', () => {
  let contract: Contract;

  beforeEach(function() {
    contract = new Contract(mockContractsData[0]);
  });

  describe('constructor', () => {
    it('should set default values', () => {
      contract = new Contract();

      expect(contract.isActive).toBe(true);
      expect(contract.accountingServiceProvider).toEqual('NORTHERN_TRUST');
      expect(contract.resetFrequencyTypeCode).toEqual('MONTHLY');
      expect(contract.workflowTypeCode).toEqual('CONFIRM_RATES');
      expect(contract.rateSentTypeCode).toEqual('VANGUARD');
    });

    it('should intialize properties using constructor param', () => {
      contract = new Contract(mockContractsData[1]);

      expect(contract.contractId).toEqual(mockContractsData[1].contractId);
      expect(contract.resetFrequencyTypeCode).toEqual(mockContractsData[1].resetFrequencyTypeCode);
      expect(contract.workflowTypeCode).toEqual(mockContractsData[1].workflowTypeCode);
    });

    it('should intialize rate reset frequency to "MONTHLY" ', () => {
      contract = new Contract(mockContractsData[0]);
      expect(contract.contractId).toEqual(mockContractsData[0].contractId);
      expect(contract.resetFrequencyTypeCode).toEqual(mockContractsData[0].resetFrequencyTypeCode);
      expect(contract.resetMonths).toEqual(ResetFrequencyType.MONTHLY);
      expect(contract.workflowTypeCode).toEqual(mockContractsData[0].workflowTypeCode);
    });

    it('should set action options for an active contract', () => {
      contract = new Contract(mockContractsData[0]);

      contract.actionOptions$.subscribe(options =>
        expect(options).toEqual([ACTION.EDIT, ACTION.DEACTIVATE])
      );
    });

    it('should set action options for an inactive contract', () => {
      const mockContract = Object.assign({}, mockContractsData[0]);
      mockContract.isActive = false;
      contract = new Contract(mockContract);

      contract.actionOptions$.subscribe(options => expect(options).toEqual([ACTION.REACTIVATE]));
    });

    it('should get the alphabetical three lettered version of the months from numerical format', () => {
      const mockContract = Object.assign({}, mockContractsData[1]);
      mockContract.resetSchedule = [1, 6, 8];
      contract = new Contract(mockContract);

      expect(contract.resetMonths).toEqual('Jan, Jun, Aug');
    });
  });
});
