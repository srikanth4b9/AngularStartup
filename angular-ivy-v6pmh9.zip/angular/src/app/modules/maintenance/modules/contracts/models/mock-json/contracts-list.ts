import { Contract } from '@contracts/models/contract.model';

import { mockUnderlyingAssets } from '../../../underlying-assets/models';

export const mockContractsData: Contract[] = [
  {
    accountingServiceProvider: 'NORTHERN_TRUST',
    resetFrequencyTypeCode: 'MONTHLY',
    isActive: true,
    workflowTypeCode: 'PROVIDE_RATES',
    rateSentTypeCode: 'INSURER',
    underLyingAssets: [mockUnderlyingAssets[0], mockUnderlyingAssets[1]],
    resetSchedule: [1, 4, 5],
    contractId: 'MET32782',
    insurerId: 2,
    insurerName: 'MET LIFE',
    resetStartDate: '2004-04-01T00:00:00-05:00',
    isIncludeWrapFee: false,
    wrapFee: '0.0001',
    isIncludeExpenseRatio: false,
    lastUpdatedTimestamp: '2019-04-11T13:19:35.69-04:00',
    crewUserId: 'SYSTEM',
    stableValueFunds: [
      {
        portId: '4249',
        fundName: '4249 KAISER STABLE 403B'
      },
      {
        portId: '5740',
        fundName: '5740 KAISER STABLE 403B'
      }
    ]
  },
  {
    accountingServiceProvider: 'OTHER',
    resetFrequencyTypeCode: 'ANNUAL',
    isActive: true,
    workflowTypeCode: 'PROVIDE_RATES',
    rateSentTypeCode: 'INSURER',
    underLyingAssets: [],
    resetSchedule: [1, 6, 8],
    contractId: 'MET32782',
    insurerId: 2,
    insurerName: 'MET LIFE',
    resetStartDate: '2004-04-01T00:00:00-05:00',
    isIncludeWrapFee: false,
    wrapFee: '0.0001',
    isIncludeExpenseRatio: false,
    lastUpdatedTimestamp: '2019-04-11T13:19:35.69-04:00',
    crewUserId: 'SYSTEM',
    stableValueFunds: [
      {
        portId: '4249',
        fundName: '4249 KAISER STABLE 403B'
      }
    ]
  }
];
