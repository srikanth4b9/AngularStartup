import { StableValueFund } from '../stable-value-fund.model';

export const mockStableValueFunds: StableValueFund[] = [
  {
    portId: '0423',
    fundName: 'Fidelity - FIDC'
  },
  {
    portId: '0555',
    fundName: 'Fidelity - FIVG'
  },
  {
    portId: '0677',
    fundName: 'Outside Fund Name 3'
  }
];
