import { ContractSearchForm } from './contract-search-form.model';
import { mockContractsData } from './mock-json';

describe('ContractSearchForm', () => {
  let searchForm: ContractSearchForm;

  describe('constructor', () => {
    it('should create controls for a new Contract Search', async () => {
      searchForm = new ContractSearchForm();
      expect(searchForm).toBeDefined();
    });
  });

  describe('Control Getters', () => {
    beforeEach(function () {
      searchForm = new ContractSearchForm(mockContractsData[0].insurerId, mockContractsData[0].contractId);
    });

    formControlGetterTest('insurerId');
    formControlGetterTest('contractId');
  });

  function formControlGetterTest(controlName: string) {
    it(`should create a control getter for ${controlName}`, async () => {
      expect(searchForm[controlName].value).toEqual(mockContractsData[0][controlName]);
    });
  }

  describe('insurerId value change', () => {
    beforeEach(function () {
      searchForm = new ContractSearchForm(mockContractsData[0].insurerId, mockContractsData[0].contractId);
    });

    it('should reset contract ID control when Insurer ID changes and enable if defined', async () => {
      searchForm.patchValue({
        insurerId: 1234
      });

      expect(searchForm.contractId.value).toEqual(null);
      expect(searchForm.contractId.enabled).toEqual(true);
    });

    it('should disable contract ID control when Insurer ID is undefined', async () => {
      searchForm.patchValue({
        insurerId: null
      });

      expect(searchForm.contractId.disabled).toEqual(true);
    });
  });
});
