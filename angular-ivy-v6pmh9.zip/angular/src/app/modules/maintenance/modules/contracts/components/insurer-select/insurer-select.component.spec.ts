import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule, MatSelectModule } from '@angular/material';
import { mockInsurerList, Insurer } from '@insurers/models';
import { MaintenanceService, MockMaintenanceService } from '@maintenance/services';
import { InsurerSelectComponent } from './insurer-select.component';

describe('InsurerSelectComponent', () => {
  let component: InsurerSelectComponent;
  let fixture: ComponentFixture<InsurerSelectComponent>;
  let maintenanceService: MaintenanceService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [NoopAnimationsModule, ReactiveFormsModule, MatFormFieldModule, MatSelectModule],
      declarations: [InsurerSelectComponent],
      providers: [{ provide: MaintenanceService, useValue: new MockMaintenanceService() }]
    }).compileComponents();

    maintenanceService = TestBed.get(MaintenanceService);
  });

  function createComponent() {
    fixture = TestBed.createComponent(InsurerSelectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  beforeEach(() => {
    createComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('loadInsurers:', () => {
    it('should call the service to get list of insurers', () => {
      const expectedInsurers = mockInsurerList
        .filter(insurer => insurer.isActive)
        .map(insurer => new Insurer(insurer));

      expect(maintenanceService.getInsurers).toHaveBeenCalled();
      expect(component.insurers).toEqual(expectedInsurers);
    });
  });
});
