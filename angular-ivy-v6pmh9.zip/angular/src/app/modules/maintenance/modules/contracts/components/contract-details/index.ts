export * from './contract-details.component';
export * from './contract-details.module';
