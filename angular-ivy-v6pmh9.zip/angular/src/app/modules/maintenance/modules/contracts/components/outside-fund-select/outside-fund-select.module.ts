import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OutsideFundSelectComponent } from './outside-fund-select.component';
import { ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule, MatSelectModule } from '@angular/material';

@NgModule({
  declarations: [OutsideFundSelectComponent],
  imports: [CommonModule, ReactiveFormsModule, MatFormFieldModule, MatSelectModule],
  exports: [OutsideFundSelectComponent]
})
export class OutsideFundSelectModule {}
