import { FormGroup, FormControl, Validators, AbstractControl } from '@angular/forms';

export class ContractSearchForm extends FormGroup {
  /* istanbul ignore next */
  constructor(insurerId?: number, contractId?: string) {
    super({
      insurerId: new FormControl(insurerId, Validators.required),
      contractId: new FormControl(contractId)
    });

    this.insurerId.valueChanges.subscribe(value => {
      this.contractId.reset();
      value ? this.contractId.enable() : this.contractId.disable();
    });
  }

  get insurerId(): AbstractControl {
    return this.get('insurerId');
  }
  get contractId(): AbstractControl {
    return this.get('contractId');
  }
}
