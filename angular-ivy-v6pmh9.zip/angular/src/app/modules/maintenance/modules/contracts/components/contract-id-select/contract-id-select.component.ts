import { Component, Input, OnChanges } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ContractId } from '@contracts/models';
import { MaintenanceService } from '@maintenance/services';

@Component({
  selector: 'rxu-contract-id-select',
  templateUrl: './contract-id-select.component.html',
  styleUrls: ['./contract-id-select.component.scss']
})
export class ContractIdSelectComponent implements OnChanges {
  @Input() control: FormControl = new FormControl();
  @Input() insurerId: number;
  @Input() activeToggle = true;
  @Input() isActive = true;

  contractIds: ContractId[] = [];
  filteredIds: ContractId[] = [];

  constructor(private readonly maintenanceService: MaintenanceService) {}

  ngOnChanges() {
    if (this.insurerId) {
      this.loadContractIds();
    }
  }

  loadContractIds() {
    this.maintenanceService.getContractIds(this.insurerId).subscribe(data => {
      this.contractIds = data;
      this.filterContractIds();
    });
  }

  filterContractIds() {
    this.filteredIds = this.contractIds.filter(id => this._activeFilter(id.isActive));
  }

  resetContractIds() {
    this.control.reset();
    this.filterContractIds();
  }

  private _activeFilter(isIdActive: boolean = true) {
    return this.activeToggle ? this.isActive === isIdActive : isIdActive;
  }
}
