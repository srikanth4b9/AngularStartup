import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { StableValueFund } from '../../models';
import { MaintenanceService } from '@app/modules/maintenance/services';
import { MatSelectChange } from '@angular/material';

@Component({
  selector: 'rxu-outside-fund-select',
  templateUrl: './outside-fund-select.component.html',
  styleUrls: ['./outside-fund-select.component.scss']
})
export class OutsideFundSelectComponent implements OnInit {
  @Output() selectedFund: EventEmitter<StableValueFund> = new EventEmitter();

  outsideFunds: StableValueFund[] = [];

  constructor(private readonly maintenanceService: MaintenanceService) {}

  ngOnInit() {
    this.loadOutsideFunds();
  }

  loadOutsideFunds() {
    this.maintenanceService.outsideFunds$
      // .pipe(map(outsideFunds => outsideFunds.filter(fund => fund.isActive)))
      .subscribe(outsideFunds => {
        this.outsideFunds = outsideFunds;
        // this.outsideFunds.sort((a, b) => (a.portId > b.portId ? 1 : -1));
      });
    this.maintenanceService.getOutsideFunds();
  }

  selectionChange(selectChange: MatSelectChange | { source: any; value: StableValueFund }) {
    if (selectChange.value) {
      this.selectedFund.emit(selectChange.value);
      selectChange.source.writeValue(null);
    }
  }
}
