export * from './contracts-view.component';
export * from './contracts-view.module';
