import { mockUnderlyingAssets, UnderlyingAsset } from '../../underlying-assets/models';
import { ContractForm } from './contract-form.model';
import { Contract } from './contract.model';
import { mockContractsData } from './mock-json';
import { StableValueFund } from './stable-value-fund.model';

describe('ContractForm', () => {
  let contractForm: ContractForm;

  beforeEach(function() {
    contractForm = new ContractForm(mockContractsData[0]);
  });

  describe('constructor', () => {
    it('should create controls for a new Contract Search', async () => {
      expect(contractForm).toBeDefined();
    });

    it('should enable the contract ID control if contract ID is undefined', async () => {
      contractForm = new ContractForm();
      expect(contractForm.contractId.disabled).toEqual(false);
    });

    it('should disable the contract ID control if contract ID is valued', async () => {
      expect(contractForm.contractId.disabled).toEqual(true);
    });
  });

  describe('Control Getters', () => {
    const contract = mockContractsData[0];
    formControlGetterTest('insurerId', contract);
    formControlGetterTest('insurerName', contract);
    formControlGetterTest('contractId', contract);
    formControlGetterTest('accountingServiceProvider', contract);
    formControlGetterTest('isIncludeExpenseRatio', contract);
    formControlGetterTest('isIncludeWrapFee', contract);
    formControlGetterTest('wrapFee', contract);
    formControlGetterTest('workflowTypeCode', contract);
    formControlGetterTest('rateSentTypeCode', contract);
  });

  function formControlGetterTest(controlName: string, contract: Contract) {
    it(`should create a control getter for ${controlName}`, async () => {
      expect(contractForm[controlName].value).toEqual(contract[controlName]);
    });
  }

  describe('Other Service Provider', () => {
    const contract: Contract = mockContractsData[1];
    beforeEach(function() {
      contractForm = new ContractForm(contract);
    });

    formControlGetterTest('resetFrequencyTypeCode', contract);
    formControlGetterTest('resetStartDate', contract);

    describe('Stable Value Funds', () => {
      it('should create a form array getter for stable value fund', () => {
        expect(contractForm.stableValueFund.value).toEqual(
          mockContractsData[1].stableValueFunds[0]
        );
      });
    });

    describe('addOutsideFund', () => {
      let fund: StableValueFund;
      beforeEach(function() {
        fund = Object.assign({}, mockContractsData[1].stableValueFunds[0]);
      });

      it('should set the stable value fund if it is new', () => {
        fund.portId = '5555';

        contractForm.addOutsideFund(fund);

        expect(contractForm.stableValueFund.portId.value).toEqual(fund.portId);
      });

      it('should set the stable value fund if there is no fund set', () => {
        contractForm.removeOutsideFund();

        contractForm.addOutsideFund(fund);

        expect(contractForm.stableValueFund.portId.value).toEqual(fund.portId);
      });

      it('should do nothing if the fund is already set', () => {
        spyOn(contractForm, 'removeOutsideFund');
        contractForm.addOutsideFund(fund);

        expect(contractForm.removeOutsideFund).not.toHaveBeenCalled();
      });
    });

    describe('removeOutsideFund', () => {
      it('should remove the selected fund', () => {
        contractForm.removeOutsideFund();

        expect(contractForm.stableValueFunds.length).toEqual(0);
        expect(contractForm.stableValueFunds.dirty).toEqual(true);
      });
    });
  });

  describe('accountingServiceProvider value change', () => {
    it('should set accounting service provider controls', () => {
      contractForm.patchValue({
        accountingServiceProvider: 'OTHER'
      });

      expect(contractForm.resetFrequencyTypeCode).toBeDefined();
      expect(contractForm.resetStartDate).toBeDefined();
      expect(contractForm.stableValueFunds).toBeDefined();
    });
  });

  describe('workflowTypeCode value change', () => {
    it('should reset rateSentTypeCode control and options when Workflow Type changes', async () => {
      contractForm.patchValue({
        workflowTypeCode: 'CONFIRM_RATES'
      });

      expect(contractForm.rateSentTypeCode.value).toEqual('VANGUARD');
      contractForm.rateSentOptions$.subscribe(options => {
        expect(options).toEqual(['VANGUARD', 'INSURER']);
      });
    });
  });

  describe('Asset Validation', () => {
    beforeEach(function() {
      contractForm.removeAllAssets();
    });

    it('should be invalid if workflow type is not ENTER_RATES and the assets array is empty', () => {
      expect(contractForm.invalid).toBe(true);
      expect(contractForm.underLyingAssets.errors).toEqual({
        emptyArray: 'underlying asset'
      });
    });

    it('should be valid if workflow type is ENTER_RATES and the assets array is empty', () => {
      contractForm.workflowTypeCode.setValue('ENTER_RATES');

      expect(contractForm.valid).toBe(true);
    });
  });

  describe('shouldDisplayEnterRatesAssetWarning', () => {
    it('should return false if workflow type is not ENTER_RATES', () => {
      expect(contractForm.shouldDisplayEnterRatesAssetWarning()).toBe(false);
    });

    it('should return false if contract assets are empty', () => {
      contractForm.removeAllAssets();
      contractForm.workflowTypeCode.setValue('ENTER_RATES');

      expect(contractForm.shouldDisplayEnterRatesAssetWarning()).toBe(false);
    });

    it('should return true if workflow type is ENTER_RATES contract assets are not empty', () => {
      contractForm.workflowTypeCode.setValue('ENTER_RATES');

      expect(contractForm.shouldDisplayEnterRatesAssetWarning()).toBe(true);
    });
  });

  describe('addAsset', () => {
    let asset: UnderlyingAsset;
    beforeEach(function() {
      asset = Object.assign({}, mockUnderlyingAssets[0]);
    });

    it('should add an asset to the list of contract assets if it is unique', () => {
      asset.assetId = 'New Asset ID';

      contractForm.addAsset(asset);

      expect(contractForm.underLyingAssets.length).toEqual(3);
      expect(contractForm.underLyingAssets.dirty).toEqual(true);
    });

    it('should do nothing if the asset is already added', () => {
      contractForm.addAsset(asset);

      expect(contractForm.underLyingAssets.length).toEqual(2);
      expect(contractForm.underLyingAssets.dirty).toEqual(false);
    });
  });

  describe('removeAsset', () => {
    it('should remove an asset from the list of contract assets', () => {
      contractForm.removeAsset(0);

      expect(contractForm.underLyingAssets.length).toEqual(1);
      expect(contractForm.underLyingAssets.dirty).toEqual(true);
    });
  });

  describe('removeAllAssets', () => {
    it('should remove all assets from the list of contract assets', () => {
      contractForm.removeAllAssets();

      expect(contractForm.underLyingAssets.length).toEqual(0);
      expect(contractForm.underLyingAssets.dirty).toEqual(true);
    });
  });
});
