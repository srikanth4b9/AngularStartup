import { Component, Input } from '@angular/core';
import { MatDialog } from '@angular/material';
import { Router } from '@angular/router';
import { ConfirmDialogComponent } from '@app/components';
import {
  ACTION,
  ActionRequest,
  activeStatusConfirmDialogData,
  ConfirmDialogModel,
  UpdateRequest
} from '@app/shared';
import {
  AccountingServiceProvider,
  Contract,
  RateSentType,
  ResetFrequencyType,
  StableValueFundTableDef,
  WorkflowType
} from '@contracts/models';
import { environment } from '@env';
import { faEdit, IconDefinition } from '@fortawesome/free-solid-svg-icons';
import { MaintenanceService } from '@maintenance/services';
import { UnderlyingAssetTableDef } from '@underlying-assets/models';
import { BehaviorSubject, Observable } from 'rxjs';

@Component({
  selector: 'rxu-contract-details',
  templateUrl: './contract-details.component.html',
  styleUrls: ['./contract-details.component.scss']
})
export class ContractDetailsComponent {
  @Input() insurerId: number;
  @Input() contract: Contract;

  uri = environment.CONTRACTS_URI;

  private readonly actionOptions?: BehaviorSubject<ACTION[]> = new BehaviorSubject([]);
  actionOptions$?: Observable<ACTION[]> = this.actionOptions.asObservable();

  AccountingServiceProvider = AccountingServiceProvider;
  ResetFrequencyType = ResetFrequencyType;
  RateSentType = RateSentType;
  WorkflowType = WorkflowType;
  faEdit: IconDefinition = faEdit;

  stableValueFundTableDef = new StableValueFundTableDef();
  underlyingAssetTableDef = new UnderlyingAssetTableDef(false);

  private readonly editWarningDialogModel: ConfirmDialogModel = {
    title: 'Modifying the contract will re-initialize any in-progress rate resets.',
    confirmButtonText: 'Continue'
  };

  constructor(
    private readonly router: Router,
    private readonly maintenanceService: MaintenanceService,
    private readonly dialog: MatDialog
  ) {}

  action(action: ACTION) {
    if (action === ACTION.EDIT) {
      this.openEditWarningDialog();
    } else if (action === ACTION.DEACTIVATE || action === ACTION.REACTIVATE) {
      this.openActiveStatusConfirmDialog(action);
    }
  }

  private openEditWarningDialog() {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: this.editWarningDialogModel
    });
    dialogRef.afterClosed().subscribe(data => {
      if (data === 'confirm') {
        this.router.navigate([
          'maintenance/contracts',
          this.insurerId,
          this.contract.contractId,
          'edit'
        ]);
      }
    });
  }

  private openActiveStatusConfirmDialog(action: any): void {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: activeStatusConfirmDialogData[action]
    });
    dialogRef.afterClosed().subscribe(data => {
      if (data === 'confirm') {
        const actionRequest: ActionRequest<Contract> = new ActionRequest(
          action,
          this.contract.getRawValue()
        );
        const path = `${this.uri}/${this.contract.contractId}`;
        const statusRequest = new UpdateRequest(actionRequest, path);

        this.maintenanceService.updateActiveStatus(statusRequest).subscribe(() => {
          this.maintenanceService.resetContractIds(this.insurerId);
          this.router.navigate(['maintenance/contracts', this.insurerId]);
        });
      }
    });
  }
}
