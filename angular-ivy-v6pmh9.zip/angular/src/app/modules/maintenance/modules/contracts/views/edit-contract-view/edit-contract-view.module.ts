import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import {
  MatButtonModule,
  MatCheckboxModule,
  MatDatepickerModule,
  MatInputModule,
  MatSelectModule,
  MatToolbarModule
} from '@angular/material';
import { PercentLabelModule } from '@app/shared/components';
import { VuiSelectModule } from 'vg-vui-ng/select';

import { EditContractViewComponent } from './edit-contract-view.component';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { AssetSelectModule, OutsideFundSelectModule } from '../../components';

@NgModule({
  declarations: [EditContractViewComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatToolbarModule,
    MatButtonModule,
    MatCheckboxModule,
    VuiSelectModule,
    MatSelectModule,
    MatInputModule,
    MatDatepickerModule,
    MatMomentDateModule,
    PercentLabelModule,
    FontAwesomeModule,
    AssetSelectModule,
    OutsideFundSelectModule
  ],
  exports: [EditContractViewComponent]
})
export class EditContractViewModule {}
