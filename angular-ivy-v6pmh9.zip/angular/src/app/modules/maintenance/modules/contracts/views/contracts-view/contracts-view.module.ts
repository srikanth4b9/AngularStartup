import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ContractsViewComponent } from './contracts-view.component';
import { InsurerSelectModule, ContractIdSelectModule, ContractDetailsModule } from '@contracts/components';
import { MatButtonModule, MatToolbarModule } from '@angular/material';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

@NgModule({
  declarations: [ContractsViewComponent],
  imports: [
    CommonModule,
    MatButtonModule,
    MatToolbarModule,
    InsurerSelectModule,
    ContractIdSelectModule,
    ContractDetailsModule,
    FontAwesomeModule
  ],
  exports: [ContractsViewComponent]
})
export class ContractsViewModule { }
