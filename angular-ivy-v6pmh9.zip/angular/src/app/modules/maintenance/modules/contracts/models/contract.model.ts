import { ACTION } from '@app/shared';
import * as moment from 'moment';
import { BehaviorSubject, Observable } from 'rxjs';

import { UnderlyingAsset } from '../../underlying-assets/models';
import { StableValueFund } from './stable-value-fund.model';

const REMOVE_LAST_COMMA = -2;

export class Contract {
  contractId: string;
  insurerId: number;
  insurerName?: string;
  name?: string;
  accountingServiceProvider?: AccountingServiceProvider = 'NORTHERN_TRUST';
  resetFrequencyTypeCode: ResetFrequencyType = 'MONTHLY';
  resetStartDate: string;
  resetSchedule: number[] = [];
  isActive: boolean = true;
  isIncludeExpenseRatio: boolean;
  isIncludeWrapFee: boolean;
  wrapFee?: string;
  workflowTypeCode: WorkflowType = 'CONFIRM_RATES';
  rateSentTypeCode: RateSentType = 'VANGUARD';
  crewUserId: string;
  lastUpdatedTimestamp: string;
  stableValueFunds: StableValueFund[] = [];
  underLyingAssets: UnderlyingAsset[] = [];
  resetMonths?: string;

  private actionOptions?: BehaviorSubject<ACTION[]>;
  actionOptions$?: Observable<ACTION[]>;

  constructor(contract?: Contract) {
    Object.assign(this, contract);

    this.setResetMonths();
    this.actionOptions = new BehaviorSubject(
      this.isActive ? [ACTION.EDIT, ACTION.DEACTIVATE] : [ACTION.REACTIVATE]
    );
    this.actionOptions$ = this.actionOptions.asObservable();
  }

  private setResetMonths?(): void {
    this.resetMonths =
      this.resetFrequencyTypeCode === 'MONTHLY'
        ? ResetFrequencyType.MONTHLY
        : this.resetSchedule
            .reduce((accumulation, currIndex) => {
              return (accumulation +=
                moment()
                  .month(currIndex - 1)
                  .format('MMM') + ', ');
            }, '')
            .slice(0, REMOVE_LAST_COMMA);
  }

  getRawValue?(): Contract {
    const contract = Object.assign({}, this);
    delete contract.resetMonths;
    delete contract.actionOptions;
    delete contract.actionOptions$;
    return contract;
  }
}

export class ContractId {
  contract: string;
  isActive?: boolean;
}

export type AccountingServiceProvider = 'NORTHERN_TRUST' | 'OTHER' | 'NULL';
export const AccountingServiceProvider = {
  NORTHERN_TRUST: 'Northern Trust',
  OTHER: 'Other'
};

type ResetFrequencyType = 'MONTHLY' | 'QUARTERLY' | 'SEMIANNUAL' | 'ANNUAL' | 'NULL';
export const ResetFrequencyType = {
  MONTHLY: 'Monthly',
  QUARTERLY: 'Quarterly',
  SEMIANNUAL: 'Semi-Annual',
  ANNUAL: 'Annual'
};

export type RateSentType = 'VANGUARD' | 'INSURER' | 'NULL';
export const RateSentType = {
  VANGUARD: 'Vanguard',
  INSURER: 'Insurer'
};

export type WorkflowType = 'CONFIRM_RATES' | 'PROVIDE_RATES' | 'ENTER_RATES' | 'NONE';
export const WorkflowType = {
  CONFIRM_RATES: 'Confirm Rates',
  PROVIDE_RATES: 'Provide Rates',
  ENTER_RATES: 'Enter Rates'
};
