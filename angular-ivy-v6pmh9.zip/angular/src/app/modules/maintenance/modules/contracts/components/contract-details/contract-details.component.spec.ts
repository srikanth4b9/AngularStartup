import { MdcCheckboxModule } from '@angular-mdc/web';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { MatButtonModule, MatDialog, MatToolbarModule } from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { ConfirmDialogComponent } from '@app/components';
import { ACTION, activeStatusConfirmDialogData, ConfirmDialogModel } from '@app/shared';
import { ActionSelectModule, CustomMatTableModule } from '@app/shared/components';
import { mockContractsData, Contract } from '@contracts/models';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { MaintenanceService, MockMaintenanceService } from '@maintenance/services';
import { of } from 'rxjs';

import { ContractDetailsComponent } from './contract-details.component';

class MockDialog {
  open = jasmine.createSpy().and.returnValue({
    afterClosed: () => of({})
  });
}

describe('ContractDetailsComponent', () => {
  let component: ContractDetailsComponent;
  let fixture: ComponentFixture<ContractDetailsComponent>;
  let maintenanceService: MockMaintenanceService;
  let router: Router;
  let dialog: MockDialog;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule,
        RouterTestingModule,
        FormsModule,
        MatButtonModule,
        MdcCheckboxModule,
        MatToolbarModule,
        FontAwesomeModule,
        ActionSelectModule,
        CustomMatTableModule
      ],
      declarations: [ContractDetailsComponent],
      providers: [
        { provide: MaintenanceService, useClass: MockMaintenanceService },
        { provide: MatDialog, useClass: MockDialog }
      ]
    }).compileComponents();

    router = TestBed.get(Router);
    dialog = TestBed.get(MatDialog);
    maintenanceService = TestBed.get(MaintenanceService);
  }));

  function createComponent() {
    fixture = TestBed.createComponent(ContractDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  function mockDialogSave(object: any) {
    dialog.open.and.returnValue({
      afterClosed: () => of(object)
    });
  }

  it('should create', () => {
    createComponent();
    expect(component).toBeTruthy();
  });

  describe('action', () => {
    beforeEach(function() {
      createComponent();
      component.insurerId = 354;
      component.contract = new Contract(mockContractsData[0]);
      spyOn(router, 'navigate');
    });

    describe('EDIT', () => {
      it('should navigate to the edit contract page', () => {
        const expectedDialogModel: ConfirmDialogModel = {
          title: 'Modifying the contract will re-initialize any in-progress rate resets.',
          confirmButtonText: 'Continue'
        };
        mockDialogSave('confirm');

        component.action(ACTION.EDIT);

        expect(dialog.open).toHaveBeenCalledWith(ConfirmDialogComponent, {
          data: expectedDialogModel
        });

        expect(router.navigate).toHaveBeenCalledWith([
          'maintenance/contracts',
          component.insurerId,
          component.contract.contractId,
          'edit'
        ]);
      });

      it('should do nothing if action is not defined', () => {
        mockDialogSave(undefined);

        component.action(null);

        expect(router.navigate).not.toHaveBeenCalled();
      });
    });

    describe('DEACTIVATE', () => {
      let action: ACTION;
      beforeEach(function() {
        action = ACTION.DEACTIVATE;
      });

      it('should deactivate the asset when dialog is confirmed', () => {
        mockDialogSave('confirm');

        component.contract = new Contract(mockContractsData[1]);

        component.action(action);

        expect(maintenanceService.updateActiveStatus).toHaveBeenCalled();

        expect(maintenanceService.resetContractIds).toHaveBeenCalledWith(component.insurerId);
        expect(router.navigate).toHaveBeenCalledWith([
          'maintenance/contracts',
          component.insurerId
        ]);
      });

      it('should do nothing when dialog is not confirmed', () => {
        mockDialogSave(undefined);

        component.action(action);

        expect(maintenanceService.getContractDetails).not.toHaveBeenCalled();
      });
    });

    describe('REACTIVATE', () => {
      let action: ACTION;
      beforeEach(function() {
        action = ACTION.REACTIVATE;
      });

      it('should reactivate the asset when dialog is confirmed', () => {
        mockDialogSave('confirm');

        component.action(action);

        expect(dialog.open).toHaveBeenCalledWith(ConfirmDialogComponent, {
          data: activeStatusConfirmDialogData[action]
        });
      });
    });
  });
});
