import { ContractId } from '@contracts/models/contract.model';

export const mockContractIdList: ContractId[] = [
  {
      'contract': 'PRU62369',
      'isActive': true
  },
  {
      'contract': 'PRU62388',
      'isActive': true
  },
  {
      'contract': 'PRU63107',
      'isActive': false
  },
  {
      'contract': 'PRU63826',
      'isActive': false
  }
];
