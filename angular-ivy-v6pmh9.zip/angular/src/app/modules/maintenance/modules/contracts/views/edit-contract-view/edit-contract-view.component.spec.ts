import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import {
  MatButtonModule,
  MatCheckboxModule,
  MatDatepickerModule,
  MatInputModule,
  MatSelectModule,
  MatToolbarModule
} from '@angular/material';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ActivatedRoute, Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { MaintenanceService, MockMaintenanceService } from '@app/modules/maintenance/services';
import { PercentLabelModule } from '@app/shared/components';
import { VuiSelectModule } from 'vg-vui-ng/select';

import { mockInsurerList } from '../../../insurers/models';
import { ContractForm, mockContractsData } from '../../models';
import { EditContractViewComponent } from './edit-contract-view.component';
import { HomeService, MockHomeService } from '@app/modules/home/services';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { AssetSelectModule, OutsideFundSelectModule } from '../../components';
import { of } from 'rxjs';
import { DateTimeUtils } from '@app/shared';

class MockActivatedRoute {
  snapshot = {
    params: {
      insurerId: undefined,
      contractId: undefined
    }
  };
}

describe('EditContractViewComponent', () => {
  let component: EditContractViewComponent;
  let fixture: ComponentFixture<EditContractViewComponent>;
  let activatedRoute: MockActivatedRoute;
  let router: Router;
  let maintenanceService: MockMaintenanceService;
  let homeService: MockHomeService;

  beforeEach(async(() => {
    activatedRoute = new MockActivatedRoute();

    TestBed.configureTestingModule({
      declarations: [EditContractViewComponent],
      imports: [
        RouterTestingModule,
        NoopAnimationsModule,
        ReactiveFormsModule,
        MatToolbarModule,
        MatButtonModule,
        MatCheckboxModule,
        VuiSelectModule,
        MatSelectModule,
        MatInputModule,
        MatDatepickerModule,
        MatMomentDateModule,
        PercentLabelModule,
        FontAwesomeModule,
        AssetSelectModule,
        OutsideFundSelectModule
      ],
      providers: [
        { provide: MaintenanceService, useValue: new MockMaintenanceService() },
        { provide: HomeService, useValue: new MockHomeService() },
        { provide: ActivatedRoute, useValue: activatedRoute }
      ]
    }).compileComponents();

    router = TestBed.get(Router);
    maintenanceService = TestBed.get(MaintenanceService);
    homeService = TestBed.get(HomeService);
  }));

  function createComponent() {
    fixture = TestBed.createComponent(EditContractViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  function setIdRoute(insurerId = '2', contractId = 'AG1978424') {
    activatedRoute.snapshot.params.insurerId = insurerId;
    activatedRoute.snapshot.params.contractId = contractId;
  }

  it('should create', () => {
    createComponent();
    expect(component).toBeTruthy();
  });

  describe('ngOnInit:', () => {
    it('should not call loadContractDetails if no route param exists', () => {
      createComponent();

      component.ngOnInit();

      expect(maintenanceService.getContractDetails).not.toHaveBeenCalled();
    });

    describe('Route Params', () => {
      let insurerId: string;
      let contractId: string;
      beforeEach(function() {
        insurerId = '5';
        contractId = 'PRU542095723';
        setIdRoute(insurerId, contractId);
        createComponent();
      });

      it('should call loadContractDetails if a runId exists in the route params', () => {
        component.ngOnInit();

        expect(maintenanceService.getContractDetails).toHaveBeenCalledWith(contractId);
        expect(component.contractForm.isNew).toEqual(false);
      });

      it('should call maintenance service to load insurers if they are not loaded', () => {
        maintenanceService.insurers$ = of([]);

        component.ngOnInit();

        expect(maintenanceService.getInsurers).toHaveBeenCalled();
      });
    });
  });

  describe('viewTitle:', () => {
    it('should display "Create New Contract" for a new contract', () => {
      createComponent();

      expect(component.viewTitle).toEqual('Create New Contract');
    });

    it('should display "Edit Contract" for an existing contract', () => {
      createComponent();
      component.contractForm = new ContractForm(mockContractsData[0]);

      expect(component.viewTitle).toEqual('Edit Contract');
    });
  });

  describe('insurerTitle:', () => {
    it('should display insurer code and name for the given insurer', () => {
      createComponent();
      component.insurer = mockInsurerList[0];

      expect(component.insurerTitle).toEqual(
        `${component.insurer.insurerCode} - ${component.insurer.insurerName}`
      );
    });
  });

  describe('saveContract:', () => {
    beforeEach(function() {
      createComponent();
      spyOn(component, 'navigateToContracts');
    });

    it('should call maintenance service to save the contract', () => {
      component.contractForm = new ContractForm(mockContractsData[0]);

      component.saveContract();

      expect(maintenanceService.saveContract).toHaveBeenCalledWith(component.contractForm);
      expect(component.navigateToContracts).toHaveBeenCalled();
      expect(homeService.recalculateRateResetsForContract).toHaveBeenCalledWith(
        component.contractForm.contractId.value
      );
    });

    it('should format the reset start date if it is set', () => {
      component.contractForm = new ContractForm(mockContractsData[1]);
      const setValueSpy = spyOn(component.contractForm.resetStartDate, 'setValue');

      component.saveContract();

      expect(setValueSpy).toHaveBeenCalledWith(
        DateTimeUtils.toISOString(component.contractForm.resetStartDate.value)
      );
    });

    it('should not recalculate rate resets if the contract is new', () => {
      component.saveContract();

      expect(homeService.recalculateRateResetsForContract).not.toHaveBeenCalled();
    });
  });

  describe('navigateToContracts:', () => {
    it('should navigate to contracts page if no route params exist', () => {
      createComponent();
      spyOn(router, 'navigate');

      component.navigateToContracts();

      expect(router.navigate).toHaveBeenCalledWith(['maintenance/contracts']);
    });
    it('should navigate to insurer contract select page if only insurer route param exists', () => {
      const insurerId = '5';
      setIdRoute(insurerId, null);
      createComponent();
      spyOn(router, 'navigate');

      component.navigateToContracts(null);

      expect(router.navigate).toHaveBeenCalledWith(['maintenance/contracts', component.insurerId]);
    });
    it('should navigate to contract details page if route params exist', () => {
      const insurerId = '5';
      const contractId = 'PRU542095723';
      setIdRoute(insurerId, contractId);
      createComponent();
      spyOn(router, 'navigate');

      component.navigateToContracts();

      expect(router.navigate).toHaveBeenCalledWith([
        'maintenance/contracts',
        +insurerId,
        contractId
      ]);
    });
  });
});
