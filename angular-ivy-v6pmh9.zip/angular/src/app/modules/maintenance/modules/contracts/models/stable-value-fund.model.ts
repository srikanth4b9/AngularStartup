import { ColumnDefBuilder, ColumnType, TableDef } from '@app/shared';

export class StableValueFund {
  portId: string;
  fundName: string;
}

export class StableValueFundTableDef extends TableDef {
  constructor() {
    super([
      new ColumnDefBuilder('Port ID', 'portId', ColumnType.STRING).build(),
      new ColumnDefBuilder('Fund Name', 'fundName', ColumnType.STRING).build()
    ]);
  }
}
