import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ContractsRoutingModule } from './contracts-routing.module';
import { ContractsViewModule } from './views/contracts-view/contracts-view.module';
import { EditContractViewModule } from './views/edit-contract-view/edit-contract-view.module';

@NgModule({
  imports: [
    CommonModule,
    ContractsRoutingModule,
    ContractsViewModule,
    EditContractViewModule
  ],
  providers: []
})
export class ContractsModule { }
