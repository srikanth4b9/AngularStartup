import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { MatSelectChange } from '@angular/material';
import { MaintenanceService } from '@app/modules/maintenance/services';
import { map } from 'rxjs/operators';

import { UnderlyingAsset } from '../../../underlying-assets/models';

@Component({
  selector: 'rxu-asset-select',
  templateUrl: './asset-select.component.html',
  styleUrls: ['./asset-select.component.scss']
})
export class AssetSelectComponent implements OnInit {
  @Output() selectedAsset: EventEmitter<UnderlyingAsset> = new EventEmitter();

  assets: UnderlyingAsset[] = [];

  constructor(private readonly maintenanceService: MaintenanceService) {}

  ngOnInit() {
    this.loadAssets();
  }

  loadAssets() {
    this.maintenanceService.underlyingAssets$
      .pipe(map(assets => assets.filter(asset => asset.isActive)))
      .subscribe(assets => {
        this.assets = assets;
        // this.assets.sort((a, b) => (a.assetId > b.assetId ? 1 : -1));
      });
    this.maintenanceService.getUnderlyingAssets();
  }

  selectionChange(selectChange: MatSelectChange | { source: any; value: UnderlyingAsset }) {
    if (selectChange.value) {
      this.selectedAsset.emit(selectChange.value);
      selectChange.source.writeValue(null);
    }
  }
}
