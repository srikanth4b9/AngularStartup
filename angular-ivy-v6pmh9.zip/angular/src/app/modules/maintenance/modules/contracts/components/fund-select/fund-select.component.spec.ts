import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FundSelectComponent } from './fund-select.component';
import { MaintenanceService, MockMaintenanceService } from '@app/modules/maintenance/services';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule, MatSelectModule } from '@angular/material';
import { mockStableValueFunds } from '../../models/mock-json/stable-value-funds';

describe('FundSelectComponent', () => {
  let component: FundSelectComponent;
  let fixture: ComponentFixture<FundSelectComponent>;
  let maintenanceService: MaintenanceService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [FundSelectComponent],
      imports: [NoopAnimationsModule, ReactiveFormsModule, MatFormFieldModule, MatSelectModule],
      providers: [{ provide: MaintenanceService, useValue: new MockMaintenanceService() }]
    }).compileComponents();

    maintenanceService = TestBed.get(MaintenanceService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FundSelectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('ngOnInit:', () => {
    it('should call loadFunds to load data', () => {
      const loadFundsSpy = spyOn(component, 'loadFunds');

      component.ngOnInit();

      expect(loadFundsSpy).toHaveBeenCalled();
    });
  });

  describe('loadFunds:', () => {
    it('should call the service to get list of funds', () => {
      component.loadFunds();

      expect(maintenanceService.getFunds).toHaveBeenCalled();
      expect(component.funds).toEqual(mockStableValueFunds);
    });
  });
});
