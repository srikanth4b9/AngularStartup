import { mockStableValueFunds } from './mock-json/stable-value-funds';
import { StableValueFundForm } from './stable-value-fund-form.model';

describe('StableValueFundForm', () => {
  let fundForm: StableValueFundForm;

  describe('constructor', () => {
    beforeEach(function() {
      fundForm = new StableValueFundForm();
    });

    it('should initialize form with new fund', () => {
      expect(fundForm).toBeDefined();
    });

    it('should define abstract CustomForm getters', () => {
      expect(fundForm.objectName).toEqual('Stable Value Fund');
      expect(fundForm.uri).not.toBeDefined();
      expect(fundForm.idAttribute).toEqual('portId');
    });
  });

  describe('Control Getters', () => {
    beforeEach(function() {
      fundForm = new StableValueFundForm(mockStableValueFunds[0]);
    });

    formControlGetterTest('portId');
    formControlGetterTest('fundName');
  });

  function formControlGetterTest(controlName: string) {
    it(`should create a control getter for ${controlName}`, async () => {
      expect(fundForm[controlName].value).toEqual(mockStableValueFunds[0][controlName]);
    });
  }
});
