import { ContractIdSelectModule } from './contract-id-select.module';

describe('ContractIdSelectModule', () => {
    let contractIdSelectModule: ContractIdSelectModule;

    beforeEach(() => {
        contractIdSelectModule = new ContractIdSelectModule();
    });

    it('should create an instance', () => {
        expect(contractIdSelectModule).toBeTruthy();
    });
});
