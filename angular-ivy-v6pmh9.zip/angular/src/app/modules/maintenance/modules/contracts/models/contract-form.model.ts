import { AbstractControl, FormArray, FormControl, ValidatorFn, Validators } from '@angular/forms';
import { CustomForm } from '@app/shared';
import { environment } from '@env';
import { UnderlyingAsset, UnderlyingAssetForm } from '@underlying-assets/models';
import { BehaviorSubject, Observable } from 'rxjs';

import { Contract, RateSentType } from './contract.model';
import { StableValueFundForm } from './stable-value-fund-form.model';
import { StableValueFund } from './stable-value-fund.model';

const MAX_CONTRACT_ID = 20;

export class ContractForm extends CustomForm<Contract> {
  private readonly allowedRateSentByWorkflow: {
    [key: string]: RateSentType[];
  } = {
    CONFIRM_RATES: ['VANGUARD', 'INSURER'],
    PROVIDE_RATES: ['VANGUARD'],
    ENTER_RATES: ['VANGUARD']
  };
  private readonly rateSentOptions: BehaviorSubject<RateSentType[]>;
  rateSentOptions$: Observable<RateSentType[]>;
  readonly ENTER_RATES_ASSET_WARNING =
    'Underlying assets are not required for "Enter Rates" workflow type';

  /* istanbul ignore next */
  constructor(contract: Contract = new Contract()) {
    super({
      contractId: new FormControl(contract.contractId, [
        Validators.required,
        Validators.maxLength(MAX_CONTRACT_ID)
      ]),
      insurerId: new FormControl(contract.insurerId, Validators.required),
      insurerName: new FormControl(contract.insurerName, Validators.required),
      accountingServiceProvider: new FormControl(
        contract.accountingServiceProvider,
        Validators.required
      ),
      isActive: new FormControl(contract.isActive),
      isIncludeExpenseRatio: new FormControl(contract.isIncludeExpenseRatio),
      isIncludeWrapFee: new FormControl(contract.isIncludeWrapFee),
      wrapFee: new FormControl(contract.wrapFee, [Validators.min(0), Validators.max(1)]),
      workflowTypeCode: new FormControl(contract.workflowTypeCode, Validators.required),
      rateSentTypeCode: new FormControl(contract.rateSentTypeCode, Validators.required),
      underLyingAssets: new FormArray([
        ...contract.underLyingAssets.map(asset => new UnderlyingAssetForm(asset))
      ])
    });
    this.object = contract;

    if (contract.contractId) {
      this.isNew = false;
      this.contractId.disable();
    }

    this.accountingServiceProvider.valueChanges.subscribe(() => {
      this.setAccountingServiceProviderControls([]);
    });
    this.setAccountingServiceProviderControls([
      new StableValueFundForm(this.object.stableValueFunds[0])
    ]);

    this.rateSentOptions = new BehaviorSubject(
      this.allowedRateSentByWorkflow[contract.workflowTypeCode]
    );
    this.rateSentOptions$ = this.rateSentOptions.asObservable();

    this.workflowTypeCode.valueChanges.subscribe(workflowType => {
      this.rateSentTypeCode.setValue('VANGUARD');
      this.rateSentOptions.next(this.allowedRateSentByWorkflow[workflowType]);
      this.setAssetMinimumValidator();
    });

    this.setAssetMinimumValidator();
  }

  get objectName() {
    return 'Contract';
  }
  get uri() {
    return environment.CONTRACTS_URI;
  }
  get idAttribute() {
    return 'contractId';
  }

  get insurerId(): AbstractControl {
    return this.get('insurerId');
  }
  get insurerName(): AbstractControl {
    return this.get('insurerName');
  }
  get contractId(): AbstractControl {
    return this.get('contractId');
  }
  get accountingServiceProvider(): AbstractControl {
    return this.get('accountingServiceProvider');
  }
  get resetFrequencyTypeCode(): AbstractControl {
    return this.get('resetFrequencyTypeCode');
  }
  get resetStartDate(): AbstractControl {
    return this.get('resetStartDate');
  }
  get isIncludeExpenseRatio(): AbstractControl {
    return this.get('isIncludeExpenseRatio');
  }
  get isIncludeWrapFee(): AbstractControl {
    return this.get('isIncludeWrapFee');
  }
  get wrapFee(): AbstractControl {
    return this.get('wrapFee');
  }
  get workflowTypeCode(): AbstractControl {
    return this.get('workflowTypeCode');
  }
  get rateSentTypeCode(): AbstractControl {
    return this.get('rateSentTypeCode');
  }
  get stableValueFunds(): FormArray {
    return this.get('stableValueFunds') as FormArray;
  }
  get stableValueFund(): StableValueFundForm {
    return this.stableValueFunds.controls[0] as StableValueFundForm;
  }
  get underLyingAssets(): FormArray {
    return this.get('underLyingAssets') as FormArray;
  }
  get underLyingAssetForms(): UnderlyingAssetForm[] {
    return (this.get('underLyingAssets') as FormArray).controls as UnderlyingAssetForm[];
  }

  get isOtherServiceProvider(): boolean {
    return this.accountingServiceProvider.value === 'OTHER';
  }

  private setAccountingServiceProviderControls(stableValueFundForms: AbstractControl[]) {
    if (this.isOtherServiceProvider) {
      this.addControl(
        'resetFrequencyTypeCode',
        new FormControl(this.object.resetFrequencyTypeCode, Validators.required)
      );
      this.addControl(
        'resetStartDate',
        new FormControl(this.object.resetStartDate, Validators.required)
      );
      this.addControl('stableValueFunds', new FormArray(stableValueFundForms));
      this.setOutsideFundMinimumValidator();
    } else {
      this.removeControl('resetFrequencyTypeCode');
      this.removeControl('resetStartDate');
      this.removeControl('stableValueFunds');
    }
  }

  private setAssetMinimumValidator() {
    this.underLyingAssets.setValidators(
      this.workflowTypeCode.value === 'ENTER_RATES'
        ? null
        : this._validateMinimum('underlying asset')
    );
    this.underLyingAssets.updateValueAndValidity();
  }

  private setOutsideFundMinimumValidator() {
    this.stableValueFunds.setValidators(this._validateMinimum('stable value fund'));
    this.stableValueFunds.updateValueAndValidity();
  }

  private _validateMinimum(attribute: string): ValidatorFn {
    const validator: ValidatorFn = (formArray: FormArray) => {
      return formArray.controls.length >= 1 ? null : { emptyArray: attribute };
    };
    return validator;
  }

  shouldDisplayEnterRatesAssetWarning(): boolean {
    return this.workflowTypeCode.value === 'ENTER_RATES' && this.underLyingAssetForms.length > 0;
  }

  addAsset(asset: UnderlyingAsset) {
    if (this.isUniqueAsset(asset.assetId)) {
      this.underLyingAssets.push(new UnderlyingAssetForm(asset));
      this.underLyingAssets.markAsDirty();
    }
  }

  private isUniqueAsset(assetId): boolean {
    return !this.underLyingAssetForms.some(assetForm => assetForm.assetId.value === assetId);
  }

  addOutsideFund(fund: StableValueFund) {
    if (this.isNewOutsideFund(fund.portId)) {
      this.removeOutsideFund();
      this.stableValueFunds.push(new StableValueFundForm(fund));
    }
  }

  private isNewOutsideFund(portId): boolean {
    return this.stableValueFund ? this.stableValueFund.portId.value !== portId : true;
  }

  removeAsset(index: number) {
    this.underLyingAssets.removeAt(index);
    this.underLyingAssets.markAsDirty();
  }

  removeAllAssets() {
    this.underLyingAssets.clear();
    this.underLyingAssets.markAsDirty();
  }

  removeOutsideFund() {
    this.stableValueFunds.clear();
    this.stableValueFunds.markAsDirty();
  }
}
