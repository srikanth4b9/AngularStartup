import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatButtonModule, MatSnackBarModule, MatToolbarModule } from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import {
  ContractDetailsModule,
  ContractIdSelectModule,
  InsurerSelectModule
} from '@contracts/components';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { MaintenanceService, MockMaintenanceService } from '@maintenance/services';

import { ContractsViewComponent } from './contracts-view.component';
import { mockContractsData, Contract } from '../../models';

describe('ContractsViewComponent', () => {
  let component: ContractsViewComponent;
  let fixture: ComponentFixture<ContractsViewComponent>;
  let maintenanceService: MaintenanceService;
  let router: Router;
  let navigateSpy: jasmine.Spy;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule,
        HttpClientTestingModule,
        RouterTestingModule,
        MatButtonModule,
        MatToolbarModule,
        FontAwesomeModule,
        InsurerSelectModule,
        ContractIdSelectModule,
        ContractDetailsModule,
        MatSnackBarModule
      ],
      declarations: [ContractsViewComponent],
      providers: [{ provide: MaintenanceService, useClass: MockMaintenanceService }]
    }).compileComponents();

    router = TestBed.get(Router);
    maintenanceService = TestBed.get(MaintenanceService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContractsViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    navigateSpy = spyOn(router, 'navigate');
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('value changes:', () => {
    const insurerId = 1234;
    const contractId = 'AG28952';

    describe('insurerId value change', () => {
      it('should route to contract select if defined', async () => {
        component.contractSearchForm.patchValue({
          insurerId: insurerId
        });

        expect(navigateSpy).toHaveBeenCalledWith(['maintenance/contracts', insurerId]);
      });

      it('should disable contract ID control when Insurer ID is undefined', async () => {
        component.contractSearchForm.patchValue({
          insurerId: null
        });

        expect(navigateSpy).not.toHaveBeenCalled();
      });
    });

    describe('contract ID value change', () => {
      it('should route to contract select if defined', async () => {
        component.contractSearchForm.insurerId.setValue(insurerId);
        component.contractSearchForm.contractId.setValue(contractId);

        expect(navigateSpy).toHaveBeenCalledWith(['maintenance/contracts', insurerId, contractId]);
      });

      it('should disable contract ID control when Insurer ID is undefined', async () => {
        component.contractSearchForm.patchValue({
          contractId: null
        });

        expect(navigateSpy).not.toHaveBeenCalled();
      });
    });
  });

  describe('loadContract:', () => {
    it('should call the service to load contract details', () => {
      component.loadContract();

      expect(maintenanceService.getContractDetails).toHaveBeenCalled();
      expect(component.contract).toEqual(new Contract(mockContractsData[0]));
    });
  });

  describe('addNewContract', () => {
    it('should navigate to the create contract page', () => {
      component.addNewContract();

      expect(navigateSpy).toHaveBeenCalledWith([
        'maintenance/contracts',
        component.insurerId,
        'create'
      ]);
    });
  });
});
