import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ContractsViewComponent } from './views/contracts-view/contracts-view.component';
import { EditContractViewComponent } from './views/edit-contract-view/edit-contract-view.component';

const routes: Routes = [
  {
    path: ':insurerId',
    component: ContractsViewComponent
  },
  {
    path: ':insurerId/create',
    component: EditContractViewComponent
  },
  {
    path: ':insurerId/:contractId',
    component: ContractsViewComponent
  },
  {
    path: ':insurerId/:contractId/edit',
    component: EditContractViewComponent
  },
  {
    path: '',
    component: ContractsViewComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ContractsRoutingModule { }
