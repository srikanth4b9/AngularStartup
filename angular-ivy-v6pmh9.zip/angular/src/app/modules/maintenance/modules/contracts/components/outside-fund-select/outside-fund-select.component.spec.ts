import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OutsideFundSelectComponent } from './outside-fund-select.component';
import { MaintenanceService, MockMaintenanceService } from '@app/modules/maintenance/services';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule, MatSelectModule } from '@angular/material';
import { mockStableValueFunds } from '../../models/mock-json/stable-value-funds';

describe('OutsideFundSelectComponent', () => {
  let component: OutsideFundSelectComponent;
  let fixture: ComponentFixture<OutsideFundSelectComponent>;
  let maintenanceService: MaintenanceService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [OutsideFundSelectComponent],
      imports: [NoopAnimationsModule, ReactiveFormsModule, MatFormFieldModule, MatSelectModule],
      providers: [{ provide: MaintenanceService, useValue: new MockMaintenanceService() }]
    }).compileComponents();

    maintenanceService = TestBed.get(MaintenanceService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OutsideFundSelectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('ngOnInit:', () => {
    it('should call loadAssets to load data', () => {
      const loadOutsideFundsSpy = spyOn(component, 'loadOutsideFunds');

      component.ngOnInit();

      expect(loadOutsideFundsSpy).toHaveBeenCalled();
    });
  });

  describe('loadOutsideFunds:', () => {
    it('should call the service to get list of outside funds', () => {
      component.loadOutsideFunds();

      expect(maintenanceService.getOutsideFunds).toHaveBeenCalled();
      expect(component.outsideFunds).toEqual(mockStableValueFunds);
    });
  });

  describe('selectionChange', () => {
    let mockMatSelectChange;

    beforeEach(function() {
      mockMatSelectChange = {
        source: { writeValue: jasmine.createSpy() },
        value: mockStableValueFunds[0]
      };
      spyOn(component.selectedFund, 'emit');
    });

    it('should emit selection event when assset is selected', () => {
      component.selectionChange(mockMatSelectChange);

      expect(component.selectedFund.emit).toHaveBeenCalledWith(mockMatSelectChange.value);
      expect(mockMatSelectChange.source.writeValue).toHaveBeenCalledWith(null);
    });

    it('should do nothing if an asset is not selected', () => {
      mockMatSelectChange.value = null;

      component.selectionChange(mockMatSelectChange);

      expect(component.selectedFund.emit).not.toHaveBeenCalled();
    });
  });
});
