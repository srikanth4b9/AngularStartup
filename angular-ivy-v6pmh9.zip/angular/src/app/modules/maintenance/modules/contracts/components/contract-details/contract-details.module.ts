import { MdcCheckboxModule } from '@angular-mdc/web';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import {
  MatButtonModule,
  MatDialogModule,
  MatToolbarModule
} from '@angular/material';
import {
  ActionSelectModule,
  CustomMatTableModule
} from '@app/shared/components';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

import { ContractDetailsComponent } from './contract-details.component';

@NgModule({
  declarations: [ContractDetailsComponent],
  imports: [
    CommonModule,
    FormsModule,
    MatButtonModule,
    MdcCheckboxModule,
    MatToolbarModule,
    FontAwesomeModule,
    ActionSelectModule,
    CustomMatTableModule,
    MatDialogModule
  ],
  exports: [ContractDetailsComponent]
})
export class ContractDetailsModule {}
