import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule, MatSelectModule } from '@angular/material';
import { ActiveToggleModule } from '@app/shared/components';

import { ContractIdSelectComponent } from './contract-id-select.component';

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatSelectModule,
    ActiveToggleModule
  ],
  declarations: [ContractIdSelectComponent],
  exports: [ContractIdSelectComponent]
})
export class ContractIdSelectModule { }
