import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FundSelectComponent } from './fund-select.component';
import { ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule, MatSelectModule } from '@angular/material';

@NgModule({
  declarations: [FundSelectComponent],
  imports: [CommonModule, ReactiveFormsModule, MatFormFieldModule, MatSelectModule],
  exports: [FundSelectComponent]
})
export class FundSelectModule {}
