import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule, MatSelectModule } from '@angular/material';

import { AssetSelectComponent } from './asset-select.component';
import { MaintenanceService, MockMaintenanceService } from '@maintenance/services';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { mockUnderlyingAssets, UnderlyingAsset } from '../../../underlying-assets/models';

describe('AssetSelectComponent', () => {
  let component: AssetSelectComponent;
  let fixture: ComponentFixture<AssetSelectComponent>;
  let maintenanceService: MaintenanceService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AssetSelectComponent],
      imports: [
        NoopAnimationsModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatSelectModule
      ],
      providers: [
        { provide: MaintenanceService, useValue: new MockMaintenanceService() }
      ]
    })
      .compileComponents();

      maintenanceService = TestBed.get(MaintenanceService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssetSelectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('ngOnInit:', () => {
    it('should call loadAssets to load data', () => {
      const loadAssetsSpy = spyOn(component, 'loadAssets');

      component.ngOnInit();

      expect(loadAssetsSpy).toHaveBeenCalled();
    });
  });

  describe('loadAssets:', () => {
    it('should call the service to get list of assets', () => {
      const expectedAssets = mockUnderlyingAssets
        .filter(asset => asset.isActive)
        .map(asset => new UnderlyingAsset(asset));

      component.loadAssets();

      expect(maintenanceService.getUnderlyingAssets).toHaveBeenCalled();
      expect(component.assets).toEqual(expectedAssets);
    });
  });

  describe('selectionChange', () => {
    let mockMatSelectChange;

    beforeEach(function () {
      mockMatSelectChange = {
        source: { writeValue: jasmine.createSpy() },
        value: mockUnderlyingAssets[0]
      };
      spyOn(component.selectedAsset, 'emit');
    });

    it('should emit selection event when assset is selected', () => {
      component.selectionChange(mockMatSelectChange);

      expect(component.selectedAsset.emit).toHaveBeenCalledWith(mockMatSelectChange.value);
      expect(mockMatSelectChange.source.writeValue).toHaveBeenCalledWith(null);
    });

    it('should do nothing if an asset is not selected', () => {
      mockMatSelectChange.value = null;

      component.selectionChange(mockMatSelectChange);

      expect(component.selectedAsset.emit).not.toHaveBeenCalled();
    });
  });
});
