import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import {
  MatButtonModule,
  MatDatepickerModule,
  MatFormFieldModule,
  MatInputModule,
  MatToolbarModule
} from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { UpdateAction } from '@app/modules/home/models';
import { CustomMatTableModule } from '@app/shared/components';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { MaintenanceService, MockMaintenanceService } from '@maintenance/services';

import { AssetYieldDuration } from '../../models/yield-and-duration.model';
import { YieldAndDurationViewComponent } from './yield-and-duration-view.component';
import moment = require('moment');
import { DateTimeUtils } from '@app/shared';

describe('YieldAndDurationComponent', () => {
  let component: YieldAndDurationViewComponent;
  let fixture: ComponentFixture<YieldAndDurationViewComponent>;
  let maintenanceService: MockMaintenanceService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule,
        ReactiveFormsModule,
        MatButtonModule,
        MatToolbarModule,
        MatDatepickerModule,
        MatFormFieldModule,
        MatInputModule,
        FontAwesomeModule,
        CustomMatTableModule
      ],
      declarations: [YieldAndDurationViewComponent],
      providers: [{ provide: MaintenanceService, useValue: new MockMaintenanceService() }]
    }).compileComponents();

    maintenanceService = TestBed.get(MaintenanceService);
  }));

  function createComponent() {
    fixture = TestBed.createComponent(YieldAndDurationViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  beforeEach(function() {
    createComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('getYieldAndDuration', () => {
    it('should get the yield and duration ', () => {
      const asOfDate = moment();
      component.asOfDate.setValue(asOfDate);
      component.getYieldsDurations();

      expect(maintenanceService.getYieldsDurations).toHaveBeenCalledWith(
        DateTimeUtils.toFormattedDate(asOfDate)
      );
    });
  });

  describe('updateYieldAndDuration', () => {
    it('should call maintenance service to update yield & duration entry', () => {
      const request = {
        object: new AssetYieldDuration(),
        action: UpdateAction.YIELD
      };
      component.asOfDate.setValue(moment());

      component.updateYieldAndDuration(request);

      expect(maintenanceService.saveYieldDuration).toHaveBeenCalledWith(
        DateTimeUtils.toFormattedDate(component.asOfDate.value),
        request.object
      );
    });
  });
});
