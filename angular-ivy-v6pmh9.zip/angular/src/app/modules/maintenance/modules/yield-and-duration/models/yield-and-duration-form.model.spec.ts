import { mockYieldAndDuration } from './mock-json';
import { AssetYieldDurationForm } from './yield-and-duration-form.model';
import { environment } from '@env';

describe('AssetYieldDurationForm', () => {
  let fundForm: AssetYieldDurationForm;

  describe('constructor', () => {
    beforeEach(function() {
      fundForm = new AssetYieldDurationForm();
    });

    it('should initialize form with new fund', () => {
      expect(fundForm).toBeDefined();
    });

    it('should define abstract CustomForm getters', () => {
      expect(fundForm.objectName).toEqual('Yield & Duration');
      expect(fundForm.uri).toEqual(environment.YIELDS_DURATIONS_URI);
      expect(fundForm.idAttribute).toEqual('assetId');
    });
  });

  describe('Control Getters', () => {
    beforeEach(function() {
      fundForm = new AssetYieldDurationForm(mockYieldAndDuration[0]);
    });

    formControlGetterTest('assetId');
    formControlGetterTest('assetName');
    formControlGetterTest('isExternal');
    formControlGetterTest('yield');
    formControlGetterTest('yieldOverride');
    formControlGetterTest('duration');
    formControlGetterTest('durationOverride');
  });

  function formControlGetterTest(controlName: string) {
    it(`should create a control getter for ${controlName}`, async () => {
      expect(fundForm[controlName].value).toEqual(mockYieldAndDuration[0][controlName]);
    });
  }
});
