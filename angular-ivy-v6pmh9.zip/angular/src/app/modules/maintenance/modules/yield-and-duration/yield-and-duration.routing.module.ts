import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { YieldAndDurationViewComponent } from './views';

const routes: Routes = [
  {
    path: '',
    component: YieldAndDurationViewComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class YieldAndDurationRoutingModule {}
