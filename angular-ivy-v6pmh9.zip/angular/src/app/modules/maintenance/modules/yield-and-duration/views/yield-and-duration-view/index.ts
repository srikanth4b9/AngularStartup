export * from './yield-and-duration-view.component';
export * from './yield-and-duration-view.module';
