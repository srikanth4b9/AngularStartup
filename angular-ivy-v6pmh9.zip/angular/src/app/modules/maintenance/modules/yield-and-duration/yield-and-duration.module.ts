import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { YieldAndDurationRoutingModule } from './yield-and-duration.routing.module';
import { YieldAndDurationViewModule } from './views';

@NgModule({
  imports: [CommonModule, YieldAndDurationViewModule, YieldAndDurationRoutingModule]
})
export class YieldAndDurationModule {}
