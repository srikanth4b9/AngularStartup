export * from './yield-and-duration-view';
