import { ColumnDefBuilder, ColumnType, TableDef, InputDef } from '@app/shared';
import { UpdateAction } from '@app/modules/home/models';

export class AssetYieldDuration {
  assetId: string;
  assetName: string;
  isExternal: boolean;
  yield: number;
  yieldOverride?: boolean;
  duration: number;
  durationOverride?: boolean;
}

export class YieldAndDurationTableDef extends TableDef {
  constructor() {
    super([
      new ColumnDefBuilder('Asset Id', 'assetId', ColumnType.STRING).build(),
      new ColumnDefBuilder('Asset Name', 'assetName', ColumnType.STRING).build(),
      new ColumnDefBuilder('External Asset', 'isExternal', ColumnType.BOOLEAN).build(),
      new ColumnDefBuilder('Yield', 'yield', ColumnType.PERCENT)
        .editable(new InputDef(UpdateAction.YIELD, 'yieldOverride'))
        .build(),
      new ColumnDefBuilder('Duration', 'duration', ColumnType.NUMBER)
        .editable(new InputDef(UpdateAction.DURATION, 'durationOverride'))
        .build()
    ]);
  }
}
