import { YieldAndDurationTableDef } from './yield-and-duration.model';

describe('Yield And Duration', () => {
  let yieldAndDurationTableDef: YieldAndDurationTableDef;

  describe('constructor', () => {
    it('should set action options for an active asset', () => {
      yieldAndDurationTableDef = new YieldAndDurationTableDef();

      expect(yieldAndDurationTableDef).toBeTruthy();
    });
  });
});
