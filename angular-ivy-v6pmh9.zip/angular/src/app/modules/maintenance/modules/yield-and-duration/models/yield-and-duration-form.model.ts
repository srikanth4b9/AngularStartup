import { AbstractControl, FormControl, Validators } from '@angular/forms';
import { CustomForm } from '@app/shared';
import { environment } from '@env';

import { AssetYieldDuration } from './yield-and-duration.model';

export class AssetYieldDurationForm extends CustomForm<AssetYieldDuration> {
  /* istanbul ignore next */
  constructor(assetYield: AssetYieldDuration = new AssetYieldDuration()) {
    super({
      assetId: new FormControl(assetYield.assetId, Validators.required),
      assetName: new FormControl(assetYield.assetName),
      isExternal: new FormControl(assetYield.isExternal),
      yield: new FormControl(assetYield.yield, { updateOn: 'blur' }),
      yieldOverride: new FormControl(assetYield.yieldOverride),
      duration: new FormControl(assetYield.duration, { updateOn: 'blur' }),
      durationOverride: new FormControl(assetYield.durationOverride)
    });
    this.object = assetYield;
  }

  get objectName() {
    return 'Yield & Duration';
  }
  get uri() {
    return environment.YIELDS_DURATIONS_URI;
  }
  get idAttribute() {
    return 'assetId';
  }

  get assetId(): AbstractControl {
    return this.get('assetId');
  }
  get assetName(): AbstractControl {
    return this.get('assetName');
  }
  get isExternal(): AbstractControl {
    return this.get('isExternal');
  }
  get yield(): AbstractControl {
    return this.get('yield');
  }
  get yieldOverride(): AbstractControl {
    return this.get('yieldOverride');
  }
  get duration(): AbstractControl {
    return this.get('duration');
  }
  get durationOverride(): AbstractControl {
    return this.get('durationOverride');
  }
}
