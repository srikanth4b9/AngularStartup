import { Component } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup } from '@angular/forms';
import { AttributeUpdateRequest } from '@app/modules/home/models';
import { MaintenanceService } from '@app/modules/maintenance/services';
import { DateTimeUtils, TableDef } from '@app/shared';
import { faSearch, IconDefinition } from '@fortawesome/free-solid-svg-icons';

import { AssetYieldDurationForm } from '../../models/yield-and-duration-form.model';
import {
  AssetYieldDuration,
  YieldAndDurationTableDef
} from '../../models/yield-and-duration.model';

@Component({
  selector: 'rxu-yield-and-duration',
  templateUrl: './yield-and-duration-view.html',
  styleUrls: ['./yield-and-duration-view.scss']
})
export class YieldAndDurationViewComponent {
  tableDef: TableDef = new YieldAndDurationTableDef();
  tableData: AssetYieldDurationForm[] = [];
  asOfDateForm: FormGroup;
  maxDate = new Date();
  asOfDateString: string;

  faSearch: IconDefinition = faSearch;

  constructor(
    private readonly maintenanceService: MaintenanceService,
    private formBuilder: FormBuilder
  ) {
    this.asOfDateForm = this.createFormGroup();
    this.maintenanceService.yieldsDurations$.subscribe(assetYields => {
      this.tableData = assetYields.map(assetYield => new AssetYieldDurationForm(assetYield));
    });
  }

  private createFormGroup() {
    return this.formBuilder.group({
      date: ['']
    });
  }

  get asOfDate(): AbstractControl {
    return this.asOfDateForm.get('date');
  }

  updateYieldAndDuration(request: AttributeUpdateRequest<AssetYieldDuration>): void {
    this.maintenanceService.saveYieldDuration(
      DateTimeUtils.toFormattedDate(this.asOfDate.value),
      request.object
    );
  }

  getYieldsDurations(): any {
    const asOfDate = this.asOfDate.value;
    this.asOfDateString = DateTimeUtils.toFormattedDisplayDate(asOfDate);
    this.maintenanceService.getYieldsDurations(DateTimeUtils.toFormattedDate(asOfDate));
  }
}
