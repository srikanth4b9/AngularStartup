import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import {
  MatDatepickerModule,
  MatFormFieldModule,
  MatInputModule,
  MatToolbarModule,
  MatButtonModule
} from '@angular/material';
import { CustomMatTableModule } from '@app/shared/components';

import { YieldAndDurationViewComponent } from './yield-and-duration-view.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

@NgModule({
  declarations: [YieldAndDurationViewComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatToolbarModule,
    MatDatepickerModule,
    MatFormFieldModule,
    MatInputModule,
    FontAwesomeModule,
    CustomMatTableModule
  ],
  exports: [YieldAndDurationViewComponent]
})
export class YieldAndDurationViewModule {}
