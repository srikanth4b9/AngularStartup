import { AssetYieldDuration } from '../yield-and-duration.model';

export const mockYieldAndDuration: AssetYieldDuration[] = [
  {
    assetId: '0465',
    assetName: ' VFTC Short Term Bond Trust',
    isExternal: false,
    yield: 0.2,
    yieldOverride: false,
    duration: 2.33,
    durationOverride: false
  },
  {
    assetId: '0472',
    assetName: 'INSTL ShortTerm Bond Fund',
    isExternal: false,
    yield: 0.2,
    yieldOverride: true,
    duration: 5.43
  },
  {
    assetId: '0744',
    assetName: 'Metlife - Met 744',
    isExternal: true,
    yield: 0.4,
    duration: 2.34
  },
  {
    assetId: 'PIBF',
    assetName: 'Prudential - PIBF',
    isExternal: true,
    yield: 0.5,
    duration: 4.65,
    durationOverride: true
  }
];
