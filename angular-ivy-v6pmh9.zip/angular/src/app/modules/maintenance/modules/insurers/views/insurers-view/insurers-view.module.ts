import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MaintenanceTableViewModule } from '@app/modules/maintenance/components';

import { InsurersViewComponent } from './insurers-view.component';

@NgModule({
  declarations: [InsurersViewComponent],
  imports: [
    CommonModule,
    MaintenanceTableViewModule
  ],
  exports: [InsurersViewComponent]
})
export class InsurersViewModule { }
