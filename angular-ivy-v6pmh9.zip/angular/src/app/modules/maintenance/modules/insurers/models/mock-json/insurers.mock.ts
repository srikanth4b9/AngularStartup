import { Insurer } from '@insurers/models';

export const mockInsurerList: Insurer[] = [
  { 'insurerId': 1, 'insurerCode': 'PRU', 'insurerName': 'PRUDENTIAL', 'isActive': true },
  { 'insurerId': 2, 'insurerCode': 'MTL', 'insurerName': 'MET TOW LIFE', 'isActive': true },
  { 'insurerId': 3, 'insurerCode': 'JPM', 'insurerName': 'JP MORGAN', 'isActive': true },
  { 'insurerId': 4, 'insurerCode': 'AG', 'insurerName': 'AMERICAN GENERAL', 'isActive': true },
  { 'insurerId': 5, 'insurerCode': 'SSB', 'insurerName': 'STATE STREET BANK', 'isActive': false },
  { 'insurerId': 6, 'insurerCode': 'OSS', 'insurerName': 'Closed - OS Sunoco', 'isActive': false },
  { 'insurerId': 7, 'insurerCode': 'ML', 'insurerName': 'MET TOW LIFE', 'isActive': false },
  { 'insurerId': 8, 'insurerCode': 'INA', 'insurerName': 'Inactive Insurer', 'isActive': false }
];
