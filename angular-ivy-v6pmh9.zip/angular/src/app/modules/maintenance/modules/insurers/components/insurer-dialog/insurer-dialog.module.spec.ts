import { InsurerDialogModule } from './insurer-dialog.module';

describe('InsurerDialogModule', () => {
    let insurerDialogModule: InsurerDialogModule;

    beforeEach(() => {
        insurerDialogModule = new InsurerDialogModule();
    });

    it('should create an instance', () => {
        expect(insurerDialogModule).toBeTruthy();
    });
});
