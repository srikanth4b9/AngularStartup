import { InsurersModule } from './insurers.module';

describe('InsurersModule', () => {
    let insurersModule: InsurersModule;

    beforeEach(() => {
        insurersModule = new InsurersModule();
    });

    it('should create an instance', () => {
        expect(insurersModule).toBeTruthy();
    });
});
