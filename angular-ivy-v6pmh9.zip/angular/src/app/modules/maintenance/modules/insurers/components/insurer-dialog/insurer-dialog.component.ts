import { Component, Inject, Optional } from '@angular/core';
import { AbstractControl, ValidationErrors } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { MaintenanceService } from '@app/modules/maintenance/services';
import { FormUtils } from '@app/shared';
import { Observable, of } from 'rxjs';
import { map, tap } from 'rxjs/operators';

import { Insurer, insurerAttributeMap } from '../../models';
import { InsurerForm } from '../../models/forms';

@Component({
  selector: 'rxu-new-insurer',
  templateUrl: './insurer-dialog.component.html',
  styleUrls: ['./insurer-dialog.component.scss']
})
export class InsurerDialogComponent {
  insurerForm: InsurerForm;
  isActive: boolean = true;

  FormUtils = FormUtils;

  constructor(
    private readonly dialogRef: MatDialogRef<InsurerDialogComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) data,
    private readonly maintenanceService: MaintenanceService
  ) {
    this.insurerForm = new InsurerForm(data || undefined);
    this.insurerForm.insurerCode.setAsyncValidators([
      this.validateAttributeValueExists.bind(this, 'insurerCode')
    ]);
    this.insurerForm.insurerName.setAsyncValidators([
      this.validateAttributeValueExists.bind(this, 'insurerName')
    ]);
  }

  checkIfAttributeValueExists(
    attributeName: string,
    attributeValue: any
  ): Observable<boolean> {
    return this.maintenanceService.insurers$.pipe(
      map(insurers => {
        return this.isExisting(insurers, attributeName, attributeValue);
      })
    );
  }

  private isExisting(
    insurers: Insurer[],
    attributeName: string,
    attributeValue: any
  ): boolean {
    return (
      insurers.filter(insurer => insurer[attributeName] === attributeValue)
        .length > 0
    );
  }

  validateAttributeValueExists(
    attributeName: string,
    control: AbstractControl
  ): Observable<ValidationErrors> {
    if (
      !control.pristine &&
      FormUtils.isFieldDirty(this.insurerForm, attributeName)
    ) {
      return this.checkIfAttributeValueExists(
        attributeName,
        control.value
      ).pipe(
        map((response: boolean) =>
          response ? { valueExists: insurerAttributeMap[attributeName] } : null
        ),
        tap(res => control.setErrors(res))
      );
    }
    return of(null);
  }

  close() {
    this.dialogRef.close();
  }

  createInsurer() {
    this.dialogRef.close(this.insurerForm);
  }
}
