import { InsurersRoutingModule } from './insurers-routing.module';

describe('InsurersRoutingModule', () => {
    let insurersRoutingModule: InsurersRoutingModule;

    beforeEach(() => {
        insurersRoutingModule = new InsurersRoutingModule();
    });

    it('should create an instance', () => {
        expect(insurersRoutingModule).toBeTruthy();
    });
});
