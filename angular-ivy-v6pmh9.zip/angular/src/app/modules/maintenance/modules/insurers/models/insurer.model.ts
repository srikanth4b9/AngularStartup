import { ColumnDef, ColumnDefBuilder, ColumnType, TableDef, ACTION } from '@app/shared';
import { Observable, BehaviorSubject } from 'rxjs';

export class Insurer {
  insurerId: number;
  insurerCode: string;
  insurerName: string;
  isActive: boolean = true;

  private readonly actionOptions?: BehaviorSubject<ACTION[]> = new BehaviorSubject([]);
  actionOptions$?: Observable<ACTION[]>;

  constructor(insurer?: Insurer) {
    Object.assign(this, insurer);

    this.actionOptions = new BehaviorSubject(
      this.isActive ? [ACTION.EDIT, ACTION.DEACTIVATE] : [ACTION.REACTIVATE]
    );
    this.actionOptions$ = this.actionOptions.asObservable();
  }

  setActions?(actions: ACTION[]): void {
    this.actionOptions.next(actions);
  }

  getRawValue?(): Insurer {
    return {
      insurerId: this.insurerId,
      insurerCode: this.insurerCode,
      insurerName: this.insurerName,
      isActive: this.isActive
    };
  }
}

export const insurerAttributeMap = {
  insurerCode: 'Insurer Code',
  insurerName: 'Insurer Name'
};

const insurerColumns: ColumnDef[] = [
  new ColumnDefBuilder('Insurer Code', 'insurerCode', ColumnType.STRING).build(),
  new ColumnDefBuilder('Insurer Name', 'insurerName', ColumnType.STRING).build(),
  new ColumnDefBuilder('View Contracts', 'insurerId', ColumnType.VIEW_CONTRACTS).build()
];
export const insurerTableDef: TableDef = new TableDef(insurerColumns, true);
