import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MAT_DIALOG_DATA,
  MatButtonModule,
  MatDialogModule,
  MatDialogRef,
  MatInputModule,
  MatOptionModule,
  MatSelectModule,
  MatSnackBarModule,
  MatToolbarModule
} from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { of } from 'rxjs';

import { mockInsurerList, insurerAttributeMap } from '../../models';
import { InsurerForm } from '../../models/forms';
import { InsurerDialogComponent } from './insurer-dialog.component';
import { FormUtils } from '@app/shared';
import {
  MockMaintenanceService,
  MaintenanceService
} from '@app/modules/maintenance/services';

describe('InsurerDialogComponent', () => {
  let component: InsurerDialogComponent;
  let fixture: ComponentFixture<InsurerDialogComponent>;

  const mockDialogRef = {
    close: jasmine.createSpy()
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule,
        FormsModule,
        ReactiveFormsModule,
        MatDialogModule,
        MatOptionModule,
        MatDialogModule,
        MatButtonModule,
        MatToolbarModule,
        MatSelectModule,
        MatInputModule,
        HttpClientTestingModule,
        MatSnackBarModule
      ],
      declarations: [InsurerDialogComponent],
      providers: [
        { provide: MaintenanceService, useValue: new MockMaintenanceService() },
        { provide: MatDialogRef, useValue: mockDialogRef },
        { provide: MAT_DIALOG_DATA, useValue: mockInsurerList[0] }
      ]
    });
  }));

  function createComponent() {
    TestBed.compileComponents();
    fixture = TestBed.createComponent(InsurerDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  it('should create', () => {
    createComponent();
    expect(component).toBeTruthy();
  });

  describe('constructor', () => {
    it('should load form with dialog data', () => {
      createComponent();
      component.insurerForm = new InsurerForm(mockInsurerList[0]);

      expect(component.insurerForm.insurerCode.value).toEqual(
        mockInsurerList[0].insurerCode
      );
    });
    it('should load form with undefined when there is no dialog data', () => {
      TestBed.overrideProvider(MAT_DIALOG_DATA, { useValue: undefined });

      createComponent();

      expect(component).toBeTruthy();
      expect(component.insurerForm.isNew).toEqual(true);
    });
  });

  describe('close', () => {
    it('should close the dialog', () => {
      createComponent();

      component.close();

      expect(mockDialogRef.close).toHaveBeenCalled();
    });

    it('should close the dialog with create insurer form ', () => {
      createComponent();
      component.insurerForm = new InsurerForm(mockInsurerList[0]);

      component.createInsurer();

      expect(mockDialogRef.close).toHaveBeenCalledWith(component.insurerForm);
    });
  });

  describe('checkIfAttributeValueExists:', () => {
    beforeEach(() => {
      createComponent();
    });

    it('should return true if attribute value already exists', () => {
      component
        .checkIfAttributeValueExists('insurerCode', 'PRU')
        .subscribe(response => expect(response).toBeTruthy());
    });

    it('should have been called with mock', () => {
      component
        .checkIfAttributeValueExists('insurerCode', 'ABC')
        .subscribe(response => expect(response).toBeFalsy());
    });
  });

  describe('validateAttributeValueExists', () => {
    const attributeName: string = 'insurerCode';
    let control: FormControl;

    beforeEach(() => {
      control = new FormControl('PRU');
      createComponent();
    });

    it('should return null', () => {
      control.markAsPristine();

      component
        .validateAttributeValueExists(attributeName, control)
        .subscribe(response => {
          expect(response).toBeNull();
        });
    });

    it('should validate attribute', () => {
      control.markAsDirty();

      spyOn(component, 'checkIfAttributeValueExists').and.returnValue(of(true));
      spyOn(FormUtils, 'isFieldDirty').and.returnValue(true);

      component
        .validateAttributeValueExists(attributeName, control)
        .subscribe(response => {
          expect(response).toEqual({
            valueExists: insurerAttributeMap[attributeName]
          });
          expect(component.checkIfAttributeValueExists).toHaveBeenCalledWith(
            attributeName,
            control.value
          );
        });
    });

    it('should return null', () => {
      control.markAsDirty();

      component.checkIfAttributeValueExists = jasmine
        .createSpy()
        .and.returnValue(of(false));
      component
        .validateAttributeValueExists(attributeName, control)
        .subscribe(response => {
          expect(response).toEqual(null);
        });
    });
  });
});
