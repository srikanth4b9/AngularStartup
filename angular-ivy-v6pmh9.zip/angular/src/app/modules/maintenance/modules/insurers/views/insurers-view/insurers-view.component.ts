import { Component } from '@angular/core';
import { MaintenanceService } from '@app/modules/maintenance/services/maintenance.service';
import { TableDef } from '@app/shared';
import { environment } from '@env';
import { Insurer, insurerTableDef } from '@insurers/models';

import { InsurerDialogComponent } from '../../components/insurer-dialog';
import { InsurerForm } from '../../models/forms';

@Component({
  selector: 'rxu-insurers-view',
  templateUrl: './insurers-view.component.html',
  styleUrls: ['./insurers-view.component.scss']
})
export class InsurersViewComponent {
  tableDef: TableDef = insurerTableDef;
  tableData: Insurer[] = [];
  dialogType = InsurerDialogComponent;
  uri = environment.INSURERS_URI;

  constructor(
    private readonly maintenanceService: MaintenanceService) {
    this.maintenanceService.insurers$.subscribe(insurers => {
      this.tableData = insurers;
    });
  }

  loadInsurers(): void {
    this.maintenanceService.getInsurers();
  }

  saveInsurer(insurerForm: InsurerForm): void {
    this.maintenanceService.saveInsurer(insurerForm);
  }
}
