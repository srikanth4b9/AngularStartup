import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatButtonModule,
  MatDialogModule,
  MatInputModule,
  MatOptionModule,
  MatSelectModule,
  MatToolbarModule
} from '@angular/material';

import { InsurerDialogComponent } from './insurer-dialog.component';

@NgModule({
  declarations: [InsurerDialogComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatOptionModule,
    MatButtonModule,
    MatToolbarModule,
    MatSelectModule,
    MatInputModule,
    FormsModule
  ],
  exports: [InsurerDialogComponent]
})
export class InsurerDialogModule {}
