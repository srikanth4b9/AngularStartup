import { Insurer } from '../insurer.model';
import { mockInsurerList } from '../mock-json';
import { InsurerForm } from './insurer-form.model';

describe('insurer form model', () => {
    let insurerForm: InsurerForm;
    let insurer: Insurer;

    describe('constructor', () => {
        it('should create a blank insurer form ', () => {
            insurer = new Insurer(null);
            insurerForm = new InsurerForm(insurer);
            expect(insurerForm).toBeDefined();
        });
        it('should create a insurer form without an insurer', () => {
            insurerForm = new InsurerForm();
            expect(insurerForm).toBeDefined();
        });
    });

    describe('Name of the group', () => {
        beforeEach(() => {
            insurerForm = new InsurerForm(mockInsurerList[0]);
        });
        formControlGetterTest('insurerCode');
        formControlGetterTest('insurerName');
        formControlGetterTest('isActive');
    });

    function formControlGetterTest(controlName: string) {
        it(`should create a control getter for ${controlName}`, () => {
            expect(insurerForm[controlName]).toEqual(insurerForm.get(controlName));
        });
    }
});
