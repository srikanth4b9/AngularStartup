import { InsurersViewModule } from './insurers-view.module';

describe('InsurersViewModule', () => {
    let insurersViewModule: InsurersViewModule;

    beforeEach(() => {
        insurersViewModule = new InsurersViewModule();
    });

    it('should create an instance', () => {
        expect(insurersViewModule).toBeTruthy();
    });
});
