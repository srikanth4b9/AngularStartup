import { Insurer } from './insurer.model';
import { mockInsurerList } from './mock-json';
import { ACTION } from '@app/shared';


describe('Insurer', () => {
  it('should get Insurer', () => {
    const insurer = new Insurer(mockInsurerList[0]);

    expect(insurer.insurerCode).toBe('PRU');
    expect(insurer.insurerName).toBe('PRUDENTIAL');
    expect(insurer.isActive).toBe(true);
    expect(insurer.insurerId).toBe(1);
  });

  it('should get Insurer with active value of false', () => {
    const insurer = new Insurer(mockInsurerList[4]);

    expect(insurer.isActive).toBe(false);
  });

  it('should get Insurer with active value of null', () => {
    const insurer = new Insurer(null);

    expect(insurer.insurerCode).toBe(undefined);
    expect(insurer.insurerName).toBe(undefined);
    expect(insurer.isActive).toBe(true);
    expect(insurer.insurerId).toBe(undefined);

  });

  describe('setActions', () => {
    it('should set action options', async () => {
      const expectedActions = [ACTION.REACTIVATE];
      const insurer = new Insurer(null);

      insurer.setActions(expectedActions);

      insurer.actionOptions$.subscribe(actions => {
        expect(actions).toEqual(expectedActions);
      });
    });
  });

  describe('getRawValue', () => {
    it('should get raw insurer json object', () => {
      const insurer = new Insurer(mockInsurerList[0]);

      expect(insurer.getRawValue()).toEqual(mockInsurerList[0]);
    });
  });

});

