import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { InsurersViewComponent } from './views/insurers-view';

const routes: Routes = [
  {
    path: '',
    component: InsurersViewComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class InsurersRoutingModule { }
