import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { InsurersRoutingModule } from './insurers-routing.module';
import { InsurersViewModule } from './views';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    InsurersRoutingModule,
    InsurersViewModule
  ]
})
export class InsurersModule { }
