import { AbstractControl, FormControl, Validators } from '@angular/forms';
import { CustomForm } from '@app/shared';
import { environment } from '@env';

import { Insurer } from '../insurer.model';

const INSURER_CODE_MAXLENGTH = 20;
const INSURER_NAME_MAXLENGTH = 255;

export class InsurerForm extends CustomForm<Insurer> {
  /* istanbul ignore next */
  constructor(insurer: Insurer = new Insurer(undefined)) {
    super({
      insurerId: new FormControl(insurer.insurerId),
      insurerCode: new FormControl(insurer.insurerCode, [
        Validators.required,
        Validators.maxLength(INSURER_CODE_MAXLENGTH)
      ]),
      insurerName: new FormControl(insurer.insurerName, [
        Validators.required,
        Validators.maxLength(INSURER_NAME_MAXLENGTH)
      ]),
      isActive: new FormControl(insurer.isActive)
    });
    this.object = insurer;
    this.isNew = !insurer.insurerId;
  }

  get objectName() {
    return 'Insurer';
  }
  
  get uri() {
    return environment.INSURERS_URI;
  }

  get idAttribute() {
    return 'insurerId';
  }

  get insurerCode(): AbstractControl {
    return this.get('insurerCode');
  }
  get insurerName(): AbstractControl {
    return this.get('insurerName');
  }
  get isActive(): AbstractControl {
    return this.get('isActive');
  }
}
