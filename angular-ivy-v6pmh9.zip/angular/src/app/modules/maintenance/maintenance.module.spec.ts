import { Location } from '@angular/common';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { fakeAsync, TestBed, tick } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';

import { HomeService, MockHomeService } from '../home/services';
import { routes } from './maintenance-routing.module';
import { MaintenanceModule } from './maintenance.module';
import { MaintenanceService, MockMaintenanceService } from './services';
import { MaintenanceTabsComponent } from './views';
import { MatTabsModule } from '@angular/material';

describe('MaintenanceModule', () => {
  let maintenanceModule: MaintenanceModule;
  let location: Location;
  let router: Router;

  beforeEach(() => {
    maintenanceModule = new MaintenanceModule();
    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule,
        RouterTestingModule.withRoutes(routes),
        MatTabsModule
      ],
      declarations: [MaintenanceTabsComponent],
      providers: [
        Location,
        { provide: HomeService, useValue: new MockHomeService() },
        { provide: MaintenanceService, useValue: new MockMaintenanceService() }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();

    router = TestBed.get(Router);
    location = TestBed.get(Location);
    router.initialNavigation();
  });

  it('should create an instance', () => {
    expect(maintenanceModule).toBeTruthy();
  });

  it('should navigate to /insurers lazy loaded module', fakeAsync(() => {
    router.navigate(['insurers']);
    tick();

    expect(location.path()).toBe('/insurers');
  }));

  it('should navigate to /contracts lazy loaded module', fakeAsync(() => {
    router.navigate(['contracts']);
    tick();

    expect(location.path()).toBe('/contracts');
  }));

  it('should navigate to /underlying-assets lazy loaded module', fakeAsync(() => {
    router.navigate(['underlying-assets']);
    tick();

    expect(location.path()).toBe('/underlying-assets');
  }));

  it('should navigate to /yield-and-asset lazy loaded module', fakeAsync(() => {
    router.navigate(['yield-and-duration']);
    tick();

    expect(location.path()).toBe('/yield-and-duration');
  }));
});
