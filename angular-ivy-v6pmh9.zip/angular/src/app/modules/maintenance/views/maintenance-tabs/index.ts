export * from './maintenance-tabs.component';
export * from './maintenance-tabs.module';
