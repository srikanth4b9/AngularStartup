import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MaintenanceTabsComponent } from './maintenance-tabs.component';
import { MatTabsModule } from '@angular/material/tabs';

@NgModule({
  declarations: [MaintenanceTabsComponent],
  imports: [
    CommonModule,
    RouterModule,
    MatTabsModule
  ],
  exports: [MaintenanceTabsComponent]
})
export class MaintenanceTabsModule { }
