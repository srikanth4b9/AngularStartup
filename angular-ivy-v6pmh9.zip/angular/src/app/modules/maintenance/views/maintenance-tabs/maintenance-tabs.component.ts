import { Component } from '@angular/core';
import { NavLink } from '@app/shared/models';

@Component({
  selector: 'rxu-maintenance-tabs',
  templateUrl: './maintenance-tabs.component.html',
  styleUrls: ['./maintenance-tabs.component.scss']
})
export class MaintenanceTabsComponent {
  navLinks: NavLink[] = [
    { path: 'insurers', label: 'Insurers' },
    { path: 'contracts', label: 'Contracts' },
    { path: 'underlying-assets', label: 'Assets' },
    { path: 'yield-and-duration', label: 'Yield & Duration' }
  ];
}
