import { Location } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { fakeAsync, TestBed, tick } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';

import { AppRoutingModule, routes } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeService, MockHomeService } from './modules/home/services';
import { MaintenanceService, MockMaintenanceService } from './modules/maintenance/services';

describe('AppRoutingModule', () => {
  let appRoutingModule: AppRoutingModule;
  let location: Location;
  let router: Router;

  beforeEach(() => {
    appRoutingModule = new AppRoutingModule();
    TestBed.configureTestingModule({
      imports: [NoopAnimationsModule, RouterTestingModule.withRoutes(routes)],
      declarations: [AppComponent],
      providers: [
        Location,
        { provide: HomeService, useValue: new MockHomeService() },
        { provide: MaintenanceService, useValue: new MockMaintenanceService() }
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();

    router = TestBed.get(Router);
    location = TestBed.get(Location);
    router.initialNavigation();
  });

  it('should create an instance', () => {
    expect(appRoutingModule).toBeTruthy();
  });

  it('should navigate to /home lazy loaded module', fakeAsync(() => {
    router.navigate(['home']);
    tick();

    expect(location.path()).toBe('/home');
  }));

  it('should navigate to /reports lazy loaded module', fakeAsync(() => {
    router.navigate(['reports']);
    tick();

    expect(location.path()).toBe('/reports');
  }));

  it('should navigate to /maintenance lazy loaded module', fakeAsync(() => {
    router.navigate(['maintenance']);
    tick();

    expect(location.path()).toBe('/maintenance/insurers');
  }));
});
