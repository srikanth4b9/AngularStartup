import { common } from './environment.common';
import { internal } from './environment.internal';

export const production = require('../../package.json').deployment.properties[
  'production-us-east-1'
].env;

export const environment = {
  ...common,
  ...production,
  ...internal,
  RXS_REST_BASE: `https://apii.cf.opsp.c1.vanguard.com${common.SERVICE_RTE}${common.BASE_PATH}`
};
