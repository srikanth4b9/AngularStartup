/**
 * Common Environment Variables for all build states
 * Don't add API endpoints here, addd them to ./endpoints.ts
 */
import { version as packageVersion } from 'package.json';

export const common = {
  VERSION: packageVersion,
  NON_PRD_SERVICE_URL: 'https://satapii.cf.opst.c1.vanguard.com',
  SERVICE_RTE: '/rs/cf/rate-reset-webservice',
  BASE_PATH: '/rs/rxs',
  INSURERS_URI: '/insurers',
  CONTRACTS_URI: '/contracts',
  ASSETS_URI: '/assets',
  OUTSIDE_FUNDS_URI: '/outside-funds',
  FUNDS_URI: '/stable-value-funds',
  RATE_RESET_URI: '/crediting-rate-resets',
  YIELDS_DURATIONS_URI: '/yields-durations',
  REPORTS_URI: '/reports'
};
