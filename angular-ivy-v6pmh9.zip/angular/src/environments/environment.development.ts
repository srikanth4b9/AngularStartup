import { common } from './environment.common';
import { internal } from './environment.internal';
import { nonProduction } from './environment.non-production';

const T_NUMBER = 'tXXXXX'; // Replace with your T-Number locally, Do not commit
const LOCAL_PORT = '8080';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
const LOCAL_URL = `http://${T_NUMBER}.vanguard.com:${LOCAL_PORT}${common.BASE_PATH}`;

export const environment = {
  ...common,
  development: true,
  ...nonProduction,
  ...internal,
  RXS_REST_BASE: `${common.NON_PRD_SERVICE_URL}${common.SERVICE_RTE}${common.BASE_PATH}` // replace with LOCAL_URL to use local webservice
};
