export const internal = {
  SRV_TYP: 'internal',
  external: false,
  internal: true
};
