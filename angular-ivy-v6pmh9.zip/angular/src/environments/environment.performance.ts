import { common } from './environment.common';
import { internal } from './environment.internal';

export const performance = require('../../package.json').deployment.properties[
  'performance-us-east-1'
].env;

export const environment = {
  ...common,
  ...performance,
  ...internal,
  RXS_REST_BASE: `${common.NON_PRD_SERVICE_URL}${common.SERVICE_RTE}-prfp${common.BASE_PATH}`
};
