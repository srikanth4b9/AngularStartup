import { common } from './environment.common';
import { internal } from './environment.internal';

export const nonProduction = require('../../package.json').deployment
  .properties['test-us-east-1'].env;

export const environment = {
  ...common,
  ...nonProduction,
  ...internal,
  RXS_REST_BASE: `${common.NON_PRD_SERVICE_URL}${common.SERVICE_RTE}${common.BASE_PATH}`
};
