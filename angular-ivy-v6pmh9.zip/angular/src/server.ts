import { NestFactory } from '@nestjs/core';
import { NestExpressApplication } from '@nestjs/platform-express';
import { AddressInfo, Server } from 'net';
import * as helmet from 'helmet';
import * as vgBaseHref from 'vg-base-href';
import * as expressStaticGzip from 'express-static-gzip';
import * as compression from 'compression';
import { ServerModule } from './server.module';
import { join } from 'path';

const PKG = require('../package.json');
const PATH_STATIC_PKG_ROUTE = `/pkg/${PKG.version}/web`;
const PATH_ASSETS_ROUTE = '/';
const CSP_ALLOWED_URLS = ['*.vanguard.com:*', '*.vgcontent.info:*'];
const DOCUMENT_ROOT = join(__dirname, process.env.ANGULAR_ENV);
const FALLBACK_PORT = 8080;

export const server = bootstrap().catch(console.error);

async function bootstrap(): Promise<Server> {
  const app = await NestFactory.create<NestExpressApplication>(ServerModule, {
    logger: false
  });

  app.use(helmet());
  app.use(
    helmet.contentSecurityPolicy({
      directives: {
        defaultSrc: ["'self'", ...CSP_ALLOWED_URLS],
        scriptSrc: ["'self'", "'unsafe-eval'", ...CSP_ALLOWED_URLS],
        styleSrc: ["'self'", "'unsafe-inline'", ...CSP_ALLOWED_URLS],
        imgSrc: ["'self'", 'data:', ...CSP_ALLOWED_URLS],
        fontSrc: ["'self'", 'data:', ...CSP_ALLOWED_URLS]
      }
    })
  );
  app.use(helmet.permittedCrossDomainPolicies());
  app.use(helmet.referrerPolicy());
  app.use(vgBaseHref({ pkg: PKG, logger: console }));

  /*
    Middleware to provide static assets. This module dynamically returns the type of compressed files that your browser
     supports by the accept-encoding header. Brotli is currently not supported by Akamai, so if your application needs
     to run on-prem, set "enableBrotli" to false.

     If you are committed to updating your package.json version every release (which cache busts your static assets),
     set etag to false for best performance
   */

  app.use(
    PATH_STATIC_PKG_ROUTE,
    expressStaticGzip(DOCUMENT_ROOT, {
      enableBrotli: true,
      orderPreference: ['br'],
      index: false,
      serveStatic: {
        maxAge: '365d',
        etag: true
      }
    })
  );

  /*
  Provide an additional route to easily access assets relatively from Angular code
   */
  app.use(
    PATH_ASSETS_ROUTE,
    expressStaticGzip(DOCUMENT_ROOT, {
      enableBrotli: true,
      orderPreference: ['br'],
      index: false
    })
  );

  // For compression of any other routes if needed
  app.use(compression());
  await app.listen(process.env.PORT || FALLBACK_PORT);
  const httpServer = await app.getHttpServer();
  const serverAddressInfo = (await httpServer.address()) as AddressInfo;
  console.info(
    `${PKG.name}@${PKG.version} is listening on ${serverAddressInfo.address}:${serverAddressInfo.port}`
  );
  return httpServer;
}
